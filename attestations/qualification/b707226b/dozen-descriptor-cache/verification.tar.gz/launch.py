from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

root = Path.cwd()
stage = Path(__file__).resolve().parent
build = root / "bin/linux-ci"
app = build / "src/sirius/app"
icd = Path.home() / ".local/opt/mesa-dzn/dzn_icd.x86_64.json"
driver = icd.parent / "libvulkan_dzn.so"
case = "OperationalVulkan.RequiredRuntimeDispatch"
revision = (stage / "revision").read_text().strip()

def digest(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()

assert not subprocess.check_output(["git", "status", "--porcelain"])
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == revision
assert shutil.disk_usage("/").free >= 100_000_000_000
assert "wsl2" in os.uname().release.lower()
assert digest(icd) == "fde51461538211ae38c973644f99f6c6adb4e9d8fcfe16ed172533c9aa9ef392"
assert digest(driver) == "72de4021c66f994f59a733e643f775c3dd416b566c88b8aedec7efa38c26e071"
assert json.loads(icd.read_text())["ICD"]["library_path"] == str(driver)
for entry in Path("/proc").glob("[0-9]*"):
    try:
        executable = Path(os.readlink(entry / "exe"))
        command = (entry / "cmdline").read_bytes().split(b"\0")
    except (PermissionError, FileNotFoundError, ProcessLookupError):
        continue
    assert not (executable.name in {"sirius.exe", "sirius", "sirius_render_tests", "sirius_backend_tests"}
                or (executable.name == "ctest" and os.fsencode(build) in command)), executable

registered = subprocess.check_output([
    "ctest", "--test-dir", str(build), "-C", "Release", "-R",
    "^" + re.escape(case) + "$", "--show-only=json-v1"])
test, = json.loads(registered)["tests"]
assert test["name"] == case
properties = {item["name"]: item["value"] for item in test["properties"]}
assert properties["RUN_SERIAL"] and properties["TIMEOUT"] == 300.0 and "Mandatory" in properties["LABELS"]
assert test["command"][1:] == [f"-DSIRIUS_RENDER_TESTS={app/'sirius_render_tests'}",
                                "-P", str(root / "tests/operational/vulkan_runtime_profile.cmake")]
(stage / "registration.json").write_bytes(registered)
render_output = stage / "render-output"
render_output.mkdir()
env = {key: value for key, value in os.environ.items()
       if not (key.startswith(("SIRIUS_", "VK_", "LP_", "MESA_", "GALLIVM_", "GTEST_", "CTEST_"))
               or key in {"LD_PRELOAD", "LD_AUDIT", "LD_LIBRARY_PATH"})}
scope_env = {"SIRIUS_MEMORY_BUDGET_MB": "2048", "TMPDIR": str(render_output),
             "XDG_CACHE_HOME": str(stage / "cache")}
provider_env = {"VK_DRIVER_FILES": str(icd), "SIRIUS_VULKAN_DEVICE": "0",
                "MESA_SHADER_CACHE_DISABLE": "true"}
subprocess.run([sys.executable, "-B", str(root / "scripts/runtime_identity.py"),
                "--source-root", str(root), "--source-revision", revision,
                "--source-tree-clean", "true", "--executable", str(app / "sirius"),
                "--require-vulkan", "true", "--output", str(stage / "runtime-identity.json")],
               cwd=root, env={**env, **scope_env, **provider_env}, check=True)
identity = json.loads((stage / "runtime-identity.json").read_text())
device = identity["selected_device"]
assert "780M" in device["name"] and "dozen" in device["driver_name"].lower() and device["index"] == 0, device
assert device["render_memory_bytes"] >= 2048 * (1024 ** 2), device

dependencies = set()
for binary in (app / "sirius_render_tests", driver):
    for line in subprocess.check_output(["ldd", str(binary)], env=env, text=True).splitlines():
        match = re.search(r"(?:^\s*|=>\s+)(/\S+)", line)
        if match:
            dependencies.add(Path(match[1]).resolve())
wsl = Path("/usr/lib/wsl/lib")
files = [app / "sirius", app / "sirius_render_tests", driver, icd, stage / "registration.json",
         stage / "runtime-identity.json", Path(__file__), Path(test["command"][0]),
         *(wsl / name for name in ("libdxcore.so", "libd3d12.so", "libd3d12core.so")),
         *sorted(dependencies)]
files.extend(path for path in (app / "resources").rglob("*") if path.is_file())
action = {"scope": "Original cold 128x128 one-SPP Vulkan case on the Radeon 780M WSL2 Dozen route.",
          "revision": revision, "software_provider": True, "runtime_provider": str(driver),
          "runtime_icd": str(icd), "disable_software_shader_cache": True, "kind": "test",
          "limits": {"seconds": 300, "rss_kib": 2097152, "reserve_kib": 2097152},
          "expected_exit": 0, "argv": test["command"],
          "frozen_inputs": [str(path) for path in dict.fromkeys(files)],
          "build_environment": scope_env}
(stage / "actions.json").write_text(json.dumps({"dozen-cold": action}, indent=2) + "\n")
raise SystemExit(subprocess.run([sys.executable, "-B", str(stage / "run_owned.py"), "dozen-cold"],
                                cwd=root, env=env).returncode)

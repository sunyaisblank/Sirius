#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"
#include "sirius/render/session/kerr_point_detector.h"

#include <iomanip>
#include <iostream>

using namespace sirius;
using namespace sirius::render;

int CheckLedger() {
    const core::StarfieldSpatialIndex empty({});
    const std::array<PointDetectorFootprint, 1> footprints{};
    PointDetectorPolicy policy;
    policy.maximum_depth = 1;
    constexpr std::size_t consumed = 7;
    const PointDetectorSampler hidden = [](const DetectorCoordinate&) {
        return PointDetectorProbe{};
    };
    for (unsigned mode : {0, 1, 2, 3}) {
        unsigned calls = 0;
        bool coordinate_mismatch = false;
        const PointDetectorCellBound bound =
            [&](const auto& footprint, const auto& lower, const auto& upper, std::size_t& remaining)
                -> std::optional<std::array<double, 3>> {
            if (footprint.centre != footprints[0].centre || upper[0] - lower[0] != 4 ||
                remaining != policy.maximum_candidate_visits - consumed * calls)
                coordinate_mismatch = true;
            ++calls;
            remaining -= consumed;
            if (mode == 2) return {};
            const double error = policy.absolute_rgb_error * (mode == 1 ? .26 : .1);
            return std::array{error, error, error};
        };
        const auto value = EvaluatePointDetectorGroup(empty, 1, footprints, hidden,
            [&] { return mode == 3 && calls != 0; }, policy, {}, {}, bound);
        if (coordinate_mismatch) return 1;
        if (mode == 0) {
            if (!value || value->samples[0].rgb != std::array<double, 3>{} ||
                value->samples[0].estimated_error[0] < .4 * policy.absolute_rgb_error ||
                value->samples[0].estimated_error[0] > .401 * policy.absolute_rgb_error ||
                value->statistics.candidate_visits != consumed * calls || calls != 4) return 2;
        } else {
            const auto expected = mode == 3 ? PointDetectorFailure::Cancelled
                                            : PointDetectorFailure::Unresolved;
            if (value || value.error().reason != expected ||
                value.error().statistics.candidate_visits != consumed * calls ||
                calls != (mode == 1 ? 4u : 1u)) return 3;
        }
    }
    std::cout << "ledger=passed terminal_cells=4 cumulative_refusal=1 failed_visit_debit=1 cancellation=1\n";
    return 0;
}

int main() {
    if (const int r = CheckLedger()) return 10 + r;
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{896 + double(sample.image_u), 576 + double(sample.image_v)};
    const auto pupil = camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u,
                                                     sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const core::PointStarfieldConfig stars;
    const core::StarfieldSpatialIndex catalogue(core::StarfieldGenerator(
        core::ExpandPointStarfieldConfig(stars)).GenerateCatalogue());
    const auto indexed = PrepareKerrDetectorCatalogue(catalogue);
    const PointDetectorFootprint footprint{
        {0, 17}, {{{0, -0x1.d357ebd0e3748p-1}, {0x1.d30c6a29fa83fp-1, 0x1.e454f19fc15dep-9}}}};
    constexpr DetectorCoordinate lower{0x1.2b6p-1, 0x1.fa7cp+1};
    constexpr DetectorCoordinate upper{0x1.2b7p-1, 0x1.fa8p+1};
    const PointDetectorPolicy policy;
    auto remaining = policy.maximum_candidate_visits;
    const auto bound = BoundKerrDetectorCell(*indexed, stars.brightness_scale, config, *launch,
                                            origin, footprint, lower, upper, {}, remaining);
    std::cout << "device=" << info.name << " provider=" << info.driver_name
              << " visit_debit=" << policy.maximum_candidate_visits - remaining;
    if (!bound) {
        std::cout << " result=declined\n";
        return 27;
    }
    std::cout << std::setprecision(17) << " rgb_bound=" << (*bound)[0]
              << " absolute_policy=" << policy.absolute_rgb_error << '\n';
    return (*bound)[0] > 0 && (*bound)[0] < policy.absolute_rgb_error ? 0 : 28;
}

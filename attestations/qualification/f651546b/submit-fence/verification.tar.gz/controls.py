from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path.cwd()
work = Path(__file__).resolve().parent
build = root / "bin/linux-ci"
backend_test = build / "tests/backend/sirius_backend_tests"
render_test = build / "src/sirius/app/sirius_render_tests"
revision = (work / "revision").read_text().strip()
alignment = json.loads((build / "generated/sirius/alignment_receipt.json").read_text())
assert alignment["source_revision"] == revision and alignment["source_tree_clean"]
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == revision
assert not subprocess.check_output(["git", "status", "--porcelain"])
driver = backend_test.parent / "resources/providers/linux-x86_64/libvulkan_lvp.so"
pristine = root / "attestations/qualification/c096156f/accepted-packaged-software-inputs/libvulkan_lvp.so"
assert driver.samefile(pristine)
llvm = Path("/usr/lib/x86_64-linux-gnu/libLLVM.so.21.1")
icd = work / "controls-icd.json"
icd.write_text(json.dumps({"file_format_version": "1.0.0",
                           "ICD": {"library_path": str(driver), "api_version": "1.4.305"}}) + "\n")
cases = ["VulkanBackend.SubmissionErrorsDoNotImplyIdleCompletion",
         "VulkanBackend.IndependentPairCompletesDistinctKernelsAndRejectsSharedBuffers",
         "RetainedComputeTest.SharedEndpointDensePreservesPrivateIntervalsAndSerialRetry",
         "RetainedComputeTest.DeviceTimestampsPreserveOriginalIntervalResults"]
environment = {key: value for key, value in os.environ.items()
               if not (key.startswith(("SIRIUS_", "VK_", "LP_", "MESA_", "GALLIVM_", "GTEST_", "CTEST_"))
                       or key in {"LD_PRELOAD", "LD_AUDIT", "LD_LIBRARY_PATH"})}
settings = {"SIRIUS_PACKAGED_SOFTWARE_VULKAN": "1", "TMPDIR": str(work),
            "XDG_CACHE_HOME": str(work / "controls-cache")}
action = {"scope": "Finite retained DP/Endpoint pairing, original readbacks, refusal and timing on sealed native Vulkan.",
          "revision": revision, "software_provider": True, "runtime_provider": str(driver),
          "runtime_icd": str(icd), "disable_software_shader_cache": True, "kind": "test",
          "limits": {"seconds": 240, "rss_kib": 4194304, "reserve_kib": 2097152},
          "expected_exit": 0,
          "argv": [str(backend_test), "--gtest_filter=" + ":".join(cases), "--gtest_color=no"],
          "frozen_inputs": [str(item) for item in (backend_test, driver, llvm, icd, Path(__file__))],
          "build_environment": settings}
actions = work / "actions.json"
actions.write_text(json.dumps({"sealed-controls": action}, indent=2) + "\n")
subprocess.run([sys.executable, "-B", str(work / "run_owned.py"), "sealed-controls"],
               cwd=root, env=environment, check=True)
actions.rename(work / "controls-actions.json")
suite = ET.parse(work / "sealed-controls/gtest.xml").getroot()
assert suite.get("tests") == str(len(cases)) and suite.get("failures") == "0" and suite.get("errors") == "0"
assert all(testcase.get("result") == "completed" and testcase.find("skipped") is None
           for testcase in suite.findall(".//testcase"))
subprocess.run([sys.executable, "-B", "scripts/verify-attestation.py", "--self-test",
                "--render-test-executable", str(render_test)], cwd=root,
               env={**environment, "TMPDIR": str(work)}, check=True)

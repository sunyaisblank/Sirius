from datetime import UTC, datetime
import json
import os
from pathlib import Path
import sys
import time

def load():
    line = Path("/proc/stat").read_text().splitlines()[0]
    counters = [int(value) for value in line.split()[1:9]]
    tracked = {}
    for entry in Path("/proc").glob("[0-9]*"):
        try:
            data = (entry / "stat").read_text()
            left, right = data.index("("), data.rindex(")")
            name = data[left+1:right]
            if name not in {"aletheia_qualif", "VBCSCompiler"}:
                continue
            fields = data[right+2:].split()
            tracked[(entry.name, fields[19])] = (name, int(fields[11]) + int(fields[12]))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return counters, tracked

a, first = load()
start = time.monotonic()
time.sleep(.5)
b, second = load()
elapsed = time.monotonic() - start
total = sum(b) - sum(a)
idle = (b[3] + b[4]) - (a[3] + a[4])
competing = {}
for process, (name, ticks) in second.items():
    if process in first:
        competing[name] = competing.get(name, 0) + ticks - first[process][1]
observation = {"phase": sys.argv[1], "utc": datetime.now(UTC).isoformat(),
               "interval_seconds": elapsed, "busy_core_fraction": (total-idle)/total,
               "online_logical_cpus": os.cpu_count(), "ticks_per_second": os.sysconf("SC_CLK_TCK"),
               "selected_competing_process_cpu_ticks": competing}
with Path(__file__).with_name("host-load.jsonl").open("a") as stream:
    stream.write(json.dumps(observation) + "\n")
print(json.dumps(observation))

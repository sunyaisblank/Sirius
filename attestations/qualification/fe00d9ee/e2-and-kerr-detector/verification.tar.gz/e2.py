from concurrent.futures import ThreadPoolExecutor
import gzip
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
from xml.etree import ElementTree as ET

root = Path.cwd()
scratch = root / 'out/kerr-terminal-first'
build = root / 'bin/linux-ci'
authority = root / 'tests/operating_model.json'
operating_model = json.loads(authority.read_text())
rows = [row for key, values in operating_model.items() if isinstance(values, list)
        for row in values if isinstance(row, dict) and row.get('id') == 'E2']
assert len(rows) == 1
tests = [entry['name'] for entry in rows[0]['evidence'] if entry['kind'] == 'gtest']
assert len(tests) == len(set(tests)) == 11
compile_commands = json.loads((build/'compile_commands.json').read_text())
sources = ['polarisation_acceptance_test.cpp', 'walker_penrose_test.cpp',
           'polarisation_transport_test.cpp', 'config_validation_test.cpp']
commands = []
objects = []
for file in sources:
    original, = [row for row in compile_commands if row['file'].endswith('/'+file)]
    command = shlex.split(original['command'])
    assert command[-2] == '-c' and command[-4] == '-o'
    output = scratch/(file + '.o')
    objects.append(str(output))
    commands.append([*command[:-4], '-o', str(output), '-c', original['file']])

env = {**os.environ, 'TMPDIR': str(scratch)}
def run(command):
    return subprocess.run(command, cwd=build, env=env, check=True)

if '--compile' in sys.argv:
    with ThreadPoolExecutor(max_workers=2) as workers:
        list(workers.map(run, commands))
    sys.exit(0)

prior = json.loads(gzip.decompress((root/'attestations/qualification/7fd2aa59/kerr-finite-turn/early-build.json.gz').read_bytes()))
libraries = prior['link'][prior['link'].index('src/sirius/app/libsirius_app_lib.a'):]
link = ['/usr/bin/g++-14', *objects, *libraries, 'lib/libgtest_main.a', 'lib/libgtest.a',
        '-pthread', '-o', str(scratch/'e2-direct')]
run(link)

render_names = [test for test in tests if test.startswith(('RenderSessionProbe.', 'GeodesicTracerTest.'))]
direct_names = [test for test in tests if test not in render_names]
render, = [path.resolve() for path in build.rglob('sirius_render_tests') if path.is_file()]
result_names = []
for key, target, expected in [('direct', scratch/'e2-direct', direct_names),
                              ('render', render, render_names)]:
    report = scratch/f'e2-{key}.xml'
    with (scratch/f'e2-{key}.log').open('w') as output:
        subprocess.run(['/usr/bin/time','-v','timeout','600',str(target),
                        '--gtest_filter='+':'.join(expected), f'--gtest_output=xml:{report}'],
                        cwd=scratch, env=env, stdout=output, stderr=subprocess.STDOUT, check=True)
    cases = ET.parse(report).getroot().findall('.//testcase')
    names = [f'{case.attrib["classname"]}.{case.attrib["name"]}' for case in cases]
    assert sorted(names) == sorted(expected)
    assert all(case.attrib['status'] == 'run' and case.attrib['result'] == 'completed'
               and all(case.find(tag) is None for tag in ('skipped', 'error', 'failure'))
               for case in cases)
    result_names.extend(names)
assert sorted(result_names) == sorted(tests)
print(f'{len(result_names)} named original E2 witnesses passed with zero failures, errors or skips.')
print(*result_names, sep='\n')
(scratch/'e2-build-commands.json').write_text(json.dumps({'compile':commands,'link':link},indent=2)+'\n')

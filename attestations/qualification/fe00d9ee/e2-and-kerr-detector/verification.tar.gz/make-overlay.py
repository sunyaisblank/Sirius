from pathlib import Path


root = Path.cwd()
scratch = root / 'out/kerr-terminal-first'
source = (root / 'src/sirius/render/session/point_source_detector.cpp').read_text()
source = source.replace('#include <limits>', '#include <limits>\n#include <iostream>')
source = source.replace('''    bool whole_sky_query = false;
};''', '''    bool whole_sky_query = false;
    bool terminal_bound_attempted = false;
};''')
source = source.replace('''            statistics_.roots = roots_.size();
            return PointDetectorResult''', '''            statistics_.roots = roots_.size();
            ReportEarlyBounds();
            return PointDetectorResult''')
source = source.replace('''            statistics_.roots = roots_.size();
            return std::unexpected(PointDetectorError{reason, statistics_});''', '''            statistics_.roots = roots_.size();
            ReportEarlyBounds();
            return std::unexpected(PointDetectorError{reason, statistics_});''')
source = source.replace('''    Estimate Measure(const Cell& cell) {''', '''    Estimate Measure(const Cell& cell, bool near_visibility_boundary = false) {''')
marker = '''        const auto centre = cell.Centre();
        const double half = cell.Width() * .5;'''
replacement = '''        if (near_visibility_boundary && cell_bound_ && cell.depth >= policy_.maximum_depth) {
            ++early_bound_attempts_;
            result.terminal_bound_attempted = true;
            if (const auto bound = BoundCell(cell)) {
                ++early_bounds_;
                return *bound;
            }
        }
''' + marker
assert source.count(marker)==1
source = source.replace(marker, replacement)
start = source.index('''            const auto available = policy_.maximum_candidate_visits - statistics_.candidate_visits;''',
                     source.index('''    Estimate Refine(const Cell& cell'''))
end = source.index('''        if (terminal) Fail(PointDetectorFailure::Unresolved);''', start)
body = source[start:end]
assert body.endswith('        }\n')
full_bound = body[:-len('        }\n')]
source = source[:start] + '''            if (const auto bound = BoundCell(cell)) return *bound;
        }
''' + source[end:]
full_bound = '\n'.join(line[4:] if line.startswith('    ') else line
                       for line in full_bound.splitlines()) + '\n'
function = '''    std::optional<Estimate> BoundCell(const Cell& cell) {
''' + full_bound + '''        return std::nullopt;
    }

    void ReportEarlyBounds() const {
        if (early_bound_attempts_ != 0)
            std::clog << "terminal early bounds attempts=" << early_bound_attempts_
                      << " successes=" << early_bounds_ << " probes=" << statistics_.probes
                      << " cells=" << statistics_.cells << " visits=" << statistics_.candidate_visits
                      << '\\n';
    }

'''
source = source.replace('    Estimate Refine(const Cell& cell', function+'    Estimate Refine(const Cell& cell')
source = source.replace('''        if (coarse.certified_dark || !cell.IntersectsSupport()) return coarse;''',
                        '''        if (coarse.certified_dark || coarse.bounded_omission || !cell.IntersectsSupport())
            return coarse;''')
source = source.replace('''        if (cell_bound_ && ((terminal && coarse.has_hidden_probe) || last_whole_sky_split)) {''',
                        '''        if (cell_bound_ && !coarse.terminal_bound_attempted &&
            ((terminal && coarse.has_hidden_probe) || last_whole_sky_split)) {''')
source = source.replace(
    """        std::array<Estimate, 4> estimates;
        for (int i = 0; i < 4; ++i) estimates[i] = Measure(children[i]);""",
    """        std::array<Estimate, 4> estimates;
        if (cell_bound_ && coarse.has_hidden_probe && cell.depth + 1 == policy_.maximum_depth) {
            // A terminal child cannot participate in another convergence comparison.
            // Finish each child before spending probes or catalogue visits on the next.
            for (int i = 0; i < 4; ++i)
                estimates[i] = Refine(children[i], Measure(children[i], true));
            return Sum(estimates);
        }
        for (int i = 0; i < 4; ++i) estimates[i] = Measure(children[i]);""")
source = source.replace('''    PointDetectorStatistics statistics_;
    std::vector<CachedProbe> probes_;''', '''    PointDetectorStatistics statistics_;
    std::size_t early_bound_attempts_ = 0, early_bounds_ = 0;
    std::vector<CachedProbe> probes_;''')
(scratch / 'point_source_detector.cpp').write_text(source)

#include "sirius/render/session/point_source_detector.h"

#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>

using namespace sirius;
using namespace sirius::render;

int main(int argc, char**) {
    const core::StarfieldSpatialIndex catalogue(std::vector<core::StarEntry>{});
    const std::array footprints{PointDetectorFootprint{{0.0, 0.0}, {{{1.,0.},{0.,1.}}}}};
    for (const unsigned mode : {0u,1u,2u,3u}) {
        std::size_t callbacks = 0;
        std::size_t visits = 0;
        bool cancelled = false;
        const PointDetectorSampler sample = [](DetectorCoordinate z)
            -> std::expected<PointDetectorProbe,PointDetectorFailure> {
            if (z[0] == std::floor(z[0]) && z[1] == std::floor(z[1])) return PointDetectorProbe{};
            PointDetectorProbe point;
            point.visible = true;
            point.direction = {1.0, .001*z[0], .001*z[1]};
            point.source_derivative = {{{.001,0.},{0.,.001}}};
            return point;
        };
        const PointDetectorCellBound bound =
            [&](const PointDetectorFootprint&, const DetectorCoordinate&, const DetectorCoordinate&,
                std::size_t& remaining) -> std::optional<std::array<double,3>> {
                ++callbacks;
                if (mode == 2) {
                    ++remaining;
                    return {};
                }
                if (mode == 3) cancelled = true;
                if (remaining == 0) return {};
                --remaining;
                ++visits;
                if (mode == 1) return {};
                return std::array<double,3>{1e-10,2e-10,3e-10};
            };
        PointDetectorPolicy policy;
        policy.maximum_depth = 2;
        policy.minimum_depth = 2;
        const auto result = EvaluatePointDetectorGroup(catalogue, 1.0, footprints, sample,
            [&]{return cancelled;},policy,{},{},bound);
        const auto& stats = result ? result->statistics : result.error().statistics;
        std::cout << "mode=" << mode << " completed=" << bool(result)
                  << " reason=" << (result ? -1 : int(result.error().reason))
                  << " probes=" << stats.probes << " cells=" << stats.cells
                  << " callbacks=" << callbacks << " charged=" << stats.candidate_visits
                  << " actual=" << visits;
        if (result)
            for (const auto error : result->samples[0].estimated_error) std::cout << ' ' << error;
        std::cout << '\n';
        if (argc > 1 && ((mode == 0 && (!result || callbacks == 0 || visits != stats.candidate_visits)) ||
                        (mode == 1 && (result || visits != stats.candidate_visits)) ||
                        (mode == 2 && (result || result.error().reason != PointDetectorFailure::Arithmetic)) ||
                        (mode == 3 && (result || result.error().reason != PointDetectorFailure::Cancelled))))
            return 1;
    }
}

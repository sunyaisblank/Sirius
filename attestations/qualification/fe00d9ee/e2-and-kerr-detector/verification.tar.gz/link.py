from concurrent.futures import ThreadPoolExecutor
import gzip
import json
from pathlib import Path
import os
import shlex
import subprocess
import sys

root = Path.cwd()
scratch = root / 'out/kerr-terminal-first'
build = root / 'bin/linux-ci'
history = root / 'attestations/qualification/7fd2aa59/kerr-finite-turn/early-build.json.gz'
prior = json.loads(gzip.decompress(history.read_bytes()))
compile_commands = json.loads((build / 'compile_commands.json').read_text())
original = next(row for row in compile_commands
                if row['file'].endswith('/session/point_source_detector.cpp'))
overlay = shlex.split(original['command'])
assert overlay[-2] == '-c' and overlay[-4] == '-o'
overlay = [*overlay[:-4], '-o', str(scratch / 'point_source_detector.cpp.o'),
           '-c', str(scratch / 'point_source_detector.cpp')]
block_compile = [entry for entry in prior['compile'] if entry[-1].endswith('/block.cpp')][0]
base = ['-I' + str(root/'src'), '-std=c++2c', '-O3', '-DNDEBUG', '-Wall', '-Wextra',
        '-Wpedantic', '-Werror', '-Wno-missing-field-initializers', '-DSIRIUS_CONTRACT_MODE=2']
block = [*block_compile[:-4], '-o', str(scratch / 'block.cpp.o'), '-c', str(scratch / 'block.cpp')]
libraries = prior['link'][prior['link'].index('src/sirius/app/libsirius_app_lib.a'):]
block_command = [
    '/usr/bin/g++-14', str(scratch/'block.cpp.o'), str(scratch/'point_source_detector.cpp.o'),
    '-o', str(scratch/'block'), *libraries,
]
test_commands = []
for name in ('baseline', 'candidate'):
    objects = [str(scratch/'point_source_detector.cpp.o')] if name == 'candidate' else []
    test_commands.append(['/usr/bin/g++-14', *base, str(scratch/'probe-order.cpp'), *objects,
                          '-o', str(scratch/f'probe-{name}'), *libraries])
commands = ([overlay, block] if '--compile' in sys.argv else
            [block_command, *test_commands])
with ThreadPoolExecutor() as workers:
    for result in workers.map(lambda command: subprocess.run(command, cwd=build,
           env={**os.environ,'TMPDIR':str(scratch)},check=True), commands):
        pass

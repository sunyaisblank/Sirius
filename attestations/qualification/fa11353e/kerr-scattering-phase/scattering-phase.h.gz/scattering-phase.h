#pragma once

#include "sirius/core/kerr_infinity.h"

namespace sirius::core::relativity::kerr_infinity_detail {

using finite_tail_detail::Range;

inline Range LogReduced(Range mantissa) {
    const auto z = (mantissa - Range(1.0)) / (mantissa + Range(1.0));
    const auto square = finite_tail_detail::Square(z);
    Range term = z, sum{};
    for (unsigned n = 1; n < 40; n += 2) {
        sum = sum + term / Range(n);
        term = term * square;
    }
    const double remainder = (Range(2.0) * finite_tail_detail::Abs(term) /
                              (Range(41.0) * (Range(1.0) - square))).hi;
    return Range(2.0) * sum + Range(-remainder, remainder);
}

inline Range LogPoint(double value) {
    if (!(value > 0.0) || !std::isfinite(value)) return finite_tail_detail::InvalidRange();
    if (value == 1.0) return Range(0.0);
    int exponent;
    const double mantissa = std::frexp(value, &exponent) * 2;
    const static Range log_two = LogReduced(Range(2.0));
    return LogReduced(Range(mantissa)) + Range(exponent - 1) * log_two;
}

inline Range AsinhNonnegative(Range argument) {
    if (!(argument.lo >= 0.0) || !argument.Finite()) return finite_tail_detail::InvalidRange();
    const Range input = argument + sqrt(Range(1.0) + finite_tail_detail::Square(argument));
    return Range(LogPoint(input.lo).lo, LogPoint(input.hi).hi);
}

template <typename Scalar>
std::optional<Range> BracketRadialZero(const std::array<Scalar, 5>& coefficients, double lo,
                                      double hi, bool positive_left) {
    using finite_tail_detail::Enclosure;
    const auto sign = [&](double value, bool positive) {
        const Range bounds = Enclosure(EvaluateRadial(coefficients, Scalar(value)));
        return positive ? bounds.lo > 0.0 : bounds.hi < 0.0;
    };
    if (!(lo < hi) || !sign(lo, positive_left) || !sign(hi, !positive_left)) return {};
    const auto tighten = [&](double proven, double other, bool positive) {
        for (unsigned i = 0; i < 42; ++i) {
            const double m = std::midpoint(proven, other);
            if (m == proven || m == other) break;
            if (sign(m, positive)) proven = m;
            else other = m;
        }
        return proven;
    };
    const double lower = tighten(lo, hi, positive_left);
    return Range(lower, tighten(hi, lower, !positive_left));
}

struct RadialScatteringPhase {
    Range turn, inner, mino;
};

template <typename Scalar>
std::optional<RadialScatteringPhase> EncloseRadialScatteringPhase(
    const DetectorRadialBounds<Scalar>& state, unsigned panels) {
    using finite_tail_detail::Enclosure;
    using finite_tail_detail::Square;
    if (!state.inward || panels == 0 || panels > 128) return {};
    const auto minimum = EncloseRadialMinimum(state);
    if (!minimum || !(minimum->value.hi < 0.0)) return {};
    const auto& c = state.coefficients;
    const auto turn = BracketRadialZero(c, state.start.hi, minimum->inverse_radius.lo, true);
    const auto inner = BracketRadialZero(c, minimum->inverse_radius.hi, state.horizon.lo, false);
    if (!turn || !inner) return {};
    const Range delta = *inner - *turn;
    if (!(delta.lo > 0.0)) return {};

    // H(u)=(u_turn-u)(u_inner-u)G(u). Evaluate the constant term
    // from H(0) and the other two terms by matching powers of u.
    const Range fourth = Enclosure(c[4]);
    const std::array quadratic{Enclosure(c[0]) / (*turn * *inner),
                               Enclosure(c[3]) + (*turn + *inner) * fourth, fourth};
    Range phase{};
    for (const auto span : {*turn - state.start, *turn}) {
        if (!(span.lo > 0.0)) return {};
        for (unsigned i = 0; i < panels; ++i) {
            // t is exactly representable for the power-of-two panel counts in use.
            const Range a = Range(i) / Range(panels);
            const Range b = Range(i + 1) / Range(panels);
            const Range qa2 = Square(a) * span, qb2 = Square(b) * span;
            const Range u = *turn - Range(qa2.lo, qb2.hi);
            const Range quotient = EvaluateRadial(quadratic, u);
            if (!(quotient.lo > 0.0)) return {};
            // q²=u_turn-u. Weight the panel exactly by the integral
            // of dq/sqrt(delta+q²), using the difference of two asinh
            // values in rationalized form to preserve parameter correlation.
            const Range sinh_span = sqrt(span) * (b - a) * (b + a) /
                                    (b * sqrt(delta + qa2) + a * sqrt(delta + qb2));
            const Range weight = AsinhNonnegative(sinh_span);
            phase = phase + Range(2.0) * weight / sqrt(quotient);
        }
    }
    if (!phase.Finite()) return {};
    return RadialScatteringPhase{*turn, *inner, phase};
}

inline Range SinePoint(double angle) {
    using finite_tail_detail::Square;
    const Range x(angle), x2 = Square(x);
    Range term = x, sum = x;
    for (unsigned n = 1; n <= 12; ++n) {
        term = term * x2 / Range((2*n)*(2*n+1));
        sum = n % 2 != 0 ? sum - term : sum + term;
    }
    // For 0 <= angle <= pi, the Taylor terms decrease after the
    // first term. Degree 27 gives the outward omitted-term bound.
    const double remainder = (term * x2 / Range(26*27)).hi;
    return Range((sum - Range(remainder)).lo, sum.hi);
}

struct PolarCrossings {
    Range half_period, first_crossing, source_mu;
    unsigned count;
};

template <typename Scalar>
std::optional<PolarCrossings> EnclosePolarCrossings(double spin,
                                                   const DetectorRadialBounds<Scalar>& state,
                                                   Range mino) {
    using finite_tail_detail::Abs;
    using finite_tail_detail::Enclosure;
    using finite_tail_detail::Square;
    const Scalar a(spin);
    const Scalar scale = Square(a * state.energy);
    const Scalar carter_q = state.carter - Square(state.angular - a * state.energy);
    const Scalar b = scale - carter_q - Square(state.angular);
    const Range Q = Enclosure(carter_q);
    if (!(Q.lo > 0.0)) return {};
    const Range omega2 = (sqrt(Square(Enclosure(b)) + Range(4.0)*Enclosure(scale * carter_q))
                          - Enclosure(b)) * Range(0.5);
    const Range turning_mu2 = Q / omega2;
    if (!(turning_mu2.lo > 0.0 && turning_mu2.hi < 1.0)) return {};
    const Range modulation = Enclosure(scale) * turning_mu2;
    const Range m = modulation / omega2;
    if (!(m.lo >= 0.0 && m.hi < 1.0)) return {};
    // After mu = sqrt(mu_turn^2) sin(psi), the half-period is the
    // average of (1 + m sin^2(psi))^(-1/2) on [0,pi], times pi/omega.
    // The alternating binomial expansion of that average has terms
    // C(2k,k)^2 m^k / 16^k. The first omitted term bounds the error.
    Range term(1.0), sum(1.0);
    for (unsigned k = 1; k <= 9; ++k) {
        term = term * Square(Range(2*k-1) / Range(2*k)) * m;
        if (k == 9) {
            sum = sum - Range(0.0, term.hi);
            break;
        }
        sum = k % 2 != 0 ? sum - term : sum + term;
    }
    const Range pi{0x1.921fb54442d18p+1, 0x1.921fb54442d19p+1};
    const Range period = pi * sum / sqrt(omega2);
    const Range q = Abs(Enclosure(state.mu)) / sqrt(turning_mu2);
    if (!(q.hi < 1.0)) return {};
    // Integrate from the equator to |mu_0|. After substituting
    // t=sin(psi), both factors can be bounded directly on 0<=t<=q.
    const Range q2 = Square(q);
    const Range to_equator(
        (q / sqrt(omega2 + modulation * q2)).lo,
        (q / (sqrt(omega2) * sqrt(Range(1.0) - q2))).hi);
    const Range outward = Enclosure(state.mu * state.mu_rate);
    if (!(outward.lo > 0.0 || outward.hi < 0.0)) return {};
    const Range next = outward.lo > 0.0 ? period - to_equator : to_equator;
    const Range laps = (mino - next) / period;
    if (!laps.Finite() || laps.hi >= 10000.0) return {};
    const auto count = [](double x) {
        return x < 0.0 ? 0U : static_cast<unsigned>(std::floor(x)) + 1;
    };
    const unsigned crossings = count(laps.lo);
    if (crossings == 0 || crossings != count(laps.hi)) return {};
    const Range initial_mu = Enclosure(state.mu);
    if (!(initial_mu.lo > 0.0 || initial_mu.hi < 0.0)) return {};
    const Range elapsed = mino - next - Range(crossings - 1) * period;
    const Range travel = elapsed * Range(sqrt(omega2).lo, sqrt(omega2 + modulation).hi);
    if (!travel.Finite()) return {};
    const double lower = std::max(0.0, travel.lo), upper = std::min(pi.hi, travel.hi);
    if (!(lower <= upper)) return {};
    const Range first = SinePoint(lower), last = SinePoint(upper);
    const bool includes_peak = lower <= pi.hi * 0.5 && upper >= pi.lo * 0.5;
    const Range sine{std::max(0.0, std::min(first.lo, last.lo)),
                     includes_peak ? 1.0 : std::min(1.0, std::max(first.hi, last.hi))};
    const double sign = (initial_mu.lo > 0.0) == (crossings % 2 == 0) ? 1.0 : -1.0;
    return PolarCrossings{period, next, Range(sign) * sqrt(turning_mu2) * sine, crossings};
}

} // namespace sirius::core::relativity::kerr_infinity_detail

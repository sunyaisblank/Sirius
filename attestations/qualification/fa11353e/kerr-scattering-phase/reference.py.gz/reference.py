"""Independent high precision radial and scalar polar reference for two camera rays."""

from decimal import Decimal as D, localcontext
import math
from pathlib import Path
import re

A = D.from_float(0.9)


def constants(launch):
    _, x, y, z, _, kx, ky, kz = [D.from_float(float.fromhex(v)) for v in launch.split(",")]
    s = x*x+y*y+z*z-A*A
    r2 = (s+(s*s+4*A*A*z*z).sqrt())/2
    r = r2.sqrt()
    mu = z/r
    sigma = r2 + A*A*mu*mu
    ellx, elly = (r*x+A*y)/(r2+A*A), (r*y-A*x)/(r2+A*A)
    h = 2*r/sigma
    dot = ellx*kx + elly*ky + mu*kz
    spatial2 = kx*kx + ky*ky + kz*kz
    kt = (h*dot-(h*dot*dot+(1-h)*spatial2).sqrt())/(1-h)
    correction = h*(kt+dot)
    energy = kt-correction
    angular = x*(ky+correction*elly)-y*(kx+correction*ellx)
    r_rate = (r*(x*kx+y*ky)+(r2+A*A)*mu*kz)/sigma
    mu_rate = sigma*(kz-mu*r_rate)/r
    q = (mu_rate*mu_rate+mu*mu*angular*angular)/(1-mu*mu)-mu*mu*A*A*energy*energy
    return 1/r, energy, angular, q, mu, mu_rate


def radial(u0, energy, angular, carter, panels):
    z = A*A*energy-A*angular
    c = carter+(angular-A*energy)**2
    coefficients = [energy*energy, D(0), 2*energy*z-c, 2*c, z*z-A*A*c]

    def poly(coeff, radius):
        value = coeff[-1]
        for field in reversed(coeff[:-1]):
            value = field+value*radius
        return value

    # Fixed brackets are derived from the signs of the independent decimal
    # polynomial, with the recorded neighbourhood bounded by 0.54 and 0.55.
    middle = D(".5473496")
    assert poly(coefficients, middle) < 0

    def root(low, high, positive_left):
        for _ in range(210):
            m = (low+high)/2
            if (poly(coefficients, m) > 0) == positive_left:
                low = m
            else:
                high = m
        return (low+high)/2

    turn = root(D(".54"), middle, True)
    other = root(middle, D(".55"), False)
    # Single-root synthetic division. Integrate the entire transformed
    # integrand using a fixed four-node Gauss rule in a separately scaled
    # hyperbolic parameter. No interval brackets or panel weights are used.
    factor = [-coefficients[4]]
    for v in reversed(coefficients[1:4]):
        factor.append(turn*factor[-1]-v)
    factor.reverse()
    scale = D(".02")

    def f(s):
        exponential = s.exp()
        q = scale*(exponential-1/exponential)/2
        q_rate = scale*(exponential+1/exponential)/2
        return 2*q_rate/poly(factor, turn-q*q).sqrt()

    offset = (D(6)/5).sqrt()*2
    offsets = [((3+offset)/7).sqrt(), ((3-offset)/7).sqrt()]
    weights = [(18-D(30).sqrt())/72, (18+D(30).sqrt())/72]
    phase = D(0)
    for span in (turn-u0, turn):
        q = span.sqrt()/scale
        width = (q+(1+q*q).sqrt()).ln()/panels
        for i in range(panels):
            midpoint = (D(i)+D(".5"))*width
            for node, weight in zip(offsets, weights, strict=True):
                half_offset = width*node/2
                phase += width*weight*(f(midpoint-half_offset)+f(midpoint+half_offset))
    return turn, other, phase


def scalar_polar(energy, angular, carter, mu, mu_rate, phase):
    a = float((A*energy)**2)
    l = float(angular)
    q = float(carter)
    b = a-q-l*l
    omega2 = (math.hypot(b, 2*math.sqrt(a*q))-b)/2
    amplitude = math.sqrt(q/omega2)
    scale = a*amplitude*amplitude

    def integrate(angle, panels=128):
        dx = angle/panels
        values = [1/math.sqrt(omega2+scale*math.sin(j*dx)**2) for j in range(panels+1)]
        return dx/3*sum(value*(1 if j in {0, panels} else (4 if j % 2 else 2))
                        for j, value in enumerate(values))

    half = integrate(math.pi)
    equator = integrate(math.asin(abs(float(mu))/amplitude))
    first = half-equator if mu*mu_rate > 0 else equator
    n = 1+math.floor((float(phase)-first)/half)
    elapsed = float(phase)-first-(n-1)*half
    lo, hi = 0.0, math.pi
    for _ in range(48):
        mid = (lo+hi)/2
        if integrate(mid) < elapsed:
            lo = mid
        else:
            hi = mid
    sky_mu = math.copysign(1, float(mu))*(-1)**n*amplitude*math.sin((hi+lo)/2)
    return half, first, n, sky_mu


lines = Path(__file__).with_name("phase.log").read_text().splitlines()
with localcontext() as ctx:
    ctx.prec = 64
    for line in (line for line in lines if "xk=" in line):
        args = constants(line.split("xk=", 1)[1])
        coarse = radial(*args[:4], panels=128)
        fine = radial(*args[:4], panels=256)
        gap = abs(coarse[-1] - fine[-1])
        assert gap < D("2e-12"), gap
        half, first, count, mu = scalar_polar(*args[1:], fine[-1])
        expected = dict(zip(("turn", "inner", "mino", "half", "first", "source_mu"),
                            (*fine, half, first, mu), strict=True))
        for name, value in expected.items():
            lower, upper = re.search(rf" {name}=\[([^,]+),([^\]]+)\]", line).groups()
            assert D(lower) <= D(value) <= D(upper), (name, lower, value, upper)
        assert f"crossings={count}" in line
        print({name: str(value) for name, value in expected.items()} | {
            "polar_crossings": count, "radial_refinement_gap": str(gap),
        })

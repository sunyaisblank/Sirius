#include "sirius/backend/cpu/geodesic_tracer.h"
#include "scattering-phase.h"
#include "sirius/core/camera_sampling.h"
#include "sirius/core/starfield.h"
#include <array>
#include <iomanip>
#include <iostream>

using namespace sirius;
int main() {
    core::CameraConfig config;
    config.r=30;
    config.theta=80*core::constants::math::kPi/180.0;
    config.fov=60;
    config.width=1920;
    config.height=1080;
    config.beta_x=.1;
    config.beta_y=.02;
    config.beta_z=-.01;
    config.focal_length=50;
    config.aperture=2.8f;
    config.focus_distance=30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1,.9));
    core::CameraSample sample;
    bool first=true;
    core::ForEachCameraSample(4,[&](auto next) {
        if (first) sample=next;
        first=false;
    });
    constexpr std::array lo{0x1.2b6p-1,0x1.fa7cp+1}, hi{0x1.2b7p-1,0x1.fa8p+1};
    constexpr double m01=-0x1.d357ebd0e3748p-1, m10=0x1.d30c6a29fa83fp-1;
    constexpr double m11=0x1.e454f19fc15dep-9;
    using Coordinate=std::array<double,2>;
    const double midX=std::midpoint(lo[0],hi[0]),midY=std::midpoint(lo[1],hi[1]);
    const double half=(hi[0]-lo[0])*.5;
    std::array<Coordinate,13> nodes{};
    unsigned count=0;
    nodes[count++]={0,0};
    for(int y=-1;y<=1;++y)
        for(int x=-1;x<=1;++x)
            if (x!=0 || y!=0) nodes[count++]={double(x),double(y)};
    for (const auto d:{Coordinate{-.37,-.61},Coordinate{.61,-.37},
                       Coordinate{.37,.61},Coordinate{-.61,.37}}) nodes[count++]=d;
    using namespace core::relativity::finite_tail_detail;
    using namespace core::relativity::kerr_infinity_detail;
    const double x=896+double(sample.image_u), y=576+double(sample.image_v);
    const auto central=camera.ProjectFilmForObserver(x,y,sample.pupil_u,sample.pupil_v);
    if (!central) return 1;
    const auto launched=core::LaunchCameraRay(metric,0.9,central->ray);
    if (!launched) return 1;
    backend::DetectorLaunchFrame frame;
    frame.pupil=central->ray;
    for (int i=0;i<4;++i) {
        frame.position[i]=Range(launched->position(i));
        frame.tetrad[0][i]=Range(launched->observer.time(i));
        for (int axis=0;axis<3;++axis) frame.tetrad[axis+1][i]=Range(launched->observer.spatial[axis](i));
    }

    const core::PointStarfieldConfig point_stars{};
    const auto stars=core::StarfieldGenerator(core::ExpandPointStarfieldConfig(point_stars)).GenerateCatalogue();
    const auto record = [&](const char* tag, Range z0, Range z1) {
        const std::array box{Range(x)+Range(m01)*z1,
            Range(y)+(Range(17)+(Range(m10)*z0+Range(m11)*z1))};
        const auto q=core::camera_detail::ThinLensFilmVector(
            core::camera_detail::FilmPlaneX(box[0],config),
            core::camera_detail::FilmPlaneY(box[1],config),
            core::camera_detail::FilmTangent(config),config.focus_distance,
            frame.pupil.aperture_up,frame.pupil.aperture_right);
        const std::array magnitude{Abs(q[0]),Abs(q[1]),Abs(q[2])};
        const auto length=core::camera_detail::ThinLensFilmLength(magnitude,Range(config.focus_distance));
        const std::array ray{q[0]/length,q[1]/length,q[2]/length};
        const auto norm=sqrt(Square(ray[0])+Square(ray[1])+Square(ray[2]));
        const std::array direction{ray[0]/norm,ray[1]/norm,ray[2]/norm};
        const auto state=EncloseCorrelatedKerrDetectorState(metric.GetParams(),frame.position,
                                                           frame.tetrad,direction);
        if (!state) return false;
        const auto minimum=EncloseRadialMinimum(*state);
        if (!minimum) return false;
        std::cout<<std::setprecision(16)<<tag<<" H=["<<minimum->value.lo<<','
                 <<minimum->value.hi<<"] ";
        const auto phase=EncloseRadialScatteringPhase(*state,64);
        if (phase) {
            std::cout<<"turn=["<<phase->turn.lo<<','<<phase->turn.hi
                     <<"] inner=["<<phase->inner.lo<<','<<phase->inner.hi
                     <<"] mino=["<<phase->mino.lo<<','<<phase->mino.hi<<']';
            const auto polar=EnclosePolarCrossings(.9,*state,phase->mino);
            if (polar) {
                const auto overlapping=[&](const core::StarEntry& star) {
                    const Range az(star.direction_z);
                    const Range normalized=az/sqrt(Square(Range(star.direction_x))+
                                                      Square(Range(star.direction_y))+Square(az));
                    return normalized.lo<=polar->source_mu.hi && normalized.hi>=polar->source_mu.lo;
                };
                std::cout<<" half=["<<polar->half_period.lo<<','
                                <<polar->half_period.hi<<"] first=["<<polar->first_crossing.lo
                                <<','<<polar->first_crossing.hi<<"] crossings="<<polar->count
                                <<" source_mu=["<<polar->source_mu.lo<<','<<polar->source_mu.hi<<']'
                                <<" catalogue_in_band="<<std::ranges::count_if(stars,overlapping)
                                <<'/'<<stars.size();
            }
            if (z0.lo==z0.hi && z1.lo==z1.hi) {
                const auto point=camera.ProjectFilmOffsetForObserver(x,y,m01*z1.lo,
                    17+(m10*z0.lo+m11*z1.lo),sample.pupil_u,sample.pupil_v);
                if (!point) return false;
                const auto exact=core::LaunchCameraRay(metric,.9,point->ray);
                if (!exact) return false;
                std::cout<<" xk="<<std::hexfloat;
                for (int i=0;i<4;++i) std::cout<<exact->position(i)<<',';
                for (int i=0;i<4;++i) std::cout<<exact->tangent(i)<<(i==3?"":",");
                std::cout<<std::defaultfloat;
            }
        }
        else std::cout<<"unclassified";
        std::cout<<'\n';
        return true;
    };
    if (!record("adjacent_dark",Range(0x1.2b5p-1,0x1.2b6p-1),Range(0x1.fa74p+1,0x1.fa78p+1)) ||
        !record("actual_mixed",Range(lo[0],hi[0]),Range(lo[1],hi[1]))) return 2;
    for (const auto& node:nodes) {
        if (!record("node",Range(midX+node[0]*half),Range(midY+node[1]*half))) return 3;
    }
    const double sx=(hi[0]-lo[0])/32, sy=(hi[1]-lo[1])/32;
    for (unsigned i=0;i<4;++i) {
        for (unsigned j=0;j<4;++j) {
            if (!record("strip_box",Range(hi[0]-(i+1)*sx,hi[0]-i*sx),
                  Range(hi[1]-(j+1)*sy,hi[1]-j*sy))) return 4;
        }
    }
}

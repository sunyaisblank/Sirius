#include "sirius/backend/cpu/geodesic_tracer.h"
#include "winding-tail.h"
#include "sirius/core/camera_sampling.h"
#include "sirius/core/starfield.h"
#include "sirius/render/session/point_source_detector.h"
#include <array>
#include <iomanip>
#include <iostream>

using namespace sirius;
int main() {
    core::CameraConfig config;
    config.r=30;
    config.theta=80*core::constants::math::kPi/180.0;
    config.fov=60;
    config.width=1920;
    config.height=1080;
    config.beta_x=.1;
    config.beta_y=.02;
    config.beta_z=-.01;
    config.focal_length=50;
    config.aperture=2.8f;
    config.focus_distance=30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1,.9));
    core::CameraSample sample;
    bool first=true;
    core::ForEachCameraSample(4,[&](auto next) {
        if (first) sample=next;
        first=false;
    });
    constexpr std::array lo{0x1.2b6p-1,0x1.fa7cp+1}, hi{0x1.2b7p-1,0x1.fa8p+1};
    constexpr double m01=-0x1.d357ebd0e3748p-1, m10=0x1.d30c6a29fa83fp-1;
    constexpr double m11=0x1.e454f19fc15dep-9;
    using Coordinate=std::array<double,2>;
    using namespace core::relativity::finite_tail_detail;
    using namespace core::relativity::kerr_infinity_detail;
    const double x=896+double(sample.image_u), y=576+double(sample.image_v);
    const auto central=camera.ProjectFilmForObserver(x,y,sample.pupil_u,sample.pupil_v);
    if (!central) return 1;
    const auto launched=core::LaunchCameraRay(metric,0.9,central->ray);
    if (!launched) return 1;
    backend::DetectorLaunchFrame frame;
    frame.pupil=central->ray;
    for (int i=0;i<4;++i) {
        frame.position[i]=Range(launched->position(i));
        frame.tetrad[0][i]=Range(launched->observer.time(i));
        for (int axis=0;axis<3;++axis) frame.tetrad[axis+1][i]=Range(launched->observer.spatial[axis](i));
    }

    using namespace core::relativity::finite_tail_detail;
    using namespace core::relativity::kerr_infinity_detail;
    const auto evaluate = [&](const FilmVector& box) -> std::optional<StationaryChart> {
        const FilmJet z0(box[0],{Range(1.0),Range(0.0)});
        const FilmJet z1(box[1],{Range(0.0),Range(1.0)});
        const auto q=core::camera_detail::ThinLensFilmVector(
            core::camera_detail::FilmPlaneX(FilmJet(x)+FilmJet(m01)*z1,config),
            core::camera_detail::FilmPlaneY(FilmJet(y)+FilmJet(17.0)+
                                           FilmJet(m10)*z0+FilmJet(m11)*z1,config),
            core::camera_detail::FilmTangent(config),config.focus_distance,
            frame.pupil.aperture_up,frame.pupil.aperture_right);
        const FilmJet norm=sqrt(Square(q[0])+Square(q[1])+Square(q[2]));
        const std::array direction{q[0]/norm,q[1]/norm,q[2]/norm};
        std::array<FilmJet,4> event,tangent;
        for (unsigned i=0;i<4;++i) {
            event[i]=FilmJet(frame.position[i]);
            tangent[i]=FilmJet(0.0)-FilmJet(frame.tetrad[0][i])+
                       FilmJet(frame.tetrad[1][i])*direction[0]+
                       FilmJet(frame.tetrad[2][i])*direction[1]+
                       FilmJet(frame.tetrad[3][i])*direction[2];
        }
        const auto state=EncloseDetectorRadialState<true>(metric.GetParams(),event,tangent);
        if (!state) return {};
        return MakeStationaryChart(*state,0.9);
    };
    const auto print=[](std::string_view key, Range range) {
        std::cout<<' '<<key<<"=["<<range.lo<<','<<range.hi<<']';
    };
    std::cout<<std::setprecision(17);
    const FilmVector box{Range(lo[0],hi[0]),Range(lo[1],hi[1])};
    const auto whole=evaluate(box);
    if (!whole) return 2;
    const auto proof=ProveInjectiveChart(whole->jacobian);
    if (!proof) return 3;
    const auto& [radial_row,potential_row]=whole->jacobian;
    const Range det=radial_row[0]*potential_row[1]-radial_row[1]*potential_row[0];
    std::cout<<"whole contraction="<<proof->contraction;
    print("det",det);
    print("du_dz0",radial_row[0]); print("du_dz1",radial_row[1]);
    print("dH_dz0",potential_row[0]); print("dH_dz1",potential_row[1]);
    std::cout<<'\n';

    // Locate a point on the critical curve to centre a target rectangle.
    // The following interval inclusion certifies the rectangle even if
    // this scalar bisection stops on an uncertain final sign.
    const double z0=std::lerp(lo[0],hi[0],0.85);
    double lower=lo[1], upper=hi[1];
    for (unsigned i=0;i<36;++i) {
        const double z1=std::midpoint(lower,upper);
        const auto at=evaluate({Range(z0),Range(z1)});
        if (!at) return 4;
        if (at->coordinate[1].lo>0.0) lower=z1;
        else if (at->coordinate[1].hi<0.0) upper=z1;
        else break;
    }
    FilmVector centre{Range(z0),Range(std::midpoint(lower,upper))};
    const auto at_centre=evaluate(centre);
    if (!at_centre) return 5;
    const double u=std::midpoint(at_centre->coordinate[0].lo,at_centre->coordinate[0].hi);
    const std::array target_middle{u,0.0};
    FilmVector target;
    for (unsigned j=0;j<2;++j) {
        double width=std::numeric_limits<double>::infinity();
        for (unsigned i=0;i<2;++i) {
            const double margin=std::min(centre[i].lo-box[i].lo,box[i].hi-centre[i].hi);
            const double gain=Abs(proof->preconditioner[i][j]).hi;
            if (gain>0.0) width=std::min(width,0.375*margin/gain);
        }
        target[j]=Range(target_middle[j]-width,target_middle[j]+width);
    }
    const auto covered=IncludeChartTargets(box,centre,at_centre->coordinate,target,*proof);
    if (!covered || !(target[1].lo<0.0 && target[1].hi>0.0)) return 6;
    const auto converted=InvertStationaryChart(1.0,0.9,target);
    if (!converted) return 7;
    std::cout<<"target";
    print("u",target[0]); print("H",target[1]); print("z0",(*covered)[0]); print("z1",(*covered)[1]);
    print("lambda",converted->lambda); print("eta",converted->eta);
    std::cout<<'\n';

    const Range scale(0.0,std::nextafter(sqrt(Range(-target[1].lo)).lo,0.0));
    const auto turning=EncloseScaledTurningPair(1.0,0.9,target[0],scale);
    if (!turning) return 12;
    std::cout<<"scaling contraction="<<turning->contraction;
    print("s",turning->s);
    print("turn_offset",turning->turn_offset);
    print("inner_offset",turning->inner_offset);
    print("gap_over_s",turning->gap_over_s);
    std::cout<<'\n';

    const auto residual=EncloseRegularizedRadialPhase(1.0,.9,target[0],scale,whole->inverse_start,128);
    if (!residual) return 13;
    std::cout<<"remainder";
    print("inverse_start",whole->inverse_start);
    print("leading_factor",residual->leading_factor);
    print("limiting_drag",residual->limiting_drag);
    print("leading_radial",residual->leading_gradient[0]);
    print("drag_radial",residual->drag_gradient[0]);
    print("drag_scale",residual->drag_gradient[1]);
    print("time_log_derivative",residual->time_log_derivative);
    print("time",residual->time_remainder.value);
    print("time_radial",residual->time_remainder.radial);
    print("time_log_scale",residual->time_remainder.log_scale);
    print("spin",residual->spin_remainder.value);
    print("spin_radial",residual->spin_remainder.radial);
    print("spin_log_scale",residual->spin_remainder.log_scale);
    std::cout<<" spin_decay_constant="<<residual->spin_derivative_constant
             <<" spin_decay_log_coefficient="<<residual->spin_derivative_log_coefficient;
    const Range time_at_edge=Range(-2.0)*residual->leading_factor*LogPoint(scale.hi)+
                            residual->time_remainder.value;
    print("time_at_outer_scale",time_at_edge);
    if (!(residual->time_log_derivative.hi<0.0 && residual->leading_factor.lo>0.0)) return 14;
    std::cout<<'\n';

    // Independently enclose the turning latitude of this smaller
    // coefficient chart, preserving the two shared affine coordinates.
    const auto span_u=PupilAffine::Coordinate(target[0],true);
    const auto span_h=PupilAffine::Coordinate(Range(0.0)-Square(scale),false);
    const auto polar=InvertStationaryScalars(1.0,.9,std::array{span_u,span_h});
    if (!polar) return 16;
    const auto a2=Square(PupilAffine(.9));
    const auto b=a2-polar->eta-Square(polar->lambda);
    const auto omega2=(sqrt(Square(b)+PupilAffine(4.0)*a2*polar->eta)-b)*PupilAffine(.5);
    const Range amplitude=sqrt(polar->eta/omega2).Bounds();
    if (!amplitude.Finite()) return 17;
    const auto stars=core::StarfieldGenerator(core::ExpandPointStarfieldConfig(
        core::PointStarfieldConfig{})).GenerateCatalogue();
    struct CatalogueBand {
        double minimum_gap=std::numeric_limits<double>::infinity();
        double maximum_temperature=0.0;
        unsigned size=0;
        Range intensity{};
    };
    std::array<CatalogueBand,3> bands{};
    double local_gap=std::numeric_limits<double>::infinity();
    unsigned reachable=0, uncertain=0;
    std::optional<double> reference_latitude;
    for (const auto& star : stars) {
        const Range x(star.direction_x), y(star.direction_y), z(star.direction_z);
        const Range latitude=Abs(z)/sqrt(Square(x)+Square(y)+Square(z));
        if (latitude.lo>amplitude.hi) continue;
        if (latitude.hi>=amplitude.lo) {
            ++uncertain;
            continue;
        }
        ++reachable;
        if (!reference_latitude && z.lo<0.0 && latitude.lo>.4 && latitude.hi<.41) {
            reference_latitude=-std::midpoint(latitude.lo,latitude.hi);
        }
        const double gap=(amplitude-latitude).lo;
        local_gap=std::min(local_gap,gap);
        auto& band=bands[gap>=.01 ? 0 : gap>=.0001 ? 1 : 2];
        band.minimum_gap=std::min(band.minimum_gap,gap);
        band.maximum_temperature=std::max(band.maximum_temperature,double(star.temperature_K));
        band.intensity=band.intensity+Range(star.Intensity());
        ++band.size;
    }
    // The earlier continuous full-cell check supplied a 2^-27 gap
    // even if a coarser interval for this chart retains an overlap.
    double clearance=0x1p-27;
    if (uncertain==0 && reachable>0) clearance=std::max(clearance,local_gap);
    std::cout<<"catalogue";
    print("amplitude",amplitude);
    std::cout<<" reachable="<<reachable<<" uncertain="<<uncertain
             <<" clearance="<<clearance<<'\n';

    const auto latitude=EncloseLatitudeRootMonotonicity(
        1.0,.9,target[0],scale,whole->initial_mu,clearance,*residual);
    if (!latitude) return 15;
    std::cout<<"latitude";
    print("initial_mu",whole->initial_mu);
    print("half_period",latitude->half_period);
    std::cout<<" period_h_bound="<<latitude->period_h_bound
             <<" partial_h_bound="<<latitude->endpoint_h_bound
             <<" winding_s2_bound="<<latitude->winding_s2_bound
             <<" root_log_slope_upper="<<latitude->slope_upper<<'\n';

    if (uncertain!=0 || !(whole->energy.hi<-.5)) return 18;
    // Launches have unit camera-frame frequency. This encloses nu_cam /
    // nu_infty by two on the whole film cell, including this chart.
    constexpr double g_upper=2.0;
    constexpr double brightness=core::PointStarfieldConfig{}.brightness_scale;
    constexpr double detector_allowance=render::PointDetectorPolicy{}.absolute_rgb_error;
    // A fixed-pupil target satisfies the entire film inclusion box.
    // exp(-|z|²/2) <= 1/2000 there, and 2*pi*(1-exp(-8)) > 6.
    const Range film_radius2=Square((*covered)[0])+Square((*covered)[1]);
    if (!((film_radius2*Range(0.5)).lo>LogPoint(2000.0).hi &&
          LogPoint(1000.0).hi<8.0 && (Range(2.0)*kPiBounds*Range(.999)).lo>6.0))
        return 25;
    const Range gaussian_factor=Range(1.0)/Range(12000.0);
    const Range lambda_min(core::constants::spectral::kLambdaMin);
    const Range lambda_max(core::constants::spectral::kLambdaMax);
    constexpr double step=(core::constants::spectral::kLambdaMax-
                           core::constants::spectral::kLambdaMin)/32.0;
    for (unsigned i=0;i<32;++i) {
        const double wavelength=core::constants::spectral::kLambdaMin+(i+.5)*step;
        const auto matching=core::spectral::WavelengthToXyz(wavelength*1e9);
        if (!(std::abs(matching.X)<2 && std::abs(matching.Y)<2 && std::abs(matching.Z)<2))
            return 19;
    }
    // Rayleigh-Jeans bounds Planck, since exp(x)-1 >= x. The XYZ
    // table is bounded by two, the colour-matrix row sum is below
    // eight, and the source-normalizer floor exceeds 0.0005.
    const Range sky_factor=gaussian_factor*Range(64.0)*(lambda_max-lambda_min)*
        Range(core::constants::physical::kPlanckC1)*Range(g_upper)*Range(brightness)/
        (Range(core::constants::physical::kPlanckC2)*Square(Square(lambda_min))*Range(.0005));
    Range rgb{};
    std::cout<<"radiometry";
    print("energy",whole->energy);
    print("gaussian_factor",gaussian_factor);
    if (!reference_latitude) return 26;
    std::cout<<" reference_latitude="<<*reference_latitude;
    std::cout<<" g_upper="<<g_upper<<" brightness="<<brightness
             <<" sample_absolute_error="<<detector_allowance<<'\n';
    for (std::size_t index=0;index<bands.size();++index) {
        const auto& band=bands[index];
        if (band.size==0) continue;
        const Range flux=sky_factor*Range(band.maximum_temperature)*band.intensity;
        if (!flux.Finite()) return 20;
        auto tail=EncloseWindingTail(1,.9,target[0],scale,whole->initial_mu,
                                     band.minimum_gap,det,*residual,*latitude,8);
        if (!tail) return 21;
        double flux_upper=std::nextafter(
            std::scalbn((flux*Range(tail->tail_prefactor)).hi,tail->tail_exponent),kInfinity);
        if (!(flux_upper<detector_allowance/3.0)) {
            // Keep the proved monotonic threshold and sum from a later
            // winding if its radiometric allowance requires it.
            const double prefactor=(flux*Range(tail->tail_prefactor)).hi;
            const int exponent=std::ilogb(prefactor/(detector_allowance/4.0));
            const unsigned first=std::max(tail->first_winding,unsigned((2*(exponent+2)+6)/7));
            tail=EncloseWindingTail(1,.9,target[0],scale,whole->initial_mu,
                                   band.minimum_gap,det,*residual,*latitude,first);
            if (!tail) return 22;
            flux_upper=std::nextafter(
                std::scalbn((flux*Range(tail->tail_prefactor)).hi,tail->tail_exponent),kInfinity);
        }
        if (!(flux_upper<detector_allowance/3.0)) return 23;
        rgb=rgb+Range(0.0,flux_upper);
        std::cout<<"tail band="<<index<<" stars="<<band.size
                 <<" clearance="<<band.minimum_gap<<" max_temperature="<<band.maximum_temperature;
        print("intensity",band.intensity);
        print("half_azimuth_radial",tail->half_azimuth_radial);
        std::cout<<" first="<<tail->first_winding
                 <<" slope_lower="<<tail->azimuth_slope_per_winding_lower
                 <<" slope_upper="<<tail->azimuth_slope_per_winding_upper
                 <<" min_polar_speed="<<tail->source_polar_speed_lower
                 <<" wrap_count_slope="<<tail->wrap_count_slope
                 <<" inverse_determinant_coefficient="<<tail->inverse_determinant_coefficient
                 <<" response_prefactor="<<tail->tail_prefactor
                 <<" response_base2_exponent="<<tail->tail_exponent
                 <<" transfer_flux_upper="<<flux.hi<<" rgb_upper="<<flux_upper<<'\n';
    }
    if (!(rgb.Finite() && rgb.hi<detector_allowance)) return 24;
    std::cout<<"total rgb_upper="<<rgb.hi<<'\n';

    for (const auto& point:std::array{Coordinate{lo[0],hi[1]},Coordinate{hi[0],hi[1]},Coordinate{z0,centre[1].lo}}) {
        const auto chart=evaluate({Range(point[0]),Range(point[1])});
        if (!chart) return 8;
        const auto inverse=InvertStationaryChart(1.0,0.9,chart->coordinate);
        if (!inverse || inverse->lambda.lo>chart->lambda.hi || inverse->lambda.hi<chart->lambda.lo ||
            inverse->eta.lo>chart->eta.hi || inverse->eta.hi<chart->eta.lo) return 9;
        const auto ray=camera.ProjectFilmOffsetForObserver(x,y,m01*point[1],
                    17+(m10*point[0]+m11*point[1]),sample.pupil_u,sample.pupil_v);
        if (!ray) return 10;
        const auto launch=core::LaunchCameraRay(metric,.9,ray->ray);
        if (!launch) return 11;
        std::cout<<"point";
        print("z0",Range(point[0])); print("z1",Range(point[1]));
        print("u",chart->coordinate[0]); print("H",chart->coordinate[1]);
        print("lambda",inverse->lambda); print("eta",inverse->eta);
        std::cout<<" xk="<<std::hexfloat;
        for (int i=0;i<4;++i) std::cout<<launch->position(i)<<',';
        for (int i=0;i<4;++i) std::cout<<launch->tangent(i)<<(i==3?"":",");
        std::cout<<std::defaultfloat<<'\n';
    }
}

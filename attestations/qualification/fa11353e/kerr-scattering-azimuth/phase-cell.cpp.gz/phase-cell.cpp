#include "sirius/backend/cpu/geodesic_tracer.h"
#include "scattering-phase.h"
#include "sirius/core/camera_sampling.h"
#include "sirius/core/starfield.h"
#include <array>
#include <iomanip>
#include <iostream>

using namespace sirius;
int main() {
    core::CameraConfig config;
    config.r=30;
    config.theta=80*core::constants::math::kPi/180.0;
    config.fov=60;
    config.width=1920;
    config.height=1080;
    config.beta_x=.1;
    config.beta_y=.02;
    config.beta_z=-.01;
    config.focal_length=50;
    config.aperture=2.8f;
    config.focus_distance=30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1,.9));
    core::CameraSample sample;
    bool first=true;
    core::ForEachCameraSample(4,[&](auto next) {
        if (first) sample=next;
        first=false;
    });
    constexpr std::array lo{0x1.2b6p-1,0x1.fa7cp+1}, hi{0x1.2b7p-1,0x1.fa8p+1};
    constexpr double m01=-0x1.d357ebd0e3748p-1, m10=0x1.d30c6a29fa83fp-1;
    constexpr double m11=0x1.e454f19fc15dep-9;
    using Coordinate=std::array<double,2>;
    const double midX=std::midpoint(lo[0],hi[0]),midY=std::midpoint(lo[1],hi[1]);
    const double half=(hi[0]-lo[0])*.5;
    std::array<Coordinate,13> nodes{};
    unsigned count=0;
    nodes[count++]={0,0};
    for(int y=-1;y<=1;++y)
        for(int x=-1;x<=1;++x)
            if (x!=0 || y!=0) nodes[count++]={double(x),double(y)};
    for (const auto d:{Coordinate{-.37,-.61},Coordinate{.61,-.37},
                       Coordinate{.37,.61},Coordinate{-.61,.37}}) nodes[count++]=d;
    using namespace core::relativity::finite_tail_detail;
    using namespace core::relativity::kerr_infinity_detail;
    const double x=896+double(sample.image_u), y=576+double(sample.image_v);
    const auto central=camera.ProjectFilmForObserver(x,y,sample.pupil_u,sample.pupil_v);
    if (!central) return 1;
    const auto launched=core::LaunchCameraRay(metric,0.9,central->ray);
    if (!launched) return 1;
    backend::DetectorLaunchFrame frame;
    frame.pupil=central->ray;
    for (int i=0;i<4;++i) {
        frame.position[i]=Range(launched->position(i));
        frame.tetrad[0][i]=Range(launched->observer.time(i));
        for (int axis=0;axis<3;++axis) frame.tetrad[axis+1][i]=Range(launched->observer.spatial[axis](i));
    }

    const core::PointStarfieldConfig point_stars{};
    const auto stars=core::StarfieldGenerator(core::ExpandPointStarfieldConfig(point_stars)).GenerateCatalogue();
    struct SkyStar { Range z, phi; };
    std::vector<SkyStar> sky;
    sky.reserve(stars.size());
    for (const auto& star : stars) {
        const Range z(star.direction_z);
        sky.push_back({z / sqrt(Square(Range(star.direction_x)) +
                                Square(Range(star.direction_y)) + Square(z)),
                       CatalogueAzimuth(star.direction_x, star.direction_y)});
    }
    const auto enclose_state = [&](Range z0, Range z1) {
        const std::array box{Range(x)+Range(m01)*z1,
            Range(y)+(Range(17)+(Range(m10)*z0+Range(m11)*z1))};
        const auto q=core::camera_detail::ThinLensFilmVector(
            core::camera_detail::FilmPlaneX(box[0],config),
            core::camera_detail::FilmPlaneY(box[1],config),
            core::camera_detail::FilmTangent(config),config.focus_distance,
            frame.pupil.aperture_up,frame.pupil.aperture_right);
        const std::array magnitude{Abs(q[0]),Abs(q[1]),Abs(q[2])};
        const auto length=core::camera_detail::ThinLensFilmLength(magnitude,Range(config.focus_distance));
        const std::array ray{q[0]/length,q[1]/length,q[2]/length};
        const auto norm=sqrt(Square(ray[0])+Square(ray[1])+Square(ray[2]));
        const std::array direction{ray[0]/norm,ray[1]/norm,ray[2]/norm};
        return EncloseCorrelatedKerrDetectorState(metric.GetParams(),frame.position,
                                                  frame.tetrad,direction);
    };
    const auto record = [&](const char* tag, Range z0, Range z1) {
        const auto state=enclose_state(z0,z1);
        if (!state) return false;
        const auto minimum=EncloseRadialMinimum(*state);
        if (!minimum) return false;
        std::cout<<std::setprecision(16)<<tag<<" H=["<<minimum->value.lo<<','
                 <<minimum->value.hi<<"] ";
        if (std::string_view(tag)=="actual_mixed") {
            const auto shape=EnclosePolarShape(.9,*state);
            if (!shape) return false;
            const auto amplitude=sqrt(shape->turning_mu2);
            double minimum_speed=std::numeric_limits<double>::infinity();
            double minimum_clearance=std::numeric_limits<double>::infinity();
            unsigned within=0, contact=0;
            std::vector<std::pair<std::size_t,Range>> turning_stars;
            for (const auto& star:sky) {
                const auto abs_z=Abs(star.z);
                if (abs_z.lo>amplitude.hi) continue;
                if (abs_z.hi>=amplitude.lo) {
                    ++contact;
                    turning_stars.emplace_back(&star-sky.data(),abs_z);
                    continue;
                }
                ++within;
                const auto z2=Square(abs_z);
                const auto speed=sqrt((shape->turning_mu2-z2)*(shape->omega2+shape->spin_energy2*z2));
                if (!speed.Finite()) return false;
                minimum_speed=std::min(minimum_speed,speed.lo);
                minimum_clearance=std::min(minimum_clearance,(amplitude-abs_z).lo);
            }
            std::cout<<" polar_turn_abs_mu=["<<amplitude.lo<<','<<amplitude.hi
                     <<"] catalogue_below_turn="<<within<<" catalogue_turn_contact="<<contact
                     <<" minimum_mu_speed="<<minimum_speed
                     <<" minimum_turn_clearance="<<minimum_clearance;
            const auto slope=SphericalAzimuthSlope(1,.9,Range(1.0)/minimum->inverse_radius);
            if (!slope.Finite()) return false;
            const auto radius=Range(1.0)/minimum->inverse_radius;
            std::cout<<" spherical_radius=["<<radius.lo<<','<<radius.hi<<']'
                     <<" spherical_azimuth_slope=["<<slope.lo<<','<<slope.hi<<']';
            bool transversality_certified=true;
            for (const auto& [star,abs_z]:turning_stars) {
                constexpr double margin=0x1p-27;
                const Range requested=abs_z+Range(-margin,margin);
                double h_lower=std::numeric_limits<double>::infinity();
                double h_upper=-h_lower;
                unsigned visited=0, retained=0;
                const auto cover=[&](this const auto& self, std::array<Range,2> box,
                                     unsigned depth) -> bool {
                    ++visited;
                    const auto launch=enclose_state(box[0],box[1]);
                    if (!launch) return false;
                    const auto polar=EnclosePolarShape(.9,*launch);
                    const auto radial=EncloseRadialMinimum(*launch);
                    if (!polar || !radial) return false;
                    const Range bound=sqrt(polar->turning_mu2);
                    if (bound.hi<requested.lo || bound.lo>requested.hi) return true;
                    if (radial->value.lo>0.0 || depth==16) {
                        ++retained;
                        h_lower=std::min(h_lower,radial->value.lo);
                        h_upper=std::max(h_upper,radial->value.hi);
                        return true;
                    }
                    const int axis=depth%2;
                    const auto [low,high]=box[axis];
                    const double mid=std::midpoint(low,high);
                    box[axis].hi=mid;
                    if (!self(box,depth+1)) return false;
                    box[axis]=Range(mid,high);
                    return self(box,depth+1);
                };
                if (!cover({z0,z1},0)) return false;
                std::cout<<" contact="<<star<<':'<<abs_z.lo<<','<<abs_z.hi
                         <<" contact_margin="<<margin<<" contact_boxes="<<visited
                         <<" retained_contact_boxes="<<retained
                         <<" contact_H=["<<h_lower<<','<<h_upper<<']';
                if (retained==0 || h_lower>0.0) {
                    const Range speed=sqrt(Range(margin)*(amplitude+abs_z)*shape->omega2);
                    if (!speed.Finite()) return false;
                    minimum_speed=std::min(minimum_speed,speed.lo);
                } else {
                    transversality_certified=false;
                }
            }
            if (transversality_certified) std::cout<<" escape_minimum_mu_speed="<<minimum_speed;
            const Range u=minimum->inverse_radius;
            const auto& c=state->coefficients;
            const Range curvature=Enclosure(c[2])+u*(Range(3.0)*Enclosure(c[3])+
                                                 u*Range(6.0)*Enclosure(c[4]));
            const Range period(kPiBounds.lo/sqrt(shape->omega2+
                                               shape->spin_energy2*shape->turning_mu2).hi,
                               kPiBounds.hi/sqrt(shape->omega2).lo);
            const Range exponent=sqrt(curvature)*Widen(period.lo,period.hi);
            if (!exponent.Finite()) return false;
            std::cout<<" critical_instability_exponent=["<<exponent.lo<<','<<exponent.hi<<"] ";
        }
        const auto phase=EncloseRadialScatteringPhase(1,.9,*state,64);
        if (phase) {
            std::cout<<"turn=["<<phase->turn.lo<<','<<phase->turn.hi
                     <<"] inner=["<<phase->inner.lo<<','<<phase->inner.hi
                     <<"] mino=["<<phase->mino.lo<<','<<phase->mino.hi<<']';
            const auto polar=EnclosePolarCrossings(.9,*state,*phase);
            if (polar) {
                const auto latitude=[&](const SkyStar& star) {
                    return star.z.lo<=polar->source_mu.hi && star.z.hi>=polar->source_mu.lo;
                };
                const auto angular=[&](const SkyStar& star) {
                    if (!latitude(star)) return false;
                    if (!star.phi.Finite()) return true;
                    const Range winding=(polar->source_phi-star.phi)/(Range(2.0)*kPiBounds);
                    return std::ceil(winding.lo)<=std::floor(winding.hi);
                };
                const auto phase_filter=[&](const SkyStar& star) {
                    if (!angular(star)) return false;
                    for (const auto& band:polar->sky) {
                        if (!band || star.z.lo>band->mu.hi || star.z.hi<band->mu.lo) continue;
                        if (!star.phi.Finite()) return true;
                        const Range k=(band->phi-star.phi)/(Range(2.0)*kPiBounds);
                        if (std::ceil(k.lo)<=std::floor(k.hi)) return true;
                    }
                    return false;
                };
                std::cout<<" half=["<<polar->half_period.lo<<','
                                <<polar->half_period.hi<<"] first=["<<polar->first_crossing.lo
                                <<','<<polar->first_crossing.hi<<"] crossings="<<polar->count
                                <<" source_mu=["<<polar->source_mu.lo<<','<<polar->source_mu.hi<<']'
                                <<" source_phi=["<<polar->source_phi.lo<<','<<polar->source_phi.hi<<']'
                                <<" catalogue_in_band="<<std::ranges::count_if(sky,latitude)
                                <<'/'<<sky.size()
                                <<" catalogue_in_rectangle="<<std::ranges::count_if(sky,angular)
                                <<'/'<<sky.size()
                                <<" catalogue_in_phase_union="<<std::ranges::count_if(sky,phase_filter)
                                <<'/'<<sky.size();
                if (z0.lo==z0.hi && z1.lo==z1.hi) {
                    for (const auto& band:polar->sky) {
                        if (band) std::cout<<" sector="<<band->mu.lo<<','<<band->mu.hi
                                          <<','<<band->phi.lo<<','<<band->phi.hi;
                    }
                }
            }
            if (z0.lo==z0.hi && z1.lo==z1.hi) {
                const auto point=camera.ProjectFilmOffsetForObserver(x,y,m01*z1.lo,
                    17+(m10*z0.lo+m11*z1.lo),sample.pupil_u,sample.pupil_v);
                if (!point) return false;
                const auto exact=core::LaunchCameraRay(metric,.9,point->ray);
                if (!exact) return false;
                std::cout<<" xk="<<std::hexfloat;
                for (int i=0;i<4;++i) std::cout<<exact->position(i)<<',';
                for (int i=0;i<4;++i) std::cout<<exact->tangent(i)<<(i==3?"":",");
                std::cout<<std::defaultfloat;
            }
        }
        else std::cout<<"unclassified";
        std::cout<<'\n';
        return true;
    };
    if (!record("adjacent_dark",Range(0x1.2b5p-1,0x1.2b6p-1),Range(0x1.fa74p+1,0x1.fa78p+1)) ||
        !record("actual_mixed",Range(lo[0],hi[0]),Range(lo[1],hi[1]))) return 2;
    for (const auto& node:nodes) {
        if (!record("node",Range(midX+node[0]*half),Range(midY+node[1]*half))) return 3;
    }
    const double sx=(hi[0]-lo[0])/32, sy=(hi[1]-lo[1])/32;
    for (unsigned i=0;i<4;++i) {
        for (unsigned j=0;j<4;++j) {
            if (!record("strip_box",Range(hi[0]-(i+1)*sx,hi[0]-i*sx),
                  Range(hi[1]-(j+1)*sy,hi[1]-j*sy))) return 4;
        }
    }
}

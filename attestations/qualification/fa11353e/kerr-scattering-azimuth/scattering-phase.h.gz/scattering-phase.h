#pragma once

#include "sirius/core/kerr_infinity.h"

namespace sirius::core::relativity::kerr_infinity_detail {

using finite_tail_detail::Range;

inline Range LogReduced(Range mantissa) {
    const auto z = (mantissa - Range(1.0)) / (mantissa + Range(1.0));
    const auto square = finite_tail_detail::Square(z);
    Range term = z, sum{};
    for (unsigned n = 1; n < 40; n += 2) {
        sum = sum + term / Range(n);
        term = term * square;
    }
    const double remainder = (Range(2.0) * finite_tail_detail::Abs(term) /
                              (Range(41.0) * (Range(1.0) - square))).hi;
    return Range(2.0) * sum + Range(-remainder, remainder);
}

inline Range LogPoint(double value) {
    if (!(value > 0.0) || !std::isfinite(value)) return finite_tail_detail::InvalidRange();
    if (value == 1.0) return Range(0.0);
    int exponent;
    const double mantissa = std::frexp(value, &exponent) * 2;
    const static Range log_two = LogReduced(Range(2.0));
    return LogReduced(Range(mantissa)) + Range(exponent - 1) * log_two;
}

inline Range AsinhNonnegative(Range argument) {
    if (!(argument.lo >= 0.0) || !argument.Finite()) return finite_tail_detail::InvalidRange();
    const Range input = argument + sqrt(Range(1.0) + finite_tail_detail::Square(argument));
    return Range(LogPoint(input.lo).lo, LogPoint(input.hi).hi);
}

template <typename Scalar>
std::optional<Range> BracketRadialZero(const std::array<Scalar, 5>& coefficients, double lo,
                                      double hi, bool positive_left) {
    using finite_tail_detail::Enclosure;
    const auto sign = [&](double value, bool positive) {
        const Range bounds = Enclosure(EvaluateRadial(coefficients, Scalar(value)));
        return positive ? bounds.lo > 0.0 : bounds.hi < 0.0;
    };
    if (!(lo < hi) || !sign(lo, positive_left) || !sign(hi, !positive_left)) return {};
    const auto tighten = [&](double proven, double other, bool positive) {
        for (unsigned i = 0; i < 42; ++i) {
            const double m = std::midpoint(proven, other);
            if (m == proven || m == other) break;
            if (sign(m, positive)) proven = m;
            else other = m;
        }
        return proven;
    };
    const double lower = tighten(lo, hi, positive_left);
    return Range(lower, tighten(hi, lower, !positive_left));
}

struct RadialScatteringPhase {
    Range turn, inner, mino, drag_residual, chart;
    double reference_drag;
};

template <typename Scalar>
std::optional<RadialScatteringPhase> EncloseRadialScatteringPhase(
    double mass, double spin, const DetectorRadialBounds<Scalar>& state, unsigned panels) {
    using finite_tail_detail::Enclosure;
    using finite_tail_detail::Square;
    if (!state.inward || panels == 0 || panels > 128) return {};
    const auto minimum = EncloseRadialMinimum(state);
    if (!minimum || !(minimum->value.hi < 0.0)) return {};
    const auto& c = state.coefficients;
    const auto turn = BracketRadialZero(c, state.start.hi, minimum->inverse_radius.lo, true);
    const auto inner = BracketRadialZero(c, minimum->inverse_radius.hi, state.horizon.lo, false);
    if (!turn || !inner) return {};
    const Range delta = *inner - *turn;
    if (!(delta.lo > 0.0)) return {};

    // H(u)=(u_turn-u)(u_inner-u)G(u). Evaluate the constant term
    // from H(0) and the other two terms by matching powers of u.
    const Range fourth = Enclosure(c[4]);
    const std::array quadratic{Enclosure(c[0]) / (*turn * *inner),
                               Enclosure(c[3]) + (*turn + *inner) * fourth, fourth};
    const Range a(spin), a2 = Square(a), two_mass(2.0 * mass);
    const auto delta_at = [&](Range u) { return Range(1.0) + u * (a2 * u - two_mass); };
    const Range drag_linear = a * two_mass * Enclosure(state.energy);
    const Range drag_quadratic = Range(0.0) - a2 * Enclosure(state.angular);
    const Range centre(std::midpoint(turn->lo, turn->hi));
    const Range model = centre * (drag_linear + centre * drag_quadratic) / delta_at(centre);
    if (!model.Finite()) return {};
    const double reference = std::midpoint(model.lo, model.hi);
    const std::array residual{Range(-reference), drag_linear + two_mass * Range(reference),
                               drag_quadratic - a2 * Range(reference)};
    const Range residual_at_centre = EvaluateRadial(residual, centre);
    Range phase{}, radial{}, chart{};
    for (const auto span : {*turn - state.start, *turn}) {
        if (!(span.lo > 0.0)) return {};
        for (unsigned i = 0; i < panels; ++i) {
            // t is exactly representable for the power-of-two panel counts in use.
            const Range a = Range(i) / Range(panels);
            const Range b = Range(i + 1) / Range(panels);
            const Range qa2 = Square(a) * span, qb2 = Square(b) * span;
            const Range u = *turn - Range(qa2.lo, qb2.hi);
            const Range quotient = EvaluateRadial(quadratic, u);
            if (!(quotient.lo > 0.0)) return {};
            // q²=u_turn-u. Weight the panel exactly by the integral
            // of dq/sqrt(delta+q²), using the difference of two asinh
            // values in rationalized form to preserve parameter correlation.
            const Range sinh_span = sqrt(span) * (b - a) * (b + a) /
                                    (b * sqrt(delta + qa2) + a * sqrt(delta + qb2));
            const Range weight = AsinhNonnegative(sinh_span);
            const Range panel = Range(2.0) * weight / sqrt(quotient);
            phase = phase + panel;
            const Range numerator = residual_at_centre + (u - centre) *
                (residual[1] + residual[2] * (u + centre));
            radial = radial + panel * numerator / delta_at(u);
        }
    }
    // The ingoing Kerr-Schild chart contribution is the same on the
    // two branches, with opposite signs in u. Only the net 0..u0 remains.
    constexpr unsigned chart_panels = 16;
    const Range width = state.start / Range(chart_panels);
    for (unsigned i = 0; i < chart_panels; ++i)
        chart = chart + a * width / delta_at(width * Range(i, i + 1));
    if (!phase.Finite() || !radial.Finite() || !chart.Finite()) return {};
    return RadialScatteringPhase{*turn, *inner, phase, radial, chart, reference};
}

inline Range SinePoint(double angle) {
    using finite_tail_detail::Square;
    const Range x(angle), x2 = Square(x);
    Range term = x, sum = x;
    for (unsigned n = 1; n <= 12; ++n) {
        term = term * x2 / Range((2*n)*(2*n+1));
        sum = n % 2 != 0 ? sum - term : sum + term;
    }
    // For 0 <= angle <= pi, the Taylor terms decrease after the
    // first term. Degree 27 gives the outward omitted-term bound.
    const double remainder = (term * x2 / Range(26*27)).hi;
    return Range((sum - Range(remainder)).lo, sum.hi);
}

inline constexpr Range kPiBounds{0x1.921fb54442d18p+1, 0x1.921fb54442d19p+1};

inline Range SineLobe(Range angle) {
    const double lower = std::max(0.0, angle.lo);
    const double upper = std::min(kPiBounds.hi, angle.hi);
    if (!(lower <= upper)) return finite_tail_detail::InvalidRange();
    const Range first = SinePoint(lower), last = SinePoint(upper);
    const bool includes_peak = lower <= kPiBounds.hi * 0.5 && upper >= kPiBounds.lo * 0.5;
    return Range(std::min(first.lo, last.lo),
                 includes_peak ? 1.0 : std::min(1.0, std::max(first.hi, last.hi)));
}

inline Range AtanSmall(Range x) {
    using finite_tail_detail::Abs;
    using finite_tail_detail::Square;
    const Range x2 = Square(x);
    Range term = x, sum = x;
    for (unsigned n = 1; n < 20; ++n) {
        term = term * x2;
        sum = n % 2 != 0 ? sum - term / Range(2*n+1) : sum + term / Range(2*n+1);
    }
    const double remainder = (Abs(term) * x2 / Range(41.0)).hi;
    return sum + Range(-remainder, remainder);
}

inline Range AtanPoint(double value) {
    const double magnitude = std::abs(value);
    const Range x(magnitude);
    const Range result = magnitude <= 0.5
                             ? AtanSmall(x)
                             : kPiBounds * Range(0.25) + AtanSmall((x - Range(1.0)) /
                                                                   (x + Range(1.0)));
    return value < 0.0 ? Range(-result.hi, -result.lo) : result;
}

inline Range AtanUnit(Range value) {
    if (!value.Finite() || finite_tail_detail::Magnitude(value) > 1.00000000000001)
        return finite_tail_detail::InvalidRange();
    return Range(AtanPoint(value.lo).lo, AtanPoint(value.hi).hi);
}

inline Range CatalogueAzimuth(double x, double y) {
    if (x == 0.0 && y == 0.0) return finite_tail_detail::InvalidRange();
    if (std::abs(x) >= std::abs(y)) {
        const auto theta = AtanUnit(Range(x < 0 ? -y : y) / Range(std::abs(x)));
        if (x < 0.0) return theta + (y >= 0.0 ? kPiBounds : Range(-kPiBounds.hi, -kPiBounds.lo));
        return theta;
    }
    const auto theta = AtanUnit(Range(x) / Range(std::abs(y)));
    return y > 0.0 ? kPiBounds * Range(0.5) - theta : theta - kPiBounds * Range(0.5);
}

template <typename Function>
Range EnclosePolarIntegral(Range extent, unsigned panels, const Function& integrand) {
    if (!extent.Finite() || !(extent.lo >= 0.0)) return finite_tail_detail::InvalidRange();
    constexpr unsigned max_panels = 128;
    if (panels == 0 || panels > max_panels) return finite_tail_detail::InvalidRange();
    using finite_tail_detail::Magnitude;
    using finite_tail_detail::Square;
    using finite_tail_detail::TaylorSeries;
    Range sum{};
    const Range width = Range(extent.lo) / Range(panels);
    for (unsigned i = 0; i <= panels; ++i) {
        const Range sample = integrand(Square(SineLobe(Range(i) * width)));
        sum = sum + sample * Range(i == 0 || i == panels ? 0.5 : 1.0);
    }
    // f = h(sin² psi). Since |(sin² psi)'| <= 1 and
    // |(sin² psi)''| <= 2, |f''| <= |h''| + 2|h'|.
    const auto derivatives = integrand(TaylorSeries<2>::Variable(0.0, 1.0));
    const Range second = Range(2.0) *
        (Range(Magnitude(derivatives.coefficient[2])) +
         Range(Magnitude(derivatives.coefficient[1])));
    const double error = (Range(extent.lo) * Square(width) * second / Range(12.0)).hi;
    const double rest = (Range(extent.hi) - Range(extent.lo)).hi;
    return width * sum + Range(-error, error) +
           Range(0.0, rest) * integrand(Square(SineLobe(extent)));
}

struct SkyBand {
    Range mu, phi;
};

struct PolarCrossings {
    Range half_period, first_crossing, source_mu, source_phi;
    std::array<std::optional<SkyBand>, 16> sky;
    unsigned count;
};

struct PolarShape {
    Range omega2, turning_mu2, spin_energy2;
};

template <typename Scalar>
std::optional<PolarShape> EnclosePolarShape(double spin, const DetectorRadialBounds<Scalar>& state) {
    using finite_tail_detail::Enclosure;
    using finite_tail_detail::Square;
    const Scalar a(spin);
    const Scalar scale = Square(a * state.energy);
    const Scalar carter_q = state.carter - Square(state.angular - a * state.energy);
    const Scalar b = scale - carter_q - Square(state.angular);
    if (!(Enclosure(carter_q).lo > 0.0)) return {};
    const Scalar omega = (sqrt(Square(b) + Scalar(4.0) * scale * carter_q) - b) * Scalar(0.5);
    const Range omega2 = Enclosure(omega);
    const Range turning_mu2 = Enclosure(carter_q / omega);
    if (!(turning_mu2.lo > 0.0 && turning_mu2.hi < 1.0)) return {};
    return PolarShape{omega2, turning_mu2, Enclosure(scale)};
}

// Derivative of the unwrapped azimuth per polar half-libration
// along the critical spherical family. The signed energy convention
// here is future-directed E=1. Reversing direction reverses the sign.
inline Range SphericalAzimuthSlope(double mass, double spin, Range radius) {
    using finite_tail_detail::Square;
    using Series = finite_tail_detail::TaylorSeries<1>;
    const Series r = Series::Variable(radius.lo, radius.hi);
    const Series m(mass), a(spin);
    const Series r2 = r*r, a2 = a*a;
    const Series lambda = (r2*(Series(3.0)*m-r)-a2*(r+m))/(a*(r-m));
    const Series q = r2*r*(Series(4.0)*a2*m-r*(r-Series(3.0)*m)*(r-Series(3.0)*m))/
                     (a2*(r-m)*(r-m));
    const Series b = a2-q-lambda*lambda;
    const Series omega2 = (sqrt(b*b+Series(4.0)*a2*q)-b)*Series(0.5);
    const Series mu2 = q/omega2;
    const Series drag = a*(Series(2.0)*m*r-a*lambda)/(r2-Series(2.0)*m*r+a2);

    constexpr unsigned panels = 128;
    Range result{};
    const Range width = kPiBounds / Range(panels);
    for (unsigned i = 0; i < panels; ++i) {
        const Series s(Square(SineLobe(width * Range(i,i+1))));
        const Series az = (lambda / (Series(1.0)-mu2*s) + drag) /
                          sqrt(omega2+a2*mu2*s);
        result = result + width*az.coefficient[1];
    }
    return result;
}

template <typename Scalar>
std::optional<PolarCrossings> EnclosePolarCrossings(double spin,
                                                   const DetectorRadialBounds<Scalar>& state,
                                                   const RadialScatteringPhase& radial) {
    const Range mino = radial.mino;
    using finite_tail_detail::Abs;
    using finite_tail_detail::Enclosure;
    using finite_tail_detail::Square;
    const auto shape = EnclosePolarShape(spin, state);
    if (!shape) return {};
    const auto& [omega2, turning_mu2, scale] = *shape;
    const Range modulation = scale * turning_mu2;
    const Range m = modulation / omega2;
    if (!(m.lo >= 0.0 && m.hi < 1.0)) return {};
    // After mu = sqrt(mu_turn^2) sin(psi), the half-period is the
    // average of (1 + m sin^2(psi))^(-1/2) on [0,pi], times pi/omega.
    // The alternating binomial expansion of that average has terms
    // C(2k,k)^2 m^k / 16^k. The first omitted term bounds the error.
    Range term(1.0), sum(1.0);
    for (unsigned k = 1; k <= 9; ++k) {
        term = term * Square(Range(2*k-1) / Range(2*k)) * m;
        if (k == 9) {
            sum = sum - Range(0.0, term.hi);
            break;
        }
        sum = k % 2 != 0 ? sum - term : sum + term;
    }
    const Range period = kPiBounds * sum / sqrt(omega2);
    const Range q = Abs(Enclosure(state.mu)) / sqrt(turning_mu2);
    if (!(q.hi < 1.0)) return {};
    // Integrate from the equator to |mu_0|. After substituting
    // t=sin(psi), both factors can be bounded directly on 0<=t<=q.
    const Range q2 = Square(q);
    const Range to_equator(
        (q / sqrt(omega2 + modulation * q2)).lo,
        (q / (sqrt(omega2) * sqrt(Range(1.0) - q2))).hi);
    const Range outward = Enclosure(state.mu * state.mu_rate);
    if (!(outward.lo > 0.0 || outward.hi < 0.0)) return {};
    const Range next = outward.lo > 0.0 ? period - to_equator : to_equator;
    const Range laps = (mino - next) / period;
    if (!laps.Finite() || laps.hi >= 10000.0) return {};
    const auto count = [](double x) {
        return x < 0.0 ? 0U : static_cast<unsigned>(std::floor(x)) + 1;
    };
    const unsigned crossings = count(laps.lo);
    if (crossings == 0 || crossings != count(laps.hi)) return {};
    const Range initial_mu = Enclosure(state.mu);
    if (!(initial_mu.lo > 0.0 || initial_mu.hi < 0.0)) return {};
    const Range elapsed = mino - next - Range(crossings - 1) * period;
    const Range travel = elapsed * Range(sqrt(omega2).lo, sqrt(omega2 + modulation).hi);
    if (!travel.Finite()) return {};
    const Range final_angle(std::max(0.0, travel.lo), std::min(kPiBounds.hi, travel.hi));
    const Range sine = SineLobe(final_angle);
    const double sign = (initial_mu.lo > 0.0) == (crossings % 2 == 0) ? 1.0 : -1.0;

    const Range angular = Enclosure(state.angular);
    const auto polar_rate = [&](auto sine2) {
        using Number = decltype(sine2);
        return Number(angular) / (Number(1.0) - Number(turning_mu2) * sine2);
    };
    const auto speed = [&](auto sine2) {
        using Number = decltype(sine2);
        return sqrt(Number(omega2) + Number(modulation) * sine2);
    };
    const auto time_integrand = [&](auto sine2) {
        using Number = decltype(sine2);
        return Number(1.0) / speed(sine2);
    };
    const Range mean = EnclosePolarIntegral(kPiBounds, 128, [&](auto sine2) {
        return polar_rate(sine2) / speed(sine2);
    }) / period;
    const auto periodic_integrand = [&](auto sine2) {
        using Number = decltype(sine2);
        return (polar_rate(sine2) - Number(mean)) / speed(sine2);
    };
    // For these launches |sin psi0| < 1/sqrt(2). Reflection in the
    // adjacent equator controls the sign of the initial residual.
    const Range initial_angle = AtanUnit(q / sqrt(Range(1.0) - q2));
    const Range from_launch = Range(outward.lo > 0.0 ? -1.0 : 1.0) *
                              EnclosePolarIntegral(initial_angle, 24, periodic_integrand);
    const Range final = EnclosePolarIntegral(final_angle, 64, periodic_integrand);
    const Range phi0 = AtanUnit(Enclosure(state.ny / state.nx));

    // Both residuals stay bounded through this finite winding band.
    // The full half periods contribute only their mean rate.
    const Range rate = mean + Range(radial.reference_drag);
    const Range fixed = phi0 + radial.drag_residual + radial.chart + from_launch;
    const Range phi = fixed + rate * mino + final;
    if (!(Enclosure(state.nx).lo > 0.0) || !phi.Finite() || !sine.Finite()) return {};

    // Keep the same polar phase in both sky coordinates. Time increases
    // with the polar angle in the current half oscillation.
    const Range amplitude = Range(sign) * sqrt(turning_mu2);
    const Range before_final = next + Range(crossings - 1) * period;
    const Range phi_before_final = fixed + rate * before_final;
    const auto coupled_integrand = [&](auto sine2) {
        using Number = decltype(sine2);
        return (polar_rate(sine2) + Number(radial.reference_drag)) / speed(sine2);
    };
    PolarCrossings result{period, next, amplitude * sine, phi, {}, crossings};
    const auto edge = [&](std::size_t i) {
        return std::lerp(final_angle.lo, final_angle.hi, double(i) / double(result.sky.size()));
    };
    for (std::size_t i = 0; i < result.sky.size(); ++i) {
        const Range angle(edge(i), edge(i + 1));
        const Range phase = before_final + EnclosePolarIntegral(angle, 64, time_integrand);
        if (!phase.Finite()) return {};
        const Range time(std::max(phase.lo, mino.lo), std::min(phase.hi, mino.hi));
        if (time.lo > time.hi) continue;
        // Combine the secular radial drag with the polar integral
        // at the same phase. This avoids interval subtraction between
        // the final time and the mean term of the polar correction.
        const Range part = phi_before_final + EnclosePolarIntegral(angle, 64, coupled_integrand);
        const Range part_mu = amplitude * SineLobe(angle);
        if (!part.Finite() || !part_mu.Finite()) return {};
        const Range part_phi(std::max(phi.lo, part.lo), std::min(phi.hi, part.hi));
        if (part_phi.lo > part_phi.hi) continue;
        result.sky[i] = SkyBand{part_mu, part_phi};
    }
    return result;
}

} // namespace sirius::core::relativity::kerr_infinity_detail

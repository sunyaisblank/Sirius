"""Independent high precision radial and scalar polar reference for two camera rays."""

from decimal import Decimal as D, localcontext
import math
from pathlib import Path
import re

A = D.from_float(0.9)


def constants(launch):
    _, x, y, z, _, kx, ky, kz = [D.from_float(float.fromhex(v)) for v in launch.split(",")]
    s = x*x+y*y+z*z-A*A
    r2 = (s+(s*s+4*A*A*z*z).sqrt())/2
    r = r2.sqrt()
    mu = z/r
    sigma = r2 + A*A*mu*mu
    ellx, elly = (r*x+A*y)/(r2+A*A), (r*y-A*x)/(r2+A*A)
    h = 2*r/sigma
    dot = ellx*kx + elly*ky + mu*kz
    spatial2 = kx*kx + ky*ky + kz*kz
    kt = (h*dot-(h*dot*dot+(1-h)*spatial2).sqrt())/(1-h)
    correction = h*(kt+dot)
    energy = kt-correction
    angular = x*(ky+correction*elly)-y*(kx+correction*ellx)
    r_rate = (r*(x*kx+y*ky)+(r2+A*A)*mu*kz)/sigma
    mu_rate = sigma*(kz-mu*r_rate)/r
    q = (mu_rate*mu_rate+mu*mu*angular*angular)/(1-mu*mu)-mu*mu*A*A*energy*energy
    return 1/r, energy, angular, q, mu, mu_rate, math.atan2(float(elly), float(ellx))


def radial(u0, energy, angular, carter, panels):
    z = A*A*energy-A*angular
    c = carter+(angular-A*energy)**2
    coefficients = [energy*energy, D(0), 2*energy*z-c, 2*c, z*z-A*A*c]

    def poly(coeff, radius):
        value = coeff[-1]
        for field in reversed(coeff[:-1]):
            value = field+value*radius
        return value

    # Fixed brackets are derived from the signs of the independent decimal
    # polynomial, with the recorded neighbourhood bounded by 0.54 and 0.55.
    middle = D(".5473496")
    assert poly(coefficients, middle) < 0

    def root(low, high, positive_left):
        for _ in range(210):
            m = (low+high)/2
            if (poly(coefficients, m) > 0) == positive_left:
                low = m
            else:
                high = m
        return (low+high)/2

    turn = root(D(".54"), middle, True)
    other = root(middle, D(".55"), False)
    # Single-root synthetic division. Integrate the entire transformed
    # integrand using a fixed four-node Gauss rule in a separately scaled
    # hyperbolic parameter. No interval brackets or panel weights are used.
    factor = [-coefficients[4]]
    for v in reversed(coefficients[1:4]):
        factor.append(turn*factor[-1]-v)
    factor.reverse()
    scale = D(".02")

    def f(s):
        exponential = s.exp()
        q = scale*(exponential-1/exponential)/2
        q_rate = scale*(exponential+1/exponential)/2
        u = turn-q*q
        mino_rate = 2*q_rate/poly(factor,u).sqrt()
        drag = (2*A*energy*u-A*A*angular*u*u)/(1-2*u+A*A*u*u)
        return mino_rate, mino_rate*drag

    offset = (D(6)/5).sqrt()*2
    offsets = [((3+offset)/7).sqrt(), ((3-offset)/7).sqrt()]
    weights = [(18-D(30).sqrt())/72, (18+D(30).sqrt())/72]
    phase = D(0)
    azimuth = D(0)
    for span in (turn-u0, turn):
        q = span.sqrt()/scale
        width = (q+(1+q*q).sqrt()).ln()/panels
        for i in range(panels):
            midpoint = (D(i)+D(".5"))*width
            for node, weight in zip(offsets, weights, strict=True):
                half_offset = width*node/2
                minus, phi_minus = f(midpoint-half_offset)
                plus, phi_plus = f(midpoint+half_offset)
                phase += width*weight*(minus+plus)
                azimuth += width*weight*(phi_minus+phi_plus)
    horizon = (1-A*A).sqrt()
    chart = A/(2*horizon)*((1-(1-horizon)*u0)/(1-(1+horizon)*u0)).ln()
    return turn, other, phase, azimuth+chart


def scalar_polar(energy, angular, carter, mu, mu_rate, initial_phi, phase, radial_phi):
    a = float((A*energy)**2)
    l = float(angular)
    q = float(carter)
    b = a-q-l*l
    omega2 = (math.hypot(b, 2*math.sqrt(a*q))-b)/2
    amplitude = math.sqrt(q/omega2)
    scale = a*amplitude*amplitude

    def integrate(angle, panels=512, azimuth=False):
        dx = angle/panels
        values = []
        for j in range(panels+1):
            sine2 = math.sin(j*dx)**2
            time = 1/math.sqrt(omega2+scale*sine2)
            values.append(time*l/(1-amplitude**2*sine2) if azimuth else time)
        return dx/3*sum(value*(1 if j in {0, panels} else (4 if j % 2 else 2))
                        for j, value in enumerate(values))

    half = integrate(math.pi)
    initial_angle = math.asin(abs(float(mu))/amplitude)
    equator = integrate(initial_angle)
    first = half-equator if mu*mu_rate > 0 else equator
    n = 1+math.floor((float(phase)-first)/half)
    elapsed = float(phase)-first-(n-1)*half
    lo, hi = 0.0, math.pi
    for _ in range(48):
        mid = (lo+hi)/2
        if integrate(mid) < elapsed:
            lo = mid
        else:
            hi = mid
    final_angle = (hi+lo)/2
    sky_mu = math.copysign(1, float(mu))*(-1)**n*amplitude*math.sin(final_angle)
    polar_half = integrate(math.pi, azimuth=True)
    initial_to_crossing = integrate(initial_angle, azimuth=True)
    if mu*mu_rate > 0:
        initial_to_crossing = polar_half-initial_to_crossing
    sky_phi = (initial_phi+float(radial_phi)+initial_to_crossing
               +(n-1)*polar_half+integrate(final_angle, azimuth=True))
    return half, first, n, sky_mu, sky_phi


lines = Path(__file__).with_name("phase.log").read_text().splitlines()
with localcontext() as ctx:
    ctx.prec = 64
    for line in (line for line in lines if "xk=" in line):
        args = constants(line.split("xk=", 1)[1])
        coarse = radial(*args[:4], panels=128)
        fine = radial(*args[:4], panels=256)
        gap = abs(coarse[2] - fine[2])
        azimuth_gap = abs(coarse[3] - fine[3])
        assert gap < D("2e-12") and azimuth_gap < D("1e-11"), (gap, azimuth_gap)
        half, first, count, mu, phi = scalar_polar(*args[1:], *fine[2:])
        expected = dict(zip(("turn", "inner", "mino", "half", "first", "source_mu", "source_phi"),
                            (*fine[:3], half, first, mu, phi), strict=True))
        for name, value in expected.items():
            lower, upper = re.search(rf" {name}=\[([^,]+),([^\]]+)\]", line).groups()
            assert D(lower) <= D(value) <= D(upper), (name, lower, value, upper)
        sectors = [tuple(map(float, sector.split(",")))
                   for sector in re.findall(r" sector=([^ ]+)", line)]
        assert any(z0 <= mu <= z1 and p0 <= phi <= p1 for z0, z1, p0, p1 in sectors)
        assert f"crossings={count}" in line
        print({name: str(value) for name, value in expected.items()} | {
            "polar_crossings": count, "radial_refinement_gap": str(gap),
            "radial_azimuth_refinement_gap": str(azimuth_gap),
        })


def spherical_twist(radius):
    a = float(A)
    delta = radius**2-2*radius+a*a
    p = 2*radius*delta/(radius-1)
    angular = (radius**2+a*a-p)/a
    carter = p*p/delta-(angular-a)**2
    b = a*a-carter-angular*angular
    omega2 = (math.hypot(b,2*a*math.sqrt(carter))-b)/2
    mu2 = carter/omega2
    drag = a*(p/delta-1)
    panels = 1024
    step = math.pi/panels
    total = 0.0
    for i in range(panels+1):
        s2 = math.sin(i*step)**2
        f = (angular/(1-mu2*s2)+drag)/math.sqrt(omega2+a*a*mu2*s2)
        total += f*(1 if i in {0,panels} else (4 if i % 2 else 2))
    return step*total/3

mixed = next(row for row in lines if row.startswith("actual_mixed"))
number = r"([^,]+),([^\]]+)"
r0, r1 = map(float, re.search(r" spherical_radius=\["+number+r"\]",mixed).groups())
low, high = map(float, re.search(r" spherical_azimuth_slope=\["+number+r"\]",mixed).groups())
centre = (r0+r1)/2
derivatives = [(spherical_twist(centre+step)-spherical_twist(centre-step))/(2*step)
               for step in (1e-5, 5e-6)]
assert low < min(derivatives) <= max(derivatives) < high
assert abs(derivatives[0]-derivatives[1]) < 1e-7
print({"spherical_azimuth_slope": derivatives[1], "refinement_gap": abs(derivatives[0]-derivatives[1])})

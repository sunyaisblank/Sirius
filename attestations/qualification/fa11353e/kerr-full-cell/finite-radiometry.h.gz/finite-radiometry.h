#pragma once

#include "finite-screen.h"
#include "sirius/core/spectral/point_source_transfer.h"

namespace sirius::core::relativity::finite_tail_detail {

inline std::optional<Range> RepresentedStarNormalizer(double temperature) {
    const auto source=spectral::BlackbodyBandRgb(temperature);
    if (!source || !std::isfinite(source->r) || !std::isfinite(source->g) ||
        !std::isfinite(source->b)) return {};
    return Range(std::max({source->r,source->g,source->b,.001f}));
}

// Enclose the shifted 32-bin band using the represented source normalizer
// and outward Planck arithmetic.
inline std::optional<std::array<Range,3>> EncloseFiniteStarColour(double temperature, Range g) {
    const auto normalizer=RepresentedStarNormalizer(temperature);
    if (!normalizer) return {};
    const Range shifted=Range(temperature)*g;
    constexpr double step=(constants::spectral::kLambdaMax-
                           constants::spectral::kLambdaMin)/32.0;
    std::array<Range,3> xyz{};
    for (unsigned i=0;i<32;++i) {
        const double lambda=constants::spectral::kLambdaMin+(i+.5)*step;
        const auto weights=spectral::WavelengthToXyz(lambda*1e9);
        const Range wavelength(lambda),wave5=Square(Square(wavelength))*wavelength;
        const Range argument=Range(constants::physical::kPlanckC2)/(wavelength*shifted);
        const Range denominator=wave5*(ExpBounds(argument)-Range(1.0));
        const Range sample=Range(constants::physical::kPlanckC1)*Range(step)/denominator;
        xyz[0]=xyz[0]+sample*Range(weights.X);
        xyz[1]=xyz[1]+sample*Range(weights.Y);
        xyz[2]=xyz[2]+sample*Range(weights.Z);
    }
    // Transform unit XYZ axes through the production D65 matrix to
    // retain the same rational coefficient authority.
    constexpr auto X=colour::XyzD65ToLinearSrgb(1.0,0.0,0.0);
    constexpr auto Y=colour::XyzD65ToLinearSrgb(0.0,1.0,0.0);
    constexpr auto Z=colour::XyzD65ToLinearSrgb(0.0,0.0,1.0);
    constexpr std::array<std::array<double,3>,3> rows{{{X.r,Y.r,Z.r},
                                                       {X.g,Y.g,Z.g},
                                                       {X.b,Y.b,Z.b}}};
    const auto centre=spectral::TransferPointSourceBand(temperature,std::midpoint(g.lo,g.hi),
                                                        1.0,1.0);
    if (!centre) return {};
    std::array<Range,3> rgb;
    for (unsigned channel=0;channel<3;++channel) {
        Range value{};
        for (unsigned axis=0;axis<3;++axis) {
            const double coefficient=rows[channel][axis];
            value=value+xyz[axis]*Widen(coefficient,coefficient);
        }
        if (!value.Finite()) return {};
        rgb[channel]=Range(std::max(value.lo,0.0),std::max(value.hi,0.0))/ *normalizer;
        if (!rgb[channel].Finite() || (*centre)[channel]<rgb[channel].lo ||
            (*centre)[channel]>rgb[channel].hi) return {};
    }
    return rgb;
}

} // namespace sirius::core::relativity::finite_tail_detail

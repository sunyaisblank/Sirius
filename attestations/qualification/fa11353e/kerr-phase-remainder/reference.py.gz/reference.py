"""Independent high precision radial and scalar polar reference for two camera rays."""

from decimal import Decimal as D, localcontext
import math
from pathlib import Path
import re

A = D.from_float(0.9)


def constants(launch):
    _, x, y, z, _, kx, ky, kz = [D.from_float(float.fromhex(v)) for v in launch.split(",")]
    s = x*x+y*y+z*z-A*A
    r2 = (s+(s*s+4*A*A*z*z).sqrt())/2
    r = r2.sqrt()
    mu = z/r
    sigma = r2 + A*A*mu*mu
    ellx, elly = (r*x+A*y)/(r2+A*A), (r*y-A*x)/(r2+A*A)
    h = 2*r/sigma
    dot = ellx*kx + elly*ky + mu*kz
    spatial2 = kx*kx + ky*ky + kz*kz
    kt = (h*dot-(h*dot*dot+(1-h)*spatial2).sqrt())/(1-h)
    correction = h*(kt+dot)
    energy = kt-correction
    angular = x*(ky+correction*elly)-y*(kx+correction*ellx)
    r_rate = (r*(x*kx+y*ky)+(r2+A*A)*mu*kz)/sigma
    mu_rate = sigma*(kz-mu*r_rate)/r
    q = (mu_rate*mu_rate+mu*mu*angular*angular)/(1-mu*mu)-mu*mu*A*A*energy*energy
    return 1/r, energy, angular, q, mu, mu_rate, math.atan2(float(elly), float(ellx))


def coefficients(lam, eta):
    z = A*A-A*lam
    c = eta+(lam-A)**2
    return [D(1),D(0),2*z-c,2*c,z*z-A*A*c]


def eval_at(coef,u):
    out = coef[-1]
    for value in reversed(coef[:-1]):
        out = out*u+value
    return out


def bracket(row,key):
    return tuple(map(D,re.search(rf" {key}=\[([^,]+),([^\]]+)\]",row).groups()))


def assert_enclosed(bounds,value):
    assert bounds[0] <= value <= bounds[1], (bounds, value)


def inverse_by_newton(u,h):
    # Solve H(u)=h and H'(u)=0 directly for pz=a²-aλ and C.
    # This does not use the candidate's quadratic inversion.
    u2 = u*u
    delta = 1-2*u+A*A*u2
    du_delta = -2+2*A*A*u
    radial_measure = delta*u2
    du_measure = du_delta*u2+2*u*delta
    z = D("-1.15")
    c = D("9.65")
    for _ in range(10):
        p = 1+z*u2
        f = p*p-radial_measure*c-h
        g = 4*z*u*p-du_measure*c
        fz, fc = 2*p*u2, -radial_measure
        gz, gc = 4*u*(1+2*z*u2), -du_measure
        det = fz*gc-fc*gz
        z -= (f*gc-g*fc)/det
        c -= (fz*g-gz*f)/det
    lam = (A*A-z)/A
    eta = c-(lam-A)**2
    co = coefficients(lam,eta)
    assert abs(eval_at(co,u)-h) < D("1e-84")
    return co


def root(co,u,s,sign):
    # The reference evaluates the complete quartic in 92-digit Decimal,
    # even when the full inverse-radius separation is below binary64.
    inside, outside = D(0), s
    assert eval_at(co,u+D(sign)*outside) > 0
    for _ in range(192):
        middle = (inside+outside)/2
        if eval_at(co,u+D(sign)*middle) > 0:
            outside = middle
        else:
            inside = middle
    return (outside+inside)/(2*s)


def full_integrals(u, s, start, panels):
    # Reconstruct the normalized potential with the independent 2D
    # Newton equations, then remove only its simple exterior root.
    co = inverse_by_newton(u, -s*s)
    outer = u-s*root(co,u,s,-1)
    inner = u+s*root(co,u,s,1)
    gap = inner-outer
    factor = [-co[4]]
    for term in reversed(co[1:4]):
        factor.append(outer*factor[-1]-term)
    factor.reverse()
    coefficient = (gap/eval_at(factor,outer)).sqrt()
    carter = co[3]/2
    z = (co[2]+carter)/2
    angular = (A*A-z)/A

    def drag(v):
        return (2*A*v-A*A*angular*v*v)/(1-2*v+A*A*v*v)

    at_turn = drag(outer)
    # Independent single-root quadrature of both full integrals. This
    # uses a different hyperbolic scale and does not subtract a singular
    # contribution inside the integrand or use the candidate panel bounds.
    scale = D(".85")*s.sqrt()

    def rate(t):
        exp = t.exp()
        q = scale*(exp-1/exp)/2
        dq = scale*(exp+1/exp)/2
        v = outer-q*q
        t_rate = 2*dq/eval_at(factor,v).sqrt()
        return t_rate, t_rate*drag(v)

    time, spin = D(0), D(0)
    offsets = [((3+sign*2*(D(6)/5).sqrt())/7).sqrt() for sign in (1,-1)]
    weights = [(18-sign*D(30).sqrt())/72 for sign in (1,-1)]
    for span in (outer-start, outer):
        q = span.sqrt()/scale
        measure = (q+(1+q*q).sqrt()).ln()/panels
        for i in range(panels):
            centre=(D(i)+D(".5"))*measure
            for node,weight in zip(offsets,weights,strict=True):
                delta = measure*node/2
                a_time,a_spin=rate(centre-delta)
                b_time,b_spin=rate(centre+delta)
                time+=measure*weight*(a_time+b_time)
                spin+=measure*weight*(a_spin+b_spin)
    return time+2*coefficient*s.ln(), spin-at_turn*time, time, coefficient, at_turn


lines = Path(__file__).with_name("chart.log").read_text().splitlines()
row = next(x for x in lines if x.startswith("remainder"))
target = next(x for x in lines if x.startswith("target"))
scaled = next(x for x in lines if x.startswith("scaling"))
with localcontext() as ctx:
    ctx.prec = 92
    centre = sum(bracket(target,"u"))/2
    start = sum(bracket(row,"inverse_start"))/2
    scale_max = bracket(scaled,"s")[1]
    for s in (D("1e-30"), D("1e-7"), scale_max/2):
        coarse=full_integrals(centre,s,start,384)
        truth=full_integrals(centre,s,start,768)
        gap=abs(coarse[0]-truth[0])+abs(coarse[1]-truth[1])
        assert gap < D("5e-9"), (s,gap)
        results = dict(zip(("time","spin","mino","leading_factor","limiting_drag"),truth,strict=True))
        u_delta=D("1e-9")
        u_left=full_integrals(centre-u_delta,s,start,768)
        u_right=full_integrals(centre+u_delta,s,start,768)
        results["time_radial"]=(u_right[0]-u_left[0])/(2*u_delta)
        results["spin_radial"]=(u_right[1]-u_left[1])/(2*u_delta)
        results["leading_radial"]=(u_right[3]-u_left[3])/(2*u_delta)
        results["drag_radial"]=(u_right[4]-u_left[4])/(2*u_delta)
        fraction=D("1e-5")
        lower=s*(1-fraction)
        higher=s*(1+fraction)
        s_left=full_integrals(centre,lower,start,768)
        s_right=full_integrals(centre,higher,start,768)
        l_width=higher.ln()-lower.ln()
        results["time_log_derivative"]=(s_right[2]-s_left[2])/l_width
        if s > D("1e-10"):
            results["time_log_scale"]=(s_right[0]-s_left[0])/l_width
            results["spin_log_scale"]=(s_right[1]-s_left[1])/l_width
            results["drag_scale"]=(s_right[4]-s_left[4])/(higher-lower)
            value=lambda key: D(re.search(rf" {key}=([^ ]+)",row)[1])
            decay=s*(value("spin_decay_constant")-value("spin_decay_log_coefficient")*s.ln())
            assert abs(results["spin_log_scale"]) <= decay
        for key,value in results.items():
            if key!="mino":
                assert_enclosed(bracket(row,key),value)
        print({"s":str(s),"refinement_gap":str(gap), **{key:str(value) for key,value in results.items()}})

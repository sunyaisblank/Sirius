"""Independent high precision radial and scalar polar reference for two camera rays."""

from decimal import Decimal as D, localcontext
import math
from pathlib import Path
import re

A = D.from_float(0.9)


def constants(launch):
    _, x, y, z, _, kx, ky, kz = [D.from_float(float.fromhex(v)) for v in launch.split(",")]
    s = x*x+y*y+z*z-A*A
    r2 = (s+(s*s+4*A*A*z*z).sqrt())/2
    r = r2.sqrt()
    mu = z/r
    sigma = r2 + A*A*mu*mu
    ellx, elly = (r*x+A*y)/(r2+A*A), (r*y-A*x)/(r2+A*A)
    h = 2*r/sigma
    dot = ellx*kx + elly*ky + mu*kz
    spatial2 = kx*kx + ky*ky + kz*kz
    kt = (h*dot-(h*dot*dot+(1-h)*spatial2).sqrt())/(1-h)
    correction = h*(kt+dot)
    energy = kt-correction
    angular = x*(ky+correction*elly)-y*(kx+correction*ellx)
    r_rate = (r*(x*kx+y*ky)+(r2+A*A)*mu*kz)/sigma
    mu_rate = sigma*(kz-mu*r_rate)/r
    q = (mu_rate*mu_rate+mu*mu*angular*angular)/(1-mu*mu)-mu*mu*A*A*energy*energy
    return 1/r, energy, angular, q, mu, mu_rate, math.atan2(float(elly), float(ellx))


def coefficients(lam, eta):
    z = A*A-A*lam
    c = eta+(lam-A)**2
    return [D(1),D(0),2*z-c,2*c,z*z-A*A*c]


def eval_at(coef,u):
    out = coef[-1]
    for value in reversed(coef[:-1]):
        out = out*u+value
    return out


def bracket(row,key):
    return tuple(map(D,re.search(rf" {key}=\[([^,]+),([^\]]+)\]",row).groups()))


def assert_enclosed(bounds,value):
    assert bounds[0] <= value <= bounds[1], (bounds, value)


def inverse_by_newton(u,h):
    # Solve H(u)=h and H'(u)=0 directly for pz=a²-aλ and C.
    # This does not use the candidate's quadratic inversion.
    u2 = u*u
    delta = 1-2*u+A*A*u2
    du_delta = -2+2*A*A*u
    radial_measure = delta*u2
    du_measure = du_delta*u2+2*u*delta
    z = D("-1.15")
    c = D("9.65")
    for _ in range(10):
        p = 1+z*u2
        f = p*p-radial_measure*c-h
        g = 4*z*u*p-du_measure*c
        fz, fc = 2*p*u2, -radial_measure
        gz, gc = 4*u*(1+2*z*u2), -du_measure
        det = fz*gc-fc*gz
        z -= (f*gc-g*fc)/det
        c -= (fz*g-gz*f)/det
    lam = (A*A-z)/A
    eta = c-(lam-A)**2
    co = coefficients(lam,eta)
    assert abs(eval_at(co,u)-h) < D("1e-84")
    return co


def root(co,u,s,sign):
    # The reference evaluates the complete quartic in 92-digit Decimal,
    # even when the full inverse-radius separation is below binary64.
    inside, outside = D(0), s
    assert eval_at(co,u+D(sign)*outside) > 0
    for _ in range(192):
        middle = (inside+outside)/2
        if eval_at(co,u+D(sign)*middle) > 0:
            outside = middle
        else:
            inside = middle
    return (outside+inside)/(2*s)


lines = Path(__file__).with_name("chart.log").read_text().splitlines()
target = next(line for line in lines if line.startswith("target"))
scaled = next(line for line in lines if line.startswith("scaling"))
with localcontext() as ctx:
    ctx.prec = 92
    for row in (line for line in lines if line.startswith("point")):
        _, energy, angular, q, *_ = constants(row.split("xk=",1)[1])
        lam, eta = angular/energy, q/(energy*energy)
        co=coefficients(lam,eta)
        deriv=[D(i)*coef for i,coef in enumerate(co) if i]
        l,r=D("0.54"),D("0.56")
        for _ in range(190):
            u=(l+r)/2
            if eval_at(deriv,u) < 0:
                l=u
            else:
                r=u
        u=(l+r)/2
        h=eval_at(co,u)
        for key,value in (("u",u),("H",h),("lambda",lam),("eta",eta)):
            assert_enclosed(bracket(row,key),value)
        print({"u":str(u),"H":str(h),"lambda":str(lam),"eta":str(eta)})
    positions=bracket(target,"u")
    upper=bracket(scaled,"s")[1]
    for u,s in ((positions[0],D("1e-30")),
                (sum(positions)/2,D("1e-14")),
                (positions[1],upper/2)):
        co=inverse_by_newton(u,-s*s)
        first,second=root(co,u,s,-1),root(co,u,s,1)
        assert_enclosed(bracket(scaled,"turn_offset"),first)
        assert_enclosed(bracket(scaled,"inner_offset"),second)
        assert_enclosed(bracket(scaled,"gap_over_s"),first+second)
        print({"s":str(s),"gap_over_s":str(first+second)})

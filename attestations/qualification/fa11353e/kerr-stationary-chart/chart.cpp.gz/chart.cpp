#include "sirius/backend/cpu/geodesic_tracer.h"
#include "stationary-chart.h"
#include "sirius/core/camera_sampling.h"
#include <array>
#include <iomanip>
#include <iostream>

using namespace sirius;
int main() {
    core::CameraConfig config;
    config.r=30;
    config.theta=80*core::constants::math::kPi/180.0;
    config.fov=60;
    config.width=1920;
    config.height=1080;
    config.beta_x=.1;
    config.beta_y=.02;
    config.beta_z=-.01;
    config.focal_length=50;
    config.aperture=2.8f;
    config.focus_distance=30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1,.9));
    core::CameraSample sample;
    bool first=true;
    core::ForEachCameraSample(4,[&](auto next) {
        if (first) sample=next;
        first=false;
    });
    constexpr std::array lo{0x1.2b6p-1,0x1.fa7cp+1}, hi{0x1.2b7p-1,0x1.fa8p+1};
    constexpr double m01=-0x1.d357ebd0e3748p-1, m10=0x1.d30c6a29fa83fp-1;
    constexpr double m11=0x1.e454f19fc15dep-9;
    using Coordinate=std::array<double,2>;
    using namespace core::relativity::finite_tail_detail;
    using namespace core::relativity::kerr_infinity_detail;
    const double x=896+double(sample.image_u), y=576+double(sample.image_v);
    const auto central=camera.ProjectFilmForObserver(x,y,sample.pupil_u,sample.pupil_v);
    if (!central) return 1;
    const auto launched=core::LaunchCameraRay(metric,0.9,central->ray);
    if (!launched) return 1;
    backend::DetectorLaunchFrame frame;
    frame.pupil=central->ray;
    for (int i=0;i<4;++i) {
        frame.position[i]=Range(launched->position(i));
        frame.tetrad[0][i]=Range(launched->observer.time(i));
        for (int axis=0;axis<3;++axis) frame.tetrad[axis+1][i]=Range(launched->observer.spatial[axis](i));
    }

    using namespace core::relativity::finite_tail_detail;
    using namespace core::relativity::kerr_infinity_detail;
    const auto evaluate = [&](const FilmVector& box) -> std::optional<StationaryChart> {
        const FilmJet z0(box[0],{Range(1.0),Range(0.0)});
        const FilmJet z1(box[1],{Range(0.0),Range(1.0)});
        const auto q=core::camera_detail::ThinLensFilmVector(
            core::camera_detail::FilmPlaneX(FilmJet(x)+FilmJet(m01)*z1,config),
            core::camera_detail::FilmPlaneY(FilmJet(y)+FilmJet(17.0)+
                                           FilmJet(m10)*z0+FilmJet(m11)*z1,config),
            core::camera_detail::FilmTangent(config),config.focus_distance,
            frame.pupil.aperture_up,frame.pupil.aperture_right);
        const FilmJet norm=sqrt(Square(q[0])+Square(q[1])+Square(q[2]));
        const std::array direction{q[0]/norm,q[1]/norm,q[2]/norm};
        std::array<FilmJet,4> event,tangent;
        for (unsigned i=0;i<4;++i) {
            event[i]=FilmJet(frame.position[i]);
            tangent[i]=FilmJet(0.0)-FilmJet(frame.tetrad[0][i])+
                       FilmJet(frame.tetrad[1][i])*direction[0]+
                       FilmJet(frame.tetrad[2][i])*direction[1]+
                       FilmJet(frame.tetrad[3][i])*direction[2];
        }
        const auto state=EncloseDetectorRadialState<true>(metric.GetParams(),event,tangent);
        if (!state) return {};
        return MakeStationaryChart(*state,0.9);
    };
    const auto print=[](std::string_view key, Range range) {
        std::cout<<' '<<key<<"=["<<range.lo<<','<<range.hi<<']';
    };
    std::cout<<std::setprecision(17);
    const FilmVector box{Range(lo[0],hi[0]),Range(lo[1],hi[1])};
    const auto whole=evaluate(box);
    if (!whole) return 2;
    const auto proof=ProveInjectiveChart(whole->jacobian);
    if (!proof) return 3;
    const auto& [radial_row,potential_row]=whole->jacobian;
    const Range det=radial_row[0]*potential_row[1]-radial_row[1]*potential_row[0];
    std::cout<<"whole contraction="<<proof->contraction;
    print("det",det);
    print("du_dz0",radial_row[0]); print("du_dz1",radial_row[1]);
    print("dH_dz0",potential_row[0]); print("dH_dz1",potential_row[1]);
    std::cout<<'\n';

    // Locate a point on the critical curve to centre a target rectangle.
    // The following interval inclusion certifies the rectangle even if
    // this scalar bisection stops on an uncertain final sign.
    const double z0=std::lerp(lo[0],hi[0],0.85);
    double lower=lo[1], upper=hi[1];
    for (unsigned i=0;i<36;++i) {
        const double z1=std::midpoint(lower,upper);
        const auto at=evaluate({Range(z0),Range(z1)});
        if (!at) return 4;
        if (at->coordinate[1].lo>0.0) lower=z1;
        else if (at->coordinate[1].hi<0.0) upper=z1;
        else break;
    }
    FilmVector centre{Range(z0),Range(std::midpoint(lower,upper))};
    const auto at_centre=evaluate(centre);
    if (!at_centre) return 5;
    const double u=std::midpoint(at_centre->coordinate[0].lo,at_centre->coordinate[0].hi);
    const std::array target_middle{u,0.0};
    FilmVector target;
    for (unsigned j=0;j<2;++j) {
        double width=std::numeric_limits<double>::infinity();
        for (unsigned i=0;i<2;++i) {
            const double margin=std::min(centre[i].lo-box[i].lo,box[i].hi-centre[i].hi);
            const double gain=Abs(proof->preconditioner[i][j]).hi;
            if (gain>0.0) width=std::min(width,0.375*margin/gain);
        }
        target[j]=Range(target_middle[j]-width,target_middle[j]+width);
    }
    const auto covered=IncludeChartTargets(box,centre,at_centre->coordinate,target,*proof);
    if (!covered || !(target[1].lo<0.0 && target[1].hi>0.0)) return 6;
    const auto converted=InvertStationaryChart(1.0,0.9,target);
    if (!converted) return 7;
    std::cout<<"target";
    print("u",target[0]); print("H",target[1]); print("z0",(*covered)[0]); print("z1",(*covered)[1]);
    print("lambda",converted->lambda); print("eta",converted->eta);
    std::cout<<'\n';

    const Range scale(0.0,std::nextafter(sqrt(Range(-target[1].lo)).lo,0.0));
    const auto turning=EncloseScaledTurningPair(1.0,0.9,target[0],scale);
    if (!turning) return 12;
    std::cout<<"scaling contraction="<<turning->contraction;
    print("s",turning->s);
    print("turn_offset",turning->turn_offset);
    print("inner_offset",turning->inner_offset);
    print("gap_over_s",turning->gap_over_s);
    std::cout<<'\n';

    for (const auto& point:std::array{Coordinate{lo[0],hi[1]},Coordinate{hi[0],hi[1]},Coordinate{z0,centre[1].lo}}) {
        const auto chart=evaluate({Range(point[0]),Range(point[1])});
        if (!chart) return 8;
        const auto inverse=InvertStationaryChart(1.0,0.9,chart->coordinate);
        if (!inverse || inverse->lambda.lo>chart->lambda.hi || inverse->lambda.hi<chart->lambda.lo ||
            inverse->eta.lo>chart->eta.hi || inverse->eta.hi<chart->eta.lo) return 9;
        const auto ray=camera.ProjectFilmOffsetForObserver(x,y,m01*point[1],
                    17+(m10*point[0]+m11*point[1]),sample.pupil_u,sample.pupil_v);
        if (!ray) return 10;
        const auto launch=core::LaunchCameraRay(metric,.9,ray->ray);
        if (!launch) return 11;
        std::cout<<"point";
        print("z0",Range(point[0])); print("z1",Range(point[1]));
        print("u",chart->coordinate[0]); print("H",chart->coordinate[1]);
        print("lambda",inverse->lambda); print("eta",inverse->eta);
        std::cout<<" xk="<<std::hexfloat;
        for (int i=0;i<4;++i) std::cout<<launch->position(i)<<',';
        for (int i=0;i<4;++i) std::cout<<launch->tangent(i)<<(i==3?"":",");
        std::cout<<std::defaultfloat<<'\n';
    }
}

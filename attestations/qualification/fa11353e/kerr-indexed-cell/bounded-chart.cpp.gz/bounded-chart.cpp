#include "sirius/backend/cpu/geodesic_tracer.h"
#ifdef SIRIUS_FULL_CELL_RADEON
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#endif
#include "finite-radiometry.h"
#include "sirius/core/camera_sampling.h"
#include "sirius/core/starfield.h"
#include "sirius/render/session/point_source_detector.h"
#include <array>
#include <chrono>
#include <string_view>
#include <tuple>
#include <iomanip>
#include <iostream>

using namespace sirius;
int main(int argc,char* argv[]) {
    const bool verify_exhaustive=argc==2 && std::string_view(argv[1])=="--oracle";
    if (argc!=1 && !verify_exhaustive) return 2;
    core::CameraConfig config;
    config.r=30;
    config.theta=80*core::constants::math::kPi/180.0;
    config.fov=60;
    config.width=1920;
    config.height=1080;
    config.beta_x=.1;
    config.beta_y=.02;
    config.beta_z=-.01;
    config.focal_length=50;
    config.aperture=2.8f;
    config.focus_distance=30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1,.9));
    core::CameraSample sample;
    bool first=true;
    core::ForEachCameraSample(4,[&](auto next) {
        if (first) sample=next;
        first=false;
    });
    constexpr std::array lo{0x1.2b6p-1,0x1.fa7cp+1}, hi{0x1.2b7p-1,0x1.fa8p+1};
    constexpr double m01=-0x1.d357ebd0e3748p-1, m10=0x1.d30c6a29fa83fp-1;
    constexpr double m11=0x1.e454f19fc15dep-9;
    using Coordinate=std::array<double,2>;
    using namespace core::relativity::finite_tail_detail;
    using namespace core::relativity::kerr_infinity_detail;
    const double x=896+double(sample.image_u), y=576+double(sample.image_v);
    const auto central=camera.ProjectFilmForObserver(x,y,sample.pupil_u,sample.pupil_v);
    if (!central) return 1;
    const auto launched=core::LaunchCameraRay(metric,0.9,central->ray);
    if (!launched) return 1;
    backend::DetectorLaunchFrame frame;
    frame.pupil=central->ray;
    for (int i=0;i<4;++i) {
        frame.position[i]=Range(launched->position(i));
        frame.tetrad[0][i]=Range(launched->observer.time(i));
        for (int axis=0;axis<3;++axis) frame.tetrad[axis+1][i]=Range(launched->observer.spatial[axis](i));
    }

    using namespace core::relativity::finite_tail_detail;
    using namespace core::relativity::kerr_infinity_detail;
#ifdef SIRIUS_FULL_CELL_RADEON
    const auto inventory=backend::EnumerateVulkanDevices();
    if (!inventory || inventory->empty()) return 51;
    const auto index=backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index>=inventory->size()) return 52;
    const auto& info=(*inventory)[*index];
    if (info.vendor_id!=0x1002 || info.name.find("780M")==std::string::npos) return 53;
    auto device=backend::CreateVulkanDevice(*index);
    if (!device) return 54;
    const auto compute=backend::RetainedCompute::Create(**device,1);
    if (!compute) return 55;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk=false;
    trace.enable_ray_bundles=true;
    trace.bundle_point_source=true;
    backend::GeodesicTracer tracer(&metric,trace);
    tracer.SetStepExecutor(&executor);
    const auto retained=tracer.PrepareDetectorPupil(central->ray);
    if (!retained || executor.Error()) return 56;
    double frame_diameter=0.0;
    for (unsigned i=0;i<4;++i) {
        frame_diameter=std::max(frame_diameter,retained->position[i].hi-retained->position[i].lo);
        for (unsigned axis=0;axis<4;++axis)
            frame_diameter=std::max(frame_diameter,retained->tetrad[axis][i].hi-retained->tetrad[axis][i].lo);
    }
    frame=*retained;
    std::cout<<"retained_device="<<info.name<<" driver="<<info.driver_name
             <<" driver_info="<<info.driver_info
             <<" launch_interval_max_width="<<std::setprecision(17)<<frame_diameter<<'\n';
#endif
    const auto evaluate = [&](const FilmVector& box) -> std::optional<StationaryChart> {
        const FilmJet z0(box[0],{Range(1.0),Range(0.0)});
        const FilmJet z1(box[1],{Range(0.0),Range(1.0)});
        const auto q=core::camera_detail::ThinLensFilmVector(
            core::camera_detail::FilmPlaneX(FilmJet(x)+FilmJet(m01)*z1,config),
            core::camera_detail::FilmPlaneY(FilmJet(y)+FilmJet(17.0)+
                                           FilmJet(m10)*z0+FilmJet(m11)*z1,config),
            core::camera_detail::FilmTangent(config),config.focus_distance,
            frame.pupil.aperture_up,frame.pupil.aperture_right);
        const FilmJet norm=sqrt(Square(q[0])+Square(q[1])+Square(q[2]));
        const std::array direction{q[0]/norm,q[1]/norm,q[2]/norm};
        std::array<FilmJet,4> event,tangent;
        for (unsigned i=0;i<4;++i) {
            event[i]=FilmJet(frame.position[i]);
            tangent[i]=FilmJet(0.0)-FilmJet(frame.tetrad[0][i])+
                       FilmJet(frame.tetrad[1][i])*direction[0]+
                       FilmJet(frame.tetrad[2][i])*direction[1]+
                       FilmJet(frame.tetrad[3][i])*direction[2];
        }
        const auto state=EncloseDetectorRadialState<true>(metric.GetParams(),event,tangent);
        if (!state) return {};
        return MakeStationaryChart(*state,0.9);
    };
    const auto print=[](std::string_view key, Range range) {
        std::cout<<' '<<key<<"=["<<range.lo<<','<<range.hi<<']';
    };
    std::cout<<std::setprecision(17);
    const FilmVector box{Range(lo[0],hi[0]),Range(lo[1],hi[1])};
    const auto whole=evaluate(box);
    if (!whole) return 2;
    const auto proof=ProveInjectiveChart(whole->jacobian);
    if (!proof) return 3;
    const auto& [radial_row,potential_row]=whole->jacobian;
    const Range det=radial_row[0]*potential_row[1]-radial_row[1]*potential_row[0];
    std::cout<<"whole contraction="<<proof->contraction;
    print("det",det);
    print("du_dz0",radial_row[0]); print("du_dz1",radial_row[1]);
    print("dH_dz0",potential_row[0]); print("dH_dz1",potential_row[1]);
    std::cout<<'\n';

    // Locate a point on the critical curve to centre a target rectangle.
    // The following interval inclusion certifies the rectangle even if
    // this scalar bisection stops on an uncertain final sign.
    const double z0=std::lerp(lo[0],hi[0],0.85);
    double lower=lo[1], upper=hi[1];
    for (unsigned i=0;i<36;++i) {
        const double z1=std::midpoint(lower,upper);
        const auto at=evaluate({Range(z0),Range(z1)});
        if (!at) return 4;
        if (at->coordinate[1].lo>0.0) lower=z1;
        else if (at->coordinate[1].hi<0.0) upper=z1;
        else break;
    }
    FilmVector centre{Range(z0),Range(std::midpoint(lower,upper))};
    const auto at_centre=evaluate(centre);
    if (!at_centre) return 5;
    const double u=std::midpoint(at_centre->coordinate[0].lo,at_centre->coordinate[0].hi);
    // The signs cover the whole original film box. At any fixed z0,
    // moving z1 upward decreases H and increases u. The largest u on
    // H<=0 is therefore at H=0 on the upper z1 edge. Moving z0 right
    // decreases both coordinates, so the smallest u is at H=0 on the
    // right z0 edge. The minimum H is at the upper-right corner.
    if (!(radial_row[0].hi<0.0 && radial_row[1].lo>0.0 &&
          potential_row[0].hi<0.0 && potential_row[1].hi<0.0)) return 40;
    const auto critical_on_edge=[&](unsigned axis) -> std::optional<FilmVector> {
        FilmVector edge{Range(hi[0]),Range(hi[1])};
        const auto h=[&](double z) {
            edge[axis]=Range(z);
            const auto point=evaluate(edge);
            return point ? point->coordinate[1] : InvalidRange();
        };
        if (!(h(lo[axis]).lo>0.0 && h(hi[axis]).hi<0.0)) return {};
        const auto tighten=[&](double known,double other,bool positive) {
            for (unsigned iteration=0;iteration<45;++iteration) {
                const double mid=std::midpoint(known,other);
                if (mid==known || mid==other) break;
                const auto range=h(mid);
                if (positive ? range.lo>0.0 : range.hi<0.0) known=mid;
                else other=mid;
            }
            return known;
        };
        const double dark=tighten(lo[axis],hi[axis],true),
                     light=tighten(hi[axis],dark,false);
        edge[axis]=Range(dark,light);
        return edge;
    };
    const auto max_edge=critical_on_edge(0), min_edge=critical_on_edge(1);
    if (!max_edge || !min_edge) return 41;
    const auto top=evaluate(*max_edge), right=evaluate(*min_edge);
    const auto corner=evaluate({Range(hi[0]),Range(hi[1])});
    if (!top || !right || !corner) return 42;
    const FilmVector target{Range(right->coordinate[0].lo,top->coordinate[0].hi),
                            Range(corner->coordinate[1].lo,0.0)};
    if (!(target[0].Finite() && target[1].lo<0.0)) return 43;
    const auto covered=&box;
    std::cout<<"escaping_extent";
    print("critical_top_z0",(*max_edge)[0]);
    print("critical_right_z1",(*min_edge)[1]);
    print("amin_u",right->coordinate[0]);
    print("amax_u",top->coordinate[0]);
    print("h_min",corner->coordinate[1]);
    std::cout<<'\n';
    const auto converted=InvertStationaryChart(1.0,0.9,target);
    if (!converted) return 7;
    std::cout<<"target";
    print("u",target[0]); print("H",target[1]); print("z0",(*covered)[0]); print("z1",(*covered)[1]);
    print("lambda",converted->lambda); print("eta",converted->eta);
    std::cout<<'\n';

    const Range scale(0.0,sqrt(Range(-target[1].lo)).hi);
    const auto turning=EncloseScaledTurningPair(1.0,0.9,target[0],scale);
    if (!turning) return 12;
    std::cout<<"scaling contraction="<<turning->contraction;
    print("s",turning->s);
    print("turn_offset",turning->turn_offset);
    print("inner_offset",turning->inner_offset);
    print("gap_over_s",turning->gap_over_s);
    std::cout<<'\n';

    const auto residual=EncloseRegularizedRadialPhase(1.0,.9,target[0],scale,whole->inverse_start,128);
    if (!residual) return 13;
    std::cout<<"remainder";
    print("inverse_start",whole->inverse_start);
    print("leading_factor",residual->leading_factor);
    print("limiting_drag",residual->limiting_drag);
    print("leading_radial",residual->leading_gradient[0]);
    print("drag_radial",residual->drag_gradient[0]);
    print("drag_scale",residual->drag_gradient[1]);
    print("time_log_derivative",residual->time_log_derivative);
    print("time",residual->time_remainder.value);
    print("time_radial",residual->time_remainder.radial);
    print("time_log_scale",residual->time_remainder.log_scale);
    print("spin",residual->spin_remainder.value);
    print("spin_radial",residual->spin_remainder.radial);
    print("spin_log_scale",residual->spin_remainder.log_scale);
    std::cout<<" spin_decay_constant="<<residual->spin_derivative_constant
             <<" spin_decay_log_coefficient="<<residual->spin_derivative_log_coefficient;
    const Range time_at_edge=Range(-2.0)*residual->leading_factor*LogPoint(scale.hi)+
                            residual->time_remainder.value;
    print("time_at_outer_scale",time_at_edge);
    if (!(residual->time_log_derivative.hi<0.0 && residual->leading_factor.lo>0.0)) return 14;
    std::cout<<'\n';

    // Independently enclose the turning latitude of this smaller
    // coefficient chart, preserving the two shared affine coordinates.
    const auto span_u=PupilAffine::Coordinate(target[0],true);
    const auto span_h=PupilAffine::Coordinate(Range(0.0)-Square(scale),false);
    const auto polar=InvertStationaryScalars(1.0,.9,std::array{span_u,span_h});
    if (!polar) return 16;
    const auto a2=Square(PupilAffine(.9));
    const auto b=a2-polar->eta-Square(polar->lambda);
    const auto omega2=(sqrt(Square(b)+PupilAffine(4.0)*a2*polar->eta)-b)*PupilAffine(.5);
    const Range amplitude=sqrt(polar->eta/omega2).Bounds();
    if (!amplitude.Finite()) return 17;
    const auto stars=core::StarfieldGenerator(core::ExpandPointStarfieldConfig(
        core::PointStarfieldConfig{})).GenerateCatalogue();
    struct CatalogueBand {
        double minimum_gap=std::numeric_limits<double>::infinity();
        double maximum_temperature=0.0;
        unsigned size=0;
        Range intensity{}, normalized_temperature_flux{};
    };
    std::array<CatalogueBand,3> bands{};
    double local_gap=std::numeric_limits<double>::infinity();
    unsigned reachable=0, uncertain=0;
    std::optional<double> reference_latitude;
    for (const auto& star : stars) {
        const Range x(star.direction_x), y(star.direction_y), z(star.direction_z);
        const Range latitude=Abs(z)/sqrt(Square(x)+Square(y)+Square(z));
        if (latitude.lo>amplitude.hi) continue;
        if (latitude.hi>=amplitude.lo) {
            ++uncertain;
            continue;
        }
        ++reachable;
        if (!reference_latitude && z.lo<0.0 && latitude.lo>.4 && latitude.hi<.41) {
            reference_latitude=-std::midpoint(latitude.lo,latitude.hi);
        }
        const double gap=(amplitude-latitude).lo;
        local_gap=std::min(local_gap,gap);
        auto& band=bands[gap>=.01 ? 0 : gap>=.0001 ? 1 : 2];
        band.minimum_gap=std::min(band.minimum_gap,gap);
        band.maximum_temperature=std::max(band.maximum_temperature,double(star.temperature_K));
        const Range intensity(star.Intensity());
        const auto normalizer=RepresentedStarNormalizer(star.temperature_K);
        if (!normalizer) return 46;
        band.intensity=band.intensity+intensity;
        band.normalized_temperature_flux=band.normalized_temperature_flux+
            intensity*Range(star.temperature_K)/ *normalizer;
        ++band.size;
    }
    // The earlier continuous full-cell check supplied a 2^-27 gap
    // even if a coarser interval for this chart retains an overlap.
    double clearance=0x1p-27;
    if (uncertain==0 && reachable>0) clearance=std::max(clearance,local_gap);
    std::cout<<"catalogue";
    print("amplitude",amplitude);
    std::cout<<" reachable="<<reachable<<" uncertain="<<uncertain
             <<" clearance="<<clearance<<'\n';

    const auto latitude=EncloseLatitudeRootMonotonicity(
        1.0,.9,target[0],scale,whole->initial_mu,clearance,*residual);
    if (!latitude) return 15;
    std::cout<<"latitude";
    print("initial_mu",whole->initial_mu);
    print("half_period",latitude->half_period);
    std::cout<<" period_h_bound="<<latitude->period_h_bound
             <<" partial_h_bound="<<latitude->endpoint_h_bound
             <<" winding_s2_bound="<<latitude->winding_s2_bound
             <<" root_log_slope_upper="<<latitude->slope_upper<<'\n';

    if (uncertain!=0 || !(whole->energy.hi<-.5)) return 18;
    // Launches have unit camera-frame frequency. This encloses nu_cam /
    // nu_infty by two on the whole film cell, including this chart.
    constexpr double g_upper=2.0;
    constexpr double brightness=core::PointStarfieldConfig{}.brightness_scale;
    constexpr double detector_allowance=render::PointDetectorPolicy{}.absolute_rgb_error;
    // A fixed-pupil target satisfies the entire film inclusion box.
    // exp(-|z|²/2) <= 1/2000 there, and 2*pi*(1-exp(-8)) > 6.
    const Range film_radius2=Square((*covered)[0])+Square((*covered)[1]);
    if (!((film_radius2*Range(0.5)).lo>LogPoint(2000.0).hi &&
          LogPoint(1000.0).hi<8.0 && (Range(2.0)*kPiBounds*Range(.999)).lo>6.0))
        return 25;
    const Range gaussian_factor=Range(1.0)/Range(12000.0);
    const Range lambda_min(core::constants::spectral::kLambdaMin);
    const Range lambda_max(core::constants::spectral::kLambdaMax);
    constexpr double step=(core::constants::spectral::kLambdaMax-
                           core::constants::spectral::kLambdaMin)/32.0;
    for (unsigned i=0;i<32;++i) {
        const double wavelength=core::constants::spectral::kLambdaMin+(i+.5)*step;
        const auto matching=core::spectral::WavelengthToXyz(wavelength*1e9);
        if (!(std::abs(matching.X)<2 && std::abs(matching.Y)<2 && std::abs(matching.Z)<2))
            return 19;
    }
    // Rayleigh-Jeans bounds Planck, since exp(x)-1 >= x. The XYZ
    // table is bounded by two, the colour-matrix row sum is below
    // eight, and the source-normalizer floor exceeds 0.0005.
    const Range sky_factor=gaussian_factor*Range(64.0)*(lambda_max-lambda_min)*
        Range(core::constants::physical::kPlanckC1)*Range(g_upper)*Range(brightness)/
        (Range(core::constants::physical::kPlanckC2)*Square(Square(lambda_min))*Range(.0005));
    // The same geometric tail may use the measured per-star source
    // normalizer instead of its coarse global floor.
    const Range g=Range(1.0)/(Range(0.0)-whole->energy);
    const Range normalized_spectral_factor=gaussian_factor*Range(64.0)*(lambda_max-lambda_min)*
        Range(core::constants::physical::kPlanckC1)*g*Range(brightness)/
        (Range(core::constants::physical::kPlanckC2)*Square(Square(lambda_min)));
    Range rgb{}, coarse_tail{};
    std::array<unsigned,3> cutoffs{};
    std::cout<<"radiometry";
    print("energy",whole->energy);
    print("gaussian_factor",gaussian_factor);
    if (!reference_latitude) return 26;
    std::cout<<" reference_latitude="<<*reference_latitude;
    std::cout<<" g_upper="<<g_upper<<" brightness="<<brightness
             <<" sample_absolute_error="<<detector_allowance<<'\n';
    for (std::size_t index=0;index<bands.size();++index) {
        const auto& band=bands[index];
        if (band.size==0) continue;
        const Range flux=sky_factor*Range(band.maximum_temperature)*band.intensity;
        if (!flux.Finite()) return 20;
        auto tail=EncloseWindingTail(1,.9,target[0],scale,whole->initial_mu,
                                     band.minimum_gap,det,*residual,*latitude,8);
        if (!tail) return 21;
        double flux_upper=std::nextafter(
            std::scalbn((flux*Range(tail->tail_prefactor)).hi,tail->tail_exponent),kInfinity);
        if (!(flux_upper<detector_allowance/3.0)) {
            // Keep the proved monotonic threshold and sum from a later
            // winding if its radiometric allowance requires it.
            const double prefactor=(flux*Range(tail->tail_prefactor)).hi;
            const int exponent=std::ilogb(prefactor/(detector_allowance/4.0));
            const unsigned first=std::max(tail->first_winding,unsigned((2*(exponent+2)+6)/7));
            tail=EncloseWindingTail(1,.9,target[0],scale,whole->initial_mu,
                                   band.minimum_gap,det,*residual,*latitude,first);
            if (!tail) return 22;
            flux_upper=std::nextafter(
                std::scalbn((flux*Range(tail->tail_prefactor)).hi,tail->tail_exponent),kInfinity);
        }
        if (!(flux_upper<detector_allowance/3.0)) return 23;
        const Range normalized_flux=normalized_spectral_factor*band.normalized_temperature_flux;
        if (!normalized_flux.Finite()) return 47;
        const double tightened=std::nextafter(
            std::scalbn((normalized_flux*Range(tail->tail_prefactor)).hi,tail->tail_exponent),kInfinity);
        if (!std::isfinite(tightened) || tightened>flux_upper) return 48;
        coarse_tail=coarse_tail+Range(0.0,flux_upper);
        rgb=rgb+Range(0.0,tightened);
        cutoffs[index]=tail->first_winding;
        std::cout<<"tail band="<<index<<" stars="<<band.size
                 <<" clearance="<<band.minimum_gap<<" max_temperature="<<band.maximum_temperature;
        print("intensity",band.intensity);
        print("half_azimuth_radial",tail->half_azimuth_radial);
        std::cout<<" first="<<tail->first_winding
                 <<" slope_lower="<<tail->azimuth_slope_per_winding_lower
                 <<" slope_upper="<<tail->azimuth_slope_per_winding_upper
                 <<" min_polar_speed="<<tail->source_polar_speed_lower
                 <<" wrap_count_slope="<<tail->wrap_count_slope
                 <<" inverse_determinant_coefficient="<<tail->inverse_determinant_coefficient
                 <<" response_prefactor="<<tail->tail_prefactor
                 <<" response_base2_exponent="<<tail->tail_exponent
                 <<" coarse_transfer_flux_upper="<<flux.hi
                 <<" normalized_transfer_flux_upper="<<normalized_flux.hi
                 <<" coarse_rgb_upper="<<flux_upper
                 <<" rgb_upper="<<tightened<<'\n';
    }
    if (!(rgb.Finite() && rgb.hi<detector_allowance)) return 24;
    std::cout<<"total coarse_rgb_upper="<<coarse_tail.hi<<" rgb_upper="<<rgb.hi<<'\n';

    for (double s: {0.0,1e-30,1e-7,scale.hi*.5}) {
        const auto phase=EvaluateFiniteRadialPhase(1,.9,Range(u),Range(s),whole->inverse_start);
        if (!phase) return 27;
        std::cout<<"finite s="<<s<<" u="<<u;
        print("time",phase->time_residual);
        print("spin",phase->spin_residual);
        std::cout<<'\n';
    }
    const auto shape=MakeFinitePolarShape(1,.9,target[0],scale);
    if (!shape) return 28;
    const auto table=MakePolarIntegralTable(*shape);
    if (!table) return 29;
    const auto started=std::chrono::steady_clock::now();
    const auto catalogue=AngularCatalogue::Build(stars);
    if (!catalogue) return 30;
    const auto prepared=std::chrono::steady_clock::now();
    constexpr auto visits_allowed=render::PointDetectorPolicy{}.maximum_candidate_visits;
    const IndexedScreenInput input{*catalogue,cutoffs,amplitude,clearance,visits_allowed};
    const auto screened=ScreenFiniteWindings(1,.9,target[0],scale,*whole,*table,*residual,{},&input);
    if (!screened) {
        std::cerr<<"indexed screen declined within budget "<<visits_allowed<<'\n';
        return 32;
    }
    const auto screened_at=std::chrono::steady_clock::now();
    std::cout<<"indexed screen windings="<<screened->work.size()<<" reachable="<<reachable
             <<" row_queries="<<screened->selected_rows
             <<" candidate_visits="<<screened->candidate_visits
             <<" visit_ceiling="<<visits_allowed
             <<" survivors="<<screened->candidates.size()
             <<" angular_index_bytes="<<catalogue->ReservedBytes()
             <<" prepare_seconds="<<std::chrono::duration<double>(prepared-started).count()
             <<" screen_seconds="<<std::chrono::duration<double>(screened_at-prepared).count()<<'\n';
    if (verify_exhaustive) {
        std::vector<FiniteCatalogueSource> sources;
        sources.reserve(stars.size());
        for (unsigned i=0;i<stars.size();++i) {
            const auto& star=stars[i];
            const Range x(star.direction_x),y(star.direction_y),z(star.direction_z);
            const Range mu=z/sqrt(Square(x)+Square(y)+Square(z));
            if (Abs(mu).lo>amplitude.hi) continue;
            if (!(mu.lo>0.0 || mu.hi<0.0)) return 31;
            const auto at=table->Partial(AsinBounds(Abs(mu)/sqrt(shape->amplitude2)));
            const auto azimuth=CatalogueAzimuth(x.lo,y.lo);
            if (!at[0].Finite() || !at[1].Finite() || !azimuth.Finite()) return 31;
            const double gap=(amplitude-Abs(mu)).lo;
            const unsigned group=gap>=.01 ? 0 : gap>=.0001 ? 1 : 2;
            sources.push_back({i,cutoffs[group],at,azimuth,mu.lo>0.0});
        }
        const auto exhaustive=ScreenFiniteWindings(1,.9,target[0],scale,*whole,*table,*residual,sources);
        if (!exhaustive) return 33;
        unsigned trials=0;
        for (const auto& branch:exhaustive->work) trials+=branch.examined;
        auto indexed=screened->candidates;
        auto reference=exhaustive->candidates;
        const auto key=[](const FiniteCandidate& candidate) {
            return std::tuple(candidate.winding,candidate.source,candidate.approaching_equator,
                              candidate.log_scale.lo,candidate.log_scale.hi);
        };
        std::ranges::sort(indexed,{},key);
        std::ranges::sort(reference,{},key);
        const bool matches=std::ranges::equal(indexed,reference,{},key,key);
        std::cout<<"exhaustive examined="<<trials<<" survivors="<<reference.size()
                 <<" exact_candidate_and_log_scale_match="<<matches<<'\n';
        if (!matches) return 34;
    }
    // A bounded omission can charge its maximum error to the sample
    // ledger without determining the complete set of image positions.
    unsigned survivors=0, proven=0, unresolved=0;
    std::array<Range,3> finite{};
    for (const auto& candidate:screened->candidates) {
        const auto& star=stars[candidate.source];
        const Range x(star.direction_x),y(star.direction_y),z(star.direction_z);
        const Range mu=z/sqrt(Square(x)+Square(y)+Square(z));
        const Range sky=CatalogueAzimuth(x.lo,y.lo);
        const auto refined=RefineFiniteAzimuth(1,.9,target[0],scale,*whole,candidate,mu,sky);
        if (!refined) return 60;
        if (!refined->possible) continue;
        ++survivors;
        const auto branch=EntireLatitudeBranchExists(1,.9,target[0],scale,*whole,mu,candidate);
        if (!branch) return 61;
        const Range wraps=(refined->azimuth-sky)/(Range(2.0)*kPiBounds);
        const Range s=ExpBounds(refined->log_scale);
        if (!s.Finite()) return 62;
        const auto derivative=DifferentiateFiniteAzimuth(1,.9,target[0],
            Range(s.lo,std::min(s.hi,scale.hi)),refined->log_scale,*whole,
            candidate.winding,candidate.approaching_equator,mu);
        if (!*branch || !derivative || std::ceil(wraps.lo)!=std::floor(wraps.hi) ||
            !(Abs(derivative->conditioned_radial_slope).lo>0.0)) {
            ++unresolved;
            continue;
        }
        ++proven;
        const auto colour=EncloseFiniteStarColour(star.temperature_K,g);
        if (!colour) return 63;
        const Range density=gaussian_factor*Range(2.0)*Square(s)/
                (Abs(derivative->conditioned_radial_slope)*derivative->latitude_log_slope_magnitude*
                 derivative->mu_speed*det);
        const Range flux=Range(brightness)*Range(star.Intensity())*density;
        if (!flux.Finite()) return 64;
        for (unsigned channel=0;channel<3;++channel)
            finite[channel]=finite[channel]+Range(0.0,(flux*(*colour)[channel]).hi);
    }
    const double finite_max=std::max({finite[0].hi,finite[1].hi,finite[2].hi});
    const Range sum=Range(finite_max)+rgb;
    std::cout<<"bounded_without_roots survivors="<<survivors<<" proven="<<proven
             <<" unresolved="<<unresolved<<" finite_rgb_upper="<<finite_max
             <<" sum_rgb_upper="<<sum.hi<<'\n';
    if (!(unresolved==0 && sum.Finite() && sum.hi<detector_allowance)) return 65;
    for (const auto& point:std::array{Coordinate{lo[0],hi[1]},Coordinate{hi[0],hi[1]},Coordinate{z0,centre[1].lo}}) {
        const auto chart=evaluate({Range(point[0]),Range(point[1])});
        if (!chart) return 8;
        const auto inverse=InvertStationaryChart(1.0,0.9,chart->coordinate);
        if (!inverse || inverse->lambda.lo>chart->lambda.hi || inverse->lambda.hi<chart->lambda.lo ||
            inverse->eta.lo>chart->eta.hi || inverse->eta.hi<chart->eta.lo) return 9;
        const auto ray=camera.ProjectFilmOffsetForObserver(x,y,m01*point[1],
                    17+(m10*point[0]+m11*point[1]),sample.pupil_u,sample.pupil_v);
        if (!ray) return 10;
        const auto launch=core::LaunchCameraRay(metric,.9,ray->ray);
        if (!launch) return 11;
        std::cout<<"point";
        print("z0",Range(point[0])); print("z1",Range(point[1]));
        print("u",chart->coordinate[0]); print("H",chart->coordinate[1]);
        print("lambda",inverse->lambda); print("eta",inverse->eta);
        std::cout<<" xk="<<std::hexfloat;
        for (int i=0;i<4;++i) std::cout<<launch->position(i)<<',';
        for (int i=0;i<4;++i) std::cout<<launch->tangent(i)<<(i==3?"":",");
        std::cout<<std::defaultfloat<<'\n';
    }
}

#!/usr/bin/env bash
set -euo pipefail
scratch="$PWD/out/retained-result-prefixes"
test_product="$PWD/bin/linux-ci/tests/backend/sirius_backend_tests"
export TMPDIR="$scratch"
cases=VulkanBackend.BufferAllocationLimitCountsActualResidencyAndPreservesExistingBuffers
cases+=:RetainedComputeTest.CoupledIntervalsRequireEmbeddedAndIndependentDenseAgreement
cases+=:RetainedComputeTest.SharedTracerCompletesDeviceIntervalsAndRetainsRollbackState
cases+=:RetainedComputeTest.RejectedStepRowsCannotExposeOldOrPartialCandidates
env VK_DRIVER_FILES=/sirius/missing-icd.json SIRIUS_PACKAGED_SOFTWARE_VULKAN=1 SIRIUS_VULKAN_DEVICE=0 \
    MESA_SHADER_CACHE_DISABLE=true XDG_CACHE_HOME="$scratch/cache" \
    /usr/bin/time -v timeout 240 "$test_product" --gtest_filter="$cases" \
    --gtest_color=no --gtest_output="xml:$scratch/controls.xml" >"$scratch/controls.log" 2>&1

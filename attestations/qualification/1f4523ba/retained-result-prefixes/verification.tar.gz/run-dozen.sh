#!/usr/bin/env bash
set -euo pipefail
scratch="$PWD/out/retained-result-prefixes"
test_product="$PWD/bin/linux-ci/tests/backend/sirius_backend_tests"
provider="$HOME/.local/opt/mesa-dzn/dzn_icd.x86_64.json"
export TMPDIR="$scratch"
env -u SIRIUS_PACKAGED_SOFTWARE_VULKAN VK_DRIVER_FILES="$provider" SIRIUS_VULKAN_DEVICE=0 \
    SIRIUS_MEMORY_BUDGET_MB=2048 MESA_SHADER_CACHE_DISABLE=true XDG_CACHE_HOME="$scratch/dozen-cache" \
    /usr/bin/time -v timeout 30 "$test_product" \
    --gtest_filter=VulkanBackend.BufferAllocationLimitCountsActualResidencyAndPreservesExistingBuffers \
    --gtest_color=no --gtest_output="xml:$scratch/dozen.xml" >"$scratch/dozen.log" 2>&1

#!/usr/bin/env bash
set -euo pipefail
root="$PWD"
scratch="$root/out/kerr-signed-contact"
product="$root/bin/linux-ci/src/sirius"
export TMPDIR="$scratch"
g++-14 -I"$root/src" -std=c++2c -O3 -DNDEBUG -Wall -Wextra -Werror \
    -DSIRIUS_CONTRACT_MODE=2 -DSIRIUS_HAS_RETAINED_COMPUTE=1 -DSIRIUS_RELEASE_RESOURCE_LOCKED=1 \
    -fno-fast-math -ffp-contract=off -frounding-math "$scratch/partition-contact.cpp" \
    "$product/backend/libsirius_backend_cpu.a" "$product/backend/libsirius_backend.a" \
    "$product/core/libsirius_core.a" "$product/libsirius_base.a" \
    -lvulkan -ldl -lrt -pthread -o "$scratch/partition-contact"
ln -sfn "$product/app/resources" "$scratch/resources"
cd "$scratch"
env -u SIRIUS_PACKAGED_SOFTWARE_VULKAN \
    VK_DRIVER_FILES="$HOME/.local/opt/mesa-dzn/dzn_icd.x86_64.json" \
    SIRIUS_VULKAN_DEVICE=0 SIRIUS_MEMORY_BUDGET_MB=2048 MESA_SHADER_CACHE_DISABLE=true \
    XDG_CACHE_HOME="$scratch/base-cache" \
    /usr/bin/time -v timeout 50 ./partition-contact >partition-base.log 2>&1
env -u SIRIUS_PACKAGED_SOFTWARE_VULKAN \
    VK_DRIVER_FILES="$HOME/.local/opt/mesa-dzn/dzn_icd.x86_64.json" \
    SIRIUS_VULKAN_DEVICE=0 SIRIUS_MEMORY_BUDGET_MB=2048 MESA_SHADER_CACHE_DISABLE=true \
    XDG_CACHE_HOME="$scratch/partition-cache" \
    /usr/bin/time -v timeout 50 ./partition-contact --partition >partition-held-out.log 2>&1

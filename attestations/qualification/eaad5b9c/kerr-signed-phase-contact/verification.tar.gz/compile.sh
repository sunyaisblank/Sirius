#!/usr/bin/env bash
set -euo pipefail
scratch=out/kerr-signed-contact
for proof in "$@"; do
    g++-14 -std=c++2c -O2 -fno-fast-math -ffp-contract=off -frounding-math -Wall -Wextra \
        -Werror -Isrc "$scratch/$proof.cpp" src/sirius/base/contracts.cpp -o "$scratch/$proof"
    /usr/bin/time -v "$scratch/$proof" > "$scratch/$proof.log" 2>&1
done

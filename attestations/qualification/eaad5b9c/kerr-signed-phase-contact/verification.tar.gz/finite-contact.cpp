#include "sirius/core/kerr_detector/finite_screen.h"

#include <iostream>
#include <numeric>

namespace {
using namespace sirius::core::relativity::finite_tail_detail;

constexpr Range kRadius(0x1.c01a4a99ae36dp-2, 0x1.c01a5c45b2e11p-2);
constexpr Range kPotential(-0x1.efc4ffbd00001p-20, 0x1.af2ed1d680001p-20);
constexpr Range kAmplitude(0x1.f4f4898e63d47p-1, 0x1.f4f492368af0fp-1);
constexpr Range kStart(0x1.111112f155084p-5, 0x1.111112f1550a2p-5);
constexpr Range kLaunch(0x1.67f25c4fe005p-3, 0x1.67f25c4fe0117p-3);
constexpr Range kFixed(0x1.0409070a74c8p-5, 0x1.0409070a74e26p-5);
constexpr Range kLatitude(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
constexpr Range kLongitude(-0x1.1dcd0ee4d9734p+1, -0x1.1dcd0ee4d972dp+1);
constexpr Range kPhase(-0x1.48p-11, 0x1.48p-11);
constexpr Range kSmallScale(0.0, 0x1p-40);
constexpr unsigned kFirstShared = 33;
constexpr unsigned kEnd = 1025;
constexpr unsigned kExceptionalWinding = 581;
constexpr Range kProofRadius(.43759975, .4376005);

struct Enclosure {
    Range radius, scale;
    FiniteRadialPhase radial;
    FinitePolarShape polar;
    PhasePair half, launch;

    PhasePair Target(unsigned winding, Range phase) const {
        // The polar rates are even in signed phase about the turn.
        // Bound the extra integral with its positive rate over the short arc.
        const Range cosine(CosPoint(Magnitude(phase)).lo, 1.0);
        const Range sine2 = Square(cosine);
        const Range time = Range(1.0) / sqrt(polar.omega2 + polar.modulation * sine2);
        const PhasePair density{time,
                                time * polar.angular / (Range(1.0) - polar.amplitude2 * sine2)};
        PhasePair result;
        for (unsigned i = 0; i < result.size(); ++i)
            result[i] = Range(2.0 * winding + 1.0) * half[i] + launch[i] + phase * density[i];
        return result;
    }

    Range Azimuth(PhasePair target) const {
        return kFixed - target[1] - radial.drag_at_turn * target[0] - radial.spin_residual;
    }

    Range LogScale(PhasePair target) const {
        return (radial.time_residual - target[0]) / (Range(2.0) * radial.leading);
    }
};

std::optional<Enclosure> Prepare(Range radius, Range scale) {
    const auto radial = EvaluateFiniteRadialPhase(1.0, .9, radius, scale, kStart);
    const auto polar = MakeFinitePolarShape(1.0, .9, radius, scale);
    if (!radial || !polar || !(radial->leading.lo > 0)) return {};
    const Range amplitude = sqrt(polar->amplitude2);
    const auto half = IntegratePolarPartial(*polar, kPiBounds * Range(.5));
    const auto launch = IntegratePolarPartial(*polar, AsinBounds(kLaunch / amplitude));
    if (!std::ranges::all_of(half, &Range::Finite) || !std::ranges::all_of(launch, &Range::Finite))
        return {};
    return Enclosure{radius, scale, *radial, *polar, half, launch};
}

Range LatitudeResidual(Range radius, Range scale, Range cosine) {
    const auto polar = MakeFinitePolarShape(1.0, .9, radius, scale);
    return polar ? sqrt(polar->amplitude2) * cosine - kLatitude : InvalidRange();
}

Range LatitudeGradient(Range radius, Range scale) {
    const FilmJet u(radius, {Range(1), Range(0)});
    const auto constants =
        InvertStationaryScalars(1.0, .9, std::array{u, FilmJet(Range(0) - Square(scale))});
    if (!constants) return InvalidRange();
    const FilmJet a2 = Square(FilmJet(.9));
    const FilmJet b = a2 - constants->eta - Square(constants->lambda);
    const FilmJet omega2 = (sqrt(Square(b) + FilmJet(4) * a2 * constants->eta) - b) * FilmJet(.5);
    return sqrt(constants->eta / omega2).derivative[0];
}

Range RestrictRadius(Range radius, Range scale, Range phase) {
    const double closest = std::max(0.0, std::max(phase.lo, -phase.hi));
    const Range cosine(CosPoint(Magnitude(phase)).lo, std::min(1.0, CosPoint(closest).hi));
    const Range derivative = LatitudeGradient(radius, scale) * cosine;
    const double middle = std::midpoint(radius.lo, radius.hi);
    if (!derivative.Finite() || !(derivative.hi < 0.0)) return InvalidRange();
    return Range(middle) +
           LatitudeResidual(Range(middle), scale, cosine) / (Range(0.0) - derivative);
}

enum class Outcome { Absent, Possible, Failed };
struct Screen {
    Outcome outcome;
    Range log_scale{}, azimuth{};
};

Screen Exclude(const Enclosure& panel, unsigned winding, Range phase) {
    const auto initial = panel.Target(winding, phase);
    Range logs = panel.LogScale(initial);
    if (!logs.Finite()) return {Outcome::Failed};
    const auto azimuth_screen = panel.Azimuth(initial);
    if (!azimuth_screen.Finite()) return {Outcome::Failed};
    if (!AzimuthMayMatch(azimuth_screen, kLongitude))
        return {Outcome::Absent, logs, azimuth_screen};
    const double limit = LogPoint(panel.scale.hi).hi;
    if (logs.lo > limit) return {Outcome::Absent, logs};
    Range scale = panel.scale;
    if (logs.hi < limit && logs.hi > -700) {
        const auto hi = ExpPoint(logs.hi);
        if (!hi.Finite()) return {Outcome::Failed};
        scale.hi = std::min(scale.hi, hi.hi);
    }
    if (logs.lo > -700 && logs.lo < 0) {
        const auto lo = ExpPoint(logs.lo);
        if (!lo.Finite()) return {Outcome::Failed};
        scale.lo = std::max(scale.lo, lo.lo);
    }
    if (!scale.Finite()) return {Outcome::Absent, logs};
    const Range radius = RestrictRadius(panel.radius, scale, phase);
    if (!radius.Finite()) return {Outcome::Failed};
    const Range restricted(std::max(radius.lo, panel.radius.lo),
                           std::min(radius.hi, panel.radius.hi));
    if (!restricted.Finite()) return {Outcome::Absent, logs};
    const auto candidate = Prepare(restricted, scale);
    if (!candidate) return {Outcome::Failed};
    const auto target = candidate->Target(winding, phase);
    logs = candidate->LogScale(target);
    const Range azimuth = candidate->Azimuth(target);
    if (!azimuth.Finite() || !logs.Finite()) return {Outcome::Failed};
    const auto result = logs.lo > limit || !AzimuthMayMatch(azimuth, kLongitude)
                            ? Outcome::Absent
                            : Outcome::Possible;
    return {result, logs, azimuth};
}

void Print(Range r) { std::cout << '[' << r.lo << ',' << r.hi << ']'; }
}  // namespace

int main() {
    if (!RoundingEnvironment()) return 1;
    std::cout << std::hexfloat;
    const auto broad = Prepare(kRadius, Range(0, sqrt(Range(-kPotential.lo)).hi));
    if (!broad) return 2;
    const Range amplitude = sqrt(broad->polar.amplitude2);
    if (amplitude.lo != kAmplitude.lo || amplitude.hi != kAmplitude.hi) return 3;
    const Range ratio = Range(kLatitude.lo) / Range(amplitude.hi);
    if (!(ratio.lo > CosPoint(kPhase.hi).hi)) return 3;
    const auto threshold = broad->LogScale(broad->Target(kFirstShared, kPhase));
    std::cout << "shared log scale at first winding ";
    Print(threshold);
    std::cout << '\n';
    if (!(threshold.Finite() && threshold.hi < LogPoint(kSmallScale.hi).lo)) return 4;
    const auto shared = Prepare(kRadius, kSmallScale);
    if (!shared) return 5;
    const Range inverse_winding(0.0, (Range(1.0) / Range(kExceptionalWinding)).hi);
    const Range normalized_log_scale =
        ((shared->radial.time_residual - shared->Target(0, kPhase)[0]) * inverse_winding -
         Range(2) * shared->half[0]) /
        (Range(2) * shared->radial.leading);
    const Range high_radius = RestrictRadius(kRadius, kSmallScale, kPhase);
    std::cout << "normalized log scale from winding 581 ";
    Print(normalized_log_scale);
    std::cout << " reachable latitude radius ";
    Print(high_radius);
    std::cout << '\n';
    if (!normalized_log_scale.Finite() || !(normalized_log_scale.lo > -1.4) ||
        !(normalized_log_scale.hi < -1.1) || !high_radius.Finite() ||
        !(kProofRadius.lo < high_radius.lo && high_radius.hi < kProofRadius.hi))
        return 6;

    unsigned excluded = 0, unresolved = 0;
    // The launch is north and moving toward the equator. A north source
    // therefore uses odd half-libration counts; both sides of the turn
    // are represented by the one signed terminal phase interval.
    for (unsigned winding = 1; winding < kEnd; winding += 2) {
        const auto& strip = winding < kFirstShared ? *broad : *shared;
        const auto answer = Exclude(strip, winding, kPhase);
        if (answer.outcome == Outcome::Failed) return 7;
        if (answer.outcome == Outcome::Absent) {
            ++excluded;
            continue;
        }
        if (winding != kExceptionalWinding) return 8;
        ++unresolved;
        std::cout << "possible winding " << winding << " log scale ";
        Print(answer.log_scale);
        std::cout << " azimuth ";
        Print(answer.azimuth);
        std::cout << '\n';
    }
    std::cout << "excluded " << excluded << " deferred " << unresolved << '\n';
    return excluded == 511 && unresolved == 1 ? 0 : 9;
}

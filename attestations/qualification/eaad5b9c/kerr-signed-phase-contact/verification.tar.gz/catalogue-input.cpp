#include "sirius/core/kerr_detector/angular_catalogue.h"

#include <bit>
#include <cstdint>
#include <iostream>

int main() {
    using namespace sirius::core;
    using namespace sirius::core::relativity::finite_tail_detail;
    if (!RoundingEnvironment()) return 1;
    const auto stars =
        StarfieldGenerator(ExpandPointStarfieldConfig(PointStarfieldConfig{})).GenerateCatalogue();
    if (stars.size() != 100000) return 2;
    constexpr Range latitude(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
    constexpr Range azimuth(-0x1.1dcd0ee4d9734p+1, -0x1.1dcd0ee4d972dp+1);
    unsigned matches = 0;
    for (std::size_t i = 0; i < stars.size(); ++i) {
        const auto& star = stars[i];
        const Range x(star.direction_x), y(star.direction_y), z(star.direction_z);
        const Range mu = z / sqrt(Square(x) + Square(y) + Square(z));
        if (mu.lo != latitude.lo || mu.hi != latitude.hi) continue;
        const Range phi = CatalogueAzimuth(x.lo, y.lo);
        if (phi.lo != azimuth.lo || phi.hi != azimuth.hi) continue;
        std::cout << "catalogue ordinal " << i << " direction words ";
        for (float value : {star.direction_x, star.direction_y, star.direction_z})
            std::cout << "0x" << std::hex << std::bit_cast<std::uint32_t>(value) << ' ';
        std::cout << "\n" << std::hexfloat << "direction floats ";
        for (float value : {star.direction_x, star.direction_y, star.direction_z})
            std::cout << value << ' ';
        std::cout << '\n';
        ++matches;
    }
    std::cout << std::dec << "exact interval matches " << matches << '\n';
    return matches == 1 ? 0 : 3;
}

from pathlib import Path
import re
import subprocess
import sys
import time


stage = Path('out/native-viewer-transport')


def make_window(title, geometry, capture):
    with capture.open('w') as stream:
        process = subprocess.Popen(['stdbuf', '-oL', 'xev', '-name', title, '-geometry', geometry],
                                   stdout=stream, stderr=subprocess.STDOUT)
    try:
        names = subprocess.check_output(['xdotool', 'search', '--sync', '--onlyvisible',
                                         '--name', '^' + title + '$'], text=True, timeout=5)
        return process, names.split()[0]
    except BaseException:
        process.terminate()
        process.wait(timeout=5)
        raise


def send(window):
    return subprocess.run([sys.executable, '-B', 'scripts/viewer-x11-pointer.py', window],
                          text=True, capture_output=True, timeout=5)


log = stage / 'visible-xevents.log'
visible, window = make_window('Sirius pointer probe', '256x192+48+48', log)
try:
    accepted = send(window)
    assert accepted.returncode == 0, accepted.stderr
    time.sleep(0.25)
    events = log.read_text().split('\n\n')
    expected = (r'^ButtonPress event,.*?synthetic NO,.*?\(120,120\).*?button 1',
                r'^MotionNotify event,.*?synthetic NO,.*?\(180,160\).*?state 0x100',
                r'^ButtonRelease event,.*?synthetic NO,.*?\(180,160\).*?button 1',
                r'^ButtonPress event,.*?synthetic NO,.*?\(180,160\).*?button 4')
    positions = [next(i for i, event in enumerate(events) if re.search(pattern, event, re.S))
                 for pattern in expected]
    assert positions == sorted(set(positions)), positions
    print('visible XTEST drag and scroll delivered at both original client coordinates')
    cover_log = stage / 'cover-xevents.log'
    cover, _ = make_window('Sirius pointer cover', '256x192+48+48', cover_log)
    try:
        covered = send(window)
        assert covered.returncode and 'covered or has no visible input surface' in covered.stderr
        assert 'ButtonPress' not in cover_log.read_text()
        print('covered target refused before any button event')
    finally:
        cover.terminate()
        cover.wait(timeout=5)
    hidden, hidden_window = make_window('Sirius pointer outside screen', '256x192+720+560',
                                        stage/'offscreen-xevents.log')
    try:
        offscreen = send(hidden_window)
        assert offscreen.returncode and 'outside the visible X11 screen' in offscreen.stderr
        print('off-screen target refused before motion')
    finally:
        hidden.terminate()
        hidden.wait(timeout=5)
finally:
    visible.terminate()
    visible.wait(timeout=5)

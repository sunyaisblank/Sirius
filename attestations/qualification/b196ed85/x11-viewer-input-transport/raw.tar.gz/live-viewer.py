from pathlib import Path
import json
import os
import re
import subprocess
import sys
import time


root = Path.cwd()
stage = root / 'out/native-viewer-transport'
binary = root / 'bin/linux-ci/src/sirius/app/sirius'
transcript = stage / 'viewer-events.log'
env = {k: v for k, v in os.environ.items()
       if not k.startswith(('SIRIUS_', 'VK_', 'MESA_')) and k not in {'LD_PRELOAD', 'LD_LIBRARY_PATH'}}
env.update(WAYLAND_DISPLAY='', VK_DRIVER_FILES=str(Path.home()/'.local/opt/mesa-dzn/dzn_icd.x86_64.json'),
           SIRIUS_VULKAN_DEVICE='0', MESA_SHADER_CACHE_DISABLE='true',
           SIRIUS_MEMORY_BUDGET_MB='2048', TMPDIR=str(stage), XDG_CACHE_HOME=str(stage / 'cache'),
           SIRIUS_VIEWER_INPUT_TRANSCRIPT=str(transcript))
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision.startswith('b196ed85') and not subprocess.check_output(['git', 'status', '--porcelain'])
inventory = subprocess.check_output([binary, '--json', 'info', 'system'], env=env, timeout=20)
(stage / 'device.json').write_bytes(inventory)
vulkan = json.loads(inventory)['backends']['vulkan']
device = vulkan['devices'][vulkan['selected_device_index']]
assert device['kind'] == 'integrated' and device['vendor_id'] == 0x1002 and 'Radeon 780M' in device['name']
assert device['driver_name'] == 'Dozen'

command = [str(binary), 'view', '--backend', 'vulkan', '--width', '1024', '--height', '768']
result = {'source_revision': revision, 'command': command, 'device': device,
          'display_scope': 'isolated Xvfb X11 server with the real Radeon 780M Vulkan renderer',
          'display_geometry': subprocess.check_output(['xdotool','getdisplaygeometry'],text=True).strip()}
begin = time.monotonic()
preview = re.compile(r'^tile-preview-published generation=(\d+) width=(\d+) height=(\d+)$')


def events():
    return transcript.read_text().splitlines() if transcript.is_file() else []


def tiles(lines):
    return [tuple(map(int, match.groups())) for line in lines if (match := preview.fullmatch(line))]


with (stage / 'viewer.log').open('wb') as log:
    proc = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT)

    def await_event(predicate, limit):
        deadline = time.monotonic() + limit
        while time.monotonic() < deadline:
            if value := predicate(events()):
                return value
            if proc.poll() is not None:
                raise RuntimeError(f'Product viewer exited with {proc.returncode}')
            time.sleep(.1)
        raise TimeoutError('the product did not publish the awaited event')

    def xdo(*args):
        return subprocess.check_output(['xdotool', *args], text=True, env=env, timeout=10).strip()

    try:
        def owned_window(_):
            visible = subprocess.run(['xdotool', 'search', '--onlyvisible', '--pid', str(proc.pid),
                                      '--name', '^Sirius -'], text=True, capture_output=True,
                                     env=env, timeout=5)
            return visible.stdout.split()[0] if visible.returncode==0 and visible.stdout.strip() else None

        window = await_event(owned_window, 30)
        result['window'] = window
        result['window_seconds'] = time.monotonic() - begin
        (stage/'window.txt').write_text(subprocess.check_output(['xwininfo', '-id', window], text=True, env=env))
        initial = await_event(tiles, 185)[0]
        result['initial_tile'] = initial
        result['initial_seconds'] = time.monotonic() - begin
        result['complete_frames_before_input'] = sum(line.startswith('frame-published ') for line in events())
        assert initial[1:] == (256,192) and result['complete_frames_before_input']==0
        driver = Path.home()/'.local/opt/mesa-dzn/libvulkan_dzn.so'
        maps = [line for line in Path(f'/proc/{proc.pid}/maps').read_text().splitlines()
                if str(driver) in line]
        assert maps and all(int(line.split()[4])==driver.stat().st_ino for line in maps)
        (stage/'driver-mappings.txt').write_text('\n'.join(maps)+'\n')
        xdo('windowfocus', '--sync', window)
        assert xdo('getwindowfocus')==window
        start = len(events())
        xdo('keydown','--window',window,'w')
        time.sleep(.1)
        xdo('keyup','--window',window,'w')
        subprocess.run([sys.executable, '-B', 'scripts/viewer-x11-pointer.py', window], env=env, timeout=10, check=True)
        needed = (r'^keyboard-callback key=87 action=press',r'^keyboard-callback key=87 action=release',
                  r'^pointer-callback kind=button button=0 action=press',
                  r'^pointer-callback kind=cursor .* dragging=true',
                  r'^pointer-callback kind=button button=0 action=release',r'^pointer-callback kind=scroll yoffset=1')

        def replaced(lines):
            lines = lines[start:]
            indices = [next((i for i,line in enumerate(lines) if re.search(pattern,line)), -1)
                       for pattern in needed]
            if -1 in indices or indices!=sorted(set(indices)):
                return None
            return next((tile for tile in tiles(lines[max(indices)+1:]) if tile[0]>initial[0]),None)

        result['replacement_tile'] = await_event(replaced, 165)
        result['replacement_seconds'] = time.monotonic() - begin
        xdo('key','--window',window,'Escape')
        result['exit_code'] = proc.wait(timeout=25)
        assert result['exit_code']==0
        output=(stage/'viewer.log').read_text()
        scenes=[json.loads(line.split('Scene evidence: ',1)[1]) for line in output.splitlines()
                if line.startswith('[Session] Scene evidence: ')]
        result['original_scene']=scenes[0]
        result['last_scene']=scenes[-1]
        assert scenes[0]['backend']=='Vulkan' and scenes[0]['disk_enabled']
        assert scenes[0]['samples_per_pixel']==1 and scenes[-1]['field_of_view']<scenes[0]['field_of_view']
        assert any('Retained renderer:' in line and 'Radeon 780M' in line and 'budget 2048 MiB' in line
                   for line in output.splitlines())
        result['queued_cancelled_generations']=output.count('Finished with state: Cancelled')
        assert result['queued_cancelled_generations']>0
        result['passed']=True
    except BaseException as error:
        result['passed']=False
        result['failure']=f'{type(error).__name__}: {error}'
        raise
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
        result['elapsed_seconds']=time.monotonic()-begin
        (stage/'viewer-result.json').write_text(json.dumps(result,indent=2)+'\n')

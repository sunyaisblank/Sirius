#include "sirius/render/session/kerr_point_detector.cpp"
#include "sirius/core/spectral/point_source_transfer.h"

#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>

int main() {
    using namespace sirius;
    using namespace sirius::render;
    unsigned samples = 0, misses = 0;
    double maximum_actual_over_bound = 0.0;
    double minimum_fraction = 1.0;
    double maximum_fraction = 0.0;
    for (double temperature : {1800., 2500., 3550., 4600., 5772., 7200., 10300., 20000., 40000.,
                               75000., 200000.}) {
        const auto normal = core::spectral::BlackbodyBandRgb(temperature);
        if (!normal) return 10;
        const double normalizer = std::max({normal->r, normal->g, normal->b, .001f});
        for (double shift : {.2, .35, .6, .8, 1., 1.25, 1.7, 2.4, 4., 8.}) {
            const Range shifted = Range(temperature) * Range(shift);
            const auto fraction = PlanckFraction(shifted);
            if (!fraction.Finite()) return 11;
            minimum_fraction = std::min(minimum_fraction, fraction.hi);
            maximum_fraction = std::max(maximum_fraction, fraction.hi);
            const long double exponent = static_cast<long double>(core::constants::physical::kPlanckC2)/
                (static_cast<long double>(core::constants::spectral::kLambdaMax)*temperature*shift);
            if (!(exponent/std::expm1(exponent) <= fraction.hi)) ++misses;
            const auto transfer = core::spectral::TransferPointSourceBand(temperature, shift, 1, .1);
            const auto old = ColourEnvelope(Range(shift), Range(.1), 1.);
            if (!transfer || !old) return 12;
            const Range corrected = *old * fraction * Range(temperature) / Range(normalizer);
            if (!corrected.Finite()) return 13;
            for (auto value : *transfer) {
                if (!(value <= corrected.hi)) ++misses;
                maximum_actual_over_bound = std::max(maximum_actual_over_bound, value/corrected.hi);
            }
            ++samples;
        }
    }
    std::cout << std::setprecision(17) << "temperature_and_shift_samples=" << samples
              << " checks=" << samples*4 << " misses=" << misses
              << " fraction_limits=" << minimum_fraction << ':' << maximum_fraction
              << " max_rgb_over_bound=" << maximum_actual_over_bound << '\n';
    return misses==0 ? 0 : 14;
}

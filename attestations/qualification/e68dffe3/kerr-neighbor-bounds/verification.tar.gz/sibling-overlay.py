from pathlib import Path
root = Path.cwd()
out = root/'out/kerr-neighbor-cohort/prototype'

def patch(s, old, new):
    assert s.count(old) == 1, old
    return s.replace(old, new)

def read(name):
    return (root/'src/sirius/render/session'/name).read_text()

def save(name, source):
    p = out/'sirius/render/session'/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(source)

h = patch(read('point_source_detector.h'), 'using PointDetectorCellBound', '''struct PointDetectorCell {
    DetectorCoordinate lower, upper;
};

using PointDetectorCellBound''')
h = patch(h, 'struct PointDetectorBatchResult {', '''// The cells are interior-disjoint within a single original Gaussian. The
// bound is charged once for the union, using the same candidate ledger.
using PointDetectorGroupedCellBound = std::function<std::optional<std::array<double, 3>>(
    const PointDetectorFootprint&, std::span<const PointDetectorCell>, std::size_t&)>;

struct PointDetectorBatchResult {''')
h = patch(h, 'const PointDetectorCellBound& cell_bound = {});',
          '''const PointDetectorCellBound& cell_bound = {},
                           const PointDetectorGroupedCellBound& grouped_cell_bound = {});''')
save('point_source_detector.h', h)
h = patch(read('kerr_point_detector.h'), '''struct PointDetectorCell {
    DetectorCoordinate lower, upper;
};

''', '')
save('kerr_point_detector.h', h)
v = patch(read('point_source_detector.cpp'), '#include <algorithm>', '#include <algorithm>\n#include <iostream>')
v = patch(v, 'struct Estimate {', '''using GroupedCellBound =
    std::function<std::optional<Rgb>(std::span<const PointDetectorCell>, std::size_t&)>;

struct Estimate {''')
v = patch(v, '             const ScalarCellBound* cell_bound = nullptr)',
          '''             const ScalarCellBound* cell_bound = nullptr,
             const GroupedCellBound* grouped_cell_bound = nullptr)''')
v = patch(v, '          cell_bound_(cell_bound) {}',
          '''          cell_bound_(cell_bound),
          grouped_cell_bound_(grouped_cell_bound) {}''')
v = patch(v, '    Estimate Refine(const Cell& cell, const Estimate& coarse) {',
          '''    unsigned BoundSiblingCells(const std::array<Cell, 4>& children,
                               std::array<Estimate, 4>& estimates) {
        if (!grouped_cell_bound_ || children.front().depth + 1 < policy_.maximum_depth) return 0;
        const bool terminal = children.front().depth == policy_.maximum_depth;
        std::array<PointDetectorCell, 4> group;
        unsigned mask = 0;
        std::size_t count = 0;
        for (unsigned i = 0; i < children.size(); ++i) {
            if (estimates[i].certified_dark || !children[i].IntersectsSupport() ||
                (!terminal && !estimates[i].whole_sky_query))
                continue;
            group[count++] = {children[i].lower, children[i].upper};
            mask |= 1U << i;
        }
        if (count < 2) return 0;

        const auto available = policy_.maximum_candidate_visits - statistics_.candidate_visits;
        auto remaining = available;
        const auto bound = (*grouped_cell_bound_)(std::span(group).first(count), remaining);
        if (remaining > available) Fail(PointDetectorFailure::Arithmetic);
        statistics_.candidate_visits += available - remaining;
        CheckCancellation();
        const bool accepted = bound && std::ranges::all_of(*bound, [&](double error) {
            return std::isfinite(error) && error >= 0.0 && error <= policy_.absolute_rgb_error;
        });
        std::clog << "group siblings depth=" << children.front().depth << " count=" << count
                  << " visits=" << available-remaining << " accepted=" << accepted;
        if (bound) std::clog << " bound=" << (*bound)[0];
        std::clog << " used=" << statistics_.candidate_visits << std::endl;
        if (!accepted) return 0;
        for (unsigned i = 0; i < children.size(); ++i)
            if (mask & (1U << i)) estimates[i] = {};
        auto& first = estimates[std::countr_zero(mask)];
        first.error = *bound;
        first.bounded_omission = true;
        return mask;
    }

    Estimate Refine(const Cell& cell, const Estimate& coarse) {''')
v = patch(v, '        for (int i = 0; i < 4; ++i) estimates[i] = Refine(children[i], estimates[i]);',
          '''        const auto grouped = BoundSiblingCells(children, estimates);
        for (unsigned i = 0; i < children.size(); ++i)
            if (!(grouped & (1U << i))) estimates[i] = Refine(children[i], estimates[i]);''')
v = patch(v, '    const ScalarCellBound* cell_bound_;',
          '''    const ScalarCellBound* cell_bound_;
    const GroupedCellBound* grouped_cell_bound_;''')
v = patch(v, '    const PointDetectorCellBound& cell_bound) {',
          '''    const PointDetectorCellBound& cell_bound,
    const PointDetectorGroupedCellBound& grouped_cell_bound) {''')
v = patch(v, '                    const auto leaf = Detector',
          '''                    GroupedCellBound original_grouped_bound;
                    if (grouped_cell_bound)
                        original_grouped_bound = [&](std::span<const PointDetectorCell> cells,
                                                     std::size_t& remaining) {
                            return grouped_cell_bound(footprint, cells, remaining);
                        };
                    const auto leaf = Detector''')
v = patch(v, '                                               original_bound ? &original_bound : nullptr)',
          '''                                               original_bound ? &original_bound : nullptr,
                                               original_grouped_bound ? &original_grouped_bound : nullptr)''')
save('point_source_detector.cpp', v)
px = patch(read('pixel_shading.cpp'), '    PointDetectorCellBound cell_bound;',
           '''    PointDetectorCellBound cell_bound;
    PointDetectorGroupedCellBound grouped_cell_bound;''')
px = patch(px, '''                                          remaining);
        };
    }
    const auto group =''', '''                                          remaining);
        };
        grouped_cell_bound = [&, origin](const PointDetectorFootprint& footprint,
                                         std::span<const PointDetectorCell> cells,
                                         std::size_t& remaining) {
            return BoundKerrDetectorCells(*kerr_catalogue, brightness, camera.GetConfig(),
                                          *prepared, origin, footprint, cells, cancelled, remaining);
        };
    }
    const auto group =''')
px = patch(px, '                                   probe_batch, dark_cell, cell_bound);',
           '                                   probe_batch, dark_cell, cell_bound, grouped_cell_bound);')
px = patch(px, '    const auto group =\n        EvaluatePointDetectorGroup(catalogue, brightness, footprints, probe, cancelled, {},',
           '''    if (x == 928 && y == 608 && width == 32 && height == 32) {
        const auto at = std::ranges::find(indices, std::size_t{704});
        if (at == indices.end())
            return std::unexpected(PointDetectorError{PointDetectorFailure::InvalidInput, {}});
        const auto single = footprints[static_cast<std::size_t>(at-indices.begin())];
        footprints.assign(1, single);
        indices.assign(1, 704);
    }
    const auto group =
        EvaluatePointDetectorGroup(catalogue, brightness, footprints, probe, cancelled, {},''')
save('pixel_shading.cpp', px)

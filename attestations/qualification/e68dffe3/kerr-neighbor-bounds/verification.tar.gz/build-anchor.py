import json, os
from pathlib import Path
import shlex
import subprocess

root=Path.cwd()
scratch=root/'out/kerr-neighbor-cohort'
build=root/'bin/linux-ci'
overlay=scratch/'anchor'
env={**os.environ,'TMPDIR':str(scratch)}
flags=json.loads((build/'compile_commands.json').read_text())
path=root/'src/sirius/render/session/kerr_point_detector.cpp'
source=overlay/'sirius/render/session/kerr_point_detector.cpp'
entry,=[item for item in flags if item['file']==str(path)]
command=shlex.split(entry['command'])
out=scratch/'kerr_anchor.o'
args=[command[0],'-I'+str(overlay),*command[1:-4],'-o',str(out),'-c',str(source)]
prior=json.loads((scratch/'grouped-app/commands.json').read_text())
link=prior['link']
link.insert(4,str(out))
link[link.index('-o')+1]=str(scratch/'block-siblings-anchor')
for executable in (args,link):
    subprocess.run(executable,cwd=build,env=env,check=True)
(scratch/'anchor-commands.json').write_text(json.dumps({'compile':args,'link':link},indent=2)+'\n')

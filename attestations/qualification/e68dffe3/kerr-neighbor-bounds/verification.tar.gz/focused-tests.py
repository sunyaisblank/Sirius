import json
import os
from pathlib import Path
import shlex
import subprocess
from xml.etree import ElementTree

root=Path.cwd()
scratch=root/'out/kerr-neighbor-cohort'
build=root/'bin/linux-ci'
env={**os.environ,'TMPDIR':str(scratch)}
env.pop('SIRIUS_PACKAGED_SOFTWARE_VULKAN', None)
env.update(VK_DRIVER_FILES=str(Path.home()/'.local/opt/mesa-dzn/dzn_icd.x86_64.json'),
           SIRIUS_VULKAN_DEVICE='0',SIRIUS_MEMORY_BUDGET_MB='2048',
           MESA_SHADER_CACHE_DISABLE='true',XDG_CACHE_HOME=str(scratch/'test-cache'))
commands=json.loads((build/'compile_commands.json').read_text())
link_prior=json.loads((scratch/'link-commands.json').read_text())['link'][0]
libraries=link_prior[link_prior.index('src/sirius/app/libsirius_app_lib.a'):]
names=['point_source_detector_test.cpp','point_source_detector_physics_test.cpp']
objects=['tests/render/CMakeFiles/sirius_render_tests.dir/'+part+'.o' for part in names]
compile=['ninja','-j','3','sirius','gtest_main',*objects]
binary=build/'src/sirius/app/focused_point_detectors'
link=['/usr/bin/g++-14',*objects,'-o',str(binary),*libraries,'lib/libgtest_main.a','lib/libgtest.a',
      '-pthread']
xml=scratch/'focused-tests.xml'
test=['timeout','45',str(binary),
      '--gtest_filter=PointSourceDetector.*:-'
      'PointSourceDetector.RetainedMovingKerrFluxMatchesIndependentSeparatedImageAndBand:'
      'PointSourceDetector.RetainedRotatingIsolatedStarMatchesIndependentSharedRegionBrightness',
      '--gtest_output=xml:'+str(xml)]
record={'build':compile,'compile':[row for row in commands if Path(row['file']).name in names],
        'link':link,'test':test}
(scratch/'focused-tests-commands.json').write_text(json.dumps(record,indent=2)+'\n')
for command in (link,test):
    subprocess.run(command,cwd=build,env=env,check=True)
nodes=ElementTree.parse(xml).getroot().findall('.//testcase')
assert len(nodes)==25
for node in nodes:
    assert node.attrib['status']=='run'
    assert all(node.find(tag) is None for tag in ('skipped','failure','error'))

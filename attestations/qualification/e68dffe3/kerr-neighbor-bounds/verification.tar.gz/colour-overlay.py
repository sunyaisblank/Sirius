from pathlib import Path

root = Path.cwd()
out = root/'out/kerr-neighbor-cohort/colour'

def patch(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)

def read(relative):
    return (root/'src/sirius'/relative).read_text()

def save(relative, source):
    path = out/'sirius'/relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(source)

a = read('core/kerr_detector/angular_catalogue.h')
a = patch(a, '        double longitude_key;',
          '''        double longitude_key;
        float temperature_kelvin;''')
a = patch(a, '            const auto& star = stars[i];',
          '''            const auto& star = stars[i];
            index.maximum_temperature_ = std::max(index.maximum_temperature_, star.temperature_K);''')
a = patch(a, '{latitude, azimuth, weighted, std::midpoint(azimuth.lo, azimuth.hi)});',
          '''{latitude, azimuth, weighted, std::midpoint(azimuth.lo, azimuth.hi), star.temperature_K});''')
a = patch(a, '  private:\n    std::array<std::array<Row, kLatitudeRows>, 2> rows_;',
          '''    float MaximumTemperature() const { return maximum_temperature_; }

  private:
    std::array<std::array<Row, kLatitudeRows>, 2> rows_;
    float maximum_temperature_ = 0.0f;''')
save('core/kerr_detector/angular_catalogue.h', a)

source = read('render/session/kerr_point_detector.cpp')
source = patch(source,'std::optional<Range> ColourEnvelope(','''// For x = C2/(lambda*T*g), the Planck/Rayleigh-Jeans ratio is
// x/expm1(x). Positive Taylor terms give a lower bound on expm1(x)/x
// at the least exponent admitted by the physical shift and spectral band.
Range PlanckFraction(Range shifted_temperature) {
    using namespace core::constants;
    if (!shifted_temperature.Finite() || !(shifted_temperature.hi > 0.0)) return Range(1.0);
    const Range exponent = Range(physical::kPlanckC2) /
                           (Range(spectral::kLambdaMax) * Range(shifted_temperature.hi));
    if (!exponent.Finite() || !(exponent.lo > 0.0)) return Range(1.0);
    const Range x(exponent.lo), x2 = Square(x);
    const Range terms = Range(1.0) + x / Range(2.0) + x2 / Range(6.0) +
                        x2 * x / Range(24.0) + Square(x2) / Range(120.0);
    const Range fraction = Range(1.0) / terms;
    return fraction.Finite() ? Range(std::min(1.0, fraction.hi)) : Range(1.0);
}

std::optional<Range> ColourEnvelope(''')
source = patch(source, '''    const auto colour = ColourEnvelope(Range(1.0) / (Range(0.0) - whole->energy),
                                       Range(maximum_gaussian), brightness);
    if (!latitude || !colour) return {};''',
                 '''    const Range camera_frequency = Range(1.0) / (Range(0.0) - whole->energy);
    const auto colour = ColourEnvelope(camera_frequency, Range(maximum_gaussian), brightness);
    if (!latitude || !colour) return {};
    const Range full_colour =
        *colour * PlanckFraction(camera_frequency * Range(angular->MaximumTemperature()));''')
source = patch(source, '(*colour * band.weighted_temperature * Range(tail->tail_prefactor)).hi;',
               '(full_colour * band.weighted_temperature * Range(tail->tail_prefactor)).hi;')
source = patch(source, 'std::nullopt, *colour / determinant,',
               'std::nullopt, full_colour / determinant,')
source = patch(source, '''        const Range contribution =
            *colour * candidate.source->weighted_temperature * *density / determinant;''',
               '''        const Range shifted_temperature =
            camera_frequency * Range(candidate.source->temperature_kelvin);
        const Range contribution =
            *colour * PlanckFraction(shifted_temperature) *
            candidate.source->weighted_temperature * *density / determinant;''')
save('render/session/kerr_point_detector.cpp',source)

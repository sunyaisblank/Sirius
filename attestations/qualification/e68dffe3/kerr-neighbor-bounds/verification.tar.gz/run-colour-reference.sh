#!/usr/bin/env bash
set -euo pipefail
root="$PWD"
s="$root/out/kerr-neighbor-cohort"
lib="$root/bin/linux-ci/src/sirius"
export TMPDIR="$s"
g++-14 -I"$s/colour" -I"$root/src" -std=c++2c -O3 -DNDEBUG -Wall -Wextra -Werror \
    -DSIRIUS_CONTRACT_MODE=2 -DSIRIUS_HAS_RETAINED_COMPUTE=1 -DSIRIUS_RELEASE_RESOURCE_LOCKED=1 \
    -fno-fast-math -ffp-contract=off -frounding-math "$s/colour-reference.cpp" \
    "$lib/backend/libsirius_backend_cpu.a" "$lib/backend/libsirius_backend.a" \
    "$lib/core/libsirius_core.a" "$lib/libsirius_base.a" -lvulkan -ldl -lrt -pthread -o "$s/colour-reference"
"$s/colour-reference"

#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "sirius/render/session/kerr_point_detector.cpp"

#include <chrono>
#include <iomanip>
#include <iostream>
#include <map>

using namespace sirius;
using namespace sirius::render;

using Real = long double;
using Pair = std::array<Real, 2>;

struct PolarReference {
    Real angular, amplitude2, omega2, drag;
};

PolarReference IndependentShape(Real mass, Real spin, Real centre, Real separation) {
    const Real u = centre, a = spin;
    const auto delta = [&](Real x) { return 1 - 2 * mass * x + a * a * x * x; };
    const Real b = delta(u) * u * u;
    const Real db = (2 * a * a * u - 2 * mass) * u * u + 2 * delta(u) * u;
    Real angular = 3, carter = 25;
    for (int i = 0; i < 16; ++i) {
        const Real k = a * a - a * angular;
        const Real p = 1 + k * u * u, dp = 2 * k * u;
        const Real residual = p * p - b * carter + separation * separation;
        const Real tangent = 2 * p * dp - db * carter;
        const Real d_l = -2 * a * u * u * p, d_c = -b;
        const Real d_dl = -2 * a * (u * u * dp + 2 * u * p), d_dc = -db;
        const Real det = d_l * d_dc - d_c * d_dl;
        angular -= (d_dc * residual - d_c * tangent) / det;
        carter -= (d_l * tangent - d_dl * residual) / det;
    }
    const Real eta = carter - (angular - a) * (angular - a);
    const Real k = eta + angular * angular - a * a;
    const Real omega2 = (k + std::sqrt(k * k + 4 * a * a * eta)) / 2;
    Real low = 0, high = u;
    for (int i = 0; i < 85; ++i) {
        const Real q = std::midpoint(low, high);
        const Real p = 1 + (a * a - a * angular) * q * q;
        if (p * p - delta(q) * q * q * carter > 0)
            low = q;
        else
            high = q;
    }
    const Real turn = separation == 0 ? u : std::midpoint(low, high);
    return {angular, eta / omega2, omega2,
            turn * (2 * a * mass - a * a * angular * turn) / delta(turn)};
}

Pair IndependentPartial(Real mass, Real spin, Real centre, Real separation, Real latitude) {
    const auto shape = IndependentShape(mass, spin, centre, separation);
    constexpr int panels = 16384;
    const Real end = std::asin(std::min(1.L, latitude / std::sqrt(shape.amplitude2)));
    const Real step = end / panels;
    Pair integral{};
    for (int i = 0; i <= panels; ++i) {
        const Real sin = std::sin(i * step);
        const Real mu2 = shape.amplitude2 * sin * sin;
        const Real time = 1 / std::sqrt(shape.omega2 + spin * spin * mu2);
        const Real factor = (i == 0 || i == panels ? 1 : (i % 2 ? 4 : 2)) * step / 3;
        integral[0] += factor * time;
        integral[1] += factor * time * (shape.angular / (1 - mu2) + shape.drag);
    }
    return integral;
}


Real IndependentCriticalLongitude(Real centre,Real start,Real launch_mu,Real source_mu,Real fixed) {
    constexpr Real mass=1;
    const Real a=static_cast<Real>(.9);
    const auto shape=IndependentShape(mass,a,centre,0);
    const Real eta=shape.amplitude2*shape.omega2;
    const Real d1=2*a*mass,d2=-a*a*shape.angular;
    const auto half=IndependentPartial(mass,a,centre,0,std::sqrt(shape.amplitude2));
    const auto initial=IndependentPartial(mass,a,centre,0,launch_mu);
    const auto final=IndependentPartial(mass,a,centre,0,source_mu);
    const Real polar_drag=140*half[1]+initial[1]-final[1];
    const Real carter=eta+(shape.angular-a)*(shape.angular-a);
    const Real p4=-a*a*eta, p3=2*mass*carter;
    const Real c0=1/(centre*centre), c1=p3+2*centre*p4;
    Real drag_remainder=0;
    constexpr int panels=32768;
    for (Real end : {0.L,start}) {
        const Real width=(centre-end)/panels;
        for (int i=0; i<=panels; ++i) {
            const Real v=end+width*i;
            const Real divisor=1+v*(a*a*v-2*mass);
            const Real g=std::sqrt(c0+v*(c1+p4*v));
            const Real rate=(shape.drag*(a*a*(v+centre)-2*mass)-d1-d2*(v+centre))/(divisor*g);
            drag_remainder += rate*width*(i==0||i==panels ? 1 : (i%2 ? 4 : 2))/3;
        }
    }
    return fixed-polar_drag-drag_remainder;
}

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const auto film=camera.ProjectFilmForObserver(origin[0],origin[1]+22.0,
                                                  sample.pupil_u,sample.pupil_v);
    if (!film||!film->differential) return 40;
    const auto& matrix=film->differential->angular_jacobian;
    const double d=std::fma(matrix[0][0],matrix[1][1],-matrix[0][1]*matrix[1][0]);
    const double sigma=(60*core::constants::math::kPi/180.0)/1080.0;
    const PointDetectorFootprint footprint{
        {0,22}, {{{sigma*matrix[1][1]/d,-sigma*matrix[0][1]/d},
                  {-sigma*matrix[1][0]/d,sigma*matrix[0][0]/d}}}};
    using namespace core::relativity::finite_tail_detail;
    std::cout<<std::hexfloat<<"footprint_matrix "<<footprint.chart_from_standard[0][0]<<' '
              <<footprint.chart_from_standard[0][1]<<' '<<footprint.chart_from_standard[1][0]<<' '
              <<footprint.chart_from_standard[1][1]<<'\n';
    const core::PointStarfieldConfig stars;
    const core::StarfieldSpatialIndex catalogue(core::StarfieldGenerator(
        core::ExpandPointStarfieldConfig(stars)).GenerateCatalogue());
    const auto indexed=PrepareKerrDetectorCatalogue(catalogue);
    #include "adjacent-cells.inc"
    const auto cell=archived[61];
    const FilmVector box{Range(cell.lower[0],cell.upper[0]),Range(cell.lower[1],cell.upper[1])};
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    const auto chart=evaluate(box);
    if (!chart) return 41;
    const Real start=std::midpoint(chart->inverse_start.lo,chart->inverse_start.hi);
    const Real initial=std::midpoint(chart->initial_mu.lo,chart->initial_mu.hi);
    const Range fixed=FixedPupilAzimuth(1.0,.9,*chart);
    const Real fixed_phi=std::midpoint(fixed.lo,fixed.hi);
    const Real mu=std::midpoint(0x1.f4ed100889174p-1,0x1.f4ed10088917ep-1);
    const Real az=std::midpoint(0x1.58cd1de0eb804p+1,0x1.58cd1de0eb816p+1);
    const Real target=az-53*2*std::numbers::pi_v<Real>;
    const Real lower=0x1.c01bf13a8b6fbp-2L, upper=0x1.c01c02e6d537ap-2L;
    for (Real u : {lower,std::lerp(lower,upper,.25L),std::midpoint(lower,upper),
                   std::lerp(lower,upper,.75L),upper}) {
        const Real p=IndependentCriticalLongitude(u,start,initial,mu,fixed_phi);
        std::cout<<std::defaultfloat<<std::setprecision(18)<<"radius="<<u<<" longitude="<<p
                 <<" target="<<target<<" residual="<<p-target<<'\n';
    }
}

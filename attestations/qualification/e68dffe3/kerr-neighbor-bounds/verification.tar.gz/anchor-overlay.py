from pathlib import Path

root=Path.cwd()
scratch=root/'out/kerr-neighbor-cohort'
colour=scratch/'colour'
overlay=scratch/'anchor'
for name in ('core/kerr_detector/angular_catalogue.h','render/session/kerr_point_detector.cpp'):
    p=overlay/'sirius'/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes((colour/'sirius'/name).read_bytes())

def patch(source, old, new):
    assert source.count(old)==1, old
    return source.replace(old,new)

def read(name):
    return (root/'src/sirius'/name).read_text()

def save(name, text):
    (overlay/'sirius'/name).write_text(text)

f='core/kerr_detector/finite_screen.h'
s=read(f)
s=patch(s,'inline PhasePair IntegratePolarPartial(const FinitePolarShape& polar, Range phase) {',
          '''inline PhasePair IntegratePolarPartial(const FinitePolarShape& polar, Range phase,
                                       unsigned panels = 24) {''')
s=patch(s,'    constexpr unsigned panels = 24;\n','')
s=patch(s,'''Range source_mu, unsigned winding, bool approach) {''',
          '''Range source_mu, unsigned winding, bool approach, unsigned panels = 24) {''')
i=s.index('inline PhasePair PolarTargetAt')
j=s.index('struct RefinedCandidate',i)
body=s[i:j].replace('kPiBounds.hi * .5));','kPiBounds.hi * .5), panels);')
body=body.replace('launch_mu / amplitude));','launch_mu / amplitude), panels);')
body=body.replace('Abs(source_mu) / amplitude));','Abs(source_mu) / amplitude), panels);')
s=s[:i]+body+s[j:]
save(f,s)

f='core/kerr_detector/finite_phase.h'
s=patch(read(f),'''        // The singular part was integrated exactly. Since q²/sqrt(q²+gap)
        // <= q, the remaining contribution below cut is enclosed by cut².''',
          '''        // The singular part was integrated exactly. Enclose the
        // residual's weight below cut without resolving the narrow turn.''')
s=patch(s,'''        time = time + Range(0.0, cut * cut) * near[0];
        azimuth = azimuth + Range(0.0, cut * cut) * near[1];''',
          '''        Range near_weight(0.0, cut * cut);
        if (gap.hi == 0.0) {
            near_weight = Range(cut * cut);
        } else if (gap.hi < cut * cut) {
            // Above q0, 2*q^2/sqrt(q^2+gap) >= 2*q - gap/q.
            const Range gap_upper(gap.hi);
            const Range q0(sqrt(gap_upper).hi);
            if (q0.lo < cut) {
                const Range lower = Range(cut * cut) - Square(q0) -
                                    gap_upper * LogBounds(Range(cut) / q0);
                if (lower.Finite()) near_weight.lo = std::max(0.0, lower.lo);
            }
        }
        time = time + near_weight * near[0];
        azimuth = azimuth + near_weight * near[1];''')
save(f,s)

f='render/session/kerr_point_detector.cpp'
s=(overlay/'sirius'/f).read_text()
s=patch(s,'#include <mutex>','#include <mutex>\n#include <iostream>')
s=patch(s,'''std::optional<Range> BoundAzimuthImages(''',
          '''bool ExcludeThroughAzimuthAnchor(double mass, double spin, Range centre, Range separation,
                                const StationaryChart& chart, const FiniteCandidate& candidate,
                                Range slope) {
    const Range midpoint(std::midpoint(centre.lo, centre.hi));
    const auto radial =
        EvaluateFiniteRadialPhase(mass, spin, midpoint, separation, chart.inverse_start);
    if (!radial) return false;
    const auto target =
        PolarTargetAt(mass, spin, midpoint, separation, chart.initial_mu,
                      candidate.source->latitude, candidate.winding, candidate.approaching_equator,
                      96);
    const Range value =
        FixedPupilAzimuth(mass, spin, chart) -
        (target[1] + radial->drag_at_turn * target[0] + radial->spin_residual);
    const Range azimuth = value + slope * (centre - midpoint);
    return azimuth.Finite() && !AzimuthMayMatch(azimuth, candidate.source->azimuth);
}

std::optional<Range> BoundAzimuthImages(''')
old='''            if (density.Finite()) return density;
        }
    }

    candidate.log_scale = refined->log_scale;'''
new='''            if (density.Finite()) return density;
        }
        if (candidate.winding >= 64 && refined->log_scale.hi < -50.0 &&
            ExcludeThroughAzimuthAnchor(mass, spin, centre, separation, chart, candidate,
                                         derivative->conditioned_radial_slope)) {
            std::clog << "anchored exclusion winding=" << candidate.winding << std::endl;
            return Range{};
        }
    }

    candidate.log_scale = refined->log_scale;'''
s=patch(s,old,new)
save(f,s)

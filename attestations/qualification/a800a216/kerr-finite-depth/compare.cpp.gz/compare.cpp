#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "../../src/sirius/render/session/kerr_point_detector.cpp"

#include <iomanip>
#include <iostream>
#include <set>

namespace sirius::render {
namespace {
#include "baseline.h"
}
}

using namespace sirius;
using namespace sirius::render;

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const PointDetectorFootprint footprint{
        {0, 22}, {{{0x1.d323e59e01b7bp-1, -0x1.9662de6ca9f26p-9}, {0, 0x1.d520d6948dde7p-1}}}};

    using namespace core::relativity::finite_tail_detail;
    constexpr PointDetectorCell cells[]{
#include "cells.inc"
    };
    struct Counts {
        unsigned supported{}, captured{}, existing_capture{}, finite{}, mixed{}, attempts{}, star{};
        unsigned old_eval{}, new_eval{}, empty{}, widened{}, independent{}, max_winding{};
        double maximum_radius_growth{};
    };
    std::array<Counts, 6> stats{};
    std::array<std::set<std::array<double, 4>>, 6> groups;
    for (const auto& leaf : cells) {
        const double depth_width = leaf.upper[0] - leaf.lower[0];
        for (unsigned offset = 0; offset < groups.size(); ++offset) {
            const double width = std::ldexp(depth_width, offset);
            const auto lower = [width](double x) {
                return std::floor((x + 4.0) / width) * width - 4.0;
            };
            const double x = lower(leaf.lower[0]), y = lower(leaf.lower[1]);
            groups[offset].insert({x, y, x + width, y + width});
        }
    }
    constexpr Range source(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    for (unsigned offset = 0; offset < groups.size(); ++offset) {
        auto& count = stats[offset];
        for (const auto& entry : groups[offset]) {
            FilmVector box{Range(entry[0], entry[2]), Range(entry[1], entry[3])};
            const std::array nearest{std::clamp(0.0, box[0].lo, box[0].hi),
                                     std::clamp(0.0, box[1].lo, box[1].hi)};
            for (unsigned axis = 0; axis < 2; ++axis) {
                const Range extent2 = Range(16.0) - Square(Range(nearest[1 - axis]));
                if (extent2.hi < 0) {
                    box[axis] = InvalidRange();
                    break;
                }
                const double extent = sqrt(Range(extent2.hi)).hi;
                box[axis] = Range(std::max(box[axis].lo, -extent), std::min(box[axis].hi, extent));
            }
            if (!box[0].Finite() || !box[1].Finite()) {
                ++count.empty;
                continue;
            }
            const auto whole = evaluate(box);
            if (!whole) return 40;
            const auto before = BisectEscapingChart(box, *whole, [&](const FilmVector& region) {
                ++count.old_eval;
                return evaluate(region);
            });
            const auto after = CoverEscapingChart(box, *whole, [&](const FilmVector& region) {
                ++count.new_eval;
                return evaluate(region);
            });
            if (!after[0].Finite() || !after[1].Finite() || after[1].hi > before[1].hi) return 41;
            if (after[1].lo < before[1].lo) return 42;
            ++count.supported;
            if (after[1].lo > 0.0 && whole->positive_radial_endpoints) {
                ++count.captured;
                FilmVector film;
                for (unsigned a = 0; a < 2; ++a) {
                    const auto& row = footprint.chart_from_standard[a];
                    film[a] = Range(origin[a]) + Range(footprint.centre[a]) +
                              (Range(row[0]) * box[0] + Range(row[1]) * box[1]);
                }
                count.existing_capture += tracer.CertifyThinLensDetectorRegion(config, *launch, film);
                continue;
            }
            if (!(after[1].lo < 0.0)) continue;
            if (after[1].hi < 0.0) ++count.finite;
            else ++count.mixed;
            const double prior_width = before[0].hi - before[0].lo;
            const double current_width = after[0].hi - after[0].lo;
            if (current_width > prior_width) {
                ++count.widened;
                count.maximum_radius_growth = std::max(count.maximum_radius_growth,
                                                        current_width / prior_width);
            }
            if (offset == 0) {
                for (const double x : {box[0].lo, std::midpoint(box[0].lo, box[0].hi), box[0].hi})
                    for (const double y : {box[1].lo, std::midpoint(box[1].lo, box[1].hi), box[1].hi}) {
                        const auto sample = evaluate({Range(x), Range(y)});
                        if (!sample) return 43;
                        const auto& [radius, potential] = sample->coordinate;
                        if (potential.lo > after[1].hi || potential.hi < after[1].lo) return 44;
                        if (potential.hi < 0.0 &&
                            (radius.lo > after[0].hi || radius.hi < after[0].lo)) return 45;
                        ++count.independent;
                    }
            }
            const Range scale(after[1].hi < 0.0 ? sqrt(Range(-after[1].hi)).lo : 0.0,
                              sqrt(Range(-after[1].lo)).hi);
            const auto shape = MakeFinitePolarShape(1, .9, after[0], scale);
            if (!shape) return 46;
            const Range amplitude = sqrt(shape->amplitude2);
            if (amplitude.lo > source.hi || amplitude.hi < source.lo) continue;
            ++count.star;
            if (scale.lo == 0.0) continue;
            const auto radial = EncloseRegularizedRadialPhase(1, .9, after[0], scale,
                                                              whole->inverse_start, 128);
            if (!radial) return 47;
            const auto half = IntegratePolarPartial(*shape, kPiBounds * Range(.5));
            const Range max_time = Range(-2.0) * radial->leading_factor *
                                   LogPoint(scale.lo) + radial->time_remainder.value;
            const auto upper = (max_time / (Range(2.0) * half[0])).hi;
            if (!(std::isfinite(upper) && upper > 0.0 && upper < 1000.0)) return 48;
            count.max_winding = std::max(count.max_winding, unsigned(std::floor(upper)));
            ++count.attempts;
        }
        std::cout << "coarsening=" << offset << " boxes=" << groups[offset].size()
                  << " clipped_empty=" << count.empty << " represented=" << count.supported
                  << " captured=" << count.captured << " already_capture=" << count.existing_capture
                  << " finite_escape=" << count.finite << " mixed=" << count.mixed
                  << " old_eval=" << count.old_eval << " new_eval=" << count.new_eval
                  << " wider_radius=" << count.widened
                  << " maximum_width_ratio=" << count.maximum_radius_growth
                  << " source_turn_boxes=" << count.star << " finite_source_turn_boxes=" << count.attempts
                  << " max_winding_for_finite_turn_boxes=" << count.max_winding
                  << " sampled_checks=" << count.independent << '\n';
    }
}

import ctypes
import json
import os
from pathlib import Path
import re
import subprocess
import time

root = Path(__file__).resolve().parent
events = root / "events.log"
env = os.environ.copy()
for key in ("VK_ICD_FILENAMES", "VK_ADD_DRIVER_FILES", "VK_LOADER_DRIVERS_SELECT",
            "VK_LOADER_DRIVERS_DISABLE", "SIRIUS_PACKAGED_SOFTWARE_VULKAN"):
    env.pop(key, None)
env.update({"WAYLAND_DISPLAY": "",
            "VK_DRIVER_FILES": str(Path.home() / ".local/opt/mesa-dzn/dzn_icd.x86_64.json"),
            "SIRIUS_VULKAN_DEVICE": "0", "SIRIUS_MEMORY_BUDGET_MB": "2048",
            "MESA_SHADER_CACHE_DIR": str(root / "xtest-cache"), "TMPDIR": str(root),
            "SIRIUS_VIEWER_INPUT_TRANSCRIPT": str(events)})
project = root.parents[1]
binary = project / "bin/linux-ci/src/sirius/app/sirius"
inventory = subprocess.run([binary, "--json", "info", "system"], env=env, check=True,
                           capture_output=True, timeout=30)
data = json.loads(inventory.stdout)
vulkan = data["backends"]["vulkan"]
selected = vulkan["devices"][vulkan["selected_device_index"]]
assert selected["kind"] == "integrated" and "780M" in selected["name"] and selected["vendor_id"] == 0x1002
(root / "device.json").write_bytes(inventory.stdout)

command = [str(root / "sirius-viewer"), "--backend", "vulkan", "--width", "1024", "--height", "768"]
display_extent = subprocess.check_output(["xdotool", "getdisplaygeometry"], env=env, text=True).strip()
result = {"command": command, "display_geometry": display_extent, "selected_device": selected}
begin = time.monotonic()

def inputs():
    return events.read_text().splitlines() if events.is_file() else []

def wait_for(test, seconds):
    stop = time.monotonic() + seconds
    while time.monotonic() < stop:
        found = test()
        if found:
            return found
        if proc.poll() is not None:
            raise RuntimeError(f"Viewer stopped with status {proc.returncode}")
        time.sleep(.05)
    raise TimeoutError("Viewer prerequisite did not appear")

pattern = re.compile(r"^tile-preview-published generation=(\d+) width=(\d+) height=(\d+)$")

def latest_preview(minimum_generation=0):
    for line in reversed(inputs()):
        match = pattern.fullmatch(line)
        if match and int(match[1]) >= minimum_generation:
            return [int(part) for part in match.groups()]
    return None

with (root / "viewer.log").open("wb") as log:
    proc = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, cwd=project)
    result["pid"] = proc.pid
    try:
        window = subprocess.run(
            ["xdotool", "search", "--sync", "--onlyvisible", "--pid", str(proc.pid),
             "--name", "^Sirius -"], env=env, check=True, capture_output=True, text=True, timeout=25
        ).stdout.split()[0]
        assert window.isdigit()
        result["window_id"] = window
        result["window_seconds"] = time.monotonic()-begin
        result["initial_preview"] = wait_for(latest_preview, 185)
        result["initial_seconds"] = time.monotonic()-begin
        result["complete_frames_before_input"] = sum(x.startswith("frame-published ") for x in inputs())

        def xdo(*args):
            subprocess.run(["xdotool", *args], env=env, check=True, timeout=10)

        result["input_started_seconds"] = time.monotonic()-begin
        xdo("windowactivate", "--sync", window)
        xdo("keydown", "--window", window, "w")
        time.sleep(.10)
        xdo("keyup", "--window", window, "w")
        x11 = ctypes.CDLL("libX11.so.6")
        xtest = ctypes.CDLL("libXtst.so.6")
        display_ptr = ctypes.c_void_p
        x11.XOpenDisplay.argtypes = (ctypes.c_char_p,)
        x11.XOpenDisplay.restype = display_ptr
        x11.XDefaultRootWindow.argtypes = (display_ptr,)
        x11.XDefaultRootWindow.restype = ctypes.c_ulong
        x11.XTranslateCoordinates.argtypes = (
            display_ptr, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int),
            ctypes.POINTER(ctypes.c_ulong))
        x11.XSync.argtypes = (display_ptr, ctypes.c_int)
        x11.XCloseDisplay.argtypes = (display_ptr,)
        xtest.XTestFakeMotionEvent.argtypes = (display_ptr, ctypes.c_int, ctypes.c_int,
                                              ctypes.c_int, ctypes.c_ulong)
        xtest.XTestFakeButtonEvent.argtypes = (display_ptr, ctypes.c_uint, ctypes.c_int,
                                              ctypes.c_ulong)
        display = x11.XOpenDisplay(None)
        assert display
        try:
            screen = x11.XDefaultRootWindow(display)
            def move(x, y):
                sx, sy, child = ctypes.c_int(), ctypes.c_int(), ctypes.c_ulong()
                assert x11.XTranslateCoordinates(display, int(window), screen, x, y,
                                                 ctypes.byref(sx), ctypes.byref(sy), ctypes.byref(child))
                assert xtest.XTestFakeMotionEvent(display, -1, sx.value, sy.value, 0)
                x11.XSync(display, 0)
                time.sleep(.10)
            def button(index, pressed):
                assert xtest.XTestFakeButtonEvent(display, index, pressed, 0)
                x11.XSync(display, 0)
                time.sleep(.08)
            move(120, 120)
            button(1, True)
            move(180, 160)
            button(1, False)
            button(4, True)
            button(4, False)
        finally:
            x11.XCloseDisplay(display)
        requirements = [r"keyboard-callback key=87 action=press", r"keyboard-callback key=87 action=release",
                        r"pointer-callback kind=cursor .*dragging=true", r"pointer-callback kind=scroll yoffset=1"]
        def delivered():
            lines = inputs()
            matches = [next((i for i, line in enumerate(lines) if re.match(expect, line)), -1)
                       for expect in requirements]
            return max(matches) + 1 if all(i >= 0 for i in matches) else None

        after_input = wait_for(delivered, 5)
        first_generation = result["initial_preview"][0]
        def replacement():
            for line in inputs()[after_input:]:
                match = pattern.fullmatch(line)
                if match and int(match[1]) > first_generation:
                    return [int(part) for part in match.groups()]
            return None
        result["replacement_preview"] = wait_for(replacement, 165)
        result["replacement_seconds_from_launch"] = time.monotonic()-begin
        result["replacement_seconds_after_input"] = time.monotonic()-begin-result["input_started_seconds"]
        xdo("key", "--window", window, "Escape")
        result["exit_code"] = proc.wait(timeout=25)
        assert result["exit_code"] == 0
        result["pass"] = True
    except BaseException as error:
        result["pass"] = False
        result["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
        result["elapsed_seconds"] = time.monotonic()-begin
        (root / "result.json").write_text(json.dumps(result, indent=2)+"\n")

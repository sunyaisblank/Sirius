#include "sirius/core/kerr_detector/finite_screen.h"

#include <iostream>

namespace {
using namespace sirius::core::relativity::finite_tail_detail;
using Jet = TaylorSeries<2>;

Jet Sine(const Jet& angle) {
    const auto& [a, d1, d2] = angle.coefficient;
    const Range s = SineLobe(a);
    const Range c(CosPoint(std::min(a.hi, kPiBounds.hi)).lo,
                  CosPoint(std::max(a.lo, 0.0)).hi);
    Jet result;
    result.coefficient = {s, c * d1, c * d2 - Range(.5) * s * Square(d1)};
    return result;
}

Jet Asin(const Jet& value) {
    const auto& [x, d1, d2] = value.coefficient;
    const Range c = sqrt(Range(1.0) - Square(x));
    Jet result;
    result.coefficient = {AsinBounds(x), d1 / c,
                          d2 / c + Range(.5) * x * Square(d1) / (c * Square(c))};
    return result;
}

constexpr unsigned kFirstWinding = 1025;
constexpr Range kInverse(.43759975, .4376005);
constexpr Range kLogScalePerWinding(-1.4,-1.1);
constexpr Range kPhase(0.0, 0x1p-10);
constexpr Range kLaunchMu(0x1.67f25c4fe005p-3, 0x1.67f25c4fe0117p-3);
constexpr Range kStart(0x1.111112f155084p-5, 0x1.111112f1550a2p-5);
constexpr Range kSourceMu(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
constexpr Range kFixedAzimuth(0x1.0409070a74c8p-5, 0x1.0409070a74e26p-5);
constexpr Range kSourceAzimuth(-0x1.1dcd0ee4d9734p+1, -0x1.1dcd0ee4d972dp+1);

// For n >= 1025 and w < -1, exp(n*w) <= 2^-n. The ratios
// ((n+1)/n)^j / 2 are less than one for j <= 3. At n=1025,
// n^3 2^-n < 2^-900, so this bounds all required weighted powers.
constexpr Range kExpBound(0x1p-900);

Jet JetWith(Range value, Range first = {}, Range second = {}) {
    Jet result;
    result.coefficient = {value, first, second};
    return result;
}

Range Symmetric(Range positive) {
    return {-positive.hi, positive.hi};
}

Jet Logarithm(const Jet& jet) {
    const auto& [v,d1,d2] = jet.coefficient;
    return JetWith(LogBounds(v), d1 / v, d2 / v - Range(.5) * Square(d1 / v));
}

Jet Scale(const Jet& w) {
    if (!w.coefficient[0].Finite() || w.coefficient[0].hi > -1.0) return Jet(InvalidRange());
    return JetWith(Range(0.0, kExpBound.hi), Symmetric(kExpBound * Abs(w.coefficient[1])),
                   Symmetric(kExpBound * (Abs(w.coefficient[2]) + Range(.5) * Square(w.coefficient[1]))));
}

std::optional<Jet> RootOffset(Range encl, const Jet& k, const Jet& linear, const Jet& quadratic) {
    Jet t(encl);
    const auto equation = [&] { return Jet(1.0) / (t*t) - (k + t*(linear+t*quadratic)); };
    const Range minus_slope = Range(2.0) / (encl*Square(encl)) + linear.coefficient[0] +
                              Range(2.0)*encl*quadratic.coefficient[0];
    if (!(minus_slope.Finite() && minus_slope.lo>0.0)) return {};
    t.coefficient[1]=equation().coefficient[1]/minus_slope;
    t.coefficient[2]=equation().coefficient[2]/minus_slope;
    return t;
}

template <class F>
Jet Integral(const F& f) {
    // Fixed-interval rectangle enclosures include parameter derivatives.
    constexpr unsigned panels=2048;
    Jet sum;
    for (unsigned i=0; i<panels; ++i)
        sum=sum+f(Jet(Range(double(i)/panels,double(i+1)/panels)));
    return sum/Jet(panels);
}

struct Radial {
    Jet leading, drag, time_residual, spin_residual;
};

// When y is the normalized distance from the outer turn, the radial
// residual has weight S=sqrt(y/(y+A)), A=s*h, and smooth factor b*f.
// Writing r=A/(y+A), 1-S<=r, S'=-(S*r/2)*(log A)' and
// S''=S*((3*r*r/4-r/2)*(log A)'^2-(r/2)*(log A)'').
// The integral of r is A*log((1+A)/A). This replaces the boundary
// layer by its integral, including both parameter derivatives.
Jet WeightError(const Jet& smooth, const Jet& ratio, const Jet& w) {
    const auto log = Logarithm(ratio).coefficient;
    const Range log_first = Abs(w.coefficient[1])+Abs(log[1]);
    const Range log_second = Abs(w.coefficient[2])+Abs(log[2]);
    const Range prefactor = kExpBound * ratio.coefficient[0] *
                             (Range(1.0)+Abs(w.coefficient[0])+Abs(log[0]));
    const Range e0=prefactor;
    const Range e1=prefactor*Range(.5)*log_first;
    // Taylor entry two is one half of the second derivative.
    const Range e2=prefactor*(Range(.625)*Square(log_first)+Range(.5)*log_second);
    const auto& [v,d1,d2]=smooth.coefficient;
    return JetWith(Symmetric(e0*Abs(v)), Symmetric(e1*Abs(v)+e0*Abs(d1)),
                   Symmetric(e2*Abs(v)+e1*Abs(d1)+e0*Abs(d2)));
}

struct Constants {
    Jet angular, eta, carter, omega2, amplitude;
};

Constants Conserved(const Jet& u, const Jet& s) {
    const Jet a(.9), a2=a*a, u2=u*u;
    const Jet delta=Jet(1.0)+u*(a2*u-Jet(2.0));
    const Jet k=Jet(2.0)+u*(Jet(2.0)*a2*u-Jet(2.0))/delta;
    const Jet coefficient=Jet(4.0)-k;
    const Jet minimum=Jet(0.0)-s*s;
    const Jet p=(Jet(4.0)+sqrt(Jet(16.0)-Jet(4.0)*coefficient*k*minimum))/(Jet(2.0)*coefficient);
    const Jet carter=(p*p-minimum)/(delta*u2);
    const Jet angular=(a2-(p-Jet(1.0))/u2)/a;
    const Jet offset=angular-a;
    const Jet eta=carter-offset*offset;
    const Jet b=a2-eta-angular*angular;
    const Jet omega2=Jet(.5)*(sqrt(b*b+Jet(4.0)*a2*eta)-b);
    return {angular,eta,carter,omega2,sqrt(eta/omega2)};
}

std::optional<Radial> RadialPhase(const Jet& u, const Jet& w, const Jet& s, const Constants& conserved) {
    using sirius::core::relativity::kerr_infinity_detail::RadialCoefficients;
    const auto turning=EncloseScaledTurningPair(1.0,.9,u.coefficient[0],s.coefficient[0]);
    if (!turning) return {};
    const auto c=RadialCoefficients(1.0,.9,Jet(1.0),conserved.angular,conserved.carter);
    const Jet k=c[2]+u*(Jet(3.0)*c[3]+Jet(6.0)*u*c[4]);
    const Jet linear=(c[3]+Jet(4.0)*u*c[4])*s;
    const Jet quadratic=c[4]*s*s;
    const auto t0=RootOffset(turning->turn_offset,k,Jet(0.0)-linear,quadratic);
    const auto t1=RootOffset(turning->inner_offset,k,linear,quadratic);
    if (!t0||!t1) return {};
    const Jet gap_factor=*t0+*t1;
    const Jet turn=u-s* *t0, inner=u+s* *t1;
    const Jet gap=s*gap_factor;
    const Jet a(.9), a2=a*a, d1=Jet(2.0)*a,d2=Jet(0.0)-a2*conserved.angular;
    const auto delta=[&](const Jet& x){return Jet(1.0)+x*(a2*x-Jet(2.0));};
    const Jet f0=Jet(1.0)/(turn*inner),f1=c[3]+(turn+inner)*c[4],f2=c[4];
    const auto speed=[&](const Jet& x){return sqrt(f0+x*(f1+f2*x));};
    const Jet gt=speed(turn);
    const Jet leading=Jet(1.0)/gt;
    const Jet drag=turn*(d1+turn*d2)/delta(turn);
    Radial result{leading,drag,{},{}};
    for (const Range end : {kStart,Range(0.0)}) {
        const Jet span=turn-Jet(end);
        const Jet h=gap_factor/span;
        if (!(h.coefficient[0].Finite()&&h.coefficient[0].lo>0.0 &&
              (kExpBound*h.coefficient[0]).hi<1.0)) return {};
        const auto density=[&](const Jet& y, bool time){
            const Jet x=turn-span*y, sum=x+turn, g=speed(x);
            if (time) return span*(f1+f2*sum)/(g*gt*(g+gt));
            return span*(drag*(a2*sum-Jet(2.0))-d1-d2*sum)/(g*delta(x));
        };
        const auto integrate=[&](bool time){
            return Integral([&](const Jet& y){return density(y,time);})+
                   WeightError(density(Jet(Range(0.0,1.0)),time),h,w);
        };
        result.time_residual=result.time_residual+integrate(true)+Jet(2.0)*leading*
            (Logarithm(sqrt(span)+sqrt(span+gap))-Jet(.5)*Logarithm(gap_factor));
        result.spin_residual=result.spin_residual+integrate(false);
    }
    return result;
}

struct Map {
    Jet latitude_residual, time_residual, longitude;
    Range time_density, longitude_density;
};

std::optional<Map> Evaluate(const Jet& u,const Jet& w,const Jet& p,Range inverse_winding) {
    const Jet s=Scale(w);
    const auto conserved=Conserved(u,s);
    const auto radial=RadialPhase(u,w,s,conserved);
    if (!radial) return {};
    const Jet a(.9),a2=a*a, amp2=conserved.amplitude*conserved.amplitude;
    const auto density=[&](const Jet& angle,bool time){
        const Jet sine=Sine(angle), sine2=sine*sine;
        const Jet rate=Jet(1.0)/sqrt(conserved.omega2+a2*amp2*sine2);
        return time?rate:rate*(conserved.angular/(Jet(1.0)-amp2*sine2)+radial->drag);
    };
    const Jet half_pi(kPiBounds*Range(.5));
    const Jet final=half_pi+p;
    const Jet initial=Asin(Jet(kLaunchMu)/conserved.amplitude);
    const auto partial=[&](const Jet& end,bool time){
        return end*Integral([&](const Jet& t){return density(t*end,time);});
    };
    const auto polar=[&](bool time){
        return partial(Jet(kPiBounds),time)+Jet(inverse_winding)*
                     (partial(initial,time)+partial(final,time));
    };
    Map result {
        conserved.amplitude*Sine(final)-Jet(kSourceMu),
        Jet(-2.0)*radial->leading*w+Jet(inverse_winding)*radial->time_residual-polar(true),
        Jet(inverse_winding)*(Jet(kFixedAzimuth)-radial->spin_residual)-polar(false),
        density(final,true).coefficient[0],density(final,false).coefficient[0]
    };
    for (const auto& jet:{result.latitude_residual,result.time_residual,result.longitude})
        if (!std::ranges::all_of(jet.coefficient,&Range::Finite)) return {};
    return result;
}

Range RadiusAtPhase(Range phase) {
    const Range scale(0.0, kExpBound.hi);
    const Jet angle(kPiBounds*Range(.5)+phase);
    const auto residual=[&](double inverse){
        return (Conserved(Jet(inverse),Jet(scale)).amplitude*Sine(angle)).coefficient[0]-kSourceMu;
    };
    double lower=kInverse.lo, right=kInverse.hi;
    for (unsigned i=0; i<42; ++i) {
        const double middle=std::midpoint(lower,right);
        if (residual(middle).lo>0.0) lower=middle;
        else right=middle;
    }
    double left=kInverse.lo, upper=kInverse.hi;
    for (unsigned i=0; i<42; ++i) {
        const double middle=std::midpoint(left,upper);
        if (residual(middle).hi<0.0) upper=middle;
        else left=middle;
    }
    return {lower,upper};
}

struct LongitudeLine {
    Range offset, period;
    Range At(unsigned winding) const { return offset-Range(winding)*period; }
};

std::optional<LongitudeLine> LongitudeAtPhase(Range phase) {
    const Range inverse=RadiusAtPhase(phase), scale(0.0,kExpBound.hi);
    const auto shape=MakeFinitePolarShape(1.0,.9,inverse,scale);
    const auto radial=EvaluateFiniteRadialPhase(1.0,.9,inverse,scale,kStart);
    if (!shape||!radial) return {};
    const Range amplitude=sqrt(shape->amplitude2), half_pi=kPiBounds*Range(.5);
    const auto half=IntegratePolarPartial(*shape,half_pi);
    const auto launch=IntegratePolarPartial(*shape,AsinBounds(kLaunchMu/amplitude));
    const auto exit=IntegratePolarPartial(*shape,half_pi+phase);
    const Range offset=kFixedAzimuth-launch[1]-exit[1]-
                       radial->drag_at_turn*(launch[0]+exit[0])-radial->spin_residual;
    const Range period=Range(2.0)*(half[1]+radial->drag_at_turn*half[0]);
    if (!offset.Finite()||!period.Finite()) return {};
    return LongitudeLine{offset,period};
}

Range LongitudeGap(Range longitude) {
    if (!longitude.Finite()) return InvalidRange();
    const Range full_turn=Range(2.0)*kPiBounds;
    const Range turns=(longitude-kSourceAzimuth)/full_turn;
    if (!turns.Finite()) return InvalidRange();
    const double integer=std::floor(turns.lo);
    if (std::ceil(turns.lo)<=std::floor(turns.hi)) return Range(0.0,kPiBounds.hi);
    const Range below=turns-Range(integer), above=Range(integer+1.0)-turns;
    return full_turn*Range(std::min(below.lo,above.lo),std::min(below.hi,above.hi));
}

void Print(const char* name, Range x) {
    std::cout<<name<<" ["<<x.lo<<", "<<x.hi<<"]\n";
}

using Vector=std::array<Range,2>;
struct ImplicitBranch {
    Map u,w;
    Range determinant;
    Vector Solve(Range f,Range g) const {
        const Range a=u.latitude_residual.coefficient[1], b=w.latitude_residual.coefficient[1];
        const Range c=u.time_residual.coefficient[1], d=w.time_residual.coefficient[1];
        return {(b*g-d*f)/determinant,(c*f-a*g)/determinant};
    }
};

std::optional<ImplicitBranch> Branch(Range phase, Range inverse_winding) {
    const auto u=Evaluate(JetWith(kInverse,Range(1.0)),Jet(kLogScalePerWinding),Jet(phase),inverse_winding);
    const auto w=Evaluate(Jet(kInverse),JetWith(kLogScalePerWinding,Range(1.0)),Jet(phase),inverse_winding);
    if (!u||!w) return {};
    const Range det=u->latitude_residual.coefficient[1]*w->time_residual.coefficient[1]-w->latitude_residual.coefficient[1]*u->time_residual.coefficient[1];
    if (!(det.Finite()&&det.lo>0.0&&u->latitude_residual.coefficient[1].hi<0.0)) return {};
    return ImplicitBranch{*u,*w,det};
}
}  // namespace

int main() {
    if (!RoundingEnvironment()) return 1;
    std::cout<<std::hexfloat;
    const Range inverse_winding(0.0,(Range(1.0)/Range(kFirstWinding)).hi);
    const auto branch=Branch(kPhase,inverse_winding);
    if (!branch) return 2;
    Print("latitude and time determinant",branch->determinant);
    const auto left=Evaluate(Jet(kInverse.lo),Jet(kLogScalePerWinding),Jet(kPhase),inverse_winding);
    const auto right=Evaluate(Jet(kInverse.hi),Jet(kLogScalePerWinding),Jet(kPhase),inverse_winding);
    const auto early=Evaluate(Jet(kInverse),Jet(kLogScalePerWinding.lo),Jet(kPhase),inverse_winding);
    const auto late=Evaluate(Jet(kInverse),Jet(kLogScalePerWinding.hi),Jet(kPhase),inverse_winding);
    if (!left||!right||!early||!late) return 3;
    Print("left latitude residual",left->latitude_residual.coefficient[0]);
    Print("right latitude residual",right->latitude_residual.coefficient[0]);
    Print("early time residual",early->time_residual.coefficient[0]);
    Print("late time residual",late->time_residual.coefficient[0]);
    if (!(left->latitude_residual.coefficient[0].lo>0 && right->latitude_residual.coefficient[0].hi<0 &&
          early->time_residual.coefficient[0].lo>0 && late->time_residual.coefficient[0].hi<0)) return 4;

    const Jet unit_phase=JetWith(kPhase,Range(1.0));
    const auto p=Evaluate(Jet(kInverse),Jet(kLogScalePerWinding),unit_phase,inverse_winding);
    if (!p) return 5;
    const auto first=branch->Solve(p->latitude_residual.coefficient[1],p->time_residual.coefficient[1]);
    const auto path=Evaluate(JetWith(kInverse,first[0]),JetWith(kLogScalePerWinding,first[1]),
                             unit_phase,inverse_winding);
    if (!path) return 6;
    const auto second=branch->Solve(path->latitude_residual.coefficient[2],path->time_residual.coefficient[2]);
    const Range curvature=Range(2.0)*(path->longitude.coefficient[2]+
        branch->u.longitude.coefficient[1]*second[0]+branch->w.longitude.coefficient[1]*second[1]);
    Print("longitude curvature per winding",curvature);
    if (!(curvature.Finite()&&curvature.lo>0.0)) return 7;

    const auto start=Branch(Range(0.0),inverse_winding);
    if (!start) return 8;
    // At p=0, latitude has zero phase slope. Time's phase derivative
    // is -nu times its density, so the conditioned slope can be evaluated
    // without dividing intervals by nu, which tends to zero.
    const auto start_first=start->Solve(Range(0.0),Range(0.0)-start->u.time_density);
    const Range start_slope=start->u.longitude.coefficient[1]*start_first[0]+
        start->w.longitude.coefficient[1]*start_first[1]-start->u.longitude_density;
    const Range edge_slope=start_slope+Range(kFirstWinding)*Range(kPhase.hi)*curvature;
    Print("zero-phase longitude slope",start_slope);
    Print("right-edge longitude slope at first winding",edge_slope);
    if (!(start_slope.Finite()&&start_slope.hi<0&&edge_slope.lo>0)) return 9;
    for (const unsigned winding : {1025u,2049u,4097u,8193u}) {
        const Range fold=(Range(0.0)-start_slope)/(Range(winding)*curvature);
        const auto line=LongitudeAtPhase(fold);
        if (!line) return 10;
        const Range phi=line->At(winding);
        const Range gap=LongitudeGap(phi);
        std::cout<<"winding "<<winding<<' ';
        Print("fold phase",fold);
        Print("fold longitude",phi);
        Print("longitude gap",gap);
        if (!(fold.Finite()&&gap.Finite()&&gap.lo>0.0)) return 10;
    }
    // A longitude interval touching the star must retain zero as possible.
    if (LongitudeGap(kSourceAzimuth).lo!=0.0) return 11;
    const auto line=LongitudeAtPhase(Range(0.0));
    if (!line) return 11;
    Print("zero-phase longitude offset",line->offset);
    Print("zero-phase longitude period",line->period);
    const Range negative_slope=Range(0.0)-start_slope;
    const Range drop=Square(negative_slope)/(Range(2.0)*curvature);
    std::size_t initial_hits=0, ambiguous=0;
    double clearance=kInfinity;
    unsigned closest=0;
    constexpr unsigned last_winding=8193;
    for (unsigned winding=kFirstWinding; winding<=last_winding; ++winding) {
        Range gap=LongitudeGap(line->At(winding)-drop/Range(winding));
        if (!gap.Finite()) return 12;
        if (gap.lo<=0.0) {
            ++initial_hits;
            const Range fold=negative_slope/(Range(winding)*curvature);
            const auto tightened=LongitudeAtPhase(fold);
            if (!tightened) return 13;
            const Range direct=LongitudeGap(tightened->At(winding));
            if (!direct.Finite()) return 14;
            gap=Range(std::max(direct.lo,gap.lo),std::min(direct.hi,gap.hi));
            if (!gap.Finite()) return 14;
        }
        if (gap.lo<clearance) {
            clearance=gap.lo;
            closest=winding;
        }
        if (gap.lo<=0.0) {
            ++ambiguous;
            std::cout<<"unresolved winding "<<winding<<' ';
            Print("longitude distance",gap);
        }
    }
    std::cout<<"finite band first="<<kFirstWinding<<" last="<<last_winding
             <<" direct refinements="<<initial_hits<<" ambiguous="<<ambiguous
             <<" smallest lower clearance="<<clearance<<" winding="<<closest<<'\n';
    if (ambiguous!=0) return 15;
    const Range extent=negative_slope*Range(kPhase.hi)+Range(.5)*
                       Range(last_winding)*curvature*Square(Range(kPhase.hi));
    if (!(extent.Finite() && (Range(2.0)*extent).hi<(Range(2.0)*kPiBounds).lo)) return 16;
    const Range slope_floor=sqrt(Range(2.0)*Range(curvature.lo)*Range(kFirstWinding)*Range(clearance));
    const Range density=Range(4.0)*p->time_density/
                        (Range(branch->determinant.lo)*Range(slope_floor.lo)*Range(.75));
    Print("finite band invariant-chart density prefactor (times 2^-2050)",density);
    return density.Finite()&&density.hi>0.0?0:17;
}

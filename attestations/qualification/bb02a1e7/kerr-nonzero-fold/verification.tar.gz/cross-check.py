from pathlib import Path
import math
import re
import tarfile


scratch = Path(__file__).resolve().parent
archive = scratch.parents[1] / 'attestations/qualification/ce1906b6/dozen-mixed-endpoint-and-kerr-fold/verification.tar.gz'
with tarfile.open(archive) as saved:
    with saved.extractfile('critical-fold-reference.log') as reference:
        independent = reference.read().decode().splitlines()

log = (scratch / 'finite-fold.log').read_text()
shape = r'\[([^,]+), ([^\]]+)\]'

def interval(match):
    return tuple(float.fromhex(v) for v in match.groups())

curvature = interval(re.search(r'longitude curvature per winding ' + shape, log))
for line in independent:
    if 'digits=58' not in line:
        continue
    values = dict(field.split('=') for field in line.split())
    winding = int(values['winding'])
    phase = interval(re.search(rf'winding {winding} fold phase ' + shape, log))
    gap = interval(re.search(rf'winding {winding} fold phase [^\n]+\nfold longitude [^\n]+\nlongitude gap ' +
                             shape, log))
    assert phase[0] < float(values['phase']) < phase[1]
    assert gap[0] < float(values['longitude_gap']) < gap[1]
    assert curvature[0] < float(values['curvature']) / winding < curvature[1]
    print(f'winding {winding} independent limiting phase, curvature, and clearance inside finite bounds')

period = interval(re.search(r'zero-phase longitude period ' + shape, log))
period_width = period[1] - period[0]
print(f'fixed period interval width={period_width:.12g} rad per winding')
print(f'first winding at which that interval alone spans approximately one turn={math.ceil(2*math.pi/period_width)}')
assert 'Exit status: 0' in log

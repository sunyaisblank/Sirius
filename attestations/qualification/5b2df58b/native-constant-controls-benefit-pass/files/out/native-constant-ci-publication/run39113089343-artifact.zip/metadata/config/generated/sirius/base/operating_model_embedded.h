#pragma once

#include <array>
#include <cstddef>
#include <string_view>

namespace sirius::base {

// Configured from tests/operating_model.json. Runtime capability reporting
// requires semantic equality with this authority, so an installed ledger
// cannot change a claim while retaining a schema shape that looks valid.
inline constexpr std::size_t kEmbeddedOperatingModelSize = 130827;
inline constexpr std::string_view kEmbeddedOperatingModelSha256 =
    "839a2f5a4dd135cd3066a150333ebfe2355b8c29390477c3c0013e833272e781";
inline constexpr std::array<std::string_view, 17>
    kEmbeddedOperatingModelChunks = {
    R"SIRIUS_MODEL({
  "schema_version": 3,
  "method": "adversarial-claim-ledger",
  "source_available_test_floor": 700,
  "acceptance_criteria": [
    {
      "id": "P1",
      "required": true,
      "verification": "build_gated",
      "profiles": ["cpu", "vulkan"],
      "requirement": "Near-extremal Kerr geodesics satisfy the stated oracle and live conservation tolerances; the canonical oracle admits capture only from a represented Boyer-Lindquist state and exposes chart, null-projection, and integration failures without hidden mutable history; the live Cartesian Kerr-Schild authority preserves every numerically represented nonzero spin without an epsilon interval, remains scale covariant below the former branch, declines the non-unique r=0 rotating sheet instead of fabricating a finite radius, and rejects an unrepresented adaptive stage before metric evaluation; every accepted CPU RK45 and device RK4 state first bounds its unprojected local null defect and is then projected onto the nearest temporal root where represented, retaining its spatial tangent and chosen light-cone branch, including exact linear g_00=0 events; inside a stationary limit where no temporal root is represented, the smallest normalized spatial correction leaves k^0 unchanged, and an entirely unrepresented projection declines; a rejection that first selects the minimum step receives that represented retry before terminating; every device-supported precision rung completes the same non-image invariant probe without a controller-induced false termination, while a device lacking shaderFloat64 explicitly rejects the fp64 module and the supported fp32 and compensated probes still execute; and the finite-observer 1080p shadow boundary agrees with Bardeen to below one pixel on both live backends, with captured CPU trajectories localised on the exact metric horizon through accepted outgoing Kerr-Schild segments; the exact exterior coordinate Jacobian preserves the original observer, Killing quantities and screens, exterior outputs return to the public chart, horizon endpoints explicitly retain their regular outgoing chart, and rejected steps never invent capture or affine progress.",
      "capability_dependencies": [],
      "evidence": [
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersCompensatedFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp64"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp32"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp32Comp"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp64"},
        {"kind": "gtest", "name": "AnalyticValidationTest.NearExtremalKerrConservesEnergyAngularMomentumAndCarter"},
        {"kind": "gtest", "name": "AnalyticValidationTest.SymplecticChartExitAndNullProjectionFailureRemainDistinct"},
        {"kind": "gtest", "name": "LivePathConservationTests.NearExtremalKerrEnergyAngularMomentumAndCarter"},
        {"kind": "gtest", "name": "FullPathAcceptance.VulkanRetainedNearExtremalRayConservesIndependentInvariants"},
        {"kind": "gtest", "name": "KernelParity.NearExtremalKerrLiveRenderIntegratorConservesEnergyAngularMomentumAndCarter"},
        {"kind": "gtest", "name": "KerrTests.CartesianMetricIsScaleCovariantBelowTheFormerSpinFloor"},
        {"kind": "gtest", "name": "KerrTests.SingularKerrDiskDeclinesInsteadOfReceivingAnEpsilonRadius"},
        {"kind": "gtest", "name": "CoordinateTransformTests.KerrRadiusPreservesExactZeroAndScaleCovariance"},
        {"kind": "gtest", "name": "RK45IntegratorTests.UnrepresentedStageShrinksBeforeMetricEvaluation"},
        {"kind": "gtest", "name": "RK45IntegratorTests.RejectionMaySelectTheMinimumStepBeforeTerminating"},
        {"kind": "gtest", "name": "KernelParity.RejectedNeighbourRetriesExactMinimumFp32"},
        {"kind": "gtest", "name": "KernelParity.RejectedNeighbourRetriesExactMinimumFp32Comp"},
        {"kind": "gtest", "name": "KernelParity.RejectedNeighbourRetriesExactMinimumFp64"},
        {"kind": "gtest", "name": "KernelParity.CapturedKerrFloorCompositeMatchesCanonicalEndpointFp32"},
        {"kind": "gtest", "name": "KernelParity.CapturedKerrFloorCompositeMatchesCanonicalEndpointFp32Comp"},
        {"kind": "gtest", "name": "RK45IntegratorTests.AcceptedDenseErrorOnlyLimitsGrowth"},
        {"kind": "gtest", "name": "RK45IntegratorTests.NullProjectionPreservesTheIncomingLightConeBranch"},
        {"kind": "gtest", "name": "RK45IntegratorTests.NullDefectAboveTheDeclaredBoundIsRejectedBeforeProjection"},
        {"kind": "gtest", "name": "RK45IntegratorTests.DoublePrecisionStagesMatchAnAnalyticRindlerNullRay"},
        {"kind": "gtest", "name": "RK45IntegratorTests.OutgoingChartPreservesMetricKillingQuantitiesAndInverseMap"},
        {"kind": "gtest", "name": "CpuTraceBoundary.PastRadialHorizonIsAnAcceptedFiniteOutgoingEvent"},
        {"kind": "gtest", "name": "CpuTraceBoundary.LateMinimumStepsPreserveAnalyticAffineAndJacobiLength"},
        {"kind": "gtest", "name": "CpuTraceBoundary.RejectedOutwardRayNearHorizonDoesNotInventCapture"},
        {"kind": "gtest", "name": "KernelParity.RepresentedSubThresholdKerrMetricIsScaleCovariant"},
        {"kind": "gtest", "name": "KernelParity.UnrepresentedKerrStageShrinksBeforeMetricEvaluation"},
        {"kind": "gtest", "name": "KernelParity.NullProjectionPreservesConeBranchAndFailsClosed"},
        {"kind": "gtest", "name": "KernelParity.PrecisionProbeArtifactsCarryOnlyTheirDeclaredFloat64Capability"},
        {"kind": "gtest", "name": "VulkanBackend.KernelPrecisionDeclinesUnsupportedFloat64AndMalformedInstructions"},
        {"kind": "gtest", "name": "VulkanBackend.KernelPrecisionDeclinesFmaBeforeDriverWorkUnlessBinary32WasEnabled"},
        {"kind": "gtest", "name": "KernelParity.PrecisionRungsConserveNearExtremalKerrWithoutImageComparison"},
        {"kind": "gtest", "name": "ShadowBoundary.KerrNearExtremalMatchesBardeenWithinOnePixelAt1080p"},
        {"kind": "gtest", "name": "ShadowBoundary.RetainedFp32ProductsKerrNearExtremalBardeenBoundaryAt1080p"},
        {"kind": "gtest", "name": "ShadowBoundary.RetainedFp64ProductsKerrNearExtremalBardeenBoundaryAt1080p"},
        {"kind": "gtest", "name": "VulkanRenderSession.KerrNearExtremalBardeenBoundaryAt1080p"},
        {"kind": "ctest", "name": "OperationalP1.NearExtremalBurnIn"}
      ]
    },
    {
      "id": "P2",
      "required": true,
      "verification": "build_gated",
      "profiles": ["cpu", "vulkan"],
      "requirement": "Both live backends propagate two geodesic-deviation vectors into an oriented beam ellipse and interpret that orientation in the same deterministic celestial tangent basis during point-catalogue filtering; the CPU central ray and Jacobi map terminate on the same accepted-segment event at a finite causal boundary; the independent Schwarzschild congruence oracle agrees to one part per million, the live CPU Cartesian tidal contraction agrees with the analytic Boyer-Lindquist tensor below five parts in ten million at matched events, its Kerr curvature scalar agrees off-equator below one part per million, and its production radial point-source congruence obeys the exact affine-axis solution; the production fp32 Vulkan tidal contraction agrees with the analytic Schwarzschild tensor below five parts in ten thousand at matched off-equatorial non-radial events and with the analytic Kerr tensor below two parts in ten thousand across both spin signs at matched off-equatorial events, and its shared accepted-segment paired Jacobi update obeys the exact radial point-source affine-axis solution below five parts per million; the footprint measurably suppresses star flicker, and the complete brightness of one isolated represented star across four quarter-pixel optical rotatio)SIRIUS_MODEL",
    R"SIRIUS_MODEL(ns at a fixed unboosted flat-space event agrees with independent original-response photometry on CPU and retained binary32 products, varies by at most two percent for the small smoothly changing footprints, and reduces coefficient of variation by at least a factor of 1.5 relative to the identical narrow-width sequence.",
      "capability_dependencies": [],
      "evidence": [
        {"kind": "gtest", "name": "RetainedComputeTest.BatchedCameraPreservesPhysicalColumnsAndRejectsInvalidRows"},
        {"kind": "gtest", "name": "RetainedComputeTest.SmoothRayCameraPreservesPhysicalLensDerivatives"},
        {"kind": "gtest", "name": "VulkanRenderSession.RetainedMovingThinLensKerrDetectorMatchesCpuLinearRadiance"},
        {"kind": "gtest", "name": "RetainedComputeTest.Fp64ProductsPreserveIndependentScienceOrDeclineUnsupportedDevices"},
        {"kind": "gtest", "name": "RetainedComputeTest.JointRkStagesRetainCriticalIncrementsAndEmbeddedError"},
        {"kind": "gtest", "name": "RetainedComputeTest.ProjectedEndpointsKeepPhysicalColumnsAndRetainedContinuation"},
        {"kind": "gtest", "name": "RetainedComputeTest.DenseSegmentsPreserveSmallCovariantArrivalDerivatives"},
        {"kind": "gtest", "name": "RetainedComputeTest.ZeroFractionArrivalsPreserveProgramAuthorityAndCompleteRefusal"},
        {"kind": "gtest", "name": "RetainedDopriTest.IndependentQuarticPreservesCompletePhase"},
        {"kind": "gtest", "name": "RetainedDopriTest.MalformedRowsRefuseAndRecover"},
        {"kind": "gtest", "name": "RetainedDopriTest.CurvedTransportConnectsSamplerAndProjection"},
        {"kind": "gtest", "name": "RetainedDopriTest.ConnectedIntervalsPreserveTrialsAndIndependentBudgets"},
        {"kind": "gtest", "name": "RetainedDopriTest.SamplerPreservesPhysicalArrivalAndRejectsInconsistentRates"},
        {"kind": "gtest", "name": "CpuTraceBoundary.RetainedQuarticEventsKeepOriginalFractionsAndExcludeLaterDisk"},
        {"kind": "gtest", "name": "CpuTraceBoundary.RetainedQuarticVolumeFailurePublishesNothingAndRecovers"},
        {"kind": "gtest", "name": "DopriPositionSegment.SamplesTheQuarticAndItsAffineDerivative"},
        {"kind": "gtest", "name": "DopriPositionSegment.DegreeEightIsolationCoversEveryRootWithoutGridSampling"},
        {"kind": "gtest", "name": "DopriPositionSegment.SameSideQuarticContactsRespectDirectionAndOriginalRestriction"},
        {"kind": "gtest", "name": "DopriPositionSegment.TangenciesAndKerrEllipsoidUseTheSameQuartic"},
        {"kind": "gtest", "name": "DopriPositionSegment.DiskRootsIncludeTangenciesAndKeepOriginalFractions"},
        {"kind": "gtest", "name": "DopriPositionSegment.IncrementBoundarySurvivesLargeOriginsAndInvalidInputsFailClosed"},
        {"kind": "gtest", "name": "RetainedComputeTest.CoupledIntervalsRequireEmbeddedAndIndependentDenseAgreement"},
        {"kind": "gtest", "name": "RetainedComputeTest.PhysicalInitializationRetainsTheHamiltonianResidual"},
        {"kind": "gtest", "name": "RetainedComputeTest.ProjectionReserveKeepsLogicalCohortsBounded"},
        {"kind": "gtest", "name": "RetainedComputeTest.SharedTracerCompletesDeviceIntervalsAndRetainsRollbackState"},
        {"kind": "gtest", "name": "RetainedComputeTest.RejectedStepRowsCannotExposeOldOrPartialCandidates"},
        {"kind": "gtest", "name": "RetainedValue.Binary64InputsKeepTheirRepresentationResidual"},
        {"kind": "gtest", "name": "RetainedCameraProgram.Fp32CompletePhysicalLaunchAndRefusals"},
        {"kind": "gtest", "name": "RetainedCameraProgram.CompensatedCompletePhysicalLaunchAndRefusals"},
        {"kind": "gtest", "name": "PointSourceDetector.OriginalGaussianOwnsSharedEdgesAndRejectsOutsideSupport"},
        {"kind": "gtest", "name": "PointSourceDetector.ImageFrequencyAndTransmissionAreAppliedOnce"},
        {"kind": "gtest", "name": "PointSourceDetector.FoldKeepsBothImagesOfTheSameCatalogueEntry"},
        {"kind": "gtest", "name": "PointSourceDetector.FoldOwnershipSurvivesRotationTranslationAndTighterRefinement"},
        {"kind": "gtest", "name": "PointSourceDetector.ExhaustionCancellationAndFailedTracesHaveNoPartialRadiance"},
        {"kind": "gtest", "name": "PointSourceDetector.PolynomialFoldResolvesCloseImagesBetweenTheCoarseNodes"},
        {"kind": "gtest", "name": "PointSourceDetector.DisconnectedVisibilityIslandAndStripeUseActualImageVisibility"},
        {"kind": "gtest", "name": "RenderSessionProbe.PhysicalPointDetectorCompletesAMovingThinLensKerrFrame"},
        {"kind": "gtest", "name": "CameraContinuousProjection.AngularProjectionPreservesGeometricZerosForDetectorOffsets"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersCompensatedFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp64"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsPreserveOriginalGaussianAndNormalization"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferKeepsFluxAndDensityLinear"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp32"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp32Comp"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp64"},
        {"kind": "gtest", "name": "PointSourceTransfer.ReferenceFrequencyPreservesCatalogueColourAndFlux"},
        {"kind": "gtest", "name": "CoupledTransport.PhysicalEventVariationRetainsArrivalPositionWithoutDenseAccelerationNoise"},
        {"kind": "gtest", "name": "CoupledTransport.OriginalKerrDiskEventMatchesIndependentNeighboursAndRefinement"},
        {"kind": "gtest", "name": "CoupledTransport.CapturedKerrBeamMatchesNeighboursAndStepRefinement"},
        {"kind": "gtest", "name": "CoupledTransport.EveryCanonicalColumnCanRejectProjectedAndInteriorCurvedError"},
        {"kind": "gtest", "name": "CoupledTransport.AcceptedIncrementsKeepRefinedEventDerivativesTranslationInvariant"},
        {"kind": "gtest", "name": "CoupledTransport.EndpointAndZeroFractionIncludeEventTimeVariation"},
        {"kind": "gtest", "name": "RetainedArithmetic.SmallTermsSurviveLargeSumsProductsAndDivision"},
        {"kind": "gtest", "name": "RetainedArithmetic.CartesianGradientMatchesIndependentRationalValues"},
        {"kind": "gtest", "name": "RetainedArithmetic.CompleteCriticalMetricMatchesIndependentPrecisionWitnesses"},
        {"kind": "gtest", "name": "CoupledTransport.MinimumStepCriticalColumnsMatchIndependentRefinedFlow"},
        {"kind": "gtest", "name": "CoupledTransport.OriginalCriticalLaunchesHavePhysicalFatesOrExplicitWorkExhaustion"},
        {"kind": "gtest", "name": "CoupledTransport.FlatFourColumnsUseActualProjectedAndInteriorTrials"},
        {"kind": "gtest", "name": "CoupledTransport.CameraColumnUnitsPreserveTheJointErrorDecision"},
        {"kind": "gtest", "name": "CoupledTransport.PhysicalCameraColumnsReachTheLiveCpuSourceMap"},
        {"kind": "gtest", "name": "CoupledTransport.NonfiniteColumnsAndUnrepresentedInteriorDeclineWithoutCommit"},
        {"kind": "gtest", "name": "CoupledTransport.SkyMapIsIndependentOfPhysicalBundleOutputAndWorkLimitDeclines"},
        {"kind": "gtest", "name": "RenderSessionProbe.ExhaustedNonKerrRayCannotPublishACompletedBlackFrame"},
        {"kind": "gtest", "name": "RenderSessionProbe.NumericalRayFailureKeepsCpuTilesPrivateAndPreventsOutput"},
        {"kind": "gtest", "name": "RenderSessionProbe.LaterGoodCameraSampleCannotEraseCpuNumericalFailure"},
        {"kind": "gtest", "name": "KernelInfinityDevice.Fp32IndependentDirectionsVariationsAndTerminalStates"},
        {"kind": "gtest", "name": "KernelInfinityDevice.CompensatedIndependentDirectionsVariationsAndTerminalStates"},
        {"kind": "gtest", "name": "KernelInfinityDevice.Fp64IndependentDirectionsVariationsAndTerminalStates"},
        {"ki)SIRIUS_MODEL",
    R"SIRIUS_MODEL(nd": "gtest", "name": "KernelInfinityDevice.FinishDeclinesWithoutPublishingPartialResults"},
        {"kind": "gtest", "name": "KerrInfinity.FlatOblateRaysAndAxesReachExactCartesianSky"},
        {"kind": "gtest", "name": "KerrInfinity.VaryingHandoffAndTangentMatchExactFlatDerivative"},
        {"kind": "gtest", "name": "KerrInfinity.FrequencyScaleAndSignedParityArePreserved"},
        {"kind": "gtest", "name": "KerrInfinity.AxisPrincipalRaysHaveAnalyticAngularVariation"},
        {"kind": "gtest", "name": "KerrInfinity.KerrTailMatchesIndependentSeparatedReference"},
        {"kind": "gtest", "name": "KerrInfinity.RejectsHiddenRadialTurningPoint"},
        {"kind": "gtest", "name": "KerrInfinity.MassSpinAndRadiusScalingPreserveDirectionAndJacobian"},
        {"kind": "gtest", "name": "KerrInfinity.NearCriticalSchwarzschildDerivativeMatchesIndependentRadialIntegral"},
        {"kind": "gtest", "name": "KerrInfinity.RejectsUnrepresentedInputsAndWorkExhaustion"},
        {"kind": "gtest", "name": "SourceSkyDifferential.DeclinesUnrepresentedFrequencyGeometryAndVariation"},
        {"kind": "gtest", "name": "SourceSkyDifferential.DirectionIsInvariantUnderFrequencyAndLongitudinalVariation"},
        {"kind": "gtest", "name": "SourceSkyDifferential.KerrPositionAndTangentVariationsMatchIndependentDifferences"},
        {"kind": "gtest", "name": "SourceSkyDifferential.MovingFlatCameraMatchesAnalyticLorentzDirectionDerivative"},
        {"kind": "gtest", "name": "SourceSkyDifferential.NormalizesNonNullSpatialDirectionAndItsDerivative"},
        {"kind": "gtest", "name": "SourceSkyDifferential.ReseedsMetricVariationWithoutInheritedDualMetadata"},
        {"kind": "gtest", "name": "SourceSkyMap.EndpointVariationPreservesGaugeAndDeclinesGrazingContact"},
        {"kind": "gtest", "name": "SourceSkyMap.FlatAngularMapIsIndependentOfSphereRadiusSeedAndFrequency"},
        {"kind": "gtest", "name": "SourceSkyMap.KerrCovariantChartVariationsMatchMappedNominalFamily"},
        {"kind": "gtest", "name": "SourceSkyMap.LocalizedFlatSphereVariationMatchesAnalyticRayFamily"},
        {"kind": "gtest", "name": "SourceSkyMap.RetainsZeroRankDeficiencyAndSignedParity"},
        {"kind": "gtest", "name": "SourceSkyInfinityTrace.FlatPupilMapAndFrequencyAreHandoffIndependent"},
        {"kind": "gtest", "name": "SourceSkyInfinityTrace.KerrMapConvergesAcrossHandoffRadiiAndFixedPupilNeighbours"},
        {"kind": "gtest", "name": "SourceSkyInfinityTrace.NonVacuumAndCapturedRaysDoNotClaimVacuumInfinity"},
        {"kind": "gtest", "name": "SourceSkyMapTrace.KerrMapConvergesToFixedPupilRetracing"},
        {"kind": "gtest", "name": "SourceSkyMapTrace.MovingPupilMapMatchesAnalyticAberration"},
        {"kind": "gtest", "name": "SourceSkyMapTrace.StationaryTranslatedPupilMapIsRadiusIndependent"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OrdinaryEscapeBoundaryLaunchUsesCrossingDirection"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OrdinaryEscapeClipsCentralAndJacobiAffineIntervals"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OrdinaryEscapeDeclinesExteriorOutwardLaunchWithoutSourceEvent"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OrdinaryEscapeExcludesDiskAndVolumeBeyondBoundary"},
        {"kind": "gtest", "name": "KernelTrace.ActualTraceClipsJacobiAndRetainsInvalidSamplesAcrossRungs"},
        {"kind": "gtest", "name": "KernelTrace.ActualTraceFiniteSphereExcludesLaterDiskAndVolumeAcrossRungs"},
        {"kind": "gtest", "name": "KernelParity.FiniteEscapeUsesFirstOutwardEventAndClippedIntervalAcrossRungs"},
        {"kind": "gtest", "name": "BeamPropagationTest.SchwarzschildRadialCongruenceMatchesClosedFormToOnePartPerMillion"},
        {"kind": "gtest", "name": "BeamPropagationTest.SchwarzschildCircularPhotonCongruenceMatchesClosedFormToOnePartPerMillion"},
        {"kind": "gtest", "name": "CpuJacobiOracle.TidalContractionMatchesAnalyticSchwarzschildAtMatchedEvents"},
        {"kind": "gtest", "name": "CpuJacobiOracle.CurvatureScalarMatchesAnalyticKerrOffEquator"},
        {"kind": "gtest", "name": "CpuJacobiOracle.RadialPointSourceCongruenceMatchesClosedForm"},
        {"kind": "gtest", "name": "RayBundleTest.CurvatureStencilPreservesMassScaleAndBothSpinSigns"},
        {"kind": "gtest", "name": "RayBundleTest.CurvatureStencilStaysInsideTheActualKerrChartDomain"},
        {"kind": "gtest", "name": "RayBundleTest.MagnificationComesOnlyFromJacobiMap"},
        {"kind": "gtest", "name": "CpuTraceBoundary.JacobiBundleTerminatesAtTheSameCausalEvent"},
        {"kind": "gtest", "name": "KernelBeam.BeamFlagWiresDeviationWithoutMovingDefault"},
        {"kind": "gtest", "name": "KernelParity.BeamEllipseRetainsBothAxesAndOutputOrientation"},
        {"kind": "gtest", "name": "KernelParity.CelestialTangentBasisIsSharedByBeamAndPointFilter"},
        {"kind": "gtest", "name": "KernelParity.DeviceTidalContractionMatchesAnalyticKerrAtMatchedEvents"},
        {"kind": "gtest", "name": "KernelParity.DeviceTidalContractionMatchesAnalyticSchwarzschildAtMatchedEvents"},
        {"kind": "gtest", "name": "KernelParity.DeviceRadialPointSourceCongruenceMatchesClosedForm"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.EllipticalFilterUsesTheBeamSachsBasis"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.PointFilterRetainsImaxSubpixelOffsets"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.PointFilterMatchesIndependentAngularOracle"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.SpatialIndexIncludesStarsAcrossAngularCellBoundaries"},
        {"kind": "gtest", "name": "KernelParity.PointStarAngularWeightMatchesIndependentOracle"},
        {"kind": "gtest", "name": "PointSourceDetector.RotatingIsolatedStarMatchesIndependentSharedRegionBrightness"},
        {"kind": "gtest", "name": "PointSourceDetector.RetainedRotatingIsolatedStarMatchesIndependentSharedRegionBrightness"},
        {"kind": "gtest", "name": "StarfieldPointTest.BeamFootprintSuppressesStarFlicker"}
      ]
    },
    {
      "id": "P3",
      "required": true,
      "verification": "attestation_required",
      "profiles": ["cpu", "vulkan", "physical-imax-5616x4096"],
      "requirement": "At least 100000 point stars are sampled through the full oriented beam ellipse without aliasing at 1080p and 5616x4096 within the two-gigabyte governed envelope, and a disk-free gate proves their radiance remains spatially resolved after display quantisation.",
      "capability_dependencies": ["physical_imax_5616x4096"],
      "evidence": [
        {"kind": "gtest", "name": "PointSourceDetector.OriginalGaussianOwnsSharedEdgesAndRejectsOutsideSupport"},
        {"kind": "gtest", "name": "PointSourceDetector.ImageFrequencyAndTransmissionAreAppliedOnce"},
        {"kind": "gtest", "name": "PointSourceDetector.FoldKeepsBothImagesOfTheSameCatalogueEntry"},
        {"kind": "gtest", "name": "PointSourceDetector.FoldOwnershipSurvivesRotationTranslationAndTighterRefinement"},
        {"kind": "gtest", "name": "PointSourceDetector.ExhaustionCancellationAndFailedTracesHaveNoPartialRadiance"},
        {"kind": "gtest", "name": "PointSourceDetector.PolynomialFoldResolvesCloseImagesBetweenTheCoarseNodes"},
        {"kind": "gtest", "name": "PointSourceDetector.DisconnectedVisibilityIslandAndStripeUseActualImageVisibility"},
        {"kind": "gtest", "name": "RenderSessionProbe.PhysicalPointDetectorCompletesAMovingThinLensKerrFrame"},
        {"kind": "gtest", "name": "CameraContinuousProjection.AngularProjectionPreservesGeometricZerosForDetectorOffsets"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsPreserveOriginalGaussianAndNormalization"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsOwnSharedEdgesAndKeepParentCutoff"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsDeclineInvalidOrUnrepresentedGeometry"},
        {"kind": "gtest", "name": "CameraContinuousProjection.GeometryAndDifferentia)SIRIUS_MODEL",
    R"SIRIUS_MODEL(lAcrossOutputCrop"},
        {"kind": "gtest", "name": "CameraContinuousProjection.FixedPupilAndObserverArePreserved"},
        {"kind": "gtest", "name": "CameraContinuousProjection.RefinementDeclinesLostCoordinatesAndDirections"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferComposesDensityAndMovingFrequency"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferKeepsFluxAndDensityLinear"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferDeclinesInvalidFrequencyAndPartialFailure"},
        {"kind": "gtest", "name": "PointSourceTransfer.ReferenceFrequencyPreservesCatalogueColourAndFlux"},
        {"kind": "gtest", "name": "PointSourceTransfer.ShiftedSpectrumMatchesIndependentFixedBandPlanckLaw"},
        {"kind": "gtest", "name": "PointSourceTransfer.RejectsReciprocalExtraGainAndShiftedNormalizerSubstitutions"},
        {"kind": "gtest", "name": "PointSourceTransfer.MovingObserverUsesBandGainAndAngularAreaExactlyOnce"},
        {"kind": "gtest", "name": "PointSourceTransfer.ShiftedTemperatureHasNoCatalogueLookupClamp"},
        {"kind": "gtest", "name": "PointSourceTransfer.InvalidOrOverflowingTransferHasNoPublishedValue"},
        {"kind": "gtest", "name": "PointSourceResponseTest.IntegratedDetectorFluxFollowsSignedAffineLensMeasure"},
        {"kind": "gtest", "name": "PointSourceResponseTest.UnresolvedImageShapeStaysInDetectorCoordinates"},
        {"kind": "gtest", "name": "PointSourceResponseTest.EllipticalSupportRejectsInsideMajorCircleOutsideEllipse"},
        {"kind": "gtest", "name": "PointSourceResponseTest.SingularAndBroadMapsRequestRefinementWithoutFloors"},
        {"kind": "gtest", "name": "PointSourceResponseTest.InvalidArithmeticIsDistinctFromEmptyContribution"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueAccumulationPreservesFluxColorAndExactSupport"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CompositionCancellationAndUnrepresentedParityDecline"},
        {"kind": "gtest", "name": "PointSourceResponseTest.MovingThinLensAndSourceMapComposeIntoReceivedFlux"},
        {"kind": "gtest", "name": "StarfieldPointTest.CatalogueMeetsSizeFloorAndIsFinite"},
        {"kind": "gtest", "name": "StarfieldPointTest.SpatialIndexMatchesExhaustiveBeamOracle"},
        {"kind": "gtest", "name": "StarfieldPointTest.ImaxCatalogueIndexFitsTheTwoGigabyteOperatingEnvelope"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.EllipticalFilterUsesTheBeamSachsBasis"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.PointFilterRetainsImaxSubpixelOffsets"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.PointFilterMatchesIndependentAngularOracle"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.SpatialIndexIncludesStarsAcrossAngularCellBoundaries"},
        {"kind": "gtest", "name": "KernelParity.PointStarAngularWeightMatchesIndependentOracle"},
        {"kind": "gtest", "name": "KernelParity.CelestialTangentBasisIsSharedByBeamAndPointFilter"},
        {"kind": "gtest", "name": "VulkanRenderSession.IndexedPointCatalogueReachesLiveKernel"},
        {"kind": "gtest", "name": "VulkanRenderSession.CombinedParitySceneRetainsResolvedImageStructure"},
        {"kind": "gtest", "name": "RenderSessionProbe.SceneEvidenceBindsCanonicalTypedConfiguration"},
        {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"}
      ]
    },
    {
      "id": "P4",
      "required": true,
      "verification": "build_gated",
      "profiles": ["cpu", "vulkan"],
      "requirement": "The physical relativistic thin-disk default uses the zero-torque Page-Thorne flux integrated from a declared stable-orbit inner edge at or outside the ISCO, with every represented nonzero spin evaluated rather than aliased to Schwarzschild, and invariant circular-emitter frequency transfer exactly once. CPU metric, disk, invariant-transfer, and tracer consumers share one exact signed-spin ISCO and circular-emitter angular-velocity authority, while the Boyer-Lindquist oracle and Slang implementation remain independent comparators. Thermally emitted host colour and binned spectra consume one Planck spectral-radiance-per-metre authority, with bins applying only the exact per-metre to per-nanometre density conversion; Wien peak wavelength and Stefan-Boltzmann hemispheric radiant exitance have unit-explicit names, consume the physical-constants authority, and decline unrepresented domains, while the normalised Slang blackbody remains an independent comparator. An explicit ShakuraSunyaev request instead uses the Newtonian zero-torque flux shape r^-3[1-sqrt(r_in/r)], normalised at 1.5 r_in, without claiming relativistic or alpha-disk vertical structure. The bounded grey volume uses the selected declared radial profile under its phenomenological closure and normalises its Gaussian opacity over the represented finite vertical support. Every accepted CPU and device integration segment is midpoint-sampled without an endpoint-membership prefilter, and every finite positive represented optical-depth layer is accumulated and composed with numerically stable first-order thin-layer emission. Its physical circular-emitter and diagnostic ZAMO frequencies are evaluated at the actual Boyer-Lindquist latitude from the invariant E and L_z; Doppler suppression is identified and measured as a ZAMO substitution rather than physical disk emission, and never substitutes the radially moving Kerr-Schild slicing normal.",
      "capability_dependencies": [],
      "evidence": [
        {"kind": "gtest", "name": "AnalyticValidationTest.PageThorneFluxMatchesIndependentQuadrature"},
        {"kind": "gtest", "name": "AnalyticValidationTest.TruncatedPageThorneDiskUsesDeclaredZeroTorqueEdge"},
        {"kind": "gtest", "name": "AnalyticValidationTest.PageThorneFluxApproachesNewtonianCubicFalloff"},
        {"kind": "gtest", "name": "KerrOrbitAuthority.EveryCpuConsumerSharesSignedIscoAndCircularEmitterLaw"},
        {"kind": "gtest", "name": "KerrOrbitAuthority.UnrepresentedInputsDeclineInsteadOfChangingTheOrbit"},
        {"kind": "gtest", "name": "SpectralValidationTests.KerrDiskTransferMatchesKillingFieldContraction"},
        {"kind": "gtest", "name": "SpectralValidationTests.ZamoBranchRemainsTimelikeInsideTheErgosphere"},
        {"kind": "gtest", "name": "KerrZamoTransfer.ArbitraryLatitudeMatchesIndependentBoyerLindquistContraction"},
        {"kind": "gtest", "name": "KerrZamoTransfer.KerrSchildSlicingNormalIsNotTheOffEquatorialZamo"},
        {"kind": "gtest", "name": "KernelParity.ArbitraryLatitudeKerrZamoMatchesHostAuthority"},
        {"kind": "gtest", "name": "KernelParity.EquatorialKerrDiskTransferMatchesHostAuthority"},
        {"kind": "gtest", "name": "SpectralValidationTests.PlanckSpectralRadianceMatchesIndependentCodataEquation"},
        {"kind": "gtest", "name": "SpectralValidationTests.WienPeakMatchesIndependentNumericalPlanckMaximum"},
        {"kind": "gtest", "name": "SpectralValidationTests.StefanBoltzmannExitanceMatchesIndependentHemisphericPlanckIntegral"},
        {"kind": "gtest", "name": "SpectralValidationTests.BlackbodyLawsRejectUnrepresentedDomains"},
        {"kind": "gtest", "name": "SpectralRadianceTest.BlackbodyBinsDelegateToPlanckAuthorityAndRejectInvalidTemperature"},
        {"kind": "gtest", "name": "KernelParity.BlackbodyMatchesIntegratedCoreSpectrum"},
        {"kind": "gtest", "name": "KernelParity.FullPageThorneDiskTemperatureMatchesIndependentCoreModel"},
        {"kind": "gtest", "name": "KernelParity.RepresentedSmallKerrSpinDoesNotAliasToSchwarzschildIsco"},
        {"kind": "gtest", "name": "CpuTraceBoundary.TruncatedPageThorneLiveProfileUsesDeclaredZeroTorqueEdge"},
        {"kind": "gtest", "name": "GeodesicTracerTest.LiveDiskTemperatureUsesFullPageThorneProfile"},
        {)SIRIUS_MODEL",
    R"SIRIUS_MODEL("kind": "gtest", "name": "AccretionDiskTest.ShakuraSunyaevProfileHasZeroTorqueEdgeAndDeclaredScale"},
        {"kind": "gtest", "name": "GeodesicTracerTest.LiveDiskTemperatureUsesZeroTorqueShakuraSunyaevProfile"},
        {"kind": "gtest", "name": "KernelParity.ShakuraSunyaevZeroTorqueTemperatureMatchesCoreModel"},
        {"kind": "gtest", "name": "SpectralEmissionTest.BolometricDiskAuthorityAppliesExactlyOneGFourthFactor"},
        {"kind": "gtest", "name": "KernelParity.DiskEmissionAppliesExactlyOneGFourthFactor"},
        {"kind": "gtest", "name": "GeodesicTracerRedshift.NearExtremalInnerDiskEmissionRemainsFinite"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.TransferAccumulatesAcrossEveryTraversedSegment"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.OpticallyThinTransferIsNotDiscardedAtCompositionBoundary"},
        {"kind": "gtest", "name": "SpectralValidationTests.OpticallyThinGreyLayerPreservesFirstOrderEmission"},
        {"kind": "gtest", "name": "KernelParity.OpticallyThinGreyLayerAbsorptionMatchesHostAuthority"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.RedshiftAndDopplerReachTheLiveVolumeSource"},
        {"kind": "gtest", "name": "VolumetricDiskClosure.TruncatedGaussianColumnEqualsDeclaredOpticalDepth"},
        {"kind": "gtest", "name": "KernelParity.TruncatedGaussianOpacityMatchesFiniteColumnCoreClosure"},
        {"kind": "gtest", "name": "VulkanRenderSession.ThinAndVolumetricDopplerSuppressionAffectLiveEmission"},
        {"kind": "gtest", "name": "VulkanRenderSession.ProceduralVolumetricTurbulenceReachesLiveKernel"},
        {"kind": "gtest", "name": "DopplerToggleTest.SuppressionCollapsesDiskAsymmetry"},
        {"kind": "ctest", "name": "OperationalEvidence.SourceAndIdealGovernanceRejectUncoveredClaims"}
      ]
    },
    {
      "id": "P5",
      "required": true,
      "verification": "attestation_required",
      "profiles": ["cpu", "vulkan", "physical-imax-5616x4096"],
      "requirement": "Arbitrary finite timelike camera velocity and aberration compose with pinhole and finite-aperture lenses. Film position and pupil position must occupy separate dimensions of the exact-count deterministic camera sequence rather than collapsing the four-dimensional lens integral onto a two-dimensional diagonal. A finite-aperture sample must launch across the camera-rest-frame pupil rather than changing direction at one pinhole event, converge on its requested focus-plane point, and remain within the bounded local tangent-plane domain r_pupil <= 0.1 min(r_observer, d_focus); the independent Slang projection must match that geometry. The 5616x4096 scene then resolves within the governed hardware envelope.",
      "capability_dependencies": ["physical_imax_5616x4096"],
      "evidence": [
        {"kind": "gtest", "name": "RetainedCameraProgram.Fp32CompletePhysicalLaunchAndRefusals"},
        {"kind": "gtest", "name": "RetainedCameraProgram.CompensatedCompletePhysicalLaunchAndRefusals"},
        {"kind": "gtest", "name": "CameraContinuousProjection.GeometryAndDifferentialAcrossOutputCrop"},
        {"kind": "gtest", "name": "CameraContinuousProjection.FixedPupilAndObserverArePreserved"},
        {"kind": "gtest", "name": "CameraContinuousProjection.FisheyeCropMaskCentreAndAntipodalRim"},
        {"kind": "gtest", "name": "CameraContinuousProjection.RefinementDeclinesLostCoordinatesAndDirections"},
        {"kind": "gtest", "name": "CameraContinuousProjection.CropTranslationDoesNotRenormalizeOrMaskProjection"},
        {"kind": "gtest", "name": "CameraContinuousProjection.OriginalPacketsKeepLegacyValuesWithExplicitSmoothRoundoff"},
        {"kind": "gtest", "name": "CameraContinuousProjection.InvalidAndUnsupportedProjectionPublishesNoRay"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferComposesDensityAndMovingFrequency"},
        {"kind": "gtest", "name": "PointSourceTransfer.MovingObserverUsesBandGainAndAngularAreaExactlyOnce"},
        {"kind": "gtest", "name": "CameraFilmDifferential.IndependentGeometryAndActualRayStencils"},
        {"kind": "gtest", "name": "CameraFilmDifferential.FullLaunchDifferentiatesDisplacedMovingKerrObserver"},
        {"kind": "gtest", "name": "CameraFilmDifferential.FilmColumnsRecoverAngularScreenAndPinholeHasNoPupilColumns"},
        {"kind": "gtest", "name": "CameraFilmDifferential.PerspectiveAndFixedPupilSolidAngleLaws"},
        {"kind": "gtest", "name": "CameraFilmDifferential.EquidistantCentreLimitAndAntipodalMask"},
        {"kind": "gtest", "name": "CameraFilmDifferential.PixelUnitsAndIntegratedRectangleSolidAngle"},
        {"kind": "gtest", "name": "CameraFilmDifferential.PreservesNominalRaysAndExistingOrientationSemantics"},
        {"kind": "gtest", "name": "CameraFilmDifferential.GovernedFourSampleLaunchAndSingleObserverBoost"},
        {"kind": "gtest", "name": "CameraFilmDifferential.CustomCameraDeclinesUnavailableDifferential"},
        {"kind": "gtest", "name": "ObserverFrameTests.MovingCameraLaunchMatchesIndependentLorentzTransform"},
        {"kind": "gtest", "name": "ObserverFrameTests.KerrCameraRayIsPastNullAndLaunchFrequencyIsOne"},
        {"kind": "gtest", "name": "CameraWorldlineTest.RestScreenRayAndWorldlineComposeOverLensModels"},
        {"kind": "gtest", "name": "ThinLensCameraTest.CentreApertureSharesPinholeProjectionAndFieldOfView"},
        {"kind": "gtest", "name": "ThinLensCameraTest.PupilSamplesSpanFiniteLaunchAndConvergeAtFocus"},
        {"kind": "gtest", "name": "ThinLensCameraTest.OversizedPupilDeclinesTheLocalTangentPlane"},
        {"kind": "gtest", "name": "CameraSampling.SequenceDoesNotCollapseFilmAndPupilDimensions"},
        {"kind": "gtest", "name": "CpuTraceBoundary.FinitePupilOffsetMovesTheLiveCpuLaunchEvent"},
        {"kind": "gtest", "name": "KernelParity.ThinLensPupilProjectionAndFocusMatchIndependentCoreModel"},
        {"kind": "gtest", "name": "VulkanRenderSession.NonSquareMultisamplingCameraAndLensReachLiveKernel"},
        {"kind": "gtest", "name": "VulkanRenderSession.CombinedParitySceneRetainsResolvedImageStructure"},
        {"kind": "gtest", "name": "RenderSessionProbe.SceneEvidenceBindsCanonicalTypedConfiguration"},
        {"kind": "gtest", "name": "MemoryGovernor.TwoGigabyteBudgetSeatsAWorkableTile"},
        {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"}
      ]
    },
    {
      "id": "P6",
      "required": true,
      "verification": "build_gated",
      "profiles": ["cpu", "vulkan"],
      "requirement": "EXR preserves finite fp32 linear HDR radiance outside the display pipeline. Both host spectral facades evaluate one explicitly approximate Wyman-Sloan-Shirley CIE 1931 2-degree observer fit at their actual represented wavelengths; the fit is bounded against checksum-identified official CIE 018:2019 samples across 380-780 nm, declines wavelengths outside that band, and has one directly parity-gated Slang mirror. CIE XYZ relative to D65 reaches linear-light sRGB through one exact rational host matrix derived from the declared sRGB primaries and white point, with one directly parity-gated Slang mirror. Spectral previews, explicit 8-bit views, PNG, and PPM share one IEC 61966-2-1 host transfer-curve and 8-bit quantisation authority; each display writer invokes it exactly once at its owned output boundary, and non-finite inputs decline. The live viewer consumes the already tone-mapped, graded, bounded display-linear result and its sole installed fragment shader mirrors only the exact IEC transfer curve while hardware framebuffer conversion is disabled; unreachable postprocess shaders are absent.",
      "capability_dependencies": [],
      "evidence": [
        {"kind": "gtest", "name": "SrgbTransferAuthority.CurveMatchesIndependentIecOracleAcrossBothBranches"},
        {"kind": "gtest", "name": "SrgbTransferAuthority.Ei)SIRIUS_MODEL",
    R"SIRIUS_MODEL(ghtBitQuantisationClipsAndDeclinesNonfiniteInputs"},
        {"kind": "gtest", "name": "SrgbTransferAuthority.SpectralFacadeDelegatesWithoutChangingClippingSemantics"},
        {"kind": "gtest", "name": "Cie1931ObserverAuthority.FitIsBoundedAgainstOfficialCieDatasetAcrossRepresentedBand"},
        {"kind": "gtest", "name": "Cie1931ObserverAuthority.HostSpectralFacadesEvaluateTheirActualWavelengths"},
        {"kind": "gtest", "name": "Cie1931ObserverAuthority.UnrepresentedWavelengthsFailClosed"},
        {"kind": "gtest", "name": "KernelParity.Cie1931TwoDegreeFitMatchesHostAuthority"},
        {"kind": "gtest", "name": "XyzSrgbAuthority.MatchesIndependentPrimaryWhiteDerivation"},
        {"kind": "gtest", "name": "XyzSrgbAuthority.PreservesExtendedGamutAndPropagatesNonfiniteInputs"},
        {"kind": "gtest", "name": "XyzSrgbAuthority.BlackbodyColourFacadeDelegatesToTheExactTransform"},
        {"kind": "gtest", "name": "KernelParity.XyzD65ToLinearSrgbMatchesHostAuthority"},
        {"kind": "gtest", "name": "RenderSessionProbe.FilmAffectsDisplayOutputButNeverLinearExr"},
        {"kind": "gtest", "name": "RenderSessionProbe.CpuKerrRenderProducesValidPpmThroughTheOwnedWriter"},
        {"kind": "gtest", "name": "PNGWriterTest.DecodeRoundTripMatchesSRGBEncoding"},
        {"kind": "gtest", "name": "EXRRoundTripTests.PpmRgbaBoundaryAppliesExactlyOneSrgbEncode"},
        {"kind": "gtest", "name": "EXRRoundTripTests.HDRGradientSurvivesWriteAndRead"}
      ]
    },
    {
      "id": "E1",
      "required": true,
      "verification": "build_gated",
      "profiles": ["cpu", "vulkan"],
      "requirement": "The single registry exposes nine CPU-renderable spacetime families, advertises only implemented backend support, rejects parameters absent from a metric, preserves observer distance as a geometric coordinate radius with metric-natural scaling, keeps every positive-Lambda observer and directional background boundary inside its cosmological causal patch, parameterises every CPU accepted-segment consumer by the true per-step affine interval, and clips a finite causal crossing before coupled state advances. The live Cartesian Kerr-Schild family satisfies the vacuum, Einstein-Maxwell, and spherical cosmological Einstein equations with an independently differentiated Kerr-Newman potential that is source-free outside the ring; source magnitudes must be large enough to reject omitted electromagnetic or cosmological terms. The model represents the asymptotically normalised zero-tidal Ellis metric independently of its one-sheet or two-sheet output boundary and matches its exact Ricci scalar and radial null-energy-condition violation on both ends. It enforces the resolved Alcubierre wall domain at every live host/device metric and RK-stage boundary, preserves its exact unit-determinant inverse, and matches the negative Eulerian warp-wall energy density required by Einstein's equation, while rejecting disk semantics absent from a metric.",
      "capability_dependencies": [],
      "evidence": [
        {"kind": "gtest", "name": "MetricRegistryTests.EveryCanonicalNameParsesToItsOwnId"},
        {"kind": "gtest", "name": "MetricRegistryTests.BackendSupportMatchesImplementations"},
        {"kind": "gtest", "name": "MetricRegistryTests.PositiveLambdaObserverAndHorizonShareOneCausalDomain"},
        {"kind": "gtest", "name": "KerrSchildFieldEquations.LiveCartesianFamilySatisfiesEinsteinMaxwell"},
        {"kind": "gtest", "name": "KerrSchildFieldEquations.KerrNewmanPotentialIsSourceFreeOutsideTheRing"},
        {"kind": "gtest", "name": "ChargedReference.ExteriorChartShiftMatchesIndependentQuadrature"},
        {"kind": "gtest", "name": "ChargedReference.SphericalRadialCaptureMatchesExactAffineAndTangent"},
        {"kind": "gtest", "name": "FullPathAcceptance.CpuChargedFiniteEventsMapsAndRefinement"},
        {"kind": "gtest", "name": "CpuTraceBoundary.CentralEventIsInvariantUnderBundleFeatureToggle"},
        {"kind": "gtest", "name": "CpuTraceBoundary.KottlerBothPastHorizonsRetainRadialAffineOracleAndTracerReuse"},
        {"kind": "gtest", "name": "CpuTraceBoundary.KottlerOverlapPreservesCoupledSourceMapAgainstNativeChart"},
        {"kind": "gtest", "name": "CpuTraceBoundary.KottlerReferenceRetainsExactDeSitterAndRadialIdentities"},
        {"kind": "gtest", "name": "CpuTraceBoundary.NonradialKottlerFiniteEventsMatchIndependentQuadrature"},
        {"kind": "gtest", "name": "CpuTraceBoundary.EveryAdvertisedCpuMetricConstructsAndTracesOneRay"},
        {"kind": "gtest", "name": "CpuTraceBoundary.TwoSheetEllisCrossesThroatAndReachesInversionMatchedInfinity"},
        {"kind": "gtest", "name": "CpuTraceBoundary.NonradialEllisFiniteEventsMatchIndependentQuadrature"},
        {"kind": "gtest", "name": "CpuTraceBoundary.EllisReferenceRetainsExactRadialLengthAndIndependentRefinement"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.CurvatureAndRadialNullEnergyConditionMatchExactEllis"},
        {"kind": "gtest", "name": "CpuAlcubierreAcceptance.PublicCentreRaysMatchIndependentFiniteAxialOrbits"},
        {"kind": "gtest", "name": "AlcubierreMetricTests.AnalyticInverseMatchesExactUnitDeterminantBlock"},
        {"kind": "gtest", "name": "AlcubierreMetricTests.EulerianWarpWallEnergyMatchesEinsteinConstraint"},
        {"kind": "gtest", "name": "AlcubierreMetricTests.DirectMetricRejectsUnresolvedProfiles"},
        {"kind": "gtest", "name": "KernelParity.UnresolvedWarpProfilesFailClosedOnDevice"},
        {"kind": "gtest", "name": "ConfigValidation.MetricMassAndObserverCoordinateRadiusAreIdentityAware"},
        {"kind": "gtest", "name": "RenderSessionProbe.EveryRegisteredCpuMetricCompletesAFrame"},
        {"kind": "gtest", "name": "ConfigValidation.DiskRequestDeclinesForEveryMetricWithoutAnEmissionModel"},
        {"kind": "gtest", "name": "RenderSessionProbe.CpuMorrisThorneRenderCompletes"},
        {"kind": "gtest", "name": "VulkanRenderSession.CpuVulkanAgreeOnMorrisThorneGeometryWithinStatisticalBounds"}
      ]
    },
    {
      "id": "E2",
      "required": true,
      "verification": "build_gated",
      "profiles": ["cpu"],
      "requirement": "Schwarzschild and Kerr thin-disk polarisation transports an observer-screen basis on the accepted central ray, conserves the Walker-Penrose constant, agrees across charts with an independent oracle whose null initial data and integration stages decline outside their explicit Boyer-Lindquist domain without clamping, and applies a flux-normalised Chandrasekhar-Sobolev semi-infinite pure electron-scattering atmosphere excluding absorption, finite optical depth, magnetic/Faraday effects, and returning radiation; incomplete combinations decline.",
      "capability_dependencies": [],
      "evidence": [
        {"kind": "gtest", "name": "PolarisationAcceptance.ActualDiskStokesMatchWalkerPenroseReconstruction"},
        {"kind": "gtest", "name": "PolarisationAcceptance.CommittedOutwardTransportReachesPhysicalEscapeAndObserverIsPassive"},
        {"kind": "gtest", "name": "WalkerPenroseLivePath.ConservesConstantAndOrthonormality"},
        {"kind": "gtest", "name": "WalkerPenroseLivePath.AgreesWithOracleAcrossCharts"},
        {"kind": "gtest", "name": "WalkerPenrose.BoyerLindquistInitialDataAndAxisExitDeclineWithoutSubstitution"},
        {"kind": "gtest", "name": "WalkerPenrose.SchwarzschildEquatorialPerpendicularTransportsRigidly"},
        {"kind": "gtest", "name": "GeodesicTracerTest.LiveDiskCrossingCarriesTransportedPhysicalStokesOrientation"},
        {"kind": "gtest", "name": "GeodesicTracerTest.PolarisationGaugeRemainsRegularAtPastHorizonCapture"},
        {"kind": "gtest", "name": "RenderSessionProbe.CpuPolarisationModeConsumesTransportedDiskStokes"},
        {"kind": "gtest", "name": "ConfigValidation.PolarisationRequiresRepresentedThinBlackHoleDisk"},
        {"kind": "gtest", "name": "RenderSessionProbe.PolarisedRequestsDeclineAndTwoSheetIsRepresented"}
      ]
    },
    {
      "id": "E3",
      ")SIRIUS_MODEL",
    R"SIRIUS_MODEL(required": true,
      "verification": "attestation_required",
      "profiles": ["cpu", "physical-radeon-780m", "physical-imax-5616x4096", "viewer-native-window-input"],
      "requirement": "A complete CPU-only render works without a GPU, and interactive progressive Vulkan rendering completes on the named two-gigabyte integrated-GPU floor target. Every physical continuation submission receives its own measured safety decision, cancellation is checked between submissions, each camera sample has an explicit submission bound, and reducible overshoot discards the private parent and replays disjoint children from the original film/pupil sample and continuation zero. Completion requires all samples to finish explicitly; the most expensive actual region submission controls subsequent soft sizing. Continuation readback must preserve pixel/sample/epoch identity, one-attempt transitions, rejected private state, and immutable physical terminal state; allocation limits count actual device residency and preserve existing buffers when a new allocation is declined.",
      "capability_dependencies": ["physical_radeon_780m_runtime", "physical_imax_5616x4096", "viewer_native_window_input"],
      "evidence": [
        {"kind": "gtest", "name": "VulkanRenderSession.ContinuationRendererPublishesOnlyCompleteFramesWithinActualBudget"},
        {"kind": "gtest", "name": "DispatchGovernor.ContinuationReadbackRejectsStaleOrUncommittedState"},
        {"kind": "gtest", "name": "DispatchGovernor.OnlyPhysicalTerminalReadbackCanFinalizeWithoutChangingTrajectory"},
        {"kind": "gtest", "name": "VulkanBackend.BufferAllocationLimitCountsActualResidencyAndPreservesExistingBuffers"},
        {"kind": "gtest", "name": "DispatchGovernor.ContinuationsPreserveFourCameraSamplesAndPublishOnce"},
        {"kind": "gtest", "name": "DispatchGovernor.LateContinuationOvershootReplaysChildrenFromBothZeroOrdinals"},
        {"kind": "gtest", "name": "DispatchGovernor.EveryContinuationTimingEnforcesThePhysicalSafetyBoundary"},
        {"kind": "gtest", "name": "DispatchGovernor.CancellationStopsBetweenContinuationsAndBeforePublication"},
        {"kind": "gtest", "name": "DispatchGovernor.CheapContinuationPhasesCannotHideThePeakSoftSizingFeedback"},
        {"kind": "gtest", "name": "DispatchGovernor.ContinuationExhaustionNeverImplicitlyCompletesOrAdvancesSample"},
        {"kind": "gtest", "name": "RenderSessionProbe.CpuKerrRenderProducesValidPngAndExr"},
        {"kind": "gtest", "name": "MemoryGovernor.TwoGigabyteBudgetSeatsAWorkableTile"},
        {"kind": "gtest", "name": "VulkanRenderSession.Kerr160x120CompletesAcrossMultipleGovernedTiles"},
        {"kind": "gtest", "name": "ViewCommandOperational.VulkanRefinementPublishesProgressiveFrames"},
        {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"},
        {"kind": "gtest", "name": "RetainedComputeAdmission.ArithmeticRefusalPrecedesKernelLoading"},
        {"kind": "gtest", "name": "VulkanBackend.Fma32DeviceAdmissionRequiresAdvertisedFeatureAndEveryFloatControl"},
        {"kind": "gtest", "name": "RetainedComputeAdmission.FmaSelectsOnlyNativeWideProductsAndPreservesAllocation"},
        {"kind": "gtest", "name": "RetainedComputeAdmission.StageSevenGrantsPreservePayloadAndConsumeTokens"},
        {"kind": "gtest", "name": "RetainedComputeAdmission.StageSevenFailureCannotPublishPartialOrOldIssuance"},
        {"kind": "gtest", "name": "RetainedComputeAdmission.StageSevenRequestKeepsStockUnsupportedArithmetic"},
        {"kind": "gtest", "name": "RetainedComputeAdmission.SoftwareRendererPreparationPreservesPhysicalAccounting"},
        {"kind": "gtest", "name": "RetainedComputeTest.SoftwareRendererPreparationPreservesBuffersAndPhysicalFeedback"},
        {"kind": "gtest", "name": "RenderSessionProbe.BackendAutoResolvesByDeviceRegistryAndCapabilities"},
        {"kind": "gtest", "name": "RenderSessionProbe.BackendAutoPreservesStrictDeviceAndPrecisionRequests"},
        {"kind": "gtest", "name": "RenderSessionProbe.BackendAutoUsesCpuWithNoIcdAndKeepsExplicitVulkanIntent"},
        {"kind": "gtest", "name": "RenderSessionProbe.BackendAutoPublishesCpuWithNoIcd"}
      ]
    },
    {
      "id": "E4",
      "required": true,
      "verification": "build_gated",
      "profiles": ["compile", "cpu", "vulkan"],
      "requirement": "Independent physics oracles, immutable qualification build inputs, registration-complete non-skipping Mandatory tests, and the non-weakenable qualification-to-release build/product/install/initialisation topology are artifact-bound failures rather than advisory policy.",
      "capability_dependencies": [],
      "evidence": [
        {"kind": "gtest", "name": "KernelParity.KerrSchildMetricMatchesLegacyToOnePartInMillion"},
        {"kind": "gtest", "name": "OracleConnection.AnalyticConnectionAgreesWithMetricDerivatives"},
        {"kind": "gtest", "name": "BuildGateAuthority.ReleaseReceiptBindsEveryInstalledProductAtInitialisation"},
        {"kind": "ctest", "name": "OperationalEvidence.SourceAndIdealGovernanceRejectUncoveredClaims"},
        {"kind": "ctest", "name": "OperationalBuildPolicy.ReleaseCannotWeakenGates"},
        {"kind": "ctest", "name": "OperationalBuildGate.ReleaseInstallRequiresExactPassedEstate"},
        {"kind": "ctest", "name": "OperationalEvidence.RequiredProfileRejectsGoogleTestSkip"}
      ]
    }
  ],
  "required_dimensions": [
    {
      "id": "attestation_admission_and_release_alignment",
      "evidence": [
        {"kind": "ctest", "name": "OperationalAlignment.IncompleteOrAmbiguousAttestationSetIsRejected"},
        {"kind": "ctest", "name": "OperationalAlignment.InstalledReceiptTamperingBlocksReadiness"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"},
        {"kind": "gtest", "name": "AlignmentAuthority.CompiledReceiptMatchesTheStagedRuntimeAuthority"}
      ]
    },
    {
      "id": "compile_time_contracts",
      "evidence": [
        {"kind": "gtest", "name": "ContractsDeathTest.EnforcedPreconditionViolationTerminates"},
        {"kind": "ctest", "name": "OperationalBuildPolicy.ReleaseCannotWeakenGates"}
      ]
    },
    {
      "id": "test_evidence_integrity",
      "evidence": [
        {"kind": "ctest", "name": "OperationalEvidence.RequiredProfileRejectsGoogleTestSkip"},
        {"kind": "ctest", "name": "OperationalBuildGate.ReleaseInstallRequiresExactPassedEstate"},
        {"kind": "gtest", "name": "BuildGateAuthority.ReleaseReceiptBindsEveryInstalledProductAtInitialisation"}
      ]
    },
    {
      "id": "test_registration_completeness",
      "evidence": [
        {"kind": "ctest", "name": "OperationalEvidence.SourceAndIdealGovernanceRejectUncoveredClaims"}
      ]
    },
    {
      "id": "configuration_and_input_boundary",
      "evidence": [
        {"kind": "gtest", "name": "ConfigLoading.UnknownNestedFieldDeclines"},
        {"kind": "gtest", "name": "ConfigValidation.MetricMassAndObserverCoordinateRadiusAreIdentityAware"},
        {"kind": "gtest", "name": "ConfigValidation.FeatureSpecificControlsRequireTheirOwningModels"},
        {"kind": "gtest", "name": "RenderCommandParse.ExoticMetricScalesReachTheValidatedSchema"},
        {"kind": "gtest", "name": "RenderCommandParse.FeatureParametersSelectTheirOwningModels"},
        {"kind": "gtest", "name": "RenderCommandParse.TrailingNumericGarbageRejected"},
        {"kind": "gtest", "name": "CommandRouter.UnknownCommandReturnsFailure"},
        {"kind": "gtest", "name": "RenderSessionProbe.ConfigurationConversionPreservesObserverAndDiskControls"},
        {"kind": "gtest", "name": "RenderSessionProbe.FeatureSpecificControlsRequireOwnersAtTypedBoundary"},
        {"kind": "gtest", "name": "RenderSessionProbe.InMemoryPreviewRejectsInactiveOutputPath"}
      ]
    },
    {
      "id": "install_and_volume_initi)SIRIUS_MODEL",
    R"SIRIUS_MODEL(alisation",
      "evidence": [
        {"kind": "ctest", "name": "OperationalVolume.InstallRelocateInitialiseAndFailClosed"},
        {"kind": "ctest", "name": "OperationalBuildGate.ReleaseInstallRequiresExactPassedEstate"},
        {"kind": "gtest", "name": "BuildGateAuthority.ReleaseReceiptBindsEveryInstalledProductAtInitialisation"}
      ]
    },
    {
      "id": "operator_script_exit_and_artifact_integrity",
      "evidence": [
        {"kind": "ctest", "name": "OperationalScripts.RenderFailuresAndMissingOutputsPropagate"}
      ]
    },
    {
      "id": "runtime_resource_integrity",
      "evidence": [
        {"kind": "gtest", "name": "PlatformPaths.ExplicitResourceRootDisablesFallbacks"},
        {"kind": "gtest", "name": "PlatformPaths.ResourceNamesAndSymlinksCannotEscapeTheSelectedVolume"},
        {"kind": "gtest", "name": "BuildGateAuthority.ReleaseReceiptBindsEveryInstalledProductAtInitialisation"},
        {"kind": "ctest", "name": "OperationalVolume.InstallRelocateInitialiseAndFailClosed"}
      ]
    },
    {
      "id": "cpu_render_path",
      "evidence": [
        {"kind": "gtest", "name": "RenderSessionProbe.CpuKerrRenderProducesValidPngAndExr"}
      ]
    },
    {
      "id": "session_lifecycle_and_cancellation",
      "evidence": [
        {"kind": "gtest", "name": "RenderSessionProbe.StartIsAsynchronousAndCancellationIsTerminalWithoutOutput"},
        {"kind": "gtest", "name": "RenderSessionProbe.CancellationInterruptsAnActivePrivateRayBeforePublication"},
        {"kind": "gtest", "name": "CpuTraceBoundary.CancellationDiscardsPrivateRayDataAndAllowsTracerReuse"},
        {"kind": "gtest", "name": "RenderSessionProbe.CompletionCallbackCanReenterLifecycleWithoutDeadlock"},
        {"kind": "gtest", "name": "TileScheduler.ReinitialiseResetsCompletionLedger"}
      ]
    },
    {
      "id": "vulkan_capability_and_render_path",
      "evidence": [
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersCompensatedFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp64"},
        {"kind": "gtest", "name": "VulkanRenderSession.ContinuationRendererPublishesOnlyCompleteFramesWithinActualBudget"},
        {"kind": "gtest", "name": "VulkanRenderSession.CapabilityBoundaryRejectsUnrepresentedSceneSemantics"},
        {"kind": "ctest", "name": "OperationalVulkan.RequiredRuntimeDispatch"}
      ]
    },
    {
      "id": "sampling_semantics",
      "evidence": [
        {"kind": "gtest", "name": "PixelSampling.EmitsExactlyEveryRequestedNonSquareCount"},
        {"kind": "gtest", "name": "CameraSampling.SequenceDoesNotCollapseFilmAndPupilDimensions"}
      ]
    },
    {
      "id": "device_identity_and_allocation_domain",
      "evidence": [
        {"kind": "gtest", "name": "VulkanBackend.DeviceSelectionIsStrictAndRangeChecked"},
        {"kind": "gtest", "name": "VulkanBackend.EnumerationReportsInsteadOfThrowing"},
        {"kind": "gtest", "name": "MemoryGovernor.TwoGigabyteBudgetSeatsAWorkableTile"}
      ]
    },
    {
      "id": "physics_oracles_and_near_extremal_boundary",
      "evidence": [
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersCompensatedFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp64"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp32"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp32Comp"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp64"},
        {"kind": "gtest", "name": "KerrTests.ExactExtremalIscoIsNotClampedAndUndefinedDomainsDecline"},
        {"kind": "gtest", "name": "KerrMetricDTest.ExactExtremalParametersAreNotSilentlyRewritten"},
        {"kind": "gtest", "name": "KerrMetricDTest.BoyerLindquistAxisAndNonFinitePhaseSpaceDeclineWithoutClamping"},
        {"kind": "gtest", "name": "AnalyticValidationTest.SymplecticChartExitAndNullProjectionFailureRemainDistinct"},
        {"kind": "gtest", "name": "WalkerPenrose.BoyerLindquistInitialDataAndAxisExitDeclineWithoutSubstitution"},
        {"kind": "gtest", "name": "KernelParity.RepresentedSmallKerrSpinDoesNotAliasToSchwarzschildIsco"},
        {"kind": "gtest", "name": "KerrTests.CartesianMetricIsScaleCovariantBelowTheFormerSpinFloor"},
        {"kind": "gtest", "name": "KerrTests.SingularKerrDiskDeclinesInsteadOfReceivingAnEpsilonRadius"},
        {"kind": "gtest", "name": "CoordinateTransformTests.KerrRadiusPreservesExactZeroAndScaleCovariance"},
        {"kind": "gtest", "name": "RK45IntegratorTests.UnrepresentedStageShrinksBeforeMetricEvaluation"},
        {"kind": "gtest", "name": "KernelParity.RepresentedSubThresholdKerrMetricIsScaleCovariant"},
        {"kind": "gtest", "name": "KernelParity.UnrepresentedKerrStageShrinksBeforeMetricEvaluation"},
        {"kind": "gtest", "name": "KernelParity.NullProjectionPreservesConeBranchAndFailsClosed"},
        {"kind": "gtest", "name": "ShadowBoundary.KerrNearExtremalMatchesBardeenWithinOnePixelAt1080p"},
        {"kind": "gtest", "name": "ShadowBoundary.RetainedFp32ProductsKerrNearExtremalBardeenBoundaryAt1080p"},
        {"kind": "gtest", "name": "ShadowBoundary.RetainedFp64ProductsKerrNearExtremalBardeenBoundaryAt1080p"},
        {"kind": "gtest", "name": "VulkanRenderSession.KerrNearExtremalBardeenBoundaryAt1080p"},
        {"kind": "ctest", "name": "OperationalP1.NearExtremalBurnIn"},
        {"kind": "gtest", "name": "AnalyticValidationTest.NearExtremalKerrConservesEnergyAngularMomentumAndCarter"},
        {"kind": "gtest", "name": "LivePathConservationTests.NearExtremalKerrEnergyAngularMomentumAndCarter"},
        {"kind": "gtest", "name": "FullPathAcceptance.VulkanRetainedNearExtremalRayConservesIndependentInvariants"},
        {"kind": "gtest", "name": "KernelParity.NearExtremalKerrLiveRenderIntegratorConservesEnergyAngularMomentumAndCarter"},
        {"kind": "gtest", "name": "KernelParity.PrecisionProbeArtifactsCarryOnlyTheirDeclaredFloat64Capability"},
        {"kind": "gtest", "name": "KernelParity.PrecisionRungsConserveNearExtremalKerrWithoutImageComparison"}
      ]
    },
    {
      "id": "natural_scaled_trace_domain",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.MetricMassAndObserverCoordinateRadiusAreIdentityAware"},
        {"kind": "gtest", "name": "MetricRegistryTests.PositiveLambdaObserverAndHorizonShareOneCausalDomain"},
        {"kind": "gtest", "name": "RenderSessionProbe.TraceDomainScalesWithMassAndEnclosesTheObserver"}
      ]
    },
    {
      "id": "polarised_transport_to_film",
      "evidence": [
        {"kind": "gtest", "name": "PolarisationAcceptance.ActualDiskStokesMatchWalkerPenroseReconstruction"},
        {"kind": "gtest", "name": "PolarisationAcceptance.CommittedOutwardTransportReachesPhysicalEscapeAndObserverIsPassive"},
        {"kind": "gtest", "name": "WalkerPenrose.PolarisationStaysOrthogonalAndNormalisedUnderTransport"},
        {"kind": "gtest", "name": "WalkerPenrose.BoyerLindquistInitialDataAndAxisExitDeclineWithoutSubstitution"},
        {"kind": "gtest", "name": "WalkerPenroseLivePath.ConservesConstantAndOrthonormality"},
        {"kind": "gtest", "name": "WalkerPenroseLivePath.AgreesWithOracleAcrossCharts"},
        {"kind": "gtest", "name": "WalkerPenrose.SchwarzschildEquatorialPerpendicularTransportsRigidly"},
        {"kind": "gtest", "name": "GeodesicTracerTest.LiveDiskCrossingCarriesTransportedPhysicalStokesOrientation"},
        {"kind": "gtest", "name": "GeodesicTracerTest.PolarisationGaugeRemainsRegularAtPastHorizonCapture"},
        {"kind": "gtest", "name": "RenderSessionProbe.CpuPolarisationModeConsumesTranspor)SIRIUS_MODEL",
    R"SIRIUS_MODEL(tedDiskStokes"}
      ]
    },
    {
      "id": "page_thorne_and_volumetric_transfer",
      "evidence": [
        {"kind": "gtest", "name": "DiskCoordinateTest.AxisAndNonFiniteCoordinatesDeclineInsteadOfBecomingEquatorial"},
        {"kind": "gtest", "name": "DiskCoordinateTest.CylindricalHeightAndPolarAngleRoundTripOnTheirOwnedDomain"},
        {"kind": "gtest", "name": "CoordinateTransformTests.KerrDiskRadiusIsSpheroidalNotCylindrical"},
        {"kind": "gtest", "name": "CoordinateTransformTests.KerrRadiusPreservesExactZeroAndScaleCovariance"},
        {"kind": "gtest", "name": "KerrOrbitAuthority.EveryCpuConsumerSharesSignedIscoAndCircularEmitterLaw"},
        {"kind": "gtest", "name": "KerrOrbitAuthority.UnrepresentedInputsDeclineInsteadOfChangingTheOrbit"},
        {"kind": "gtest", "name": "SpectralValidationTests.PlanckSpectralRadianceMatchesIndependentCodataEquation"},
        {"kind": "gtest", "name": "SpectralValidationTests.WienPeakMatchesIndependentNumericalPlanckMaximum"},
        {"kind": "gtest", "name": "SpectralValidationTests.StefanBoltzmannExitanceMatchesIndependentHemisphericPlanckIntegral"},
        {"kind": "gtest", "name": "SpectralValidationTests.BlackbodyLawsRejectUnrepresentedDomains"},
        {"kind": "gtest", "name": "SpectralRadianceTest.BlackbodyBinsDelegateToPlanckAuthorityAndRejectInvalidTemperature"},
        {"kind": "gtest", "name": "KernelParity.BlackbodyMatchesIntegratedCoreSpectrum"},
        {"kind": "gtest", "name": "KernelParity.FullPageThorneDiskTemperatureMatchesIndependentCoreModel"},
        {"kind": "gtest", "name": "KernelParity.RepresentedSmallKerrSpinDoesNotAliasToSchwarzschildIsco"},
        {"kind": "gtest", "name": "CpuTraceBoundary.TruncatedPageThorneLiveProfileUsesDeclaredZeroTorqueEdge"},
        {"kind": "gtest", "name": "GeodesicTracerTest.LiveDiskTemperatureUsesFullPageThorneProfile"},
        {"kind": "gtest", "name": "AccretionDiskTest.ShakuraSunyaevProfileHasZeroTorqueEdgeAndDeclaredScale"},
        {"kind": "gtest", "name": "GeodesicTracerTest.LiveDiskTemperatureUsesZeroTorqueShakuraSunyaevProfile"},
        {"kind": "gtest", "name": "KernelParity.ShakuraSunyaevZeroTorqueTemperatureMatchesCoreModel"},
        {"kind": "gtest", "name": "KerrZamoTransfer.ArbitraryLatitudeMatchesIndependentBoyerLindquistContraction"},
        {"kind": "gtest", "name": "KerrZamoTransfer.KerrSchildSlicingNormalIsNotTheOffEquatorialZamo"},
        {"kind": "gtest", "name": "KernelParity.ArbitraryLatitudeKerrZamoMatchesHostAuthority"},
        {"kind": "gtest", "name": "KernelParity.EquatorialKerrDiskTransferMatchesHostAuthority"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.TransferAccumulatesAcrossEveryTraversedSegment"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.OpticallyThinTransferIsNotDiscardedAtCompositionBoundary"},
        {"kind": "gtest", "name": "SpectralValidationTests.OpticallyThinGreyLayerPreservesFirstOrderEmission"},
        {"kind": "gtest", "name": "KernelParity.OpticallyThinGreyLayerAbsorptionMatchesHostAuthority"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.RedshiftAndDopplerReachTheLiveVolumeSource"},
        {"kind": "gtest", "name": "VolumetricDiskClosure.TruncatedGaussianColumnEqualsDeclaredOpticalDepth"},
        {"kind": "gtest", "name": "KernelParity.TruncatedGaussianOpacityMatchesFiniteColumnCoreClosure"},
        {"kind": "gtest", "name": "VulkanRenderSession.ThinAndVolumetricDopplerSuppressionAffectLiveEmission"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.ProceduralTurbulenceAltersLiveTransferDeterministically"},
        {"kind": "gtest", "name": "VulkanRenderSession.ProceduralVolumetricTurbulenceReachesLiveKernel"},
        {"kind": "ctest", "name": "OperationalEvidence.SourceAndIdealGovernanceRejectUncoveredClaims"}
      ]
    },
    {
      "id": "ray_bundles_and_filtered_point_catalogue",
      "evidence": [
        {"kind": "gtest", "name": "RetainedComputeTest.BatchedCameraPreservesPhysicalColumnsAndRejectsInvalidRows"},
        {"kind": "gtest", "name": "RetainedComputeTest.SmoothRayCameraPreservesPhysicalLensDerivatives"},
        {"kind": "gtest", "name": "VulkanRenderSession.RetainedMovingThinLensKerrDetectorMatchesCpuLinearRadiance"},
        {"kind": "gtest", "name": "RetainedComputeTest.Fp64ProductsPreserveIndependentScienceOrDeclineUnsupportedDevices"},
        {"kind": "gtest", "name": "RetainedComputeTest.JointRkStagesRetainCriticalIncrementsAndEmbeddedError"},
        {"kind": "gtest", "name": "RetainedComputeTest.MixedIndependentTransportLayersPreserveWordsAndRefusal"},
        {"kind": "gtest", "name": "RetainedComputeTest.ProjectedEndpointsKeepPhysicalColumnsAndRetainedContinuation"},
        {"kind": "gtest", "name": "RetainedComputeTest.DenseSegmentsPreserveSmallCovariantArrivalDerivatives"},
        {"kind": "gtest", "name": "RetainedComputeTest.ZeroFractionArrivalsPreserveProgramAuthorityAndCompleteRefusal"},
        {"kind": "gtest", "name": "RetainedDopriTest.IndependentQuarticPreservesCompletePhase"},
        {"kind": "gtest", "name": "RetainedDopriTest.MalformedRowsRefuseAndRecover"},
        {"kind": "gtest", "name": "RetainedDopriTest.CurvedTransportConnectsSamplerAndProjection"},
        {"kind": "gtest", "name": "RetainedDopriTest.ConnectedIntervalsPreserveTrialsAndIndependentBudgets"},
        {"kind": "gtest", "name": "RetainedDopriTest.SamplerPreservesPhysicalArrivalAndRejectsInconsistentRates"},
        {"kind": "gtest", "name": "CpuTraceBoundary.RetainedQuarticEventsKeepOriginalFractionsAndExcludeLaterDisk"},
        {"kind": "gtest", "name": "CpuTraceBoundary.RetainedQuarticVolumeFailurePublishesNothingAndRecovers"},
        {"kind": "gtest", "name": "DopriPositionSegment.SamplesTheQuarticAndItsAffineDerivative"},
        {"kind": "gtest", "name": "DopriPositionSegment.DegreeEightIsolationCoversEveryRootWithoutGridSampling"},
        {"kind": "gtest", "name": "DopriPositionSegment.SameSideQuarticContactsRespectDirectionAndOriginalRestriction"},
        {"kind": "gtest", "name": "DopriPositionSegment.TangenciesAndKerrEllipsoidUseTheSameQuartic"},
        {"kind": "gtest", "name": "DopriPositionSegment.DiskRootsIncludeTangenciesAndKeepOriginalFractions"},
        {"kind": "gtest", "name": "DopriPositionSegment.IncrementBoundarySurvivesLargeOriginsAndInvalidInputsFailClosed"},
        {"kind": "gtest", "name": "RetainedComputeTest.CoupledIntervalsRequireEmbeddedAndIndependentDenseAgreement"},
        {"kind": "gtest", "name": "RetainedComputeTest.PhysicalInitializationRetainsTheHamiltonianResidual"},
        {"kind": "gtest", "name": "RetainedComputeTest.ProjectionReserveKeepsLogicalCohortsBounded"},
        {"kind": "gtest", "name": "RetainedComputeTest.SharedTracerCompletesDeviceIntervalsAndRetainsRollbackState"},
        {"kind": "gtest", "name": "RetainedComputeTest.RejectedStepRowsCannotExposeOldOrPartialCandidates"},
        {"kind": "gtest", "name": "RetainedValue.Binary64InputsKeepTheirRepresentationResidual"},
        {"kind": "gtest", "name": "RetainedCameraProgram.Fp32CompletePhysicalLaunchAndRefusals"},
        {"kind": "gtest", "name": "RetainedCameraProgram.CompensatedCompletePhysicalLaunchAndRefusals"},
        {"kind": "gtest", "name": "PointSourceDetector.OriginalGaussianOwnsSharedEdgesAndRejectsOutsideSupport"},
        {"kind": "gtest", "name": "PointSourceDetector.ImageFrequencyAndTransmissionAreAppliedOnce"},
        {"kind": "gtest", "name": "PointSourceDetector.FoldKeepsBothImagesOfTheSameCatalogueEntry"},
        {"kind": "gtest", "name": "PointSourceDetector.FoldOwnershipSurvivesRotationTranslationAndTighterRefinement"},
        {"kind": "gtest", "name": "PointSourceDetector.ExhaustionCancellationAndFailedTracesHaveNoPartialRadiance"},
        {"kind": "gtest", "name": "PointSourceDetector.PolynomialFoldResolvesCloseImagesBetweenTheCoarseNodes"},
        {"kind": "gtest", "name": "PointSourceDetector.DisconnectedVisibilityIslandAndStripeUseActualIma)SIRIUS_MODEL",
    R"SIRIUS_MODEL(geVisibility"},
        {"kind": "gtest", "name": "RenderSessionProbe.PhysicalPointDetectorCompletesAMovingThinLensKerrFrame"},
        {"kind": "gtest", "name": "CameraContinuousProjection.AngularProjectionPreservesGeometricZerosForDetectorOffsets"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersCompensatedFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp64"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsPreserveOriginalGaussianAndNormalization"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsOwnSharedEdgesAndKeepParentCutoff"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsDeclineInvalidOrUnrepresentedGeometry"},
        {"kind": "gtest", "name": "CameraContinuousProjection.GeometryAndDifferentialAcrossOutputCrop"},
        {"kind": "gtest", "name": "CameraContinuousProjection.FixedPupilAndObserverArePreserved"},
        {"kind": "gtest", "name": "CameraContinuousProjection.RefinementDeclinesLostCoordinatesAndDirections"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferComposesDensityAndMovingFrequency"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferKeepsFluxAndDensityLinear"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferDeclinesInvalidFrequencyAndPartialFailure"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp32"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp32Comp"},
        {"kind": "gtest", "name": "KernelParity.ActualAffineAndJacobiClocksMatchFp64"},
        {"kind": "gtest", "name": "PointSourceTransfer.ReferenceFrequencyPreservesCatalogueColourAndFlux"},
        {"kind": "gtest", "name": "PointSourceTransfer.ShiftedSpectrumMatchesIndependentFixedBandPlanckLaw"},
        {"kind": "gtest", "name": "PointSourceTransfer.RejectsReciprocalExtraGainAndShiftedNormalizerSubstitutions"},
        {"kind": "gtest", "name": "PointSourceTransfer.MovingObserverUsesBandGainAndAngularAreaExactlyOnce"},
        {"kind": "gtest", "name": "PointSourceTransfer.ShiftedTemperatureHasNoCatalogueLookupClamp"},
        {"kind": "gtest", "name": "PointSourceTransfer.InvalidOrOverflowingTransferHasNoPublishedValue"},
        {"kind": "gtest", "name": "CoupledTransport.PhysicalEventVariationRetainsArrivalPositionWithoutDenseAccelerationNoise"},
        {"kind": "gtest", "name": "CoupledTransport.OriginalKerrDiskEventMatchesIndependentNeighboursAndRefinement"},
        {"kind": "gtest", "name": "CoupledTransport.CapturedKerrBeamMatchesNeighboursAndStepRefinement"},
        {"kind": "gtest", "name": "CoupledTransport.EveryCanonicalColumnCanRejectProjectedAndInteriorCurvedError"},
        {"kind": "gtest", "name": "CoupledTransport.AcceptedIncrementsKeepRefinedEventDerivativesTranslationInvariant"},
        {"kind": "gtest", "name": "CoupledTransport.EndpointAndZeroFractionIncludeEventTimeVariation"},
        {"kind": "gtest", "name": "RetainedArithmetic.SmallTermsSurviveLargeSumsProductsAndDivision"},
        {"kind": "gtest", "name": "RetainedArithmetic.CartesianGradientMatchesIndependentRationalValues"},
        {"kind": "gtest", "name": "RetainedArithmetic.CompleteCriticalMetricMatchesIndependentPrecisionWitnesses"},
        {"kind": "gtest", "name": "CoupledTransport.MinimumStepCriticalColumnsMatchIndependentRefinedFlow"},
        {"kind": "gtest", "name": "CoupledTransport.OriginalCriticalLaunchesHavePhysicalFatesOrExplicitWorkExhaustion"},
        {"kind": "gtest", "name": "CoupledTransport.FlatFourColumnsUseActualProjectedAndInteriorTrials"},
        {"kind": "gtest", "name": "CoupledTransport.CameraColumnUnitsPreserveTheJointErrorDecision"},
        {"kind": "gtest", "name": "CoupledTransport.PhysicalCameraColumnsReachTheLiveCpuSourceMap"},
        {"kind": "gtest", "name": "CoupledTransport.NonfiniteColumnsAndUnrepresentedInteriorDeclineWithoutCommit"},
        {"kind": "gtest", "name": "CoupledTransport.SkyMapIsIndependentOfPhysicalBundleOutputAndWorkLimitDeclines"},
        {"kind": "gtest", "name": "PointSourceResponseTest.IntegratedDetectorFluxFollowsSignedAffineLensMeasure"},
        {"kind": "gtest", "name": "PointSourceResponseTest.UnresolvedImageShapeStaysInDetectorCoordinates"},
        {"kind": "gtest", "name": "PointSourceResponseTest.EllipticalSupportRejectsInsideMajorCircleOutsideEllipse"},
        {"kind": "gtest", "name": "PointSourceResponseTest.SingularAndBroadMapsRequestRefinementWithoutFloors"},
        {"kind": "gtest", "name": "PointSourceResponseTest.InvalidArithmeticIsDistinctFromEmptyContribution"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueAccumulationPreservesFluxColorAndExactSupport"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CompositionCancellationAndUnrepresentedParityDecline"},
        {"kind": "gtest", "name": "PointSourceResponseTest.MovingThinLensAndSourceMapComposeIntoReceivedFlux"},
        {"kind": "gtest", "name": "RenderSessionProbe.ExhaustedNonKerrRayCannotPublishACompletedBlackFrame"},
        {"kind": "gtest", "name": "RenderSessionProbe.NumericalRayFailureKeepsCpuTilesPrivateAndPreventsOutput"},
        {"kind": "gtest", "name": "RenderSessionProbe.LaterGoodCameraSampleCannotEraseCpuNumericalFailure"},
        {"kind": "gtest", "name": "KernelInfinityDevice.Fp32IndependentDirectionsVariationsAndTerminalStates"},
        {"kind": "gtest", "name": "KernelInfinityDevice.CompensatedIndependentDirectionsVariationsAndTerminalStates"},
        {"kind": "gtest", "name": "KernelInfinityDevice.Fp64IndependentDirectionsVariationsAndTerminalStates"},
        {"kind": "gtest", "name": "KernelInfinityDevice.FinishDeclinesWithoutPublishingPartialResults"},
        {"kind": "gtest", "name": "KerrInfinity.FlatOblateRaysAndAxesReachExactCartesianSky"},
        {"kind": "gtest", "name": "KerrInfinity.VaryingHandoffAndTangentMatchExactFlatDerivative"},
        {"kind": "gtest", "name": "KerrInfinity.FrequencyScaleAndSignedParityArePreserved"},
        {"kind": "gtest", "name": "KerrInfinity.AxisPrincipalRaysHaveAnalyticAngularVariation"},
        {"kind": "gtest", "name": "KerrInfinity.KerrTailMatchesIndependentSeparatedReference"},
        {"kind": "gtest", "name": "KerrInfinity.RejectsHiddenRadialTurningPoint"},
        {"kind": "gtest", "name": "KerrInfinity.MassSpinAndRadiusScalingPreserveDirectionAndJacobian"},
        {"kind": "gtest", "name": "KerrInfinity.NearCriticalSchwarzschildDerivativeMatchesIndependentRadialIntegral"},
        {"kind": "gtest", "name": "KerrInfinity.RejectsUnrepresentedInputsAndWorkExhaustion"},
        {"kind": "gtest", "name": "SourceSkyDifferential.DeclinesUnrepresentedFrequencyGeometryAndVariation"},
        {"kind": "gtest", "name": "SourceSkyDifferential.DirectionIsInvariantUnderFrequencyAndLongitudinalVariation"},
        {"kind": "gtest", "name": "SourceSkyDifferential.KerrPositionAndTangentVariationsMatchIndependentDifferences"},
        {"kind": "gtest", "name": "SourceSkyDifferential.MovingFlatCameraMatchesAnalyticLorentzDirectionDerivative"},
        {"kind": "gtest", "name": "SourceSkyDifferential.NormalizesNonNullSpatialDirectionAndItsDerivative"},
        {"kind": "gtest", "name": "SourceSkyDifferential.ReseedsMetricVariationWithoutInheritedDualMetadata"},
        {"kind": "gtest", "name": "SourceSkyMap.EndpointVariationPreservesGaugeAndDeclinesGrazingContact"},
        {"kind": "gtest", "name": "SourceSkyMap.FlatAngularMapIsIndependentOfSphereRadiusSeedAndFrequency"},
        {"kind": "gtest", "name": "SourceSkyMap.KerrCovariantChartVariationsMatchMappedNominalFamily"},
        {"kind": "gtest", "name": "SourceSkyMap.LocalizedFlatSphereVariationMatchesAnalyticRayFamily"},
        {"kin)SIRIUS_MODEL",
    R"SIRIUS_MODEL(d": "gtest", "name": "SourceSkyMap.RetainsZeroRankDeficiencyAndSignedParity"},
        {"kind": "gtest", "name": "SourceSkyInfinityTrace.FlatPupilMapAndFrequencyAreHandoffIndependent"},
        {"kind": "gtest", "name": "SourceSkyInfinityTrace.KerrMapConvergesAcrossHandoffRadiiAndFixedPupilNeighbours"},
        {"kind": "gtest", "name": "SourceSkyInfinityTrace.NonVacuumAndCapturedRaysDoNotClaimVacuumInfinity"},
        {"kind": "gtest", "name": "SourceSkyMapTrace.KerrMapConvergesToFixedPupilRetracing"},
        {"kind": "gtest", "name": "SourceSkyMapTrace.MovingPupilMapMatchesAnalyticAberration"},
        {"kind": "gtest", "name": "SourceSkyMapTrace.StationaryTranslatedPupilMapIsRadiusIndependent"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OrdinaryEscapeBoundaryLaunchUsesCrossingDirection"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OrdinaryEscapeClipsCentralAndJacobiAffineIntervals"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OrdinaryEscapeDeclinesExteriorOutwardLaunchWithoutSourceEvent"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OrdinaryEscapeExcludesDiskAndVolumeBeyondBoundary"},
        {"kind": "gtest", "name": "KernelTrace.ActualTraceClipsJacobiAndRetainsInvalidSamplesAcrossRungs"},
        {"kind": "gtest", "name": "KernelTrace.ActualTraceFiniteSphereExcludesLaterDiskAndVolumeAcrossRungs"},
        {"kind": "gtest", "name": "KernelParity.FiniteEscapeUsesFirstOutwardEventAndClippedIntervalAcrossRungs"},
        {"kind": "gtest", "name": "RayBundleTest.CurvatureStencilPreservesMassScaleAndBothSpinSigns"},
        {"kind": "gtest", "name": "RayBundleTest.CurvatureStencilStaysInsideTheActualKerrChartDomain"},
        {"kind": "gtest", "name": "RayBundleTest.MagnificationComesOnlyFromJacobiMap"},
        {"kind": "gtest", "name": "BeamPropagationTest.OrientationDescribesOutputEllipseRatherThanInputBasis"},
        {"kind": "gtest", "name": "BeamPropagationTest.SchwarzschildRadialCongruenceMatchesClosedFormToOnePartPerMillion"},
        {"kind": "gtest", "name": "BeamPropagationTest.SchwarzschildCircularPhotonCongruenceMatchesClosedFormToOnePartPerMillion"},
        {"kind": "gtest", "name": "CpuJacobiOracle.TidalContractionMatchesAnalyticSchwarzschildAtMatchedEvents"},
        {"kind": "gtest", "name": "CpuJacobiOracle.CurvatureScalarMatchesAnalyticKerrOffEquator"},
        {"kind": "gtest", "name": "CpuJacobiOracle.RadialPointSourceCongruenceMatchesClosedForm"},
        {"kind": "gtest", "name": "KernelParity.BeamEllipseRetainsBothAxesAndOutputOrientation"},
        {"kind": "gtest", "name": "KernelParity.CelestialTangentBasisIsSharedByBeamAndPointFilter"},
        {"kind": "gtest", "name": "KernelParity.DeviceTidalContractionMatchesAnalyticKerrAtMatchedEvents"},
        {"kind": "gtest", "name": "KernelParity.DeviceTidalContractionMatchesAnalyticSchwarzschildAtMatchedEvents"},
        {"kind": "gtest", "name": "KernelParity.DeviceRadialPointSourceCongruenceMatchesClosedForm"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.EllipticalFilterUsesTheBeamSachsBasis"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.PointFilterRetainsImaxSubpixelOffsets"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.PointFilterMatchesIndependentAngularOracle"},
        {"kind": "gtest", "name": "StarfieldGeneratorTests.SpatialIndexIncludesStarsAcrossAngularCellBoundaries"},
        {"kind": "gtest", "name": "KernelParity.PointStarAngularWeightMatchesIndependentOracle"},
        {"kind": "gtest", "name": "StarfieldPointTest.EllipticalFootprintUsesBothAxesAndOrientation"},
        {"kind": "gtest", "name": "StarfieldPointTest.SpatialIndexMatchesExhaustiveBeamOracle"},
        {"kind": "gtest", "name": "StarfieldPointTest.ImaxCatalogueIndexFitsTheTwoGigabyteOperatingEnvelope"},
        {"kind": "gtest", "name": "PointSourceDetector.RotatingIsolatedStarMatchesIndependentSharedRegionBrightness"},
        {"kind": "gtest", "name": "PointSourceDetector.RetainedRotatingIsolatedStarMatchesIndependentSharedRegionBrightness"},
        {"kind": "gtest", "name": "VulkanRenderSession.CpuVulkanPointCatalogueAgreeOnFlatScene"}
      ]
    },
    {
      "id": "camera_worldline_lens_and_film",
      "evidence": [
        {"kind": "gtest", "name": "RetainedCameraProgram.Fp32CompletePhysicalLaunchAndRefusals"},
        {"kind": "gtest", "name": "RetainedCameraProgram.CompensatedCompletePhysicalLaunchAndRefusals"},
        {"kind": "gtest", "name": "PointSourceDetector.OriginalGaussianOwnsSharedEdgesAndRejectsOutsideSupport"},
        {"kind": "gtest", "name": "PointSourceDetector.ImageFrequencyAndTransmissionAreAppliedOnce"},
        {"kind": "gtest", "name": "PointSourceDetector.FoldKeepsBothImagesOfTheSameCatalogueEntry"},
        {"kind": "gtest", "name": "PointSourceDetector.FoldOwnershipSurvivesRotationTranslationAndTighterRefinement"},
        {"kind": "gtest", "name": "PointSourceDetector.ExhaustionCancellationAndFailedTracesHaveNoPartialRadiance"},
        {"kind": "gtest", "name": "PointSourceDetector.PolynomialFoldResolvesCloseImagesBetweenTheCoarseNodes"},
        {"kind": "gtest", "name": "PointSourceDetector.DisconnectedVisibilityIslandAndStripeUseActualImageVisibility"},
        {"kind": "gtest", "name": "RenderSessionProbe.PhysicalPointDetectorCompletesAMovingThinLensKerrFrame"},
        {"kind": "gtest", "name": "CameraContinuousProjection.AngularProjectionPreservesGeometricZerosForDetectorOffsets"},
        {"kind": "gtest", "name": "CameraContinuousProjection.GeometryAndDifferentialAcrossOutputCrop"},
        {"kind": "gtest", "name": "CameraContinuousProjection.FixedPupilAndObserverArePreserved"},
        {"kind": "gtest", "name": "CameraContinuousProjection.FisheyeCropMaskCentreAndAntipodalRim"},
        {"kind": "gtest", "name": "CameraContinuousProjection.RefinementDeclinesLostCoordinatesAndDirections"},
        {"kind": "gtest", "name": "CameraContinuousProjection.CropTranslationDoesNotRenormalizeOrMaskProjection"},
        {"kind": "gtest", "name": "CameraContinuousProjection.OriginalPacketsKeepLegacyValuesWithExplicitSmoothRoundoff"},
        {"kind": "gtest", "name": "CameraContinuousProjection.InvalidAndUnsupportedProjectionPublishesNoRay"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferComposesDensityAndMovingFrequency"},
        {"kind": "gtest", "name": "PointSourceTransfer.MovingObserverUsesBandGainAndAngularAreaExactlyOnce"},
        {"kind": "gtest", "name": "CameraFilmDifferential.IndependentGeometryAndActualRayStencils"},
        {"kind": "gtest", "name": "CameraFilmDifferential.FullLaunchDifferentiatesDisplacedMovingKerrObserver"},
        {"kind": "gtest", "name": "CameraFilmDifferential.FilmColumnsRecoverAngularScreenAndPinholeHasNoPupilColumns"},
        {"kind": "gtest", "name": "CameraFilmDifferential.PerspectiveAndFixedPupilSolidAngleLaws"},
        {"kind": "gtest", "name": "CameraFilmDifferential.EquidistantCentreLimitAndAntipodalMask"},
        {"kind": "gtest", "name": "CameraFilmDifferential.PixelUnitsAndIntegratedRectangleSolidAngle"},
        {"kind": "gtest", "name": "CameraFilmDifferential.PreservesNominalRaysAndExistingOrientationSemantics"},
        {"kind": "gtest", "name": "CameraFilmDifferential.GovernedFourSampleLaunchAndSingleObserverBoost"},
        {"kind": "gtest", "name": "CameraFilmDifferential.CustomCameraDeclinesUnavailableDifferential"},
        {"kind": "gtest", "name": "CameraFactoryTest.MalformedLensValueFailsClosed"},
        {"kind": "gtest", "name": "ConfigValidation.CameraWorldlineAndLensAreValidated"},
        {"kind": "gtest", "name": "ConfigValidation.FeatureSpecificControlsRequireTheirOwningModels"},
        {"kind": "gtest", "name": "RenderCommandParse.FeatureParametersSelectTheirOwningModels"},
        {"kind": "gtest", "name": "RenderSessionProbe.FeatureSpecificControlsRequireOwnersAtTypedBoundary"},
        {"kind": "gtest", "name": "ObserverFrameTests.MovingCameraLaunchMatchesIndependentLorent)SIRIUS_MODEL",
    R"SIRIUS_MODEL(zTransform"},
        {"kind": "gtest", "name": "ObserverFrameTests.KerrCameraRayIsPastNullAndLaunchFrequencyIsOne"},
        {"kind": "gtest", "name": "ThinLensCameraTest.PupilSamplesSpanFiniteLaunchAndConvergeAtFocus"},
        {"kind": "gtest", "name": "ThinLensCameraTest.OversizedPupilDeclinesTheLocalTangentPlane"},
        {"kind": "gtest", "name": "CameraSampling.SequenceDoesNotCollapseFilmAndPupilDimensions"},
        {"kind": "gtest", "name": "CpuTraceBoundary.FinitePupilOffsetMovesTheLiveCpuLaunchEvent"},
        {"kind": "gtest", "name": "KernelParity.ThinLensPupilProjectionAndFocusMatchIndependentCoreModel"},
        {"kind": "gtest", "name": "CameraWorldlineTest.RestScreenRayAndWorldlineComposeOverLensModels"},
        {"kind": "gtest", "name": "RenderSessionProbe.FilmAffectsDisplayOutputButNeverLinearExr"}
      ]
    },
    {
      "id": "interactive_viewer_projection",
      "evidence": [
        {"kind": "gtest", "name": "ViewCommandOperational.CommittedFrameRemainsCoherentDuringRefinementAndReinitialisation"},
        {"kind": "gtest", "name": "ViewCommandOperational.StrictParsingAndSessionProjection"},
        {"kind": "gtest", "name": "ViewCommandOperational.RefinementLadderPreservesRequestedDimensions"},
        {"kind": "gtest", "name": "ViewCommandOperational.SoleRefinementPublishesExactRequestedDimensions"},
        {"kind": "gtest", "name": "ViewCommandOperational.HeadlessRefinementProducesASynchronisedFrame"},
        {"kind": "gtest", "name": "ViewCommandOperational.VulkanRefinementPublishesProgressiveFrames"}
      ]
    },
    {
      "id": "output_encoding",
      "evidence": [
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsPreserveOriginalGaussianAndNormalization"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsOwnSharedEdgesAndKeepParentCutoff"},
        {"kind": "gtest", "name": "PointSourceResponseTest.RestrictedCellsDeclineInvalidOrUnrepresentedGeometry"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferComposesDensityAndMovingFrequency"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferKeepsFluxAndDensityLinear"},
        {"kind": "gtest", "name": "PointSourceResponseTest.CatalogueBandTransferDeclinesInvalidFrequencyAndPartialFailure"},
        {"kind": "gtest", "name": "PointSourceTransfer.ReferenceFrequencyPreservesCatalogueColourAndFlux"},
        {"kind": "gtest", "name": "PointSourceTransfer.ShiftedSpectrumMatchesIndependentFixedBandPlanckLaw"},
        {"kind": "gtest", "name": "PointSourceTransfer.RejectsReciprocalExtraGainAndShiftedNormalizerSubstitutions"},
        {"kind": "gtest", "name": "PointSourceTransfer.MovingObserverUsesBandGainAndAngularAreaExactlyOnce"},
        {"kind": "gtest", "name": "PointSourceTransfer.ShiftedTemperatureHasNoCatalogueLookupClamp"},
        {"kind": "gtest", "name": "PointSourceTransfer.InvalidOrOverflowingTransferHasNoPublishedValue"},
        {"kind": "gtest", "name": "Cie1931ObserverAuthority.FitIsBoundedAgainstOfficialCieDatasetAcrossRepresentedBand"},
        {"kind": "gtest", "name": "Cie1931ObserverAuthority.HostSpectralFacadesEvaluateTheirActualWavelengths"},
        {"kind": "gtest", "name": "Cie1931ObserverAuthority.UnrepresentedWavelengthsFailClosed"},
        {"kind": "gtest", "name": "KernelParity.Cie1931TwoDegreeFitMatchesHostAuthority"},
        {"kind": "gtest", "name": "SrgbTransferAuthority.CurveMatchesIndependentIecOracleAcrossBothBranches"},
        {"kind": "gtest", "name": "SrgbTransferAuthority.EightBitQuantisationClipsAndDeclinesNonfiniteInputs"},
        {"kind": "gtest", "name": "SrgbTransferAuthority.SpectralFacadeDelegatesWithoutChangingClippingSemantics"},
        {"kind": "gtest", "name": "ViewerDisplayContract.LiveShaderAppliesOnlyExactSrgbTransfer"},
        {"kind": "gtest", "name": "ViewerDisplayContract.FilmFinishClosesDisplayLinearRange"},
        {"kind": "gtest", "name": "XyzSrgbAuthority.MatchesIndependentPrimaryWhiteDerivation"},
        {"kind": "gtest", "name": "XyzSrgbAuthority.PreservesExtendedGamutAndPropagatesNonfiniteInputs"},
        {"kind": "gtest", "name": "XyzSrgbAuthority.BlackbodyColourFacadeDelegatesToTheExactTransform"},
        {"kind": "gtest", "name": "KernelParity.XyzD65ToLinearSrgbMatchesHostAuthority"},
        {"kind": "gtest", "name": "RenderSessionProbe.GeometricMetadataNeverInventsPhysicalLengthUnits"},
        {"kind": "gtest", "name": "PNGWriterTest.DecodeRoundTripMatchesSRGBEncoding"},
        {"kind": "gtest", "name": "PNGWriterTest.NonFiniteRadianceIsRejected"},
        {"kind": "gtest", "name": "EXRRoundTripTests.PpmRgbaBoundaryAppliesExactlyOneSrgbEncode"},
        {"kind": "gtest", "name": "RenderSessionProbe.CpuKerrRenderProducesValidPpmThroughTheOwnedWriter"},
        {"kind": "gtest", "name": "EXRRoundTripTests.HDRGradientSurvivesWriteAndRead"},
        {"kind": "gtest", "name": "EXRRoundTripTests.NonFiniteRadianceIsRejected"},
        {"kind": "gtest", "name": "DisplayBuffer.NonFiniteRadianceIsIdentifiedBeforeEncoding"}
      ]
    },
    {
      "id": "memory_and_dispatch_governance",
      "evidence": [
        {"kind": "gtest", "name": "VulkanBackend.HostMemoryPreferencePreservesCompatibleHeapAndCoherence"},
        {"kind": "gtest", "name": "VulkanRenderSession.ContinuationRendererPublishesOnlyCompleteFramesWithinActualBudget"},
        {"kind": "gtest", "name": "DispatchGovernor.ContinuationReadbackRejectsStaleOrUncommittedState"},
        {"kind": "gtest", "name": "DispatchGovernor.OnlyPhysicalTerminalReadbackCanFinalizeWithoutChangingTrajectory"},
        {"kind": "gtest", "name": "VulkanBackend.BufferAllocationLimitCountsActualResidencyAndPreservesExistingBuffers"},
        {"kind": "gtest", "name": "DispatchGovernor.ContinuationsPreserveFourCameraSamplesAndPublishOnce"},
        {"kind": "gtest", "name": "DispatchGovernor.LateContinuationOvershootReplaysChildrenFromBothZeroOrdinals"},
        {"kind": "gtest", "name": "DispatchGovernor.EveryContinuationTimingEnforcesThePhysicalSafetyBoundary"},
        {"kind": "gtest", "name": "DispatchGovernor.CancellationStopsBetweenContinuationsAndBeforePublication"},
        {"kind": "gtest", "name": "DispatchGovernor.CheapContinuationPhasesCannotHideThePeakSoftSizingFeedback"},
        {"kind": "gtest", "name": "DispatchGovernor.ContinuationExhaustionNeverImplicitlyCompletesOrAdvancesSample"},
        {"kind": "gtest", "name": "MemoryGovernor.TwoGigabyteBudgetSeatsAWorkableTile"},
        {"kind": "gtest", "name": "MemoryGovernor.MalformedOverrideDeclinesInsteadOfBorrowingTheDeviceBudget"},
        {"kind": "gtest", "name": "DispatchGovernor.ExpensivePrecisionAndBundleWorkloadsUseTheStrictPhysicalFootprint"},
        {"kind": "gtest", "name": "DispatchGovernor.OrdinaryPrecisionBoundsSurviveGrowthAndDisabledAdaptation"},
        {"kind": "gtest", "name": "DispatchGovernor.TargetFailsLoudOnGarbageNegativesAndNonFinite"},
        {"kind": "gtest", "name": "DispatchGovernor.StrictCapsApplyToEveryTailEvenWithoutAdaptation"},
        {"kind": "gtest", "name": "DispatchGovernor.InvalidTimingAndIrreducibleOvershootDecline"},
        {"kind": "gtest", "name": "DispatchGovernor.NearTargetLatencyStillGrowsWholeBands"},
        {"kind": "gtest", "name": "VulkanRenderSession.DispatchSubdivisionPreservesExactCameraAndCatalogueOutput"}
      ]
    },
    {
      "id": "kernel_portability",
      "evidence": [
        {"kind": "gtest", "name": "KernelPortability.CudaEmissionCarriesTheNativeComputeEntryPoint"},
        {"kind": "gtest", "name": "KernelPortability.MetalEmissionCarriesTheNativeComputeEntryPoint"}
      ]
    },
    {
      "id": "metric_catalogue_and_declines",
      "evidence": [
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersFp32"},
        {"kind": "gtest", "name": "KernelParity.MetricConnectionAndJetShareRepresentedParametersCompensatedFp32"},
        {"kind": "gtest", "name": "Ker)SIRIUS_MODEL",
    R"SIRIUS_MODEL(nelParity.MetricConnectionAndJetShareRepresentedParametersFp64"},
        {"kind": "gtest", "name": "MetricRegistryTests.EveryCanonicalNameParsesToItsOwnId"},
        {"kind": "gtest", "name": "ConfigValidation.MetricMassAndObserverCoordinateRadiusAreIdentityAware"},
        {"kind": "gtest", "name": "KottlerHorizonTests.ExactRootsSeparateBlackHoleCaptureFromCosmologicalHorizon"},
        {"kind": "gtest", "name": "KottlerHorizonTests.PureDeSitterHasOnlyACosmologicalHorizon"},
        {"kind": "gtest", "name": "KottlerHorizonTests.RegularDeSitterOriginUsesTheExactAnalyticLimit"},
        {"kind": "gtest", "name": "KerrSchildFieldEquations.LiveCartesianFamilySatisfiesEinsteinMaxwell"},
        {"kind": "gtest", "name": "KerrSchildFieldEquations.KerrNewmanPotentialIsSourceFreeOutsideTheRing"},
        {"kind": "gtest", "name": "ConfigValidation.DeSitterRequestsEnforcePositiveLambdaAndSubNariaiBlackHole"},
        {"kind": "gtest", "name": "CpuTraceBoundary.KottlerBothPastHorizonsRetainRadialAffineOracleAndTracerReuse"},
        {"kind": "gtest", "name": "CpuTraceBoundary.KottlerOverlapPreservesCoupledSourceMapAgainstNativeChart"},
        {"kind": "gtest", "name": "CpuTraceBoundary.KottlerReferenceRetainsExactDeSitterAndRadialIdentities"},
        {"kind": "gtest", "name": "CpuTraceBoundary.NonradialKottlerFiniteEventsMatchIndependentQuadrature"},
        {"kind": "gtest", "name": "CpuTraceBoundary.EveryAdvertisedCpuMetricConstructsAndTracesOneRay"},
        {"kind": "gtest", "name": "RenderSessionProbe.EveryRegisteredCpuMetricCompletesAFrame"},
        {"kind": "gtest", "name": "ConfigValidation.DiskRequestDeclinesForEveryMetricWithoutAnEmissionModel"},
        {"kind": "gtest", "name": "RenderCommandParse.BackendVulkanDeclinesMetricOffTheRenderPath"}
      ]
    }
  ],
  "capability_contracts": [
    {
      "id": "revision_bound_release_alignment",
      "state": "supported",
      "profiles": ["compile", "build", "initialisation"],
      "request": "Produce a release build whose ultimate ideal is internally aligned",
      "behavior": "Require every external record to come from a clean strict qualification build with immutable governed inputs. The operating model must have canonical LF-terminated UTF-8 checkout bytes on every host, every bundle's gated operating-model product must byte-match the independently selected source model before its domains are admitted, and generated receipts must have one explicit UTF-8/LF byte identity, so one Git revision cannot acquire platform-local or self-consistently substituted compiled authorities. Standalone verification and native evidence issuance must derive both the expected revision and model identity from one selected clean Git source root; an explicitly selected older checkout must never fall back to the verifier branch's model. Native-build records must bind the full governed registration, exact nine-case non-render authority estate, every compiled test executable, all nine live products, alignment receipt, and copied candidate bytes; runtime, image, and viewer records must additionally carry the complete zero-skip Mandatory estate and physical evidence under one cross-checked hash chain. Then require one authority for every model-derived domain, a deterministic model-bound release receipt, a fresh artifact-bound zero-skip release gate, installed-product rehashing before render or viewer initialisation, and top-level readiness that remains false outside an aligned release.",
      "evidence": [
        {"kind": "ctest", "name": "OperationalAlignment.IncompleteOrAmbiguousAttestationSetIsRejected"},
        {"kind": "ctest", "name": "OperationalAlignment.InstalledReceiptTamperingBlocksReadiness"},
        {"kind": "gtest", "name": "AlignmentAuthority.CompiledReceiptMatchesTheStagedRuntimeAuthority"},
        {"kind": "gtest", "name": "BuildGateAuthority.ReleaseReceiptBindsEveryInstalledProductAtInitialisation"}
      ]
    },
    {
      "id": "polarised_thin_disk_cpu",
      "state": "supported",
      "profiles": ["cpu"],
      "request": "colorMode=Polarisation with a Schwarzschild/Kerr thin disk",
      "behavior": "Transport the observer screen basis on the accepted geodesic, project in the emitter screen, apply the flux-normalised Chandrasekhar-Sobolev semi-infinite pure electron-scattering atmosphere (excluding absorption, magnetic/Faraday effects, finite optical depth, and returning radiation), and publish a film result.",
      "evidence": [
        {"kind": "gtest", "name": "RenderSessionProbe.CpuPolarisationModeConsumesTransportedDiskStokes"}
      ]
    },
    {
      "id": "polarised_volumetric_transfer",
      "state": "fail_closed",
      "profiles": ["cpu", "vulkan"],
      "request": "Polarisation combined with volumetric disk transfer",
      "behavior": "Decline before rendering; scalar volume emission may not impersonate transported Stokes transfer.",
      "evidence": [
        {"kind": "gtest", "name": "RenderSessionProbe.PolarisedRequestsDeclineAndTwoSheetIsRepresented"},
        {"kind": "gtest", "name": "ConfigValidation.PolarisationRequiresRepresentedThinBlackHoleDisk"}
      ]
    },
    {
      "id": "polarised_temporal_motion_blur",
      "state": "fail_closed",
      "profiles": ["cpu", "vulkan"],
      "request": "Polarisation combined with temporal disk motion blur",
      "behavior": "Decline before rendering until Stokes states are transported and integrated at every temporal sample.",
      "evidence": [
        {"kind": "gtest", "name": "RenderSessionProbe.PolarisedRequestsDeclineAndTwoSheetIsRepresented"},
        {"kind": "gtest", "name": "ConfigValidation.PolarisationRequiresRepresentedThinBlackHoleDisk"}
      ]
    },
    {
      "id": "polarised_vulkan_render",
      "state": "fail_closed",
      "profiles": ["vulkan"],
      "request": "Vulkan rendering with polarisation enabled",
      "behavior": "Decline before device dispatch; CPU evidence is not borrowed by the Vulkan profile.",
      "evidence": [
        {"kind": "gtest", "name": "VulkanRenderSession.CapabilityBoundaryRejectsUnrepresentedSceneSemantics"}
      ]
    },
    {
      "id": "cpu_scalar_motion_blur",
      "state": "fail_closed",
      "profiles": ["cpu"],
      "request": "Scalar thin-disk temporal motion blur",
      "behavior": "Decline before rendering: an axisymmetric stationary disk cannot acquire physical blur by rotating one crossing's Euclidean line-of-sight factor; support requires an explicit time-dependent emissivity and covariant shutter integral.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.MotionBlurAndWormholeTopologyHaveExplicitOperatorBoundaries"},
        {"kind": "gtest", "name": "RenderCommandParse.MotionBlurAndWormholeTopologyReachTheValidatedSchema"},
        {"kind": "gtest", "name": "RenderCommandParse.UsageDeclaresTemporalTransferFailClosed"}
      ]
    },
    {
      "id": "vulkan_scalar_motion_blur",
      "state": "fail_closed",
      "profiles": ["vulkan"],
      "request": "Scalar thin-disk temporal motion blur on Vulkan",
      "behavior": "Decline before device dispatch; temporal sampling is not silently reduced or replaced by a static Vulkan frame.",
      "evidence": [
        {"kind": "gtest", "name": "RenderCommandParse.UsageDeclaresTemporalTransferFailClosed"},
        {"kind": "gtest", "name": "VulkanRenderSession.CapabilityBoundaryRejectsUnrepresentedSceneSemantics"}
      ]
    },
    {
      "id": "covariant_relativistic_jet_transfer",
      "state": "fail_closed",
      "profiles": ["cpu", "vulkan", "viewer"],
      "request": "Relativistic jet emission in a rendered scene",
      "behavior": "Decline before rendering or viewer initialisation; a local phenomenological chord integral may not impersonate covariant geodesic radiative transfer.",
      "evidence": [
        {"kind": "gtest", "name": "ViewCommandOperational.RelativisticJetsDeclineBeforeViewerInitialisation"},
        {"kind": "gtest", "name": "VulkanRenderSes)SIRIUS_MODEL",
    R"SIRIUS_MODEL(sion.CapabilityBoundaryRejectsUnrepresentedSceneSemantics"}
      ]
    },
    {
      "id": "ray_bundles_outside_stationary_black_holes",
      "state": "fail_closed",
      "profiles": ["cpu", "vulkan"],
      "request": "Ray-bundle propagation outside Minkowski, Schwarzschild, or Kerr",
      "behavior": "Decline at the configuration boundary until covariant curvature transport is validated for the requested metric, including its time dependence and topology.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.RayBundlesRejectMetricsWithoutStationaryCurvatureTransport"}
      ]
    },
    {
      "id": "inverse_compton_corona_transfer",
      "state": "fail_closed",
      "profiles": ["cpu", "vulkan"],
      "request": "Inverse-Compton corona emission or opacity",
      "behavior": "Decline before rendering until a frequency-dependent covariant Compton source and transfer model replaces the removed grey energy multiplier and fixed colour tint.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.TurbulenceRequiresVolumeAndSpectralCoronaDeclines"},
        {"kind": "gtest", "name": "VulkanRenderSession.CapabilityBoundaryRejectsUnrepresentedSceneSemantics"}
      ]
    },
    {
      "id": "narrowband_line_transfer",
      "state": "fail_closed",
      "profiles": ["cpu", "vulkan"],
      "request": "colorMode=Narrowband emission-line rendering",
      "behavior": "Decline before rendering until ionisation, elemental abundance, density, line emissivity, and frequency-dependent covariant transfer are represented; temperature-only SHO colour Gaussians are not an emission model.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.UnrepresentedNarrowbandEmissionDeclines"}
      ]
    },
    {
      "id": "newtonian_shakura_sunyaev_temperature_profile",
      "state": "substituted",
      "profiles": ["cpu", "vulkan"],
      "request": "temperatureModel=ShakuraSunyaev",
      "behavior": "Replace the relativistic Page-Thorne radial flux only when explicitly requested with the Newtonian zero-torque standard thin-disk shape F proportional to r^-3[1-sqrt(r_in/r)], define diskTemperature at 1.5 r_in, retain the invariant circular-emitter frequency transfer, and make no relativistic-flux, alpha-viscosity, density, opacity, or vertical-structure claim.",
      "evidence": [
        {"kind": "gtest", "name": "AccretionDiskTest.ShakuraSunyaevProfileHasZeroTorqueEdgeAndDeclaredScale"},
        {"kind": "gtest", "name": "GeodesicTracerTest.LiveDiskTemperatureUsesZeroTorqueShakuraSunyaevProfile"},
        {"kind": "gtest", "name": "KernelParity.ShakuraSunyaevZeroTorqueTemperatureMatchesCoreModel"}
      ]
    },
    {
      "id": "doppler_suppression_diagnostic",
      "state": "substituted",
      "profiles": ["cpu", "vulkan"],
      "request": "Disable orbital Doppler shift while retaining gravitational transfer",
      "behavior": "Use the exact locally non-rotating Eulerian/ZAMO frequency branch as an explicitly nonphysical diagnostic substitution; the default remains the circular-emitter invariant frequency transfer.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.FeatureSpecificControlsRequireTheirOwningModels"},
        {"kind": "gtest", "name": "DopplerToggleTest.SuppressionCollapsesDiskAsymmetry"},
        {"kind": "gtest", "name": "RenderCommandParse.FeatureParametersSelectTheirOwningModels"},
        {"kind": "gtest", "name": "RenderSessionProbe.FeatureSpecificControlsRequireOwnersAtTypedBoundary"},
        {"kind": "gtest", "name": "SpectralValidationTests.ZamoBranchRemainsTimelikeInsideTheErgosphere"}
      ]
    },
    {
      "id": "phenomenological_volumetric_disk",
      "state": "bounded",
      "profiles": ["cpu", "vulkan"],
      "request": "Grey volumetric accretion-disk transfer",
      "behavior": "Represent a stationary, vertically isothermal, Gaussian atmosphere truncated at three scale heights and normalised over that finite support with H/r clamped to [0.01,0.5], unmodulated inner-edge vertical optical depth tau_ref, tau(r)=tau_ref(r/r_ref)^(-3/2), circular Kerr flow, invariant comoving path length, the explicitly selected Page-Thorne or bounded Newtonian zero-torque Shakura-Sunyaev radial temperature, and optional explicitly procedural density modulation that perturbs the baseline column. Midpoint-sample every accepted CPU and device integration segment without using endpoint membership as an intersection proxy, and retain every finite positive represented optical-depth layer through stable observer-to-source accumulation and final composition; make no GRMHD, alpha-disk vertical-structure, ionisation, or frequency-dependent opacity claim.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.FeatureSpecificControlsRequireTheirOwningModels"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.TransferAccumulatesAcrossEveryTraversedSegment"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.OpticallyThinTransferIsNotDiscardedAtCompositionBoundary"},
        {"kind": "gtest", "name": "SpectralValidationTests.OpticallyThinGreyLayerPreservesFirstOrderEmission"},
        {"kind": "gtest", "name": "KernelParity.OpticallyThinGreyLayerAbsorptionMatchesHostAuthority"},
        {"kind": "gtest", "name": "GeodesicTracerVolumetric.RedshiftAndDopplerReachTheLiveVolumeSource"},
        {"kind": "gtest", "name": "VolumetricDiskClosure.TruncatedGaussianColumnEqualsDeclaredOpticalDepth"},
        {"kind": "gtest", "name": "KernelParity.TruncatedGaussianOpacityMatchesFiniteColumnCoreClosure"},
        {"kind": "gtest", "name": "ConfigValidation.TurbulenceRequiresVolumeAndSpectralCoronaDeclines"},
        {"kind": "gtest", "name": "RenderCommandParse.FeatureParametersSelectTheirOwningModels"},
        {"kind": "gtest", "name": "RenderSessionProbe.FeatureSpecificControlsRequireOwnersAtTypedBoundary"},
        {"kind": "ctest", "name": "OperationalEvidence.SourceAndIdealGovernanceRejectUncoveredClaims"}
      ]
    },
    {
      "id": "kerr_schild_einstein_maxwell_family",
      "state": "bounded",
      "profiles": ["cpu", "vulkan"],
      "request": "Minkowski, Schwarzschild, Kerr, Reissner-Nordstrom, or Kerr-Newman spacetime rendering",
      "behavior": "Represent the asymptotically flat family in horizon-penetrating Cartesian Kerr-Schild coordinates with the exact oblate radial root and determinant minus one. The live covariant metric and analytic first derivatives must independently recover R_mu_nu=0 in vacuum and G_mu_nu=8 pi T_mu_nu for the electromagnetic potential A_mu=-Q r l_mu/Sigma; the same potential must satisfy the source-free Maxwell equation outside the ring. Cover both spin and charge signs, scale covariance, extremal and horizonless represented continuations, and the exact flat, Schwarzschild, and zero-charge limits. Rotating or charged nonzero-Lambda combinations remain outside this ansatz and decline.",
      "evidence": [
        {"kind": "gtest", "name": "KerrSchildFieldEquations.LiveCartesianFamilySatisfiesEinsteinMaxwell"},
        {"kind": "gtest", "name": "KerrSchildFieldEquations.KerrNewmanPotentialIsSourceFreeOutsideTheRing"},
        {"kind": "gtest", "name": "KerrTests.MetricMatchesIndependentCartesianKerrSchildForm"},
        {"kind": "gtest", "name": "ReissnerNordstromTests.MetricMatchesIndependentCartesianKerrSchildForm"},
        {"kind": "gtest", "name": "ConfigValidation.RotatingLambdaRejected"},
        {"kind": "gtest", "name": "KernelParity.KerrSchildMetricMatchesLegacyToOnePartInMillion"}
      ]
    },
    {
      "id": "spherical_kottler_cosmological_sector",
      "state": "bounded",
      "profiles": ["cpu"],
      "request": "de-Sitter or Schwarzschild-de-Sitter metric rendering",
      "behavior": "Represent the exact spherical positive-Lambda Kottler metric in horizon-penetrating Cartesian Kerr-Schild coordinates and independently recover R_mu_nu=Lambda g_mu_nu and R=4 Lambda fro)SIRIUS_MODEL",
    R"SIRIUS_MODEL(m the live metric. Classify black-hole capture with the smaller positive root and use the distinct cosmological root as the outer causal-patch bound. Pure de Sitter has no black-hole capture surface and uses the exact regular analytic metric and derivative limit at the Cartesian origin; a nonzero-mass spherical origin remains singular and declines. Schwarzschild-de-Sitter requests require 9 Lambda M^2 < 1. Require the launch radius to remain at or below 0.99 of the cosmological horizon, round the fp32 directional celestial boundary inward from that horizon, and localise an accepted crossing segment back onto the bound before any Jacobi, polarisation, volume, or disk segment consumer advances; all consumers use the unconditional per-step affine interval and sky sampling observes that same terminal event. Reuse one scale-safe root authority across the metric, public and typed validation, and CPU tracing. The launch observer is the renderer's ADM/Eulerian worldline, not an implicitly static observer; the celestial texture is a finite directional boundary condition, not cosmological radiative transfer. Negative Lambda, rotating/charged Lambda sectors, Nariai, super-Nariai, and observers outside the governed causal patch decline.",
      "evidence": [
        {"kind": "gtest", "name": "KottlerHorizonTests.ExactRootsSeparateBlackHoleCaptureFromCosmologicalHorizon"},
        {"kind": "gtest", "name": "KottlerHorizonTests.PureDeSitterHasOnlyACosmologicalHorizon"},
        {"kind": "gtest", "name": "KottlerHorizonTests.RegularDeSitterOriginUsesTheExactAnalyticLimit"},
        {"kind": "gtest", "name": "CpuTraceBoundary.KottlerReferenceRetainsExactDeSitterAndRadialIdentities"},
        {"kind": "gtest", "name": "CpuTraceBoundary.NonradialKottlerFiniteEventsMatchIndependentQuadrature"},
        {"kind": "gtest", "name": "KerrSchildFieldEquations.LiveCartesianFamilySatisfiesEinsteinMaxwell"},
        {"kind": "gtest", "name": "MetricRegistryTests.PositiveLambdaObserverAndHorizonShareOneCausalDomain"},
        {"kind": "gtest", "name": "CpuTraceBoundary.CentralEventIsInvariantUnderBundleFeatureToggle"},
        {"kind": "gtest", "name": "CpuTraceBoundary.JacobiBundleTerminatesAtTheSameCausalEvent"},
        {"kind": "gtest", "name": "ConfigValidation.DeSitterRequestsEnforcePositiveLambdaAndSubNariaiBlackHole"},
        {"kind": "gtest", "name": "RenderSessionProbe.TraceDomainScalesWithMassAndEnclosesTheObserver"},
        {"kind": "gtest", "name": "RenderSessionProbe.TypedNumericBoundariesMatchTheExternalConfigurationBoundary"}
      ]
    },
    {
      "id": "disk_emission_outside_schwarzschild_kerr",
      "state": "fail_closed",
      "profiles": ["cpu", "vulkan"],
      "request": "Accretion-disk emission for any metric other than Schwarzschild or Kerr",
      "behavior": "Require diskEnabled=false; no Kerr Page-Thorne approximation is substituted.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.DiskRequestDeclinesForEveryMetricWithoutAnEmissionModel"}
      ]
    },
    {
      "id": "morris_thorne_one_sheet",
      "state": "supported",
      "profiles": ["cpu", "vulkan"],
      "request": "Morris-Thorne OneSheetCapture topology",
      "behavior": "Render the exact asymptotically normalised zero-tidal Ellis metric in isotropic Cartesian radius rho, with g_tt=-1, areal radius r=rho+b0^2/(4*rho), and conformal spatial metric [1+b0^2/(4*rho^2)]^2 delta_ij. Require the shared CPU/Vulkan radius domain 0.1 <= b0 <= 1000, 5*b0 <= rho_observer <= 1000*b0, and scale both live trace domains with b0. Independently recover R=-2*b0^2/r^4 and the equal negative radial null Ricci contraction on both ends; nonzero constant lapse, non-Ellis shape, and irrelevant shape-callback requests are not live parameters and decline. For OneSheetCapture, isolate the observer-nearest accepted-segment contact with the regular throat sphere rho=b0/2, including hidden enter/exit and tangent contacts, clip downstream consumers to that event, and publish the distinct dark Throat outcome rather than misclassifying it as an intrinsic horizon.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.MetricMassAndObserverCoordinateRadiusAreIdentityAware"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.ChartAgreementWithSphericalFamily"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.CurvatureAndRadialNullEnergyConditionMatchExactEllis"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.LiveEllisRejectsUnnormalisedLapseAndIrrelevantShapeData"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.ThroatIsARegularTopologyBoundaryNotACaptureSurface"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.ThroatAndPositiveRadiusSecondSheetAreFiniteAndUnclamped"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.SphericalArealChartDeclinesItsCoordinateSingularities"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.AcceptedSegmentFindsHiddenAndTangentThroatContacts"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.NonEllisCartesianRequestsFailClosed"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.ParameterBoundsMatchConfigAuthority"},
        {"kind": "gtest", "name": "KernelParity.IsotropicEllisMetricAndConnectionMatchCoreOnBothSheets"},
        {"kind": "gtest", "name": "KernelParity.UnnormalisedOrNonEllisDeviceProfilesFailClosed"},
        {"kind": "gtest", "name": "KernelParity.SphericalCaptureEventFindsHiddenAndTangentContacts"},
        {"kind": "gtest", "name": "CpuTraceBoundary.OneSheetEllisNamesTheRegularThroatBoundary"},
        {"kind": "gtest", "name": "CpuTraceBoundary.NonradialEllisFiniteEventsMatchIndependentQuadrature"},
        {"kind": "gtest", "name": "RenderSessionProbe.TraceDomainScalesWithMassAndEnclosesTheObserver"},
        {"kind": "gtest", "name": "RenderSessionProbe.CpuMorrisThorneRenderCompletes"},
        {"kind": "gtest", "name": "VulkanRenderSession.CpuVulkanAgreeOnMorrisThorneGeometryWithinStatisticalBounds"}
      ]
    },
    {
      "id": "morris_thorne_two_sheet",
      "state": "supported",
      "profiles": ["cpu", "vulkan"],
      "request": "Morris-Thorne TwoSheet topology",
      "behavior": "Integrate through the regular throat into 0<rho<b0/2 and terminate at the inversion-matched second asymptotic cutoff rho_minus=b0^2/(4*rho_plus), which has the same areal radius as the observer-side cutoff. Publish the opposite sheet explicitly and transform the terminal sky direction with the exact inversion Jacobian I-2nn^T. Both ends use the same catalogue as a declared symmetric boundary condition; no dark-throat one-sheet result may be relabelled as traversal.",
      "evidence": [
        {"kind": "gtest", "name": "MetricRegistryTests.MetricInfoRoundTripsById"},
        {"kind": "gtest", "name": "ConfigValidation.MotionBlurAndWormholeTopologyHaveExplicitOperatorBoundaries"},
        {"kind": "gtest", "name": "RenderSessionProbe.PolarisedRequestsDeclineAndTwoSheetIsRepresented"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.InversionExchangesEndsAndPreservesArealRadius"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.SecondSheetSkyUsesTheExactInversionJacobian"},
        {"kind": "gtest", "name": "MorrisThorneCartesianTests.DirectionalBoundaryIgnoresTangentAndSelectsInwardCrossing"},
        {"kind": "gtest", "name": "CpuTraceBoundary.TwoSheetEllisCrossesThroatAndReachesInversionMatchedInfinity"},
        {"kind": "gtest", "name": "CpuTraceBoundary.NonradialEllisFiniteEventsMatchIndependentQuadrature"},
        {"kind": "gtest", "name": "KernelParity.EllisTwoSheetTraceCrossesThroatAndMapsTheOppositeSky"}
      ]
    },
    {
      "id": "alcubierre_exterior_resolved_profile",
      "state": "bounded",
      "profiles": ["cpu", "vulkan"],
      "request": "Alcubierre exterior-observer rendering with tanh wall parameters R and sigma",
      "behavior": "Treat sigma as an )SIRIUS_MODEL",
    R"SIRIUS_MODEL(inverse coordinate length; require finite |v_s| <= 10, positive R and sigma no greater than 1000, 0.1 <= sigma*R <= 100, and 5L <= r_observer <= 1000L for L=max(R,1/sigma). The registry, concrete CPU metric, device metric/connection, and every device RK stage fail closed on that same domain. The exact t-x determinant remains -1 with one analytic host/device inverse. An independent fourth-order connection-difference Ricci oracle must recover the Eulerian energy density -v_s^2[(partial_y f)^2+(partial_z f)^2]/(32 pi), including its strict off-axis negativity, while trace-domain extent scales with L and the minimum step with min(R,1/sigma). Six admitted CPU centre-camera seeds at three refinements compare complete finite escape position, tangent, affine interval and Eulerian sky with an independent stationary-comoving axial quadrature, including its measured refinement uncertainty within the existing 1e-4 envelope. A zero-velocity flat control, both velocity signs, a safe superluminal branch with two interior coordinate turns, and small/large scales delimit this finite CPU witness; no off-axis image, trapped/horizon, beam, transfer or Vulkan trajectory accuracy is inferred.",
      "evidence": [
        {"kind": "gtest", "name": "ConfigValidation.MetricMassAndObserverCoordinateRadiusAreIdentityAware"},
        {"kind": "gtest", "name": "RenderCommandParse.ExoticMetricScalesReachTheValidatedSchema"},
        {"kind": "gtest", "name": "RenderSessionProbe.TraceDomainScalesWithMassAndEnclosesTheObserver"},
        {"kind": "gtest", "name": "CpuAlcubierreAcceptance.PublicCentreRaysMatchIndependentFiniteAxialOrbits"},
        {"kind": "gtest", "name": "AlcubierreMetricTests.AnalyticInverseMatchesExactUnitDeterminantBlock"},
        {"kind": "gtest", "name": "AlcubierreMetricTests.EulerianWarpWallEnergyMatchesEinsteinConstraint"},
        {"kind": "gtest", "name": "AlcubierreMetricTests.DirectMetricRejectsUnresolvedProfiles"},
        {"kind": "gtest", "name": "KernelParity.UnresolvedWarpProfilesFailClosedOnDevice"}
      ]
    },
    {
      "id": "vulkan_volumetric_sample_bound",
      "state": "bounded",
      "profiles": ["vulkan"],
      "request": "Volumetric midpoint samples per geodesic segment",
      "behavior": "Accept 1..128; explicit Vulkan requests above 128 decline and auto selects CPU with the reason.",
      "evidence": [
        {"kind": "gtest", "name": "VulkanRenderSession.CapabilityBoundaryAcceptsRepresentedSceneSemantics"},
        {"kind": "gtest", "name": "VulkanRenderSession.CapabilityBoundaryRejectsUnrepresentedSceneSemantics"},
        {"kind": "gtest", "name": "RenderSessionProbe.BackendAutoResolvesByDeviceRegistryAndCapabilities"}
      ]
    },
    {
      "id": "viewer_input_state_logic",
      "state": "supported",
      "profiles": ["viewer"],
      "request": "Keyboard press/repeat/release, pointer drag, and scroll input",
      "behavior": "Update finite camera state deterministically and restart progressive refinement.",
      "evidence": [
        {"kind": "gtest", "name": "ViewCommandOperational.InputStateHandlesPressRepeatReleaseMouseAndScroll"}
      ]
    },
    {
      "id": "viewer_native_window_input",
      "state": "attestation_required",
      "profiles": ["viewer-native-window-input"],
      "request": "Native GLFW/OpenGL window with a physical-Radeon Vulkan refinement frame and host-delivered keyboard, cursor and scroll events",
      "behavior": "Before expensive execution, a non-promoting exact-candidate preflight must reject false hosts, software or ambiguous devices, missing WSL2/display/input prerequisites, and every command except machine-readable info queries. On the consolidated WSL2 route, the viewer producer may reuse the full test/gate/candidate/product authority only from an independently verified same-revision physical-Radeon hardware record whose platform and complete device identity equal the live viewer selection; stale, circular, cross-host, or cross-device reuse fails before window creation. Admission still requires a strict-qualification viewer-native-window-input attestation that binds that authority to a newly published progressive Vulkan frame and newly observed keyboard, cursor and scroll callbacks in hashed evidence.",
      "evidence": [
        {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"}
      ]
    },
    {
      "id": "native_p2900_contracts",
      "state": "substituted",
      "profiles": ["compile"],
      "request": "C++26 P2900 contract semantics",
      "behavior": "Use native P2900 only when the feature macro is present; otherwise use build-enforced checked contract macros and report native support as false.",
      "evidence": [
        {"kind": "gtest", "name": "Contracts.LanguageCapabilitiesDistinguishNativeFeaturesFromSubstitutes"},
        {"kind": "gtest", "name": "ContractsDeathTest.EnforcedPreconditionViolationTerminates"}
      ]
    },
    {
      "id": "native_p2996_reflection",
      "state": "substituted",
      "profiles": ["compile"],
      "request": "C++26 P2996 static reflection",
      "behavior": "Keep explicit configuration serializers and kernel parameter bindings; do not claim or require native reflection.",
      "evidence": [
        {"kind": "gtest", "name": "Contracts.LanguageCapabilitiesDistinguishNativeFeaturesFromSubstitutes"},
        {"kind": "gtest", "name": "ConfigSchema.DefaultsRoundTripThroughJson"}
      ]
    },
    {
      "id": "physical_radeon_780m_runtime",
      "state": "attestation_required",
      "profiles": ["physical-radeon-780m"],
      "request": "Physical Radeon 780M Vulkan runtime support",
      "behavior": "A non-promoting exact-candidate preflight must first reject software, ambiguous, non-Radeon, non-Dozen, or under-budget WSL2 selections without running tests or rendering. Admission still requires strict-qualification evidence binding the copied candidate executable and its build gate to selected non-software Radeon 780M readiness, full tests, artefact hashes, and driver identity.",
      "evidence": [
        {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"}
      ]
    },
    {
      "id": "wsl2_dozen_runtime",
      "state": "attestation_required",
      "profiles": ["wsl2-dozen"],
      "request": "WSL2 Vulkan through Mesa Dozen/dzn",
      "behavior": "A non-promoting exact-candidate preflight must reject non-WSL2 hosts, absent /dev/dxg, and devices without Dozen/dzn identity before expensive execution. Admit only a WSL2 attestation whose selected physical device reports Dozen/dzn driver identity.",
      "evidence": [
        {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"}
      ]
    },
    {
      "id": "windows_native_build_and_runtime",
      "state": "attestation_required",
      "profiles": ["windows-native-build", "windows-native-vulkan"],
      "request": "Native Windows compilation/tests and native Vulkan runtime",
      "behavior": "An explicit native CI dispatch emits a clean strict-qualification build attestation whose non-promoting gate binds the complete registered test topology, exact nine-case non-render authority estate, all compiled test executables, all nine live products, alignment receipt, and copied candidate bytes. Before native runtime execution, a non-promoting exact-candidate preflight rejects wrong hosts, software or ambiguous devices, Dozen, missing resources, and every command except machine-readable info queries. Compilation and preflight claim no runtime; native Vulkan remains a distinct full-estate physical-device attestation.",
      "evidence": [
       )SIRIUS_MODEL",
    R"SIRIUS_MODEL( {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"}
      ]
    },
    {
      "id": "macos_native_build_and_moltenvk",
      "state": "attestation_required",
      "profiles": ["macos-native-build", "macos-moltenvk"],
      "request": "Native macOS compilation/tests and MoltenVK runtime",
      "behavior": "An explicit native CI dispatch emits a clean strict-qualification build attestation whose non-promoting gate binds the complete registered test topology, exact nine-case non-render authority estate, all compiled test executables, all nine live products, alignment receipt, and copied candidate bytes. Before native runtime execution, a non-promoting exact-candidate preflight rejects wrong hosts, software or ambiguous devices, non-MoltenVK drivers, missing resources, and every command except machine-readable info queries. Compilation and preflight claim no runtime; closure separately requires a full-estate physical MoltenVK attestation.",
      "evidence": [
        {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"}
      ]
    },
    {
      "id": "physical_imax_5616x4096",
      "state": "attestation_required",
      "profiles": ["physical-imax-5616x4096"],
      "request": "Full 5616x4096 physical-device P3/P5 render under a 2048 MiB governed budget",
      "behavior": "A non-promoting exact-candidate preflight must reject a selected physical device exposing less than the governed 2048 MiB render budget without running tests or rendering. Static memory planning and preflight are necessary but insufficient; closure requires exact decoded PNG dimensions and point-star structure in a disk-free frame, measured wall time, physical device identity, hashed artefacts, and one completed typed-session transcript event binding the display-calibrated beam-filtered 100000-star catalogue to Vulkan dispatch with a moving finite-aperture camera in the same governed scene.",
      "evidence": [
        {"kind": "gtest", "name": "MemoryGovernor.TwoGigabyteBudgetSeatsAWorkableTile"},
        {"kind": "gtest", "name": "StarfieldPointTest.ImaxCatalogueIndexFitsTheTwoGigabyteOperatingEnvelope"},
        {"kind": "gtest", "name": "VulkanRenderSession.CombinedParitySceneRetainsResolvedImageStructure"},
        {"kind": "gtest", "name": "RenderSessionProbe.SceneEvidenceBindsCanonicalTypedConfiguration"},
        {"kind": "ctest", "name": "OperationalAttestation.FalseExternalEvidenceIsRejected"},
        {"kind": "ctest", "name": "OperationalAttestation.PreflightAndNativeRuntimeRejectFalseHostDevice"}
      ]
    }
  ]
}
)SIRIUS_MODEL",
};

inline constexpr bool kReleaseAlignmentEnforced = false;
inline constexpr bool kQualificationAlignmentEnforced =
    true;
inline constexpr bool kEmbeddedAlignmentSatisfied = false;
inline constexpr std::size_t kEmbeddedAlignmentReceiptSize = 1240;
inline constexpr std::array<std::string_view, 1>
    kEmbeddedAlignmentReceiptChunks = {
    R"SIRIUS_ALIGN({
  "admitted_domains": [],
  "alignment_mode": "qualification",
  "method": "revision-bound-attestation-set",
  "operating_model": {
    "external_domains": [
      "macos-moltenvk",
      "macos-native-build",
      "physical-imax-5616x4096",
      "physical-radeon-780m",
      "viewer-native-window-input",
      "windows-native-build",
      "windows-native-vulkan",
      "wsl2-dozen"
    ],
    "schema_version": 3,
    "sha256": "839a2f5a4dd135cd3066a150333ebfe2355b8c29390477c3c0013e833272e781"
  },
  "pending_domains": [
    "macos-moltenvk",
    "macos-native-build",
    "physical-imax-5616x4096",
    "physical-radeon-780m",
    "viewer-native-window-input",
    "windows-native-build",
    "windows-native-vulkan",
    "wsl2-dozen"
  ],
  "records": [],
  "required_domains": [
    "macos-moltenvk",
    "macos-native-build",
    "physical-imax-5616x4096",
    "physical-radeon-780m",
    "viewer-native-window-input",
    "windows-native-build",
    "windows-native-vulkan",
    "wsl2-dozen"
  ],
  "schema_version": 1,
  "source_revision": "d2e1a265106a8b27e976ccb47cef6303aaa51746",
  "source_tree_clean": true,
  "ultimate_ideal": {
    "required": true,
    "satisfied": false,
    "state": "attestation_required"
  }
}
)SIRIUS_ALIGN",
};

static_assert(!kReleaseAlignmentEnforced || kEmbeddedAlignmentSatisfied,
              "release binaries require a complete revision-bound alignment receipt");
static_assert(!(kReleaseAlignmentEnforced && kQualificationAlignmentEnforced),
              "release and qualification modes are mutually exclusive");

}  // namespace sirius::base

#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include <array>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <span>
#include <string_view>
#include <sys/resource.h>

namespace {
using namespace sirius::backend;
using namespace sirius::core;

void Check(bool condition, const char* reason) {
    if (condition) return;
    std::fprintf(stderr, "Failed: %s\n", reason);
    std::exit(1);
}

void Memory(const char* phase) {
    struct rusage usage {};
    Check(getrusage(RUSAGE_SELF, &usage) == 0, "read process peak RSS");
    std::printf("phase=%s peak_rss_kib=%ld\n", phase, usage.ru_maxrss);
}

template <typename T>
T Require(sirius::base::Expected<T> value) {
    if (value) return std::move(*value);
    std::fprintf(stderr, "%s\n", value.error().Description().c_str());
    std::exit(1);
}

void WriteFrame(std::ofstream& output, const DetectorLaunchFrame& frame,
                const CameraRay& camera) {
    Check(frame.pupil.phase_space.has_value() &&
              frame.pupil.phase_space->direction == camera.phase_space->direction &&
              frame.pupil.aperture_up == camera.aperture_up &&
              frame.pupil.aperture_right == camera.aperture_right,
          "the frame exposes the current camera ray");
    for (int i = 0; i < 4; ++i)
        Check(frame.pupil.direction(i) == camera.direction(i), "current film direction");
    const auto range = [&](const auto& x) { output << x.lo << ' ' << x.hi << ' '; };
    for (const auto& x : frame.position) range(x);
    for (const auto& axis : frame.tetrad)
        for (const auto& x : axis) range(x);
    for (const auto& axis : frame.displacement)
        for (const auto& x : axis) range(x);
    for (const auto& basis : frame.covariant)
        for (const auto& axis : basis)
            for (const auto& x : axis) range(x);
    output << '\n';
}

void Run(RetainedCompute& compute, int width, int height, bool prior, std::ofstream& output) {
    CameraConfig config;
    config.r = 30;
    config.theta = 80 * constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = width;
    config.height = height;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    ThinLensCamera camera(config);
    KerrSchildFamily metric(KerrSchildParams::Kerr(1, .9));
    std::atomic<bool> cancel = false;
    RetainedTraceExecutor executor(compute, [&] { return cancel.load(); });
    TracerConfig settings;
    settings.enable_disk = false;
    settings.enable_ray_bundles = true;
    settings.bundle_point_source = true;
    GeodesicTracer tracer(&metric, settings);
    tracer.SetStepExecutor(&executor);
    const std::array coordinates{
        std::array{928, 608}, std::array{960, 608}, std::array{0, 0},
        std::array{32, 64}, std::array{width - 32, height - 32}, std::array{64, height - 64},
    };
    std::optional<CameraRay> reference;
    output << width << ' ' << height << '\n';
    for (const auto& pixel : coordinates) {
        Check(ForEachCameraSample(4, [&](const CameraSample& sample) {
            const auto film = camera.ProjectFilmForObserver(
                pixel[0] + double(sample.image_u), pixel[1] + double(sample.image_v),
                sample.pupil_u, sample.pupil_v);
            Check(film && film->ray.phase_space, "exact moving ThinLens film projection");
            const auto frame = tracer.PrepareDetectorPupil(film->ray);
            Check(frame.has_value(), "retained certified pupil enclosure");
            if (!reference) reference = film->ray;
            WriteFrame(output, *frame, film->ray);
        }) == 4, "original exact sample count");
    }
    const auto rows = executor.Statistics().camera_rows;
    Check(rows == (prior ? 96 : 16), "camera rows for six canonical blocks");
    std::printf("scene=%dx%d blocks=%zu pupil_samples=4 camera_rows=%llu\n", width, height,
                coordinates.size(), static_cast<unsigned long long>(rows));

    auto changed = *reference;
    changed.beta_up += .005;
    auto frame = tracer.PrepareDetectorPupil(changed);
    Check(frame.has_value() && executor.Statistics().camera_rows == rows + 4, "boost miss");
    WriteFrame(output, *frame, changed);
    changed.phase_space->pupil_up[3] = .75;
    frame = tracer.PrepareDetectorPupil(changed);
    Check(frame.has_value() && executor.Statistics().camera_rows == rows + 8, "pupil Jacobian miss");
    WriteFrame(output, *frame, changed);
    frame = tracer.PrepareDetectorPupil(changed);
    Check(frame.has_value() && executor.Statistics().camera_rows == rows + (prior ? 12 : 8),
          "a completed changed input becomes reusable");
    WriteFrame(output, *frame, changed);

    const auto before_cancel = executor.Statistics().camera_rows;
    cancel.store(true);
    Check(!tracer.PrepareDetectorPupil(changed) && executor.Statistics().camera_rows == before_cancel,
          "cancellation wins over a cache hit");
    cancel.store(false);
    const auto plain = executor.Launch(metric, .9, *reference);
    Check(plain.has_value() && !executor.Error(), "ordinary retained camera launch");
    for (int i = 0; i < 4; ++i)
        output << plain->position(i) << ' ' << plain->tangent(i) << ' ';
    output << '\n';
}
}  // namespace

int main(int argc, char** argv) {
    Check(argc == 3, "usage: compare prior|current output-file");
    const bool prior = std::string_view(argv[1]) == "prior";
    std::ofstream output(argv[2]);
    output << std::hexfloat;
    Check(output.good(), "open comparison file");
    Memory("before_device");
    const auto inventory = Require(EnumerateVulkanDevices());
    const auto index = Require(ResolveVulkanDeviceIndex(inventory));
    const auto device = Require(CreateVulkanDevice(index));
    const auto& info = device->Info();
    Check(info.vendor_id == 0x1002 && info.kind == DeviceKind::kIntegratedGpu &&
              info.name.find("780M") != std::string::npos &&
              info.driver_name.find("Dozen") != std::string::npos,
          "physical AMD Radeon 780M through Dozen");
    Check(device->SetBufferAllocationLimit(1024ULL * 1024 * 1024).has_value(), "same residency limit");
    auto compute = Require(RetainedCompute::Create(*device, 128));
    Memory("buffers_allocated");
    std::printf("device=%s driver=%s allocated_bytes=%llu\n", info.name.c_str(), info.driver_info.c_str(),
                static_cast<unsigned long long>(device->BufferAllocationBytes()));
    Run(*compute, 1920, 1080, prior, output);
    Memory("1080p_pupils");
    Run(*compute, 5616, 4096, prior, output);
    Memory("imax_pupils");
    Check(output.good(), "complete comparison file");
}

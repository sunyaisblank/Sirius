from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import os
import shlex
import subprocess


root = Path.cwd()
stage = root/'out/kerr-pupil-reuse'
build = root/'bin/linux-ci'
prior = '8c2d15e2'
source_prefix = Path('src/sirius/backend')
inputs = ('retained_trace_executor.h','retained_trace_executor.cpp','retained_spherical_escape.cpp')
overlay = stage/'prior'
old_files = {}
for name in inputs:
    source = source_prefix/name
    saved = overlay / source.relative_to('src')
    saved.parent.mkdir(parents=True,exist_ok=True)
    saved.write_bytes(subprocess.check_output(['git','show',f'{prior}:{source}']))
    old_files[name] = saved

compile_commands = json.loads((build/'compile_commands.json').read_text())
common = ['/usr/bin/g++-14', '-std=c++2c', '-O3', '-DNDEBUG', '-DSIRIUS_CONTRACT_MODE=2',
          '-DSIRIUS_HAS_RETAINED_COMPUTE=1', '-DSIRIUS_RELEASE_RESOURCE_LOCKED=1', '-Wall',
          '-Wextra','-Wpedantic','-Werror','-Wno-missing-field-initializers']
compile_jobs = []
old_objects = []
for name in inputs[1:]:
    original, = [row for row in compile_commands if row['file'].endswith('/'+name)]
    command = shlex.split(original['command'])
    assert command[-2] == '-c' and command[-4]=='-o'
    output = stage/f'{name}.old.o'
    compile_jobs.append(( [command[0],f'-I{overlay}',*command[1:-4],'-o',str(output),
                           '-c',str(old_files[name])], original['directory']))
    old_objects.append(str(output))

for mode in ('prior','current'):
    includes = [f'-I{overlay}'] if mode == 'prior' else []
    command = [*common,*includes,f'-I{root/"src"}', '-c',str(stage/'compare.cpp'),
               '-o',str(stage/f'compare-{mode}.o')]
    compile_jobs.append((command,str(root)))
lib = build/'src/sirius'
archives=[lib/'backend/libsirius_backend_cpu.a',lib/'backend/libsirius_backend.a',
          lib/'core/libsirius_core.a',lib/'libsirius_base.a']
link_jobs=[]
for mode in ('prior','current'):
    objects=[str(stage/f'compare-{mode}.o'),*(old_objects if mode=='prior' else [])]
    command=['/usr/bin/g++-14',*objects,*map(str,archives),'-lvulkan','-ldl','-lrt','-pthread',
             '-Wl,-Map,'+str(stage/f'{mode}.map'),'-o',str(stage/f'compare-{mode}')]
    link_jobs.append((command,str(root)))

(stage/'build-paired.json').write_text(json.dumps({'prior':prior,'compile':compile_jobs,'link':link_jobs},indent=2)+'\n')

def run(job):
    command, directory = job
    subprocess.run(command,cwd=directory,env={**os.environ,'TMPDIR':str(stage)},check=True)

with ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(run,compile_jobs))
    list(pool.map(run,link_jobs))

#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"

#include <array>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <sys/resource.h>

namespace {
using namespace sirius;
using namespace sirius::backend;
using namespace sirius::core;

template<class T>
T Require(base::Expected<T> value) {
    if (value) return std::move(*value);
    std::fprintf(stderr, "%s\n", value.error().Description().c_str());
    std::exit(1);
}

long Peak() {
    struct rusage usage {};
    if (getrusage(RUSAGE_SELF, &usage) != 0) std::exit(2);
    return usage.ru_maxrss;
}

class DispatchMemory final : public ComputeDevice {
  public:
    explicit DispatchMemory(ComputeDevice& device) : device_(device) {}
    const DeviceInfo& Info() const noexcept override { return device_.Info(); }
    base::Expected<KernelHandle> LoadKernel(std::span<const std::uint32_t> spirv) override {
        auto handle = device_.LoadKernel(spirv);
        if (handle) {
            const auto stage = static_cast<RetainedCompute::KernelStage>(loaded_++);
            names_[handle->value] = RetainedCompute::StageName(stage);
            std::printf("load stage=%s bytes=%zu kernel=%u peak_rss_kib=%ld\n",
                        names_[handle->value], spirv.size_bytes(), handle->value, Peak());
        }
        return handle;
    }
    base::Expected<BufferHandle> CreateBuffer(std::uint64_t bytes, BufferUsage usage) override {
        return device_.CreateBuffer(bytes, usage);
    }
    base::Expected<std::uint64_t> RequiredBufferAllocationBytes(std::uint64_t bytes,
                                                                BufferUsage usage) override {
        return device_.RequiredBufferAllocationBytes(bytes, usage);
    }
    base::Expected<void> WriteBuffer(BufferHandle h, std::span<const std::byte> data) override {
        return device_.WriteBuffer(h, data);
    }
    base::Expected<void> ReadBuffer(BufferHandle h, std::span<std::byte> data) override {
        return device_.ReadBuffer(h, data);
    }
    base::Expected<void> Dispatch(KernelHandle kernel, std::span<const BufferHandle> buffers,
                                  std::uint32_t x, std::uint32_t y, std::uint32_t z,
                                  DispatchTiming* timing) override {
        const auto before = Peak();
        const auto started = std::chrono::steady_clock::now();
        DispatchTiming measured;
        if (!timing) timing = &measured;
        const bool first = !dispatched_[kernel.value];
        dispatched_[kernel.value] = true;
        auto value = device_.Dispatch(kernel, buffers, x, y, z, timing);
        if (first || !value) {
            const auto ms = std::chrono::duration<double,std::milli>(
                std::chrono::steady_clock::now() - started).count();
            std::printf("dispatch stage=%s succeeded=%d before_rss_kib=%ld after_rss_kib=%ld "
                        "created=%d pipeline_ms=%.3f call_ms=%.3f\n",
                        names_[kernel.value], value.has_value(), before, Peak(),
                        timing->pipeline_created, timing->pipeline_setup_ms, ms);
            std::fflush(stdout);
        }
        return value;
    }
    bool SupportsIndependentPair() const noexcept override { return device_.SupportsIndependentPair(); }
    base::Expected<void> DispatchIndependentPair(const std::array<ComputeDispatch,2>& pair,
                                                  IndependentPairTiming* timing) override {
        const auto before = Peak();
        auto value = device_.DispatchIndependentPair(pair, timing);
        std::printf("pair first=%s second=%s succeeded=%d before_rss_kib=%ld after_rss_kib=%ld\n",
                    names_[pair[0].kernel.value], names_[pair[1].kernel.value],
                    value.has_value(), before, Peak());
        return value;
    }
    base::Expected<void> SetBufferAllocationLimit(std::uint64_t bytes) override {
        return device_.SetBufferAllocationLimit(bytes);
    }
    std::uint64_t BufferAllocationBytes() const noexcept override { return device_.BufferAllocationBytes(); }
    std::optional<std::uint64_t> BufferMutationEpoch(BufferHandle h) const noexcept override {
        return device_.BufferMutationEpoch(h);
    }
  private:
    ComputeDevice& device_;
    std::array<const char*, RetainedCompute::kStageCount> names_{};
    std::array<bool, RetainedCompute::kStageCount> dispatched_{};
    std::size_t loaded_ = 0;
};
}  // namespace

int main() {
    const auto inventory = Require(EnumerateVulkanDevices());
    const auto index = Require(ResolveVulkanDeviceIndex(inventory));
    const auto physical = Require(CreateVulkanDevice(index));
    if (physical->Info().vendor_id != 0x1002 || physical->Info().name.find("780M") == std::string::npos ||
        physical->Info().driver_name.find("Dozen") == std::string::npos) return 3;
    DispatchMemory device(*physical);
    if (!device.SetBufferAllocationLimit(1024ULL * 1024 * 1024)) return 4;
    auto compute = Require(RetainedCompute::Create(device,128));
    std::printf("buffers explicit_bytes=%llu peak_rss_kib=%ld\n",
                static_cast<unsigned long long>(device.BufferAllocationBytes()), Peak());
    CameraConfig camera_config;
    camera_config.width = 256;
    camera_config.height = 192;
    PinholeCamera camera(camera_config);
    const auto film = camera.ProjectFilmForObserver(115.5, 120.5, .5, .5);
    if (!film) return 5;
    KerrSchildFamily metric(KerrSchildParams::Kerr(1., 0.));
    TracerConfig config;
    config.max_steps = 2;  // Charge only the first physical intervals of an ordinary ray.
    config.integrator.initial_step = .1f;
    config.integrator.min_step = 1e-5f;
    config.integrator.max_step = 2.0f;
    config.integrator.abs_tolerance = config.integrator.rel_tolerance = 5e-6f;
    RetainedTraceExecutor executor(*compute, {}, 1000.0, 64);
    GeodesicTracer tracer(&metric, config);
    tracer.SetStepExecutor(&executor);
    const auto result = tracer.Trace(film->ray);
    const auto statistics = executor.Statistics();
    std::printf("trace steps=%d accepted=%llu rejected=%llu peak_rss_kib=%ld\n",
                result.steps_taken, static_cast<unsigned long long>(statistics.accepted_intervals),
                static_cast<unsigned long long>(statistics.rejected_intervals), Peak());
    return !executor.Error() && statistics.accepted_intervals > 0 ? 0 : 6;
}

#!/usr/bin/env bash
set -euo pipefail
scratch=out/kerr-finite-time
build=bin/linux-ci
git rev-parse HEAD
git diff 0e7dfa4b..HEAD --check
sha256sum "$HOME/.local/opt/mesa-dzn/dzn_icd.x86_64.json" \
    "$HOME/.local/opt/mesa-dzn/libvulkan_dzn.so" \
    /usr/lib/wsl/lib/libd3d12.so /usr/lib/wsl/lib/libd3d12core.so \
    /usr/lib/wsl/lib/libdxcore.so /usr/lib/x86_64-linux-gnu/libvulkan.so.1.3.275 \
    /usr/bin/g++-14 /opt/slang/bin/slangc "$build/src/sirius/app/sirius" \
    "$build/src/sirius/app/focused_point_detectors" "$scratch/block-production" \
    "$scratch"/{baseline,candidate,physical}-{terminal-cell,group} \
    "$scratch/production-overlay/sirius/core/kerr_detector/finite_screen.h" \
    "$scratch/production-overlay/sirius/render/session/kerr_point_detector.cpp" \
    "$scratch/production-focused/pixel_shading.cpp" "$scratch/cells.inc"
rg 'CMAKE_BUILD_TYPE:|SIRIUS_ALIGNMENT_MODE:|SIRIUS_SLANGC:' "$build/CMakeCache.txt"
for dep in googletest json yaml-cpp; do
    test ! -e "$build/_deps/$dep-src/.git" ||
        git -C "$build/_deps/$dep-src" rev-parse HEAD
done

from pathlib import Path
import sys

root=Path.cwd()
scratch=Path(__file__).resolve().parent
destination=scratch/'overlay/sirius'
for section,filename in [('core/kerr_detector','finite_screen.h'),('render/session','kerr_point_detector.cpp')]:
    folder=destination/section
    folder.mkdir(parents=True,exist_ok=True)
    (folder/filename).write_bytes((root/'src/sirius'/section/filename).read_bytes())

def change(section,filename,edits):
    path=destination/section/filename
    source=path.read_text()
    for before,after in edits:
        assert source.count(before)==1,(filename,source.count(before),before)
        source=source.replace(before,after)
    path.write_text(source)

if '--baseline' not in sys.argv:
    change('core/kerr_detector','finite_screen.h', [
        ('''    const NearCriticalPhases* shared_phases,
    std::span<const AngularCatalogue::Entry* const> excluded_turns = {}) {''',
         '''    const NearCriticalPhases* shared_phases,
    std::span<const AngularCatalogue::Entry* const> excluded_turns = {},
    std::optional<Range> finite_radial_time = {}) {'''),
        ('''    const Range edge_time = Range(-2.0) * edge->leading * largest_log + edge->time_residual;
    const Range twice_leading''',
         '''    const Range edge_time = Range(-2.0) * edge->leading * largest_log + edge->time_residual;
    const double earliest = finite_radial_time ? std::max(edge_time.lo, finite_radial_time->lo)
                                               : edge_time.lo;
    const double latest = finite_radial_time ? finite_radial_time->hi : kInfinity;
    // Apply the physical travel-time envelope during catalogue screening.
    // Root counting still uses the full latitude branch and its derivative.
    const auto can_arrive = [&](Range time) {
        return !(time.hi < earliest || time.lo > latest);
    };
    const auto arrival = [&](Range time) {
        return finite_radial_time && time.Finite()
                   ? Range(std::max(time.lo, earliest), std::min(time.hi, latest))
                   : time;
    };
    const Range twice_leading'''),
        ('''        if (full.hi < edge_time.lo) continue;''','''        if (!can_arrive(full)) continue;'''),
        ('''            if (tau.hi < edge_time.lo) return true;''','''            if (!can_arrive(tau)) return true;'''),
        ('''                if (tau.hi < edge_time.lo) continue;''','''                if (!can_arrive(tau)) continue;'''),
    ])
    change('render/session','kerr_point_detector.cpp', [
        ('''    std::optional<unsigned> finite_cutoff;''',
         '''    std::optional<unsigned> finite_cutoff;
    std::optional<Range> finite_radial_time;'''),
        ('''        if (maximum_winding >= 0.0 && maximum_winding < first_tail_winding)
            finite_cutoff = static_cast<unsigned>(maximum_winding) + 1;''',
         '''        if (maximum_winding >= 0.0 && maximum_winding < first_tail_winding) {
            finite_cutoff = static_cast<unsigned>(maximum_winding) + 1;
            const Range time = Range(-2.0) * phase->leading_factor * LogBounds(finite_scale) +
                               phase->time_remainder.value;
            if (time.Finite()) finite_radial_time = time;
        }'''),
        ('''                                             excluded_turns);''',
         '''                                             excluded_turns, finite_radial_time);'''),
    ])

if '--baseline' not in sys.argv:
    path=destination/'core/kerr_detector/finite_screen.h'
    source=path.read_text()
    before='phi + coarse->drag_at_turn * tau + coarse->spin_residual'
    assert source.count(before)==2
    path.write_text(source.replace(before,
              'phi + coarse->drag_at_turn * arrival(tau) + coarse->spin_residual'))

# Keep stage attribution in the study binaries.
change('render/session','kerr_point_detector.cpp', [
    ('#include <mutex>', '#include <mutex>\n#include <iostream>'),
    ('''    const auto bands =
        CollectReachableSources(*angular, amplitude, remaining, cancelled, exclude_turn);''',
     '''    const auto start_ledger = remaining;
    const auto bands =
        CollectReachableSources(*angular, amplitude, remaining, cancelled, exclude_turn);
    const auto before_screen = remaining;'''),
    ('''    if (!screen) return {};
    for (const auto& candidate''',
     '''    std::clog << "certificate phases finite=" << bool(finite_cutoff)
              << " collect=" << start_ledger-before_screen
              << " screen=" << before_screen-remaining
              << " candidates=" << (screen ? screen->candidates.size() : 0)
              << " certified_screen=" << bool(screen) << std::endl;
    if (!screen) return {};
    for (const auto& candidate'''),
])

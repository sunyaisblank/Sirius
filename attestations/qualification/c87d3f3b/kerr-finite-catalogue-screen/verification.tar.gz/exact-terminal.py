import os
from pathlib import Path
import subprocess

root=Path.cwd()
scratch=root/'out/kerr-finite-time'
libs=root/'bin/linux-ci/src/sirius'
source=(scratch/'terminal-cell.cpp').read_text()
source=source.replace('#include "sirius/render/session/kerr_point_detector.cpp"',
                      '#include "sirius/render/session/kerr_point_detector.h"')
source=source.replace('    using namespace core::relativity::finite_tail_detail;\n','')
begin=source.index('    const FilmVector original')
end=source.index('    const core::PointStarfieldConfig stars;',begin)
source=source[:begin]+source[end:]
generated=scratch/'exact-terminal.cpp'
generated.write_text(source)
binary=libs/'app/focused_exact_terminal'
arguments=['/usr/bin/g++-14','-std=c++2c','-O3','-DNDEBUG','-Wall','-Wextra','-Werror',
           '-DSIRIUS_HAS_RETAINED_COMPUTE=1','-fno-fast-math','-ffp-contract=off',
           '-frounding-math','-I'+str(root/'src'),str(generated)]
archives=('render/libsirius_render.a','backend/libsirius_backend_cpu.a','backend/libsirius_backend.a',
          'core/libsirius_core.a','libsirius_base.a')
arguments += [str(libs/item) for item in archives]
arguments += ['-lvulkan','-ldl','-lrt','-pthread','-o',str(binary)]
env={**os.environ,'TMPDIR':str(scratch)}
subprocess.run(arguments,env=env,check=True)
env.pop('SIRIUS_PACKAGED_SOFTWARE_VULKAN',None)
env.update(VK_DRIVER_FILES=str(Path.home()/'.local/opt/mesa-dzn/dzn_icd.x86_64.json'),
           SIRIUS_VULKAN_DEVICE='0',SIRIUS_MEMORY_BUDGET_MB='2048',
           MESA_SHADER_CACHE_DISABLE='true',XDG_CACHE_HOME=str(scratch/'exact-cache'))
test=subprocess.run(['/usr/bin/time','-v','timeout','30',str(binary)],env=env,
                    check=True,stdout=subprocess.PIPE,text=True)
print(test.stdout,end='',flush=True)
assert 'certificate=1 candidate_visits=1212' in test.stdout
assert 'rgb=1.0108336493510555e-09,1.0108336493510555e-09,1.0108336493510555e-09' in test.stdout

import json
import os
from pathlib import Path
import shlex
import subprocess

root=Path.cwd()
scratch=root/'out/kerr-finite-time'
build=root/'bin/linux-ci'
source=root/'src/sirius/render/session/pixel_shading.cpp'
target=scratch/'production-focused'
target.mkdir(exist_ok=True)
pixels=source.read_text().replace('#include <algorithm>','#include <algorithm>\n#include <iostream>')
marker='    const auto group =\n        EvaluatePointDetectorGroup(catalogue, brightness, footprints, probe, cancelled, {},'
assert pixels.count(marker)==1
pixels=pixels.replace(marker,'''    // Use the actual launch and film origin of the full block.
    if (x == 928 && y == 608 && width == 32 && height == 32) {
        const auto at = std::ranges::find(indices, std::size_t{704});
        if (at == indices.end())
            return std::unexpected(PointDetectorError{PointDetectorFailure::InvalidInput, {}});
        const auto selected = footprints[static_cast<std::size_t>(at - indices.begin())];
        footprints.assign(1, selected);
        indices.assign(1, 704);
    }
'''+marker)
marker='''            return BoundKerrDetectorCells(*kerr_catalogue, brightness, camera.GetConfig(),
                                          *prepared, origin, footprint, cells, cancelled,
                                          remaining);'''
assert pixels.count(marker)==1
pixels=pixels.replace(marker,'''            const auto result = BoundKerrDetectorCells(*kerr_catalogue, brightness,
                camera.GetConfig(), *prepared, origin, footprint, cells, cancelled, remaining);
            if (lower == DetectorCoordinate{-0x1.9e84p+1, 0x1.2c8cp+1} &&
                upper == DetectorCoordinate{-0x1.9e8p+1, 0x1.2c9p+1}) {
                std::clog << "live visible terminal bound=" << bool(result);
                if (result) std::clog << " rgb_upper=" << (*result)[0];
                std::clog << " visits_remaining=" << remaining << std::endl;
            }
            return result;''')
translation=target/'pixel_shading.cpp'
translation.write_text(pixels)
objects=target/'pixel_shading.o'
settings,=[entry for entry in json.loads((build/'compile_commands.json').read_text())
           if entry['file']==str(source)]
command=shlex.split(settings['command'])
assert command[-2]=='-c' and command[-4]=='-o'
compile=[*command[:-4],'-o',str(objects),'-c',str(translation)]
data=json.loads((scratch/'link-commands.json').read_text())['link'][0]
libs=data[data.index('src/sirius/app/libsirius_app_lib.a'):]
link=['/usr/bin/g++-14',str(scratch/'block.o'),str(objects),'-o',str(scratch/'block-production'),*libs]
kerr_source=root/'src/sirius/render/session/kerr_point_detector.cpp'
kerr_settings,=[entry for entry in json.loads((build/'compile_commands.json').read_text())
               if entry['file']==str(kerr_source)]
kerr_command=shlex.split(kerr_settings['command'])
kerr_object=target/'kerr_point_detector.o'
kerr_compile=[kerr_command[0],'-I'+str(scratch/'production-overlay'),*kerr_command[1:-4],
              '-o',str(kerr_object),'-c',str(scratch/'production-overlay/sirius/render/session/kerr_point_detector.cpp')]
runner_options=['/usr/bin/g++-14','-std=c++2c','-O3','-DNDEBUG','-fno-access-control',
                '-DSIRIUS_HAS_RETAINED_COMPUTE=1','-I'+str(root/'src'),'-o',str(scratch/'block.o'),
                '-c',str(scratch/'block.cpp')]
link.insert(3,str(kerr_object))
for args in (compile,kerr_compile,runner_options,link):
    subprocess.run(args,cwd=build,env={**os.environ,'TMPDIR':str(scratch)},check=True)
(target/'commands.json').write_text(json.dumps({'compile':compile,'kerr':kerr_compile,
                                               'runner':runner_options,'link':link},indent=2)+'\n')

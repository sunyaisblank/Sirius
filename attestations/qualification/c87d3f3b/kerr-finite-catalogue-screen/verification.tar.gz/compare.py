from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess

root=Path.cwd()
scratch=root/'out/kerr-finite-time'
libs=root/'bin/linux-ci/src/sirius'
env={**os.environ,'TMPDIR':str(scratch)}
options=['/usr/bin/g++-14','-I'+str(scratch/'overlay'),'-I'+str(root/'src'),
    '-std=c++2c','-O3','-DNDEBUG','-Wall','-Wextra','-Werror',
    '-DSIRIUS_CONTRACT_MODE=2','-DSIRIUS_HAS_RETAINED_COMPUTE=1','-DSIRIUS_RELEASE_RESOURCE_LOCKED=1',
    '-fno-fast-math','-ffp-contract=off','-frounding-math']
libraries=[str(libs/item) for item in ('backend/libsirius_backend_cpu.a','backend/libsirius_backend.a',
                                        'core/libsirius_core.a','libsirius_base.a')]
def run(args,**kwargs):
    return subprocess.run(args,cwd=kwargs.pop('cwd',root),env=kwargs.pop('env',env),check=True,**kwargs)
def compile(label, name):
    output=scratch/f'{label}-{name}'
    run([*options,str(scratch/(name+'.cpp')),*libraries,
         '-lvulkan','-ldl','-lrt','-pthread','-o',str(output)])

physical={**env,'VK_DRIVER_FILES':str(Path.home()/'.local/opt/mesa-dzn/dzn_icd.x86_64.json'),
   'SIRIUS_VULKAN_DEVICE':'0','SIRIUS_MEMORY_BUDGET_MB':'2048','MESA_SHADER_CACHE_DISABLE':'true',
   'XDG_CACHE_HOME':str(scratch/'cache')}
physical.pop('SIRIUS_PACKAGED_SOFTWARE_VULKAN',None)
for label in ('baseline','candidate'):
    opts=['--baseline'] if label=='baseline' else []
    run(['python3',str(scratch/'make-overlay.py'),*opts])
    with ThreadPoolExecutor(max_workers=2) as workers:
        list(workers.map(lambda name: compile(label,name),('terminal-cell','group')))
    for name in ('terminal-cell','group'):
        with (scratch/f'{label}-{name}.log').open('w') as output:
            run(['/usr/bin/time','-v','timeout','45','./'+label+'-'+name],cwd=scratch,env=physical,
                stdout=output,stderr=subprocess.STDOUT)

from pathlib import Path
import sys

scratch=Path(__file__).resolve().parent
source=scratch/'overlay'/'sirius'
target=scratch/'production-overlay'/'sirius'
for component in ('core/kerr_detector/finite_screen.h','render/session/kerr_point_detector.cpp'):
    path=target/component
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes((source/component).read_bytes())

def patch(filename, old, new, count=1):
    path=target/filename
    text=path.read_text()
    assert text.count(old)==count, (filename, old)
    path.write_text(text.replace(old,new))

screen='core/kerr_detector/finite_screen.h'
detector='render/session/kerr_point_detector.cpp'
patch(screen, 'std::optional<Range> finite_radial_time = {}) {',
      'Range finite_scale = InvalidRange()) {')
patch(screen, '    const double earliest', '''    std::optional<FiniteRadialPhase> physical_radial;
    std::optional<Range> finite_radial_time;
    if (finite_scale.Finite() && finite_scale.lo > 0.0) {
        physical_radial =
            EvaluateFiniteRadialPhase(mass, spin, centre, finite_scale, chart.inverse_start);
        if (physical_radial) {
            const Range time = Range(-2.0) * physical_radial->leading * LogBounds(finite_scale) +
                               physical_radial->time_residual;
            if (time.Finite()) finite_radial_time = time;
        }
    }
    const double earliest''')
patch(screen, '    const Range twice_leading', '''    const auto sky_window = [&](Range angle, Range time, const FiniteRadialPhase& radial) {
        const Range clipped = arrival(time);
        const Range original = fixed_phi - (angle + radial.drag_at_turn * clipped + radial.spin_residual);
        if (!physical_radial) return original;
        const Range physical = fixed_phi -
            (angle + physical_radial->drag_at_turn * clipped + physical_radial->spin_residual);
        if (!physical.Finite()) return original;
        if (!original.Finite()) return physical;
        return Range(std::max(original.lo, physical.lo), std::min(original.hi, physical.hi));
    };
    const Range twice_leading''')
patch(screen, '''            const Range sky =
                fixed_phi - (phi + coarse->drag_at_turn * arrival(tau) + coarse->spin_residual);
            if (!AzimuthMayMatch(sky, star.azimuth)) return true;''',
      '''            const Range sky = sky_window(phi, tau, *coarse);
            if (sky.lo > sky.hi || !AzimuthMayMatch(sky, star.azimuth)) return true;''')
patch(screen, '''                const Range sky =
                    fixed_phi - (phi + coarse->drag_at_turn * arrival(tau) + coarse->spin_residual);
                const auto visit''',
      '''                const Range sky = sky_window(phi, tau, *coarse);
                if (sky.lo > sky.hi) continue;
                const auto visit''')
patch(detector, '    std::optional<Range> finite_radial_time;\n', '')
patch(detector, '''        if (maximum_winding >= 0.0 && maximum_winding < first_tail_winding) {
            finite_cutoff = static_cast<unsigned>(maximum_winding) + 1;
            const Range time = Range(-2.0) * phase->leading_factor * LogBounds(finite_scale) +
                               phase->time_remainder.value;
            if (time.Finite()) finite_radial_time = time;
        }''', '''        if (maximum_winding >= 0.0 && maximum_winding < first_tail_winding)
            finite_cutoff = static_cast<unsigned>(maximum_winding) + 1;''')
patch(detector, 'excluded_turns, finite_radial_time);',
      'excluded_turns, finite_cutoff ? finite_scale : InvalidRange());')

from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root=Path.cwd()
stage=root/"out/spherical-disk-clearance"
build=root/"bin/linux-ci"
app=build/"src/sirius/app"
qualified=root/"attestations/qualification/c096156f"
prior=json.loads((qualified/"exclusive-cold-gate/MANIFEST.json").read_text())["cold_frame"]
bundle=json.loads((qualified/"accepted-packaged-software-inputs/MANIFEST.json").read_text())
driver=app/"resources/providers/linux-x86_64/libvulkan_lvp.so"
llvm=Path("/usr/lib/x86_64-linux-gnu/libLLVM.so.21.1")
guard=root/"out/native-cpu-row-ownership/cold-frame"
case="OperationalVulkan.RequiredRuntimeDispatch"

def clean_revision():
    assert not subprocess.check_output(["git","status","--porcelain"])
    return subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()

def digest(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data,"sha256").hexdigest()

def isolated():
    for entry in Path("/proc").glob("[0-9]*"):
        try:
            exe=Path(os.readlink(entry/"exe"))
            command=(entry/"cmdline").read_bytes().split(b"\0")
        except (PermissionError,FileNotFoundError,ProcessLookupError):
            continue
        assert not (exe.is_relative_to(build) or
                    (exe.name=="ctest" and os.fsencode(build) in command)), (entry.name, str(exe))

revision=clean_revision()
assert revision == "d13e858375999c303c8c84ae0a3e131b66d1f967"
all_variants=subprocess.check_output(
    ["ctest","--test-dir",str(build),"-C","Release","-R",r"^OperationalVulkan\.RequiredRuntimeDispatch$","--show-only=json-v1"])
test,=json.loads(all_variants)["tests"]
assert test["name"]==case
settings={x["name"]:x["value"] for x in test["properties"]}
assert settings["RUN_SERIAL"] and settings["TIMEOUT"]==300.0 and "Mandatory" in settings["LABELS"]
assert test["command"][1]==f"-DSIRIUS_RENDER_TESTS={app/'sirius_render_tests'}"
assert test["command"][2:]==["-P",str(root/"tests/operational/vulkan_runtime_profile.cmake")]
assert prior["action"]["limits"]=={"reserve_kib":2097152,"rss_kib":4194304,"seconds":300}
assert prior["action"]["disable_software_shader_cache"]
assert shutil.disk_usage("/").free>=100_000_000_000
assert not driver.is_symlink()
for file in bundle["files"]:
    candidate=driver if file["path"].endswith("/libvulkan_lvp.so") else root/file["path"]
    assert candidate.stat().st_size==file["bytes"] and digest(candidate)==file["sha256"]
launcher=stage/"run_owned.py"
if launcher.is_symlink():
    launcher.unlink()
shutil.copyfile(guard/"run_owned.py",launcher)
guard_module=stage/"owned_guard.py"
if not guard_module.is_symlink():
    guard_module.symlink_to(guard/"owned_guard.py")
(staged:=stage/"render-output").mkdir(exist_ok=True)
icd=stage/"isolated_icd.json"
icd.write_text(json.dumps({"file_format_version":"1.0.0",
                          "ICD":{"library_path":str(driver),"api_version":"1.4.305"}},indent=2)+"\n")
(stage/"registration.json").write_bytes(all_variants)
env={k:v for k,v in os.environ.items()
     if not (k.startswith(("SIRIUS_","VK_","LP_","MESA_","GALLIVM_","GTEST_","CTEST_"))
             or k in {"LD_PRELOAD","LD_AUDIT","LD_LIBRARY_PATH"})}
runtime_env={"VK_DRIVER_FILES":str(icd),"SIRIUS_PACKAGED_SOFTWARE_VULKAN":"1",
             "SIRIUS_VULKAN_DEVICE":"0","MESA_SHADER_CACHE_DISABLE":"true","TMPDIR":str(staged)}
subprocess.run([sys.executable,"-B",str(root/"scripts/runtime_identity.py"),
                "--source-root",str(root),"--source-revision",revision,"--source-tree-clean","true",
                "--executable",str(app/"sirius"),"--require-vulkan","true",
                "--output",str(stage/"runtime-identity.json")],
                cwd=root,env={**env,**runtime_env},check=True)
identity=json.loads((stage/"runtime-identity.json").read_text())
packaged=identity["inventory"]["backends"]["vulkan"]["packaged_software"]
assert Path(packaged["driver"]["path"])==driver
assert Path(packaged["llvm"]["path"])==llvm
assert packaged["driver"]["sha256"]==digest(driver)

dependencies=set()
for binary in (app/"sirius_render_tests", driver):
    for line in subprocess.check_output(["ldd",str(binary)],env=env,text=True).splitlines():
        tokens=line.strip().split()
        if len(tokens)>=3 and tokens[1]=="=>" and tokens[2].startswith("/"):
            dependencies.add(Path(tokens[2]).resolve())
        elif tokens and tokens[0].startswith("/"):
            dependencies.add(Path(tokens[0]).resolve())
files=[app/"sirius",app/"sirius_render_tests",driver,llvm,icd,stage/"registration.json",
       stage/"runtime-identity.json",Path(__file__).resolve(),Path(test["command"][0]),*sorted(dependencies)]
files.extend(path for path in (app/"resources").rglob("*") if path.is_file())
action={"scope":"Original isolated cold case through the source-integrated packaged Vulkan route.",
        "revision":revision,"software_provider":True,"runtime_provider":str(driver),
        "runtime_icd":str(icd),"disable_software_shader_cache":True,"kind":"test",
        "limits":prior["action"]["limits"],"expected_exit":0,"argv":test["command"],
        "frozen_inputs":[str(f) for f in dict.fromkeys(files)],
        "build_environment":{"SIRIUS_PACKAGED_SOFTWARE_VULKAN":"1","TMPDIR":str(staged),
                             "XDG_CACHE_HOME":str(stage/"cache")}}
(stage/"actions.json").write_text(json.dumps({"packaged-cold":action},indent=2)+"\n")
isolated()
assert clean_revision()==revision
raise SystemExit(subprocess.run([sys.executable,"-B",str(stage/"run_owned.py"),"packaged-cold"],
                                cwd=root,env=env).returncode)

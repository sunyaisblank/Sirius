#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"
#include "sirius/render/trace_domain.h"

#include <cstdio>
#include <cstdlib>

using namespace sirius::backend;
using namespace sirius::core;

void Check(bool value, const char* message) {
    if (value) return;
    std::fprintf(stderr, "Failed: %s\n", message);
    std::exit(1);
}

template <typename T>
T Require(sirius::base::Expected<T> value) {
    if (value) return std::move(*value);
    std::fprintf(stderr, "%s\n", value.error().Description().c_str());
    std::exit(1);
}

// Invoke the same retained solver and rollback paths. Removing the optional
// annulus from the request reproduces the previous spherical admission.
class PriorCertificate final : public TraceStepExecutor {
public:
    explicit PriorCertificate(RetainedTraceExecutor& executor) : executor_(executor) {}
    void BeginTrace() override { executor_.BeginTrace(); }
    void EndTrace() override { executor_.EndTrace(); }
    void RejectLastInterval() override { executor_.RejectLastInterval(); }
    bool SupportsSphericalEscape() const override { return true; }
    void RecordSphericalEscape(const SphericalEscapeTrial& trial) override {
        executor_.RecordSphericalEscape(trial);
    }
    std::optional<CameraLaunch> Launch(IMetric& metric, double a, const CameraRay& ray) override {
        return executor_.Launch(metric, a, ray);
    }
    bool Step(Lightray& ray, IMetric& metric, const IntegratorConfig& settings,
              Rk45CoupledState& state, Rk45CoupledComparison& comparison) override {
        return executor_.Step(ray, metric, settings, state, comparison);
    }
    std::optional<CoupledSegmentSample> Sample(CoupledTrial trial, double fraction,
                                               const Vec4* normal) override {
        return executor_.Sample(trial, fraction, normal);
    }
    std::optional<SphericalEscapeTrial> TrySphericalEscape(
        IMetric& metric, const Lightray& ray, const IntegratorConfig& config,
        const Rk45CoupledState& state, const SphericalEscapeRequest& request,
        const std::function<bool()>& cancel) override {
        auto radial_only = request;
        radial_only.thin_disk.reset();
        return executor_.TrySphericalEscape(metric, ray, config, state, radial_only, cancel);
    }

private:
    RetainedTraceExecutor& executor_;
};

int main() {
    using namespace sirius::render;
    const auto inventory = Require(EnumerateVulkanDevices());
    const auto device = Require(CreateVulkanDevice(Require(ResolveVulkanDeviceIndex(inventory))));
    const auto& info = device->Info();
    Check(info.kind == DeviceKind::kSoftware && !RetainedUsesPortableArithmetic(info),
          "native arithmetic on sealed software Vulkan");
    auto compute = Require(RetainedCompute::Create(*device, 8));
    RetainedCompute::PreparationStats preparation;
    const auto ready = compute->PrepareSoftwareRendererStages(preparation);
    Check(ready.has_value(), "prepare real shader pipelines");
    std::printf("device=%s driver=%s prepared_ms=%.3f allocation=%llu\n", info.name.c_str(),
                info.driver_info.c_str(), preparation.wall_ms,
                static_cast<unsigned long long>(device->BufferAllocationBytes()));
    std::fflush(stdout);
    RetainedTraceExecutor executor(*compute, {}, 1000.0, 4,
                                   RetainedTraceExecutor::SphericalEscape::Certified);
    PriorCertificate prior(executor);
    CameraConfig camera_config;
    camera_config.width = camera_config.height = 128;
    const PinholeCamera camera(camera_config);
    const auto domain = BuildTraceDomainParameters(
        {MetricId::Kerr, 1., 0., camera_config.r, kDefaultMorrisThorneThroatRadius,
         kDefaultAlcubierreBubbleRadius, kDefaultAlcubierreBubbleSigma});
    TracerConfig config;
    config.escape_radius = domain.escape_radius;
    config.max_steps = kRenderTraceMaximumAttempts;
    config.integrator.initial_step = domain.cpu_initial_step;
    config.integrator.min_step = domain.cpu_min_step;
    config.integrator.max_step = domain.max_step;
    config.integrator.abs_tolerance = config.integrator.rel_tolerance = 5.0e-6f;
    config.enable_ray_bundles = true;
    config.bundle_point_source = true;
    KerrSchildFamily metric(KerrSchildParams::Kerr(1.0, 0.0));
    GeodesicTracer tracer(&metric, config);
    CameraSample sample;
    Check(ForEachCameraSample(1, [&](CameraSample next) { sample = next; }) == 1, "camera sample");
    const auto scaled = [](double a, double b) {
        return std::abs(a - b) / std::max({1.0, std::abs(a), std::abs(b)});
    };
    const auto map_error = [&](const auto& a, const auto& b) {
        const auto first = relativity::MakeCelestialTangentBasis(a.direction);
        const auto second = relativity::MakeCelestialTangentBasis(b.direction);
        Check(first.has_value() && second.has_value(), "source sky basis");
        double error = scaled(a.determinant, b.determinant);
        for (unsigned axis = 0; axis < 3; ++axis) {
            error = std::max(error, scaled(a.direction[axis], b.direction[axis]));
            for (unsigned j = 0; j < 2; ++j) {
                const double da = first->first[axis] * a.jacobian[0][j] + first->second[axis] * a.jacobian[1][j];
                const double db = second->first[axis] * b.jacobian[0][j] + second->second[axis] * b.jacobian[1][j];
                error = std::max(error, scaled(da, db));
            }
        }
        return error;
    };
    struct Pixel { int x, y; TraceResult::Outcome outcome; bool earlier; };
    using Outcome = TraceResult::Outcome;
    constexpr std::array pixels{Pixel{64, 102, Outcome::Escaped, true},
                                Pixel{64, 25, Outcome::Escaped, true},
                                Pixel{64, 80, Outcome::DiskHit, false},
                                Pixel{64, 64, Outcome::Horizon, false},
                                Pixel{4, 4, Outcome::Escaped, false}};
    unsigned original_attempts = 0, actual_attempts = 0;
    for (const auto [x, y, outcome, earlier] : pixels) {
        const auto projected = camera.ProjectFilmForObserver(x + sample.image_u, y + sample.image_v,
                                                             sample.pupil_u, sample.pupil_v);
        Check(projected.has_value(), "film projection");
        tracer.SetStepExecutor(&prior);
        const auto baseline = tracer.Trace(projected->ray);
        tracer.SetStepExecutor(&executor);
        const auto candidate = tracer.Trace(projected->ray);
        original_attempts += baseline.steps_taken;
        actual_attempts += candidate.steps_taken;
        Check(baseline.outcome == outcome && candidate.outcome == outcome &&
                  !baseline.numerical_failure && !candidate.numerical_failure &&
                  !candidate.cancelled && baseline.final_tangent && candidate.final_tangent,
              "same accepted terminal event");
        Check(candidate.num_disk_crossings == baseline.num_disk_crossings &&
                  candidate.disk_radius == baseline.disk_radius && candidate.redshift == baseline.redshift,
              "unchanged opaque transfer");
        Check(earlier ? candidate.spherical_terminal_turn && !baseline.spherical_terminal_turn &&
                            candidate.steps_taken < baseline.steps_taken
                      : candidate.spherical_terminal_turn == baseline.spherical_terminal_turn &&
                            candidate.steps_taken == baseline.steps_taken,
              "only annulus-miss proposals skip more intervals");
        double terminal_error = scaled(baseline.affine_length, candidate.affine_length);
        for (unsigned j = 0; j < 4; ++j) {
            terminal_error = std::max({terminal_error,
                scaled(baseline.final_position(j), candidate.final_position(j)),
                scaled((*baseline.final_tangent)(j), (*candidate.final_tangent)(j))});
        }
        double sky_error = 0, beam_error = 0;
        if (outcome == Outcome::Escaped) {
            Check(baseline.beam.infinity_source_map && candidate.beam.infinity_source_map &&
                      baseline.beam.finite_source_map && candidate.beam.finite_source_map,
                  "both source maps published");
            sky_error = std::max(map_error(*baseline.beam.finite_source_map, *candidate.beam.finite_source_map),
                map_error(baseline.beam.infinity_source_map->map, candidate.beam.infinity_source_map->map));
            Check(baseline.beam.valid && candidate.beam.valid, "physical beam output");
            beam_error = std::max({scaled(baseline.beam.semi_major, candidate.beam.semi_major),
                scaled(baseline.beam.semi_minor, candidate.beam.semi_minor),
                scaled(baseline.beam.area_ratio, candidate.beam.area_ratio)});
        }
        std::printf("pixel=%d,%d outcome=%d prior=%d candidate=%d turn=%d panels=%u terminal_error=%.9g sky_error=%.9g beam_error=%.9g\n",
                    x, y, static_cast<int>(outcome), baseline.steps_taken, candidate.steps_taken,
                    candidate.spherical_terminal_turn, candidate.spherical_terminal_panels,
                    terminal_error, sky_error, beam_error);
        std::fflush(stdout);
        Check(terminal_error <= 1e-7 && sky_error <= 1e-7 && beam_error <= 1e-6, "terminal numeric parity");
    }
    Check(!executor.Error() && actual_attempts < original_attempts, "retained work reduction");
    std::printf("total_prior=%u total_candidate=%u\n", original_attempts, actual_attempts);
}

#include "sirius/core/camera_launch.h"
#include "sirius/core/camera_sampling.h"
#include "sirius/core/spherical_continuation/coupled_handoff.h"

#include <cstdio>
#include <cstdlib>

using namespace sirius::core;
using namespace sirius::core::relativity;
using namespace sirius::core::relativity::finite_tail_detail;

void Require(bool value, const char* message) {
    if (value) return;
    std::fprintf(stderr, "Failed: %s\n", message);
    std::exit(1);
}

int main() {
    CameraConfig config;
    config.width = config.height = 128;
    PinholeCamera camera(config);
    KerrSchildFamily metric(KerrSchildParams::Kerr(1.0, 0.0));
    CameraSample sample;
    Require(ForEachCameraSample(1, [&](CameraSample next) { sample = next; }) == 1, "sampling");
    const SphericalThinDisk disk{6.0, 20.0};
    enum class Expected { Clear, Disk, Capture, Exterior };
    struct Pixel { int x, y; Expected expected; };
    constexpr std::array pixels{Pixel{64, 102, Expected::Clear}, Pixel{64, 25, Expected::Clear},
                                Pixel{64, 80, Expected::Disk}, Pixel{64, 64, Expected::Capture},
                                Pixel{4, 4, Expected::Exterior}};
    for (const auto [x, y, expected] : pixels) {
        const auto ray = camera.ProjectFilmForObserver(x + sample.image_u, y + sample.image_v,
                                                       sample.pupil_u, sample.pupil_v);
        Require(ray.has_value(), "camera ray");
        const auto physical = LaunchCameraRay(metric, 0.0, ray->ray);
        Require(physical.has_value(), "physical launch");
        CoupledLaunch launch{Components(physical->position), Components(physical->tangent), {}, {}};
        for (unsigned column = 0; column < 4; ++column) {
            launch.displacement[column] = Components(physical->variations[column].displacement);
            launch.derivative[column] = Components(physical->variations[column].derivative);
        }
        const auto ordinary = ContinueCoupled(metric, launch, 20.0, 200.0, {},
                                              SphericalTailPath::ExteriorTurn);
        const auto candidate = ContinueCoupled(metric, launch, 2.0, 200.0, {},
                                               SphericalTailPath::ExteriorTurn, disk);
        std::printf("pixel=%d,%d radial_only=%d annulus=%d failure=%d turn=%.12g panels=%u\n",
                    x, y, ordinary.has_value(), candidate.has_value(),
                    candidate ? -1 : static_cast<int>(candidate.error()),
                    candidate ? candidate->periapsis->lower : 0, candidate ? candidate->panels : 0);
        std::fflush(stdout);
        if (expected == Expected::Clear || expected == Expected::Exterior) {
            Require(candidate.has_value() && candidate->periapsis.has_value(), "annulus cleared");
            Require(ordinary.has_value() == (expected == Expected::Exterior), "radial-only contrast");
        } else {
            Require(!candidate && candidate.error() == FiniteTailFailure::Domain,
                    "blocked disk or capture");
        }
        if (expected == Expected::Clear) {
            const auto unrestricted = ContinueCoupled(metric, launch, 2.0, 200.0, {},
                                                       SphericalTailPath::ExteriorTurn);
            Require(unrestricted.has_value() && candidate->periapsis->upper < disk.outer_radius &&
                    unrestricted->affine_length == candidate->affine_length &&
                    candidate->panels == unrestricted->panels + 32, "only clearance work changes");
            SphericalTailControl budget;
            budget.maximum_panels = 31;
            const auto exhausted = ContinueCoupled(metric, launch, 2.0, 200.0, budget,
                                                  SphericalTailPath::ExteriorTurn, disk);
            Require(!exhausted && exhausted.error() == FiniteTailFailure::WorkLimit, "work limit");
            unsigned polls = 0;
            const std::function<bool()> cancel = [&] { return ++polls > 10; };
            budget.maximum_panels = 4096;
            budget.should_cancel = &cancel;
            const auto cancelled = ContinueCoupled(metric, launch, 2.0, 200.0, budget,
                                                  SphericalTailPath::ExteriorTurn, disk);
            Require(!cancelled && cancelled.error() == FiniteTailFailure::Cancelled, "cancellation");
        }
    }
}

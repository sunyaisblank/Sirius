#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "sirius/render/session/kerr_point_detector.cpp"

#include <iomanip>
#include <iostream>
#include <map>

using namespace sirius;
using namespace sirius::render;

namespace {
using namespace core::relativity::finite_tail_detail;

class LatitudeIndex {
  public:
    using Entry = AngularCatalogue::Entry;
    explicit LatitudeIndex(const AngularCatalogue& catalogue) {
        for (const bool north : {false,true})
            for (const auto& row : catalogue.Rows(north))
                for (const auto& entry : row.entries) {
                    entries_.push_back(&entry);
                    latitude_width_ = std::max(latitude_width_,
                        (Range(entry.latitude.hi)-Range(entry.latitude.lo)).hi);
                }
        std::ranges::sort(entries_, {}, [](const Entry* entry) {return entry->latitude.lo;});
    }
    std::size_t Size() const {return entries_.size();}
    std::vector<const Entry*> Find(Range latitude, std::size_t& visits) const {
        const double support = (Range(latitude.lo) - Range(latitude_width_)).lo;
        auto lower=std::ranges::lower_bound(entries_,support,{},
                                            [](const Entry* entry){return entry->latitude.lo;});
        std::vector<const Entry*> candidates;
        for (;lower!=entries_.end() && (*lower)->latitude.lo<=latitude.hi;++lower) {
            ++visits;
            if ((*lower)->latitude.hi>=latitude.lo) candidates.push_back(*lower);
        }
        return candidates;
    }

  private:
    std::vector<const Entry*> entries_;
    double latitude_width_=0.0;
};
}  // namespace

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const PointDetectorFootprint footprint{
        {0, 22}, {{{0x1.d323e59e01b7bp-1, -0x1.9662de6ca9f26p-9}, {0, 0x1.d520d6948dde7p-1}}}};

    using namespace core::relativity::finite_tail_detail;
    constexpr PointDetectorCell cells[]{
#include "cells.inc"
    };
    const core::PointStarfieldConfig stars;
    const core::StarfieldSpatialIndex catalogue(core::StarfieldGenerator(
        core::ExpandPointStarfieldConfig(stars)).GenerateCatalogue());
    const auto indexed = PrepareKerrDetectorCatalogue(catalogue);
    const auto* angular = indexed->Get({});
    if (!angular) return 40;
    const LatitudeIndex latitude_index(*angular);
    if (latitude_index.Size()!=100000) return 41;
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    std::map<const AngularCatalogue::Entry*,std::vector<unsigned>> buckets;
    std::size_t query_visits=0, row_scan_visits=0;
    unsigned escaping=0, zero=0, multi=0, critical=0;
    for (unsigned i=0; i<std::size(cells); ++i) {
        const auto& cell = cells[i];
        const FilmVector original{Range(cell.lower[0],cell.upper[0]),Range(cell.lower[1],cell.upper[1])};
        const auto box=ClipGaussian(original);
        if (!box[0].Finite()||!box[1].Finite()) continue;
        const auto chart=evaluate(box);
        if (!chart) return 42;
        const auto [radius,potential]=CoverEscapingChart(box,*chart,evaluate);
        if (!radius.Finite()||!potential.Finite()) return 43;
        if (!(potential.lo<0)) continue;
        const Range scale(potential.hi<0?sqrt(Range(-potential.hi)).lo:0.0,
                          sqrt(Range(-potential.lo)).hi);
        const auto shape=MakeFinitePolarShape(1,.9,radius,scale);
        if (!shape) return 44;
        const Range amplitude=sqrt(shape->amplitude2);
        if (!amplitude.Finite()) return 45;

        const auto found=latitude_index.Find(amplitude,query_visits);
        std::vector<const AngularCatalogue::Entry*> authority;
        for (const bool north : {false,true})
            for (const auto& row : angular->Rows(north)) {
                if (row.entries.empty() || row.latitude.lo>amplitude.hi ||
                    row.latitude.hi<amplitude.lo) continue;
                for (const auto& entry : row.entries) {
                    ++row_scan_visits;
                    if (entry.latitude.lo<=amplitude.hi && entry.latitude.hi>=amplitude.lo)
                        authority.push_back(&entry);
                }
            }
        if (!std::ranges::is_permutation(authority,found)) return 46;
        if (!(potential.hi<0)) {
            if (!found.empty()) {
                ++critical;
                std::cout<<"critical contact cell="<<i<<" contact_count="<<found.size()<<'\n';
            }
            continue;
        }
        ++escaping;
        if (found.empty()) ++zero;
        else if (found.size()!=1) ++multi;
        else buckets[found.front()].push_back(i);
    }
    const Range known_mu(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
    const Range known_phi(-0x1.1dcd0ee4d9734p+1, -0x1.1dcd0ee4d972dp+1);
    std::size_t known_cells=0;
    for (const auto& [contact,group] : buckets) {
        const bool known=contact->latitude.lo<=known_mu.hi&&contact->latitude.hi>=known_mu.lo&&
                         contact->azimuth.lo<=known_phi.hi&&contact->azimuth.hi>=known_phi.lo;
        if (known) known_cells+=group.size();
        std::cout<<"contact bucket size="<<group.size()<<" known_turn_star="<<known<<" cells=";
        for (const auto i : group) std::cout<<' '<<i;
        std::cout<<'\n';
    }
    std::cout<<"cells="<<std::size(cells)<<" escaping="<<escaping
             <<" escaping_without_contact="<<zero<<" multiple_contacts="<<multi
             <<" contact_groups="<<buckets.size()<<" known_contact_cells="<<known_cells
             <<" critical_contact_cells="<<critical<<" indexed_visits="<<query_visits
             <<" exhaustive_rows_visits="<<row_scan_visits<<'\n';
    return known_cells==28&&critical>=1&&query_visits<row_scan_visits ? 0 : 47;
}

from pathlib import Path

root = Path.cwd()
scratch = root / 'out/kerr-compatible-cells'
source_root = root / 'src/sirius/render/session'
overlay_root = scratch / 'overlay/sirius/render/session'
overlay_root.mkdir(parents=True, exist_ok=True)

def read(name):
    return (source_root / name).read_text()

def write(name, text):
    (overlay_root / name).write_text(text)

detector_h = read('point_source_detector.h')
marker = 'struct PointDetectorBatchResult {'
assert marker in detector_h
detector_h = detector_h.replace(marker, '''struct PointDetectorCell {
    DetectorCoordinate lower, upper;
};

struct PointDetectorFiniteBounds {
    std::function<bool(const PointDetectorFootprint&, const PointDetectorCell&)> contains;
    std::function<std::optional<std::array<double, 3>>(
        const PointDetectorFootprint&, std::span<const PointDetectorCell>, std::size_t&)> bound;
};

''' + marker)
detector_h = detector_h.replace('const PointDetectorCellBound& cell_bound = {});',
                                'const PointDetectorCellBound& cell_bound = {},\n'
                                '                           const PointDetectorFiniteBounds& finite_bounds = {});')
write('point_source_detector.h', detector_h)
kerr_h = read('kerr_point_detector.h')
kerr_h = kerr_h.replace('''struct PointDetectorCell {
    DetectorCoordinate lower, upper;
};

''', '''[[nodiscard]] bool StrictlyEscapingKerrDetectorCell(
    const core::CameraConfig& camera, const backend::DetectorLaunchFrame& launch,
    const DetectorCoordinate& film_origin, const PointDetectorFootprint& footprint,
    const PointDetectorCell& cell);

''')
kerr_h = kerr_h.replace('const std::function<bool()>& cancelled, std::size_t& remaining);',
                        'const std::function<bool()>& cancelled, std::size_t& remaining,\n'
                        '    bool require_finite_winding = false);')
write('kerr_point_detector.h', kerr_h)

kerr = read('kerr_point_detector.cpp')
start = kerr.index('        // Retain only the axis-aligned hull')
end = kerr.index('        const auto chart = evaluate(box);', start)
clip = kerr[start:end].removesuffix('        if (!box[0].Finite() || !box[1].Finite()) continue;\n')
clip = ''.join(line[4:] if line.startswith('    ') else line for line in clip.splitlines(keepends=True))
method = '\nFilmVector ClipGaussian(FilmVector box) {\n' + clip + '    return box;\n}\n'
kerr = kerr[:start] + '''        box = ClipGaussian(box);
        if (!box[0].Finite() || !box[1].Finite()) continue;
''' + kerr[end:]
marker = '}  // namespace\n\nclass KerrDetectorCatalogue'
assert marker in kerr
kerr = kerr.replace(marker, method + '\n' + marker)
marker = 'std::optional<std::array<double, 3>> BoundKerrDetectorCells('
kerr = kerr.replace(marker, '''bool StrictlyEscapingKerrDetectorCell(
    const core::CameraConfig& camera, const backend::DetectorLaunchFrame& launch,
    const DetectorCoordinate& film_origin, const PointDetectorFootprint& footprint,
    const PointDetectorCell& cell) {
    const auto& [mass, spin, charge, lambda] = launch.metric;
    if (!(mass > spin && spin > 0.0) || charge != 0.0 || lambda != 0.0 || !RoundingEnvironment())
        return false;
    const core::KerrSchildParams metric{mass, spin, charge, lambda};
    FilmVector box{Range(cell.lower[0], cell.upper[0]), Range(cell.lower[1], cell.upper[1])};
    if (!box[0].Finite() || !box[1].Finite()) return false;
    box = ClipGaussian(box);
    if (!box[0].Finite() || !box[1].Finite()) return false;
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(camera, metric, launch, film_origin, footprint, region);
    };
    const auto chart = evaluate(box);
    if (!chart) return false;
    const auto potential = CoverEscapingChart(box, *chart, evaluate)[1];
    return potential.Finite() && potential.hi < 0.0;
}

''' + marker)
kerr = kerr.replace('const std::function<bool()>& cancelled, std::size_t& remaining) {\n    using core::KerrSchildParams;',
                    'const std::function<bool()>& cancelled, std::size_t& remaining,\n'
                    '    bool require_finite_winding) {\n    using core::KerrSchildParams;')
kerr = kerr.replace('    const auto* angular = catalogue.Get(cancelled);',
                    '    if (require_finite_winding && !finite_cutoff) return {};\n'
                    '    const auto* angular = catalogue.Get(cancelled);')
write('kerr_point_detector.cpp', kerr)

pixels = read('pixel_shading.cpp')
pixels = pixels.replace('    PointDetectorCellBound cell_bound;', '    PointDetectorCellBound cell_bound;\n'
                                                                  '    PointDetectorFiniteBounds finite_bounds;')
marker = '''    }
    const auto group =
        EvaluatePointDetectorGroup(catalogue, brightness, footprints, probe, cancelled, {},
                                   probe_batch, dark_cell, cell_bound);'''
assert marker in pixels
pixels = pixels.replace(marker, '''        finite_bounds.contains = [&, origin](const PointDetectorFootprint& footprint,
                                             const PointDetectorCell& cell) {
            return StrictlyEscapingKerrDetectorCell(camera.GetConfig(), *prepared, origin,
                                                   footprint, cell);
        };
        finite_bounds.bound = [&, origin](const PointDetectorFootprint& footprint,
                                          std::span<const PointDetectorCell> cells,
                                          std::size_t& remaining) {
            return BoundKerrDetectorCells(*kerr_catalogue, brightness, camera.GetConfig(),
                                          *prepared, origin, footprint, cells, cancelled,
                                          remaining, true);
        };
    }
    const auto group =
        EvaluatePointDetectorGroup(catalogue, brightness, footprints, probe, cancelled, {},
                                   probe_batch, dark_cell, cell_bound, finite_bounds);''')
write('pixel_shading.cpp', pixels)

detector = read('point_source_detector.cpp')
detector = detector.replace('#include <limits>', '#include <limits>\n#include <iostream>')
marker = 'struct Estimate {'
detector = detector.replace(marker, '''struct FiniteBounds {
    std::function<bool(const PointDetectorCell&)> contains;
    std::function<std::optional<Rgb>(std::span<const PointDetectorCell>, std::size_t&)> bound;
};

''' + marker)
detector = detector.replace('const ScalarCellBound* cell_bound = nullptr)',
                            'const ScalarCellBound* cell_bound = nullptr,\n'
                            '             const FiniteBounds* finite_bounds = nullptr)')
detector = detector.replace('          cell_bound_(cell_bound) {}',
                            '          cell_bound_(cell_bound), finite_bounds_(finite_bounds) {}')
detector = detector.replace('''            auto result = Refine(support, Measure(support));
            if (result.bounded_omission) {''', '''            auto result = Refine(support, Measure(support));
            FlushFiniteCells();
            if (queued_cells_ != 0) {
                for (unsigned channel = 0; channel < 3; ++channel)
                    result.error[channel] =
                        (finite_tail::Range(result.error[channel]) + queued_error_[channel]).hi;
            }
            if (result.bounded_omission) {''')
detector = detector.replace('''            statistics_.roots = roots_.size();
            return PointDetectorResult''', '''            statistics_.roots = roots_.size();
            ReportFiniteBounds();
            return PointDetectorResult''')
detector = detector.replace('''            statistics_.roots = roots_.size();
            return std::unexpected(PointDetectorError{reason, statistics_});''', '''            statistics_.roots = roots_.size();
            ReportFiniteBounds();
            return std::unexpected(PointDetectorError{reason, statistics_});''')
detector = detector.replace('''    Estimate Measure(const Cell& cell) {''',
                            '''    Estimate Measure(const Cell& cell, bool near_visibility_boundary = false) {''')
marker = '''        const auto centre = cell.Centre();
        const double half = cell.Width() * .5;'''
assert detector.count(marker) == 1
detector = detector.replace(marker, '''        if (near_visibility_boundary && finite_bounds_ &&
            cell.depth == policy_.maximum_depth) {
            const PointDetectorCell bounds{cell.lower, cell.upper};
            const bool eligible = finite_bounds_->contains(bounds);
            CheckCancellation();
            if (eligible) {
                pending_cells_.push_back(bounds);
                ++queued_cells_;
                if (pending_cells_.size() == 32) FlushFiniteCells();
                result.bounded_omission = true;
                return result;
            }
        }
''' + marker)
marker = '    Estimate Refine(const Cell& cell, const Estimate& coarse) {'
assert marker in detector
detector = detector.replace(marker, '''    void ChargeFiniteCells(std::span<const PointDetectorCell> cells) {
        CheckCancellation();
        ++group_attempts_;
        const auto available = policy_.maximum_candidate_visits - statistics_.candidate_visits;
        auto remaining = available;
        const auto bound = finite_bounds_->bound(cells, remaining);
        if (remaining > available) Fail(PointDetectorFailure::Arithmetic);
        statistics_.candidate_visits += available - remaining;
        group_visits_ += available - remaining;
        CheckCancellation();
        if (bound && std::ranges::all_of(*bound, [&](double error) {
                return std::isfinite(error) && error >= 0.0 &&
                       error <= policy_.absolute_rgb_error;
            })) {
            group_admitted_cells_ += cells.size();
            ++group_accepted_;
            for (unsigned i = 0; i < 3; ++i)
                queued_error_[i] = queued_error_[i] + finite_tail::Range((*bound)[i]);
            return;
        }
        if (cells.size() == 1) Fail(PointDetectorFailure::Unresolved);
        const auto middle = cells.size() / 2;
        ChargeFiniteCells(cells.first(middle));
        ChargeFiniteCells(cells.subspan(middle));
    }

    void FlushFiniteCells() {
        if (pending_cells_.empty()) return;
        ChargeFiniteCells(pending_cells_);
        pending_cells_.clear();
    }

    void ReportFiniteBounds() const {
        if (queued_cells_ != 0)
            std::clog << "finite terminal groups queued_cells=" << queued_cells_
                      << " flush_attempts=" << group_attempts_
                      << " accepted_groups=" << group_accepted_
                      << " admitted_cells=" << group_admitted_cells_
                      << " group_visits=" << group_visits_
                      << " total_visits=" << statistics_.candidate_visits
                      << " probes=" << statistics_.probes << " cells=" << statistics_.cells
                      << '\\n';
    }

''' + marker)
detector = detector.replace('''        if (coarse.certified_dark || !cell.IntersectsSupport()) return coarse;''',
                            '''        if (coarse.certified_dark || coarse.bounded_omission || !cell.IntersectsSupport())
            return coarse;''')
detector = detector.replace('''        // At the last split a whole-sky cell''',
                            '''        if (terminal) FlushFiniteCells();
        // At the last split a whole-sky cell''')
marker = '''        std::array<Estimate, 4> estimates;
        for (int i = 0; i < 4; ++i) estimates[i] = Measure(children[i]);'''
assert marker in detector
detector = detector.replace(marker, '''        std::array<Estimate, 4> estimates;
        if (finite_bounds_ && coarse.has_hidden_probe && cell.depth + 1 == policy_.maximum_depth) {
            for (int i = 0; i < 4; ++i)
                estimates[i] = Refine(children[i], Measure(children[i], true));
            return Sum(estimates);
        }
        for (int i = 0; i < 4; ++i) estimates[i] = Measure(children[i]);''')
marker = '''    const ScalarCellBound* cell_bound_;'''
detector = detector.replace(marker, marker + '''
    const FiniteBounds* finite_bounds_;
    std::vector<PointDetectorCell> pending_cells_;
    std::array<finite_tail::Range, 3> queued_error_{};
    std::size_t queued_cells_ = 0, group_attempts_ = 0, group_accepted_ = 0;
    std::size_t group_admitted_cells_ = 0, group_visits_ = 0;
''')
detector = detector.replace('''    const PointDetectorCellBound& cell_bound) {''',
                            '''    const PointDetectorCellBound& cell_bound,
    const PointDetectorFiniteBounds& finite_bounds) {''')
marker = '''                    const auto leaf = Detector(catalogue, brightness_scale, original, cancelled,
                                               policy, original_batch, original_dark, 0,
                                               original_bound ? &original_bound : nullptr)'''
assert marker in detector
detector = detector.replace(marker, '''                    FiniteBounds local_finite;
                    if (finite_bounds.contains && finite_bounds.bound) {
                        local_finite.contains = [&](const PointDetectorCell& cell) {
                            return finite_bounds.contains(footprint, cell);
                        };
                        local_finite.bound = [&](std::span<const PointDetectorCell> cells,
                                                 std::size_t& remaining) {
                            return finite_bounds.bound(footprint, cells, remaining);
                        };
                    }
                    const auto leaf = Detector(catalogue, brightness_scale, original, cancelled,
                                               policy, original_batch, original_dark, 0,
                                               original_bound ? &original_bound : nullptr,
                                               local_finite.contains ? &local_finite : nullptr)''')
write('point_source_detector.cpp', detector)

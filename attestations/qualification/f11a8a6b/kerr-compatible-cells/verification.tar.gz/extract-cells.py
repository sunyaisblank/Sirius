from pathlib import Path
import gzip
import re

scratch = Path(__file__).resolve().parent
history = scratch.parents[1] / 'attestations/qualification/ed95bfc0/kerr-footprint/prefix.log.gz'
raw = gzip.decompress(history.read_bytes()).decode()
cells = re.findall(r'^pending_cell lower=(\S+),(\S+) upper=(\S+),(\S+)', raw, flags=re.M)
assert len(cells) == 794
(scratch/'cells.inc').write_text(''.join(f'    {{{{{a}, {b}}}, {{{c}, {d}}}}},\n' for a,b,c,d in cells))

#!/usr/bin/env bash
set -euo pipefail
scratch=out/sealed-cold-readback
g++-14 -std=c++2c -O2 -DSIRIUS_CONTRACT_MODE=2 -fno-fast-math -ffp-contract=off -frounding-math \
    -Wall -Wextra -Werror -Isrc "$scratch/annulus-control.cpp" src/sirius/base/contracts.cpp \
    -o "$scratch/annulus-control"
"$scratch/annulus-control" >"$scratch/annulus-control.log" 2>&1
python3 "$scratch/annulus-reference.py" >"$scratch/annulus-reference.log"

from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import re
import subprocess

root = Path.cwd()
scratch = root / 'out/sealed-cold-readback'
pins = re.findall(r'FetchContent_Declare\((\w+)\s+GIT_REPOSITORY (\S+)\s+GIT_TAG (\w+)',
                  (root / 'cmake/sirius_dependencies.cmake').read_text())
def fetch(pin):
    name, url, commit = pin
    target = root / 'bin/linux-ci/_deps' / (name + '-src')
    target.mkdir(parents=True, exist_ok=True)
    current = subprocess.run(['git', '-C', str(target), 'rev-parse', 'HEAD'], capture_output=True,
                             text=True)
    if current.returncode == 0 and current.stdout.strip() == commit:
        return f'-DFETCHCONTENT_SOURCE_DIR_{name.upper()}={target}'
    for command in (['init', '-q'], ['fetch', '-q', '--depth=1', '--no-tags', url, commit],
                    ['checkout', '-q', '--detach', commit]):
        subprocess.run(['git', '-C', str(target), *command], check=True)
    return f'-DFETCHCONTENT_SOURCE_DIR_{name.upper()}={target}'
with ThreadPoolExecutor(max_workers=3) as pool:
    options = list(pool.map(fetch, pins))
subprocess.run(['cmake', '--preset', 'linux-ci', '-DSIRIUS_ALIGNMENT_MODE=qualification',
                '-DSIRIUS_SLANGC=/opt/slang/bin/slangc', '-DSIRIUS_SOFTWARE_VULKAN_BUNDLE=attestations/qualification/c096156f/accepted-packaged-software-inputs', *options], check=True)
subprocess.run(['cmake', '--build', '--preset', 'linux-ci', '--target', 
                'sirius', 'sirius_render_tests', '-j', '6'], env={**os.environ, 'TMPDIR': str(scratch)}, check=True)

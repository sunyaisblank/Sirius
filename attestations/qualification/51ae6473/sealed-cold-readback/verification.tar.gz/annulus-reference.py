"""Compare the annulus gate with a separately parameterized Schwarzschild orbit."""

from decimal import Decimal, localcontext
from functools import lru_cache
from pathlib import Path

D = Decimal
scratch = Path(__file__).resolve().parent
pi = D('3.1415926535897932384626433832795028841971693993751')

@lru_cache(maxsize=None)
def angle_from_turn(turn, radius, panels):
    # Factor the Schwarzschild radial polynomial in the ordinary radius.
    # r = turn+y² removes the endpoint singularity. The gate instead
    # integrates with u²=1-turn/r, so its quadrature is independent.
    impact2 = turn**3 / (turn - 2)
    width = (radius - turn).sqrt() / panels
    coefficient = 2 * impact2.sqrt()
    total = D(0)
    for index in range(panels + 1):
        radius_at_node = turn + (width * index)**2
        speed2 = radius_at_node * (
            radius_at_node**2 + turn * radius_at_node + turn**2 - impact2)
        weight = 1 if index in (0, panels) else (4 if index % 2 else 2)
        total += weight / speed2.sqrt()
    return width * coefficient * total / 3

def accurate(turn, radius):
    coarse = angle_from_turn(turn, radius, 2048)
    fine = angle_from_turn(turn, radius, 4096)
    assert abs(coarse - fine) < D('1e-10')
    return fine

with localcontext() as ctx:
    ctx.prec = 45
    rows = (scratch / 'annulus-control.log').read_text().splitlines()
    assert rows[-1] == 'panel_limit_declined=1'
    count = 0
    for row in rows[:-1]:
        name, turn, node, accepted, clearance_panels = row.split()
        turn, node = D(turn), D(node)
        launch_angle = accurate(turn, D(30))
        contacts = []
        if turn < 20:
            outer = accurate(turn, D(20))
            if turn < 6:
                inner = accurate(turn, D(6))
                windows = ((launch_angle - outer, launch_angle - inner),
                           (launch_angle + inner, launch_angle + outer))
            else:
                windows = ((launch_angle - outer, launch_angle + outer),)
            for left, right in windows:
                for lift in (-1, 0, 1, 2):
                    point = node + pi * lift
                    assert min(abs(point - left), abs(point - right)) > D('.01')
                    if left < point < right:
                        contacts.append(str(round(point, 9)))
        assert bool(int(accepted)) == (not contacts), (name, windows, contacts, accepted)
        if accepted == '1':
            expected_extra = 0 if turn > 20 else (48 if turn < 6 else 32)
            assert int(clearance_panels) == expected_extra
        print(f'{name} clearance={accepted} annulus_nodes={contacts}')
        count += 1
    assert count == 6
    print('independent_cases=6 panel_limit_declined=1')

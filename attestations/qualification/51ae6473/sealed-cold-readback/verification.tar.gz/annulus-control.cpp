#include "sirius/core/spherical_continuation/finite_tail.h"

#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string_view>

namespace {
using namespace sirius::core::relativity;
using namespace sirius::core::relativity::finite_tail_detail;
constexpr double kStart = 30., kEnd = 60., kMass = 1.;
constexpr SphericalThinDisk kDisk{6., 20.};

struct Fixture {
    std::string_view name;
    double turn;
    double first_node;
};

bool CheckClearance(const Fixture& fixture, const SphericalTailControl& control,
                    unsigned& panels) {
    const double b = fixture.turn / std::sqrt(1.0 - 2.0 * kMass / fixture.turn);
    const double f = 1.0 - 2.0 * kMass / kStart;
    const double rdot = -std::sqrt(1.0 - f * b * b / (kStart * kStart));
    const double angle = -fixture.first_node;
    const std::array n{std::cos(angle), 0., std::sin(angle)};
    const std::array a{-n[2], 0., n[0]};
    std::array<Jet, 4> x, k;
    x[0] = Jet(0.);
    k[0] = Jet(((1. - f) * rdot - 1.) / f);
    for (unsigned i = 0; i < n.size(); ++i) {
        x[i + 1] = Jet(kStart * n[i]);
        k[i + 1] = Jet(rdot * n[i] + b / kStart * a[i]);
    }
    const auto launch = Extract(x, k, kMass, 1., 2., kEnd, control.constraint_tolerance,
                                SphericalTailPath::ExteriorTurn);
    if (!launch) throw std::runtime_error("invalid comparison orbit");
    const auto turn = VacuumTurnRange(launch->radius.real, launch->impact_squared.real, kMass, 2.);
    if (!turn ||
        std::max(std::abs(turn->lo - fixture.turn), std::abs(turn->hi - fixture.turn)) > 1e-9)
        throw std::runtime_error("the continuation disagrees with the input turning radius");
    return ClearsThinDisk(*launch, *turn, kMass, kDisk, control, panels);
}
}

int main() {
    std::cout << std::setprecision(17);
    constexpr std::array fixtures{
        Fixture{"hole", 5.5, 1.8},
        Fixture{"inbound", 5.5, .9},
        Fixture{"outbound", 5.5, 3.},
        Fixture{"whole-annulus-clear", 14., 2.8},
        Fixture{"whole-annulus-crossing", 14., 1.2},
        Fixture{"above-annulus", 22., 1.},
    };
    for (const auto& fixture : fixtures) {
        unsigned panels = 0;
        const bool accepted = CheckClearance(fixture, {}, panels);
        std::cout << fixture.name << ' ' << fixture.turn << ' ' << fixture.first_node << ' '
                  << accepted << ' ' << panels << '\n';
    }
    SphericalTailControl small;
    small.maximum_panels = 20;
    unsigned panels = 0;
    const auto admitted = CheckClearance(fixtures.front(), small, panels);
    if (admitted || panels != small.maximum_panels) return 1;
    std::cout << "panel_limit_declined=1\n";
}

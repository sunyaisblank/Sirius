#include "sirius/core/kerr_detector/finite_screen.h"

#include <iomanip>
#include <iostream>

using namespace sirius;
using namespace core::relativity::finite_tail_detail;

int main() {
    const core::PointStarfieldConfig controls;
    const auto stars = core::StarfieldGenerator(core::ExpandPointStarfieldConfig(controls))
                           .GenerateCatalogue();
    const auto catalogue = AngularCatalogue::Build(stars, {});
    if (!catalogue) return 1;
    struct Chart { unsigned count; Range radius; double lower_h; };
    constexpr Chart charts[] = {
    { 7, Range(0x1.c01ce7680039bp-2, 0x1.c01d51806e569p-2), -0x1.8783e4a480001p-18 },
    { 794, Range(0x1.c018e627544aap-2, 0x1.c01d51806e569p-2), -0x1.dc75661300001p-15 },
    { 558, Range(0x1.c011fb5729b87p-2, 0x1.c01d51806e569p-2), -0x1.68c41a5c48001p-13 },
    };
    for (const auto& chart : charts) {
        const Range scale(0.0, sqrt(Range(-chart.lower_h)).hi);
        const auto envelope = MakeFinitePolarShape(1.0, .9, chart.radius, scale);
        const auto separatrix = MakeFinitePolarShape(1.0, .9, chart.radius, Range(0.0));
        if (!envelope || !separatrix) return 2;
        const Range amplitude = sqrt(envelope->amplitude2);
        const Range critical = sqrt(separatrix->amplitude2);
        const FilmJet u(chart.radius, {Range(1.0), Range(0.0)});
        const FilmJet h(Range(chart.lower_h, 0.0), {Range(0.0), Range(1.0)});
        const auto invariants = InvertStationaryScalars(1.0, .9, std::array{u, h});
        if (!invariants) return 3;
        const FilmJet spin2 = Square(FilmJet(.9));
        const FilmJet b = spin2 - invariants->eta - Square(invariants->lambda);
        const FilmJet omega2 =
            (sqrt(Square(b) + FilmJet(4.0)*spin2*invariants->eta)-b)*FilmJet(.5);
        const FilmJet turning_latitude = sqrt(invariants->eta/omega2);
        if (!turning_latitude.derivative[0].Finite() ||
            !turning_latitude.derivative[1].Finite()) return 4;
        auto overlaps = [](Range a, Range b) { return a.lo <= b.hi && b.lo <= a.hi; };
        std::cout << std::hexfloat << "cells=" << chart.count << " amplitude=[" << amplitude.lo
                  << ',' << amplitude.hi << "] critical_amplitude=[" << critical.lo << ','
                  << critical.hi << "] dA_du=[" << turning_latitude.derivative[0].lo
                  << ',' << turning_latitude.derivative[0].hi << "] dA_dH=["
                  << turning_latitude.derivative[1].lo << ','
                  << turning_latitude.derivative[1].hi << "]\n";
        unsigned count = 0, critical_count = 0;
        for (const bool north : {false, true}) {
            for (const auto& row : catalogue->Rows(north)) {
                if (!overlaps(row.latitude, amplitude)) continue;
                for (const auto& entry : row.entries) {
                    if (!overlaps(entry.latitude, amplitude)) continue;
                    ++count;
                    const bool on_critical = overlaps(critical, entry.latitude);
                    critical_count += on_critical;
                    std::cout << "  north=" << north << " latitude=[" << entry.latitude.lo
                              << ',' << entry.latitude.hi << "] azimuth=[" << entry.azimuth.lo
                              << ',' << entry.azimuth.hi << "] intersects_separatrix="
                              << on_critical << '\n';
                }
            }
        }
        std::cout << "  stars=" << count << " separatrix_stars=" << critical_count << '\n';
    }
}

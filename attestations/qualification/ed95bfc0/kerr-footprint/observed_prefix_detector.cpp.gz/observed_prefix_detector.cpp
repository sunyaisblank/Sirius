#include <cstdio>
#include "sirius/render/session/point_source_detector.h"

#include "sirius/core/observer_frame.h"
#include "sirius/core/spectral/point_source_transfer.h"
#include "sirius/core/spherical_continuation/radial_quadrature.h"

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <limits>
#include <new>
#include <numbers>
#include <numeric>
#include <optional>
#include <utility>
#include <vector>

namespace sirius::render {
namespace {
using Coordinate = DetectorCoordinate;
using Matrix = core::AngularMatrix2;
using Rgb = std::array<double, 3>;
using Direction = std::array<double, 3>;
namespace finite_tail = core::relativity::finite_tail_detail;

bool Positive(double value) { return std::isfinite(value) && value > 0; }

bool ValidPolicy(const PointDetectorPolicy& policy) {
    return Positive(policy.absolute_rgb_error) && Positive(policy.relative_rgb_error) &&
           Positive(policy.geometry_error) && Positive(policy.root_error) &&
           Positive(policy.maximum_linearization_residual) &&
           policy.maximum_linearization_residual < 1 && policy.maximum_probes > 0 &&
           policy.maximum_probes <= 65536 && policy.maximum_cells > 0 &&
           policy.maximum_candidate_visits > 0 && policy.maximum_candidate_visits <= 1048576 &&
           policy.maximum_newton_steps > 0 && policy.maximum_depth <= 20 &&
           policy.minimum_depth <= policy.maximum_depth;
}

struct Cell {
    Coordinate lower, upper;
    unsigned depth;
    Coordinate Centre() const { return {(lower[0] + upper[0]) * .5, (lower[1] + upper[1]) * .5}; }
    double Width() const { return upper[0] - lower[0]; }
    bool IntersectsSupport() const {
        return std::hypot(std::clamp(0.0, lower[0], upper[0]),
                          std::clamp(0.0, lower[1], upper[1])) <= 4;
    }
    bool Contains(Coordinate z, double margin = 0) const {
        return z[0] >= lower[0] - margin && z[0] <= upper[0] + margin &&
               z[1] >= lower[1] - margin && z[1] <= upper[1] + margin;
    }
    std::array<Cell, 4> Children() const {
        const auto c = Centre();
        return {{{lower, c, depth + 1},
                 {{c[0], lower[1]}, {upper[0], c[1]}, depth + 1},
                 {{lower[0], c[1]}, {c[0], upper[1]}, depth + 1},
                 {c, upper, depth + 1}}};
    }
};

std::optional<Coordinate> Solve(const Matrix& a, Coordinate b) {
    const double scale =
        std::max({std::abs(a[0][0]), std::abs(a[0][1]), std::abs(a[1][0]), std::abs(a[1][1])});
    if (!(scale > 0) || !std::isfinite(scale)) return std::nullopt;
    const double aa = a[0][0] / scale, ab = a[0][1] / scale;
    const double ba = a[1][0] / scale, bb = a[1][1] / scale;
    const double determinant = std::fma(aa, bb, -ab * ba);
    if (std::abs(determinant) <=
        32 * std::numeric_limits<double>::epsilon() * (std::abs(aa * bb) + std::abs(ab * ba)))
        return std::nullopt;
    b[0] /= scale;
    b[1] /= scale;
    Coordinate result{std::fma(bb, b[0], -ab * b[1]) / determinant,
                      std::fma(aa, b[1], -ba * b[0]) / determinant};
    if (!std::isfinite(result[0]) || !std::isfinite(result[1])) return std::nullopt;
    return result;
}

std::optional<Coordinate> SkyOffset(const Direction& from, const Direction& to) {
    const auto basis = core::relativity::MakeCelestialTangentBasis(from);
    if (!basis) return std::nullopt;
    const auto separation = core::relativity::MeasureCelestialSeparation(from, to);
    if (!std::isfinite(separation.angle)) return std::nullopt;
    if (separation.sine == 0) {
        if (separation.angle == 0) return Coordinate{};
        return std::nullopt;
    }
    const auto& n = separation.normal;
    const Direction tangent{(n[1] * from[2] - n[2] * from[1]) / separation.sine,
                            (n[2] * from[0] - n[0] * from[2]) / separation.sine,
                            (n[0] * from[1] - n[1] * from[0]) / separation.sine};
    Coordinate result{};
    for (int axis = 0; axis < 3; ++axis) {
        result[0] += separation.angle * tangent[axis] * basis->first[axis];
        result[1] += separation.angle * tangent[axis] * basis->second[axis];
    }
    return result;
}

// Bound the existing spherical-log and inverse-affine rejection tests over
// a catalogue bin. An ambiguous bound leaves the bin in the exact traversal.
class CandidateCellFilter {
  public:
    CandidateCellFilter(const Direction& direction, const Matrix& derivative, Coordinate anchor,
                        Coordinate margin, const Cell& cell, double radius, bool mixed,
                        Coordinate source_reach)
        : direction_(direction),
          basis_(core::relativity::MakeCelestialTangentBasis(direction)),
          anchor_(anchor),
          cell_(cell),
          margin_(margin),
          radius_(radius),
          mixed_(mixed),
          source_reach_(source_reach) {
        scale_ = std::max({std::abs(derivative[0][0]), std::abs(derivative[0][1]),
                           std::abs(derivative[1][0]), std::abs(derivative[1][1])});
        if (!(scale_ > 0.0)) return;
        for (int i = 0; i < 2; ++i)
            for (int j = 0; j < 2; ++j) matrix_[i][j] = derivative[i][j] / scale_;
        determinant_ = std::fma(matrix_[0][0], matrix_[1][1], -matrix_[0][1] * matrix_[1][0]);
        enabled_ = basis_.has_value() && finite_tail::RoundingEnvironment() &&
                   Solve(derivative, {1, 0}).has_value();
    }

    bool operator()(const core::StarfieldSpatialIndex::DirectionBounds& bounds) const {
        using finite_tail::Range;
        if (!enabled_) return true;
        std::array<Range, 3> direction, delta;
        Range cosine;
        for (int i = 0; i < 3; ++i) {
            direction[i] = Range(direction_[i]);
            const Range star(bounds.lower[i], bounds.upper[i]);
            delta[i] = star - direction[i];
            cosine = cosine + direction[i] * star;
        }
        const auto cross = [](const std::array<Range, 3>& a, const std::array<Range, 3>& b) {
            return std::array{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2],
                              a[0] * b[1] - a[1] * b[0]};
        };
        const auto normal = cross(direction, delta);
        const Range sine = sqrt(finite_tail::Square(normal[0]) + finite_tail::Square(normal[1]) +
                                finite_tail::Square(normal[2]));
        // The scalar path intentionally leaves the predictor unresolved at
        // a parallel/antipodal degeneracy. Keep any bin that could contain it.
        if (!sine.Finite() || !cosine.Finite()) return true;

        // atan2 is monotone in each coordinate with the other one fixed,
        // with the vertical sense switching when the cosine changes sign.
        // Widen the endpoints to cover binary64 libm and its input interval.
        const double low = std::atan2(cosine.hi >= 0.0 ? sine.lo : sine.hi, cosine.hi);
        const double high = std::atan2(cosine.lo >= 0.0 ? sine.hi : sine.lo, cosine.lo);
        const double slack = 8 * std::numeric_limits<double>::epsilon();
        const Range angle = finite_tail::Widen(std::max(0.0, low - slack), high + slack);
        if (!angle.Finite()) return true;
        if (angle.lo > radius_) return false;

        const auto numerators = cross(normal, direction);
        std::array<Range, 2> offset{};
        for (int axis = 0; axis < 3; ++axis) {
            const Range tangent = numerators[axis] / sine;
            offset[0] = offset[0] + angle * tangent * Range(basis_->first[axis]);
            offset[1] = offset[1] + angle * tangent * Range(basis_->second[axis]);
        }
        if (!offset[0].Finite() || !offset[1].Finite()) return true;
        if (!mixed_)
            for (int i = 0; i < 2; ++i)
                if (offset[i].lo > source_reach_[i] || offset[i].hi < -source_reach_[i])
                    return false;

        const auto b0 = offset[0] / Range(scale_), b1 = offset[1] / Range(scale_);
        const Range determinant(std::abs(determinant_));
        const Range orientation(std::copysign(1.0, determinant_));
        const std::array displacement{
            (Range(matrix_[1][1]) * b0 - Range(matrix_[0][1]) * b1) / determinant * orientation,
            (Range(matrix_[0][0]) * b1 - Range(matrix_[1][0]) * b0) / determinant * orientation};
        const auto x = Range(anchor_[0]) + displacement[0];
        const auto y = Range(anchor_[1]) + displacement[1];
        if (!x.Finite() || !y.Finite()) return true;
        return !(x.hi < cell_.lower[0] - margin_[0] || x.lo > cell_.upper[0] + margin_[0] ||
                 y.hi < cell_.lower[1] - margin_[1] || y.lo > cell_.upper[1] + margin_[1]);
    }

  private:
    Direction direction_;
    std::optional<core::relativity::CelestialTangentBasis<double>> basis_;
    Coordinate anchor_;
    Cell cell_;
    Coordinate margin_;
    double radius_;
    bool mixed_;
    Coordinate source_reach_;
    Matrix matrix_{};
    double scale_ = 0, determinant_ = 0;
    bool enabled_ = false;
};

struct CachedProbe {
    Coordinate z;
    PointDetectorProbe value;
};

// Exact original-camera coordinates only. A rounded key would merge nearby
// image rays, while scanning all preceding probes makes refinement quadratic.
// The table remains at most half full and stores indices into the stable probe
// vector; its iteration order never participates in sampling or RGB reduction.
constexpr std::size_t kEmptyProbe = std::numeric_limits<std::size_t>::max();

std::uint64_t CoordinateHash(Coordinate z) {
    const auto mix = [](std::uint64_t value) {
        value = (value ^ (value >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
        value = (value ^ (value >> 27)) * UINT64_C(0x94d049bb133111eb);
        return value ^ (value >> 31);
    };
    // Numeric equality treats both signs of zero as the same coordinate.
    const auto x = std::bit_cast<std::uint64_t>(z[0] == 0 ? 0.0 : z[0]);
    const auto y = std::bit_cast<std::uint64_t>(z[1] == 0 ? 0.0 : z[1]);
    return mix(mix(x) ^ std::rotl(mix(y), 32));
}
struct ImageRoot {
    std::uint32_t star;
    Coordinate z;
    std::size_t probe;
    double uncertainty;
    std::size_t previous_probe;
};
struct TracedImage {
    std::uint32_t star;
    const Coordinate& z;
    const PointDetectorProbe& point;
    const Coordinate& previous_z;
    const PointDetectorProbe& previous;
    double uncertainty;
};
using ScalarFootprintBound =
    std::function<std::optional<Rgb>(std::span<const PointDetectorCell>, std::size_t&)>;

struct Estimate {
    Rgb rgb{};
    Rgb error{};
    std::vector<std::size_t> images;
    bool regular = true;
    bool has_hidden_probe = false;
    bool certified_dark = false;
    bool whole_sky_query = false;
};

class Detector {
  public:
    Detector(const core::StarfieldSpatialIndex& catalogue, double brightness,
             const PointDetectorSampler& sampler, const std::function<bool()>& cancelled,
             const PointDetectorPolicy& policy, const PointDetectorProbeBatchSampler& sample_batch,
             const PointDetectorDarkCell& dark_cell, unsigned minimum_invisible_depth = 0,
             const ScalarFootprintBound* footprint_bound = nullptr)
        : catalogue_(catalogue),
          brightness_(brightness),
          sampler_(sampler),
          cancelled_(cancelled),
          policy_(policy),
          sample_batch_(sample_batch),
          dark_cell_(dark_cell),
          minimum_invisible_depth_(minimum_invisible_depth),
          footprint_bound_(footprint_bound) {}

    std::expected<PointDetectorResult, PointDetectorError> Run(
        std::vector<std::size_t>* images = nullptr) {
        try {
            if (!sampler_ || !std::isfinite(brightness_) || brightness_ < 0 ||
                !ValidPolicy(policy_))
                Fail(PointDetectorFailure::InvalidInput);
            probes_.reserve(policy_.maximum_probes);
            probe_slots_.assign(std::bit_ceil(2 * policy_.maximum_probes), kEmptyProbe);
            roots_.reserve(policy_.maximum_candidate_visits);
            statistics_.reserved_cache_bytes = sizeof(searches_) +
                                               probes_.capacity() * sizeof(CachedProbe) +
                                               roots_.capacity() * sizeof(ImageRoot) +
                                               probe_slots_.capacity() * sizeof(std::size_t);
            CheckCancellation();
            const Cell support{{-4, -4}, {4, 4}, 0};
            auto result = Refine(support, Measure(support));
            if (!deferred_.empty()) {
                statistics_.reserved_cache_bytes +=
                    deferred_.capacity() * sizeof(PointDetectorCell);
                const auto available =
                    policy_.maximum_candidate_visits - statistics_.candidate_visits;
                auto remaining = available;
                const auto bound = (*footprint_bound_)(deferred_, remaining);
                if (remaining > available) Fail(PointDetectorFailure::Arithmetic);
                statistics_.candidate_visits += available - remaining;
                CheckCancellation();
                if (!bound) Fail(PointDetectorFailure::Unresolved);
                using finite_tail::Range;
                for (unsigned channel = 0; channel < 3; ++channel) {
                    const double omission = (*bound)[channel];
                    const Range allowance =
                        Range(policy_.absolute_rgb_error) +
                        Range(policy_.relative_rgb_error) * Range(result.rgb[channel]);
                    const Range error = Range(result.error[channel]) + Range(omission);
                    if (!(omission >= 0.0) || !error.Finite() || !allowance.Finite() ||
                        error.hi > allowance.lo)
                        Fail(PointDetectorFailure::Unresolved);
                    result.error[channel] = error.hi;
                }
            }
            if (images) {
                *images = std::move(result.images);
                statistics_.reserved_cache_bytes += images->capacity() * sizeof(std::size_t);
            }
            statistics_.roots = roots_.size();
            return PointDetectorResult{result.rgb, result.error, statistics_};
        } catch (PointDetectorFailure reason) {
            if (reason == PointDetectorFailure::WorkLimit && !deferred_.empty() &&
                statistics_.candidate_visits <= policy_.maximum_candidate_visits) {
                auto left = policy_.maximum_candidate_visits - statistics_.candidate_visits;
                const auto available = left;
                std::fprintf(stderr,"pending_prefix cells=%zu probes=%zu remaining_visits=%zu\n",
                             deferred_.size(), statistics_.probes, left);
                for (const auto& r : deferred_)
                    std::fprintf(stderr,"pending_cell lower=%a,%a upper=%a,%a\n",
                                 r.lower[0],r.lower[1],r.upper[0],r.upper[1]);
                const auto result = (*footprint_bound_)(deferred_, left);
                std::fprintf(stderr,"pending_bound debit=%zu outcome=%d rgb=%a\n",
                             available-left, result.has_value(), result ? (*result)[0] : -1.0);
            }
            statistics_.roots = roots_.size();
            return std::unexpected(PointDetectorError{reason, statistics_});
        } catch (const std::bad_alloc&) {
            statistics_.roots = roots_.size();
            return std::unexpected(
                PointDetectorError{PointDetectorFailure::WorkLimit, statistics_});
        }
    }

    TracedImage Image(std::size_t index) const {
        const auto& root = roots_[index];
        const auto& previous = probes_[root.previous_probe];
        return {root.star,  root.z,         probes_[root.probe].value,
                previous.z, previous.value, root.uncertainty};
    }

  private:
    [[noreturn]] static void Fail(PointDetectorFailure reason) { throw reason; }
    void CheckCancellation() const {
        if (cancelled_ && cancelled_()) Fail(PointDetectorFailure::Cancelled);
    }
    std::size_t ProbeSlot(const Coordinate& z) {
        const std::size_t mask = probe_slots_.size() - 1;
        std::size_t slot = CoordinateHash(z) & mask;
        while (probe_slots_[slot] != kEmptyProbe) {
            ++statistics_.probe_cache_comparisons;
            const auto index = probe_slots_[slot];
            if (probes_[index].z == z) return slot;
            slot = (slot + 1) & mask;
        }
        return slot;
    }
    std::size_t StoreProbe(Coordinate z, PointDetectorProbe value, std::size_t slot) {
        if (value.visible) {
            const double norm =
                std::hypot(value.direction[0], value.direction[1], value.direction[2]);
            if (!Positive(norm) || !Positive(value.camera_over_source_frequency) ||
                !std::isfinite(value.transmission) || value.transmission < 0 ||
                value.transmission > 1)
                Fail(PointDetectorFailure::Arithmetic);
            for (auto& component : value.direction) component /= norm;
            for (const auto& row : value.source_derivative)
                for (double component : row)
                    if (!std::isfinite(component)) Fail(PointDetectorFailure::Arithmetic);
        }
        probes_.push_back({z, value});
        probe_slots_[slot] = probes_.size() - 1;
        return probes_.size() - 1;
    }
    std::size_t Probe(Coordinate z) {
        CheckCancellation();
        ++statistics_.probe_requests;
        const auto slot = ProbeSlot(z);
        if (probe_slots_[slot] != kEmptyProbe) return probe_slots_[slot];
        if (statistics_.probes == policy_.maximum_probes) Fail(PointDetectorFailure::WorkLimit);
        auto value = sampler_(z);
        ++statistics_.probes;
        ++statistics_.probe_batches;
        statistics_.maximum_probe_batch = std::max<std::size_t>(1, statistics_.maximum_probe_batch);
        CheckCancellation();
        if (!value) Fail(value.error());
        statistics_.inner_attempts += value->inner_attempts;
        statistics_.tail_attempts += value->tail_attempts;
        return StoreProbe(z, *value, slot);
    }
    std::array<std::size_t, kPointDetectorProbeBatchSize> ProbeCell(
        const std::array<Coordinate, kPointDetectorProbeBatchSize>& coordinates) {
        std::array<std::size_t, kPointDetectorProbeBatchSize> indices{};
        if (!sample_batch_) {
            for (std::size_t i = 0; i < coordinates.size(); ++i) indices[i] = Probe(coordinates[i]);
            return indices;
        }
        CheckCancellation();
        std::array<Coordinate, kPointDetectorProbeBatchSize> missing{};
        std::array<std::size_t, kPointDetectorProbeBatchSize> pending{};
        pending.fill(kEmptyProbe);
        std::size_t count = 0;
        for (std::size_t i = 0; i < coordinates.size(); ++i) {
            ++statistics_.probe_requests;
            const auto slot = ProbeSlot(coordinates[i]);
            if (probe_slots_[slot] != kEmptyProbe) {
                indices[i] = probe_slots_[slot];
                continue;
            }
            const auto end = missing.begin() + count;
            const auto found = std::find(missing.begin(), end, coordinates[i]);
            pending[i] = static_cast<std::size_t>(found - missing.begin());
            if (found == end) missing[count++] = coordinates[i];
        }
        if (count == 0) return indices;
        if (count > policy_.maximum_probes - statistics_.probes)
            Fail(PointDetectorFailure::WorkLimit);
        auto values = sample_batch_(std::span(missing).first(count));
        statistics_.probes += count;
        ++statistics_.probe_batches;
        statistics_.maximum_probe_batch = std::max(statistics_.maximum_probe_batch, count);
        CheckCancellation();
        if (values.size() != count) Fail(PointDetectorFailure::InvalidInput);
        // All speculative independent work counts, even if one result failed.
        for (const auto& value : values)
            if (value) {
                statistics_.inner_attempts += value->inner_attempts;
                statistics_.tail_attempts += value->tail_attempts;
            }
        std::array<std::size_t, kPointDetectorProbeBatchSize> stored{};
        for (std::size_t i = 0; i < count; ++i) {
            if (!values[i]) Fail(values[i].error());
            stored[i] = StoreProbe(missing[i], *values[i], ProbeSlot(missing[i]));
        }
        for (std::size_t i = 0; i < coordinates.size(); ++i)
            if (pending[i] != kEmptyProbe) indices[i] = stored[pending[i]];
        return indices;
    }

    std::optional<std::size_t> ReusableImage(std::uint32_t star, const Cell& cell) const {
        for (std::size_t i = 0; i < roots_.size(); ++i)
            if (roots_[i].star == star && cell.Contains(roots_[i].z, roots_[i].uncertainty))
                return i;
        return std::nullopt;
    }
    struct ImageSearch {
        enum class Stage { Iteration, Trial, TrialAnswer, ValidationAnswer, Complete };
        std::uint32_t star = 0;
        Direction target{};
        Coordinate z{}, residual{}, delta{}, next{};
        std::size_t index = 0, answer = 0, newton_steps = 0;
        unsigned iteration = 0, backtrack = 0;
        double weight = 1, uncertainty = 0;
        Stage stage = Stage::Iteration;
        bool regular = true, unresolved = false, validated = false, awaiting = false;
        std::optional<std::size_t> reused;
        std::optional<PointDetectorFailure> failure;
    };
    ImageSearch StartImageSearch(std::uint32_t star, const Cell& cell, std::size_t seed,
                                 bool regular) const {
        const auto& entry = catalogue_.Stars()[star];
        ImageSearch state;
        state.star = star;
        state.target = {entry.direction_x, entry.direction_y, entry.direction_z};
        state.index = seed;
        state.z = probes_[seed].z;
        state.regular = regular;
        // Only the same catalogue ID can own a reusable image. Distinct
        // searches can determine their next ray independently.
        if (regular) state.reused = ReusableImage(star, cell);
        if (state.reused) state.stage = ImageSearch::Stage::Complete;
        return state;
    }
    std::optional<Coordinate> AdvanceImageSearch(ImageSearch& state, const Cell& cell,
                                                 double margin) {
        using Stage = ImageSearch::Stage;
        for (;;) {
            if (state.stage == Stage::Complete) return std::nullopt;
            if (state.stage == Stage::Iteration) {
                if (state.iteration == policy_.maximum_newton_steps) {
                    state.unresolved = true;
                    state.stage = Stage::Complete;
                    continue;
                }
                ++state.newton_steps;
                const auto& current = probes_[state.index].value;
                if (!current.visible) {
                    state.stage = Stage::Complete;
                    continue;
                }
                const auto residual = SkyOffset(current.direction, state.target);
                const auto delta =
                    residual ? Solve(current.source_derivative, *residual) : std::nullopt;
                if (!delta) {
                    state.unresolved = true;
                    state.stage = Stage::Complete;
                    continue;
                }
                state.residual = *residual;
                state.delta = *delta;
                const double error = std::hypot((*delta)[0], (*delta)[1]);
                if (error <= policy_.root_error) {
                    // Validation always traces the independently corrected
                    // image, including when it is an exact cache hit.
                    state.next = {state.z[0] + (*delta)[0], state.z[1] + (*delta)[1]};
                    if (!cell.Contains(state.next, margin)) {
                        state.stage = Stage::Complete;
                        continue;
                    }
                    state.stage = Stage::ValidationAnswer;
                    return state.next;
                }
                const Coordinate next{state.z[0] + (*delta)[0], state.z[1] + (*delta)[1]};
                if (state.regular && !cell.Contains(next, margin)) {
                    state.stage = Stage::Complete;
                    continue;
                }
                state.weight = 1;
                state.backtrack = 0;
                state.stage = Stage::Trial;
            }
            if (state.stage == Stage::Trial) {
                if (state.backtrack == 12) {
                    state.unresolved = true;
                    state.stage = Stage::Complete;
                    continue;
                }
                state.next = {state.z[0] + state.weight * state.delta[0],
                              state.z[1] + state.weight * state.delta[1]};
                if (cell.Contains(state.next, margin) && state.next != state.z) {
                    state.stage = Stage::TrialAnswer;
                    return state.next;
                }
                state.weight *= .5;
                ++state.backtrack;
                continue;
            }
            if (state.stage == Stage::TrialAnswer) {
                if (probes_[state.answer].value.visible) {
                    const auto candidate_residual =
                        SkyOffset(probes_[state.answer].value.direction, state.target);
                    if (candidate_residual &&
                        std::hypot((*candidate_residual)[0], (*candidate_residual)[1]) <
                            std::hypot(state.residual[0], state.residual[1])) {
                        state.z = state.next;
                        state.index = state.answer;
                        ++state.iteration;
                        state.stage = Stage::Iteration;
                        continue;
                    }
                }
                state.weight *= .5;
                ++state.backtrack;
                state.stage = Stage::Trial;
                continue;
            }
            if (state.stage == Stage::ValidationAnswer) {
                const auto& actual = probes_[state.answer].value;
                state.stage = Stage::Complete;
                if (!actual.visible) continue;
                const auto remainder = SkyOffset(actual.direction, state.target);
                const auto remaining =
                    remainder ? Solve(actual.source_derivative, *remainder) : std::nullopt;
                if (!remaining ||
                    std::hypot((*remaining)[0], (*remaining)[1]) > policy_.root_error) {
                    state.unresolved = true;
                    continue;
                }
                state.uncertainty = std::hypot((*remaining)[0], (*remaining)[1]) +
                                    32 * std::numeric_limits<double>::epsilon() *
                                        (1 + std::hypot(state.next[0], state.next[1]));
                state.validated = true;
            }
        }
    }
    std::optional<std::size_t> FinishImageSearch(ImageSearch& state, bool& unresolved) {
        unresolved = unresolved || state.unresolved;
        if (state.reused) return state.reused;
        if (!state.validated) return std::nullopt;
        // Registration is separate from ray evaluation so cohort completion
        // order cannot change root indices or subsequent RGB reduction order.
        for (std::size_t i = 0; i < roots_.size(); ++i) {
            if (roots_[i].star != state.star) continue;
            if (roots_[i].z == state.next) return i;
            if (std::hypot(roots_[i].z[0] - state.next[0], roots_[i].z[1] - state.next[1]) <=
                roots_[i].uncertainty + state.uncertainty) {
                if (state.regular) return i;
                unresolved = true;
                return std::nullopt;
            }
        }
        if (roots_.size() == policy_.maximum_candidate_visits)
            Fail(PointDetectorFailure::WorkLimit);
        statistics_.maximum_root_coordinate_error =
            std::max(statistics_.maximum_root_coordinate_error, state.uncertainty);
        roots_.push_back({state.star, state.next, state.answer, state.uncertainty, state.index});
        return roots_.size() - 1;
    }
    struct SearchWork {
        PointDetectorStatistics& statistics;
        std::span<ImageSearch> searches;
        ~SearchWork() {
            // All actually executed Newton operations count, including
            // independent work discarded after another search fails.
            for (const auto& state : searches) statistics.newton_steps += state.newton_steps;
        }
    };
    std::optional<std::size_t> FindImage(std::uint32_t star, const Cell& cell, std::size_t seed,
                                         bool regular, double margin, bool& unresolved) {
        auto state = StartImageSearch(star, cell, seed, regular);
        const SearchWork work{statistics_, std::span(&state, 1)};
        while (const auto coordinate = AdvanceImageSearch(state, cell, margin))
            state.answer = Probe(*coordinate);
        return FinishImageSearch(state, unresolved);
    }

    template <class Accumulate>
    void FindImages(std::span<const std::uint32_t> stars, const Cell& cell, std::size_t seed,
                    double margin, bool& unresolved, const Accumulate& accumulate) {
        // Reserve the entire worst-case Newton/backtracking chain before any
        // independent root work. A tight or arbitrary unsigned step limit
        // retains the same scalar transition driver.
        const auto room = (policy_.maximum_probes - statistics_.probes) / stars.size();
        bool eligible = sample_batch_ && stars.size() > 1 && room > 0 &&
                        policy_.maximum_newton_steps <= (room - 1) / 12 &&
                        stars.size() <= policy_.maximum_candidate_visits - roots_.size();
        for (std::size_t i = 0; eligible && i < stars.size(); ++i)
            eligible = std::find(stars.begin(), stars.begin() + i, stars[i]) == stars.begin() + i;
        if (!eligible) {
            for (const auto star : stars)
                (void)accumulate(star, FindImage(star, cell, seed, true, margin, unresolved));
            return;
        }
        auto states = std::span(searches_).first(stars.size());
        for (std::size_t i = 0; i < stars.size(); ++i)
            states[i] = StartImageSearch(stars[i], cell, seed, true);
        const SearchWork work{statistics_, states};
        struct FailedProbe {
            Coordinate z;
            PointDetectorFailure reason;
        };
        // At most one newly failed coordinate per failed search. Keep its
        // answer available if an earlier search later requests that ray.
        std::array<FailedProbe, kPointDetectorProbeBatchSize> failed{};
        std::size_t failed_count = 0, completed = 0;
        while (completed < states.size()) {
            CheckCancellation();
            // A later row failure remains deferred while preceding searches
            // finish. No work beyond the first known failure is newly issued.
            std::size_t limit = states.size();
            for (std::size_t i = completed; i < limit; ++i) {
                auto& state = states[i];
                if (state.failure) {
                    limit = i;
                    break;
                }
                if (!state.awaiting)
                    if (const auto coordinate = AdvanceImageSearch(state, cell, margin))
                        state.awaiting = true;
            }
            // Root indices, error precedence through photometry, and RGB sums
            // follow catalogue order, regardless of which ray finished first.
            while (completed < states.size()) {
                auto& state = states[completed];
                if (state.failure) Fail(*state.failure);
                if (state.stage != ImageSearch::Stage::Complete) break;
                (void)accumulate(state.star, FinishImageSearch(state, unresolved));
                ++completed;
            }
            if (completed == states.size()) break;
            std::array<Coordinate, kPointDetectorProbeBatchSize> missing{};
            std::array<std::size_t, kPointDetectorProbeBatchSize> pending{};
            pending.fill(kEmptyProbe);
            std::size_t count = 0;
            for (std::size_t i = completed; i < limit; ++i) {
                auto& state = states[i];
                if (!state.awaiting) continue;
                ++statistics_.probe_requests;
                const auto slot = ProbeSlot(state.next);
                if (probe_slots_[slot] != kEmptyProbe) {
                    state.answer = probe_slots_[slot];
                    state.awaiting = false;
                    continue;
                }
                const auto error =
                    std::find_if(failed.begin(), failed.begin() + failed_count,
                                 [&](const auto& value) { return value.z == state.next; });
                if (error != failed.begin() + failed_count) {
                    state.failure = error->reason;
                    state.awaiting = false;
                    break;
                }
                const auto end = missing.begin() + count;
                const auto found = std::find(missing.begin(), end, state.next);
                pending[i] = static_cast<std::size_t>(found - missing.begin());
                if (found == end) missing[count++] = state.next;
            }
            if (count == 0) continue;
            if (count > policy_.maximum_probes - statistics_.probes)
                Fail(PointDetectorFailure::WorkLimit);
            auto values = sample_batch_(std::span(missing).first(count));
            statistics_.probes += count;
            ++statistics_.probe_batches;
            statistics_.maximum_probe_batch = std::max(statistics_.maximum_probe_batch, count);
            for (const auto& value : values)
                if (value) {
                    statistics_.inner_attempts += value->inner_attempts;
                    statistics_.tail_attempts += value->tail_attempts;
                }
            CheckCancellation();
            const bool shape_valid = values.size() == count;
            std::array<std::expected<std::size_t, PointDetectorFailure>,
                       kPointDetectorProbeBatchSize>
                answers{};
            for (std::size_t i = 0; i < count; ++i) {
                if (!shape_valid)
                    answers[i] = std::unexpected(PointDetectorFailure::InvalidInput);
                else if (!values[i])
                    answers[i] = std::unexpected(values[i].error());
                else {
                    try {
                        // Exact-coordinate deduplication normalizes each
                        // successful physical answer once, through StoreProbe.
                        answers[i] = StoreProbe(missing[i], *values[i], ProbeSlot(missing[i]));
                    } catch (PointDetectorFailure reason) {
                        answers[i] = std::unexpected(reason);
                    }
                }
                if (!answers[i]) failed[failed_count++] = {missing[i], answers[i].error()};
            }
            for (std::size_t i = completed; i < limit; ++i) {
                if (pending[i] == kEmptyProbe) continue;
                auto& state = states[i];
                const auto& answer = answers[pending[i]];
                state.awaiting = false;
                if (answer)
                    state.answer = *answer;
                else
                    state.failure = answer.error();
            }
        }
    }

    Estimate Measure(const Cell& cell) {
        Estimate result;
        if (!cell.IntersectsSupport()) {
            result.certified_dark = true;
            return result;
        }
        if (++statistics_.cells > policy_.maximum_cells) Fail(PointDetectorFailure::WorkLimit);
        CheckCancellation();
        if (dark_cell_) {
            const bool certified = dark_cell_(cell.lower, cell.upper, 0);
            CheckCancellation();
            if (certified) {
                result.certified_dark = true;
                return result;
            }
        }
        const auto centre = cell.Centre();
        const double half = cell.Width() * .5;
        std::array<Coordinate, kPointDetectorProbeBatchSize> coordinates{};
        std::size_t count = 0;
        coordinates[count++] = centre;
        for (int y = -1; y <= 1; ++y)
            for (int x = -1; x <= 1; ++x)
                if (x != 0 || y != 0)
                    coordinates[count++] = {centre[0] + x * half, centre[1] + y * half};
        // Staggered positions are not the quadtree's next-level corners.
        for (const Coordinate shift : {Coordinate{-.37, -.61}, Coordinate{.61, -.37},
                                       Coordinate{.37, .61}, Coordinate{-.61, .37}})
            coordinates[count++] = {centre[0] + shift[0] * half, centre[1] + shift[1] * half};
        const auto nodes = ProbeCell(coordinates);
        const auto seed = std::find_if(nodes.begin(), nodes.end(), [&](std::size_t i) {
            return probes_[i].value.visible &&
                   Solve(probes_[i].value.source_derivative, {1, 0}).has_value();
        });
        result.has_hidden_probe = std::any_of(
            nodes.begin(), nodes.end(), [&](std::size_t i) { return !probes_[i].value.visible; });
        if (seed == nodes.end()) {
            result.regular = std::none_of(nodes.begin(), nodes.end(),
                                          [&](std::size_t i) { return probes_[i].value.visible; });
            return result;
        }
        const auto& anchor = probes_[*seed];
        double residual_bound = 0;
        Coordinate residual_by_axis{};
        Coordinate source_residual{};
        Coordinate source_reach{};
        bool mixed = false;
        const auto& matrix = anchor.value.source_derivative;
        const double parity = std::fma(matrix[0][0], matrix[1][1], -matrix[0][1] * matrix[1][0]);
        for (auto i : nodes) {
            const auto& other = probes_[i];
            if (!other.value.visible) {
                mixed = true;
                continue;
            }
            const auto offset = SkyOffset(anchor.value.direction, other.value.direction);
            if (offset) {
                for (int axis = 0; axis < 2; ++axis) {
                    const double predicted = matrix[axis][0] * (other.z[0] - anchor.z[0]) +
                                             matrix[axis][1] * (other.z[1] - anchor.z[1]);
                    source_residual[axis] =
                        std::max(source_residual[axis], std::abs((*offset)[axis] - predicted));
                }
            }
            const auto inferred = offset ? Solve(matrix, *offset) : std::nullopt;
            if (!inferred) {
                result.regular = false;
                continue;
            }
            const double error = std::hypot((*inferred)[0] - (other.z[0] - anchor.z[0]),
                                            (*inferred)[1] - (other.z[1] - anchor.z[1]));
            for (int axis = 0; axis < 2; ++axis)
                residual_by_axis[axis] =
                    std::max(residual_by_axis[axis],
                             std::abs((*inferred)[axis] - (other.z[axis] - anchor.z[axis])));
            residual_bound = std::max(residual_bound, error);
            const auto& b = other.value.source_derivative;
            const double other_parity = std::fma(b[0][0], b[1][1], -b[0][1] * b[1][0]);
            // Curvature controls branch discovery and its query padding. Flux
            // uses the retraced image and its local derivative, so it does not
            // inherit this affine approximation's residual as a radiance error.
            if (!(parity * other_parity > 0) ||
                error > policy_.maximum_linearization_residual * cell.Width())
                result.regular = false;
        }
        // Visibility discontinuities require extra spatial sampling. Actual
        // image rays decide transmission; the centre cannot mask the support.
        if (mixed && cell.depth < policy_.minimum_depth + 2) {
            // This cell cannot be admitted regardless of its catalogue sum.
            // Refine visibility before spending visits on its broad query;
            // only represented descendant estimates can own radiance.
            result.regular = false;
            return result;
        }
        double reach = 0;
        for (auto i : nodes) {
            if (!probes_[i].value.visible) continue;
            const auto& b = probes_[i].value.source_derivative;
            reach = std::max(reach, std::hypot(b[0][0], b[0][1]) + std::hypot(b[1][0], b[1][1]));
        }
        // Keep the two source directions separate near a fold. Inverting an
        // almost singular map can make a distant catalogue point appear to
        // need arbitrarily deep film refinement. The forward map still has a
        // small, measured range in its critical direction. Express every node
        // in the anchor's sky chart so tangent-basis switches cannot mix axes.
        for (auto i : nodes) {
            if (!probes_[i].value.visible) continue;
            const auto offset = SkyOffset(anchor.value.direction, probes_[i].value.direction);
            if (!offset) continue;
            for (int axis = 0; axis < 2; ++axis)
                source_reach[axis] = std::max(source_reach[axis], std::abs((*offset)[axis]));
        }
        for (int axis = 0; axis < 2; ++axis)
            source_reach[axis] += 2 * source_residual[axis] +
                                  policy_.root_error * std::hypot(matrix[axis][0], matrix[axis][1]);
        double query_radius = reach * (2 * cell.Width() + residual_bound);
        if (footprint_bound_ && mixed && query_radius >= std::numbers::pi) {
            // Across the Kerr shadow a large derivative can turn the
            // tangent-plane estimate into a whole-sky search. Route it
            // to refinement without searching that envelope.
            result.regular = false;
            result.whole_sky_query = true;
            return result;
        }
        if (!mixed) {
            // The exact same rectangular forward-range predicate below
            // already rejects everything outside this circumscribed disk.
            // Apply that bound to the index query as well, without dropping
            // a candidate which could pass the existing predicate.
            query_radius =
                std::min(query_radius, std::nextafter(std::hypot(source_reach[0], source_reach[1]),
                                                      std::numeric_limits<double>::infinity()));
        }
        const float query_sigma = std::nextafter(
            static_cast<float>(query_radius * .25 + 8 * std::numeric_limits<float>::epsilon()),
            std::numeric_limits<float>::infinity());
        bool unresolved = false;
        bool has_candidate = false;
        const auto& n = anchor.value.direction;
        const double image_margin = 2 * residual_bound + policy_.root_error;
        const auto accumulate = [&](std::uint32_t star, std::optional<std::size_t> image) {
            if (!image) return true;
            const auto& root = roots_[*image];
            const auto& point = probes_[root.probe].value;
            const auto response = core::MakeRestrictedAffinePointResponse(
                point.source_derivative, cell.lower, cell.upper, policy_.geometry_error);
            if (!response) {
                unresolved = true;
                return true;
            }
            const auto density = response->DensityAtOriginalRoot(root.z);
            if (!density) Fail(PointDetectorFailure::Arithmetic);
            if (*density == 0) return true;
            const auto& entry = catalogue_.Stars()[star];
            const auto rgb = core::spectral::TransferPointSourceBand(
                entry.temperature_K, point.camera_over_source_frequency,
                static_cast<double>(entry.Intensity()) * brightness_, *density);
            if (!rgb) Fail(PointDetectorFailure::Arithmetic);
            const auto& previous = probes_[root.previous_probe];
            const double correction =
                std::hypot(previous.z[0] - root.z[0], previous.z[1] - root.z[1]);
            Rgb prior_rgb{};
            if (correction > 0) {
                const auto prior_response = core::MakeRestrictedAffinePointResponse(
                    previous.value.source_derivative, cell.lower, cell.upper,
                    policy_.geometry_error);
                if (!prior_response) {
                    unresolved = true;
                    return true;
                }
                const auto prior_density = prior_response->DensityAtOriginalRoot(root.z);
                if (!prior_density) Fail(PointDetectorFailure::Arithmetic);
                const auto transferred = core::spectral::TransferPointSourceBand(
                    entry.temperature_K, previous.value.camera_over_source_frequency,
                    static_cast<double>(entry.Intensity()) * brightness_, *prior_density);
                if (!transferred) Fail(PointDetectorFailure::Arithmetic);
                for (int channel = 0; channel < 3; ++channel)
                    prior_rgb[channel] = (*transferred)[channel] * previous.value.transmission;
            }
            result.images.push_back(*image);
            for (int channel = 0; channel < 3; ++channel) {
                const double contribution = (*rgb)[channel] * point.transmission;
                result.rgb[channel] += contribution;
                // Estimate root-location, local transfer and represented
                // response errors separately from level differences.
                const double smooth_error = correction > 0
                                                ? 2 * std::abs(contribution - prior_rgb[channel]) *
                                                      root.uncertainty / correction
                                                : 0;
                const double weight_error =
                    std::expm1(4 * root.uncertainty + .5 * root.uncertainty * root.uncertainty);
                result.error[channel] +=
                    smooth_error +
                    contribution * (weight_error + response->query.arithmetic_area_bound +
                                    128 * std::numeric_limits<double>::epsilon());
                if (!std::isfinite(result.rgb[channel]) || !std::isfinite(result.error[channel]))
                    Fail(PointDetectorFailure::Arithmetic);
            }
            return true;
        };
        std::array<std::uint32_t, kPointDetectorProbeBatchSize> pending{};
        std::size_t pending_count = 0;
        const auto flush = [&] {
            std::size_t completed = 0;
            while (completed < pending_count) {
                const auto remaining = policy_.maximum_probes - statistics_.probes;
                // The shared-discovery budget can be smaller than a full
                // cohort's reservation. Keep its original bound and use the
                // largest affordable prefix, checking before multiplication.
                const std::size_t affordable =
                    remaining != 0 && policy_.maximum_newton_steps <= (remaining - 1) / 12
                        ? remaining / (std::size_t{12} * policy_.maximum_newton_steps + 1)
                        : 1;
                const auto count =
                    std::min(pending_count - completed, std::max(std::size_t{1}, affordable));
                FindImages(std::span(pending).subspan(completed, count), cell, *seed, image_margin,
                           unresolved, accumulate);
                completed += count;
            }
            pending_count = 0;
        };
        catalogue_.ForEachCandidateWhile(
            static_cast<float>(n[0]), static_cast<float>(n[1]), static_cast<float>(n[2]),
            query_sigma,
            CandidateCellFilter(n, matrix, anchor.z,
                                {2 * residual_by_axis[0] + policy_.root_error,
                                 2 * residual_by_axis[1] + policy_.root_error},
                                cell, query_radius, mixed, source_reach),
            [&](std::uint32_t star) {
                if (++statistics_.candidate_visits > policy_.maximum_candidate_visits) {
                    flush();
                    Fail(PointDetectorFailure::WorkLimit);
                }
                CheckCancellation();
                const auto& candidate = catalogue_.Stars()[star];
                const auto separation = core::relativity::MeasureCelestialSeparation(
                    n,
                    Direction{candidate.direction_x, candidate.direction_y, candidate.direction_z});
                if (separation.angle > query_radius) return true;
                const auto offset = SkyOffset(
                    n,
                    Direction{candidate.direction_x, candidate.direction_y, candidate.direction_z});
                const auto predicted = offset ? Solve(matrix, *offset) : std::nullopt;
                if (!mixed && offset &&
                    (std::abs((*offset)[0]) > source_reach[0] ||
                     std::abs((*offset)[1]) > source_reach[1]))
                    return true;
                if (predicted) {
                    for (int axis = 0; axis < 2; ++axis) {
                        const double value = anchor.z[axis] + (*predicted)[axis];
                        const double margin = 2 * residual_by_axis[axis] + policy_.root_error;
                        if (value < cell.lower[axis] - margin || value > cell.upper[axis] + margin)
                            return true;
                    }
                }
                has_candidate = true;
                // An irregular cell only needs an existence witness before
                // subdivision; further catalogue visits cannot change its estimate.
                if (!result.regular) return false;
                if (!sample_batch_)
                    return accumulate(star,
                                      FindImage(star, cell, *seed, true, image_margin, unresolved));
                pending[pending_count++] = star;
                if (pending_count == pending.size()) flush();
                return true;
            });
        flush();
        result.regular = !unresolved && (result.regular || !has_candidate);
        std::sort(result.images.begin(), result.images.end());
        return result;
    }

    static Estimate Sum(const std::array<Estimate, 4>& children) {
        Estimate result;
        result.certified_dark = true;
        for (const auto& child : children) {
            result.certified_dark = result.certified_dark && child.certified_dark;
            result.regular = result.regular && child.regular;
            result.has_hidden_probe = result.has_hidden_probe || child.has_hidden_probe;
            result.images.insert(result.images.end(), child.images.begin(), child.images.end());
            for (int channel = 0; channel < 3; ++channel) {
                result.rgb[channel] += child.rgb[channel];
                result.error[channel] += child.error[channel];
            }
        }
        std::sort(result.images.begin(), result.images.end());
        return result;
    }
    bool Agrees(const Cell& cell, const Estimate& coarse, Estimate& fine) const {
        if (!coarse.regular || !fine.regular || coarse.images != fine.images) return false;
        bool accepted = true;
        // A LOWER Gaussian-mass bound allocates no more than the original
        // packet allowance across disjoint leaves. Boundary cells retain the
        // relative allowance; they do not gain a fresh absolute allowance.
        const double far_radius =
            std::hypot(std::max(std::abs(cell.lower[0]), std::abs(cell.upper[0])),
                       std::max(std::abs(cell.lower[1]), std::abs(cell.upper[1])));
        const double mass_bound = far_radius <= 4 ? cell.Width() * cell.Width() *
                                                        std::exp(-.5 * far_radius * far_radius) /
                                                        (2 * std::numbers::pi * -std::expm1(-8.0))
                                                  : 0;
        for (int channel = 0; channel < 3; ++channel) {
            fine.error[channel] =
                std::max(fine.error[channel], std::abs(fine.rgb[channel] - coarse.rgb[channel]));
            if (fine.error[channel] > policy_.absolute_rgb_error * mass_bound +
                                          policy_.relative_rgb_error * fine.rgb[channel])
                accepted = false;
        }
        return accepted;
    }
    Estimate Refine(const Cell& cell, const Estimate& coarse) {
        if (coarse.certified_dark || !cell.IntersectsSupport()) return coarse;
        const bool terminal = cell.depth >= policy_.maximum_depth;
        if (terminal && dark_cell_ && coarse.has_hidden_probe) {
            // Refine the enclosure, without requesting a deeper detector
            // sample or extending any of the detector's work limits.
            const bool certified = dark_cell_(cell.lower, cell.upper, 4);
            CheckCancellation();
            if (certified) {
                Estimate result;
                result.certified_dark = true;
                return result;
            }
        }
        // Each deferred leaf is removed from the quadrature exactly once.
        // The footprint bound can share chart and catalogue work along the rim.
        const bool last_whole_sky_split =
            coarse.whole_sky_query && cell.depth + 1 == policy_.maximum_depth;
        if (footprint_bound_ && (terminal || last_whole_sky_split)) {
            deferred_.push_back({cell.lower, cell.upper});
            Estimate result;
            result.regular = false;
            return result;
        }
        if (terminal) Fail(PointDetectorFailure::Unresolved);
        const auto children = cell.Children();
        std::array<Estimate, 4> estimates;
        for (int i = 0; i < 4; ++i) estimates[i] = Measure(children[i]);
        auto fine = Sum(estimates);
        if (fine.certified_dark) return fine;
        if (cell.depth >= policy_.minimum_depth &&
            ((!coarse.has_hidden_probe && !fine.has_hidden_probe) ||
             cell.depth >= minimum_invisible_depth_) &&
            cell.depth + 2 <= policy_.maximum_depth && Agrees(cell, coarse, fine)) {
            std::array<Estimate, 4> validation;
            for (int i = 0; i < 4; ++i) {
                const auto grandchildren = children[i].Children();
                std::array<Estimate, 4> leaves;
                for (int j = 0; j < 4; ++j) leaves[j] = Measure(grandchildren[j]);
                validation[i] = Sum(leaves);
            }
            auto checked = Sum(validation);
            if ((!checked.has_hidden_probe || cell.depth >= minimum_invisible_depth_) &&
                Agrees(cell, fine, checked))
                return checked;
        }
        for (int i = 0; i < 4; ++i) estimates[i] = Refine(children[i], estimates[i]);
        return Sum(estimates);
    }

    const core::StarfieldSpatialIndex& catalogue_;
    double brightness_;
    const PointDetectorSampler& sampler_;
    const std::function<bool()>& cancelled_;
    const PointDetectorPolicy& policy_;
    const PointDetectorProbeBatchSampler& sample_batch_;
    const PointDetectorDarkCell& dark_cell_;
    unsigned minimum_invisible_depth_;
    const ScalarFootprintBound* footprint_bound_;
    std::vector<PointDetectorCell> deferred_;
    PointDetectorStatistics statistics_;
    std::vector<CachedProbe> probes_;
    std::vector<std::size_t> probe_slots_;
    std::vector<ImageRoot> roots_;
    std::array<ImageSearch, kPointDetectorProbeBatchSize> searches_{};
};
}  // namespace

std::expected<PointDetectorResult, PointDetectorError> EvaluatePointDetector(
    const core::StarfieldSpatialIndex& catalogue, double brightness_scale,
    const PointDetectorSampler& sample, const std::function<bool()>& cancelled,
    const PointDetectorPolicy& policy, const PointDetectorProbeBatchSampler& sample_batch,
    const PointDetectorDarkCell& dark_cell) {
    return Detector(catalogue, brightness_scale, sample, cancelled, policy, sample_batch, dark_cell)
        .Run();
}

std::expected<PointDetectorBatchResult, PointDetectorError> EvaluatePointDetectorBatch(
    const core::StarfieldSpatialIndex& catalogue, double brightness_scale,
    std::span<const PointDetectorFootprint> footprints, const PointDetectorSampler& sample,
    const std::function<bool()>& cancelled, const PointDetectorPolicy& policy,
    const PointDetectorProbeBatchSampler& sample_batch, const PointDetectorDarkCell& dark_cell) {
    PointDetectorStatistics statistics;
    const auto failure = [&](PointDetectorFailure reason) {
        return std::unexpected(PointDetectorError{reason, statistics});
    };
    if (footprints.empty() || footprints.size() > kPointDetectorBatchCapacity || !sample ||
        !ValidPolicy(policy) || !std::isfinite(brightness_scale) || brightness_scale < 0)
        return failure(PointDetectorFailure::InvalidInput);
    try {
        // The norm is scale-safe and encloses every orientation of the original
        // circular support; a rotated/sheared Gaussian must not be clipped by
        // an axis-only extent or a new normalized discovery filter.
        const auto norm = [](const Matrix& matrix) {
            const double scale = std::max({std::abs(matrix[0][0]), std::abs(matrix[0][1]),
                                           std::abs(matrix[1][0]), std::abs(matrix[1][1])});
            if (!(scale > 0) || !std::isfinite(scale)) return scale;
            const double a = matrix[0][0] / scale, b = matrix[0][1] / scale;
            const double c = matrix[1][0] / scale, d = matrix[1][1] / scale;
            const double aa = a * a + b * b, bb = c * c + d * d, ab = a * c + b * d;
            return scale * std::sqrt(.5 * (aa + bb + std::hypot(aa - bb, 2 * ab)));
        };
        Coordinate lower = footprints.front().centre, upper = lower;
        std::vector<Matrix> inverses;
        for (const auto& footprint : footprints) {
            for (int axis = 0; axis < 2; ++axis) {
                if (!std::isfinite(footprint.centre[axis]))
                    return failure(PointDetectorFailure::InvalidInput);
                lower[axis] = std::min(lower[axis], footprint.centre[axis]);
                upper[axis] = std::max(upper[axis], footprint.centre[axis]);
            }
            for (const auto& row : footprint.chart_from_standard)
                for (const double value : row)
                    if (!std::isfinite(value)) return failure(PointDetectorFailure::InvalidInput);
            const auto x = Solve(footprint.chart_from_standard, {1, 0});
            const auto y = Solve(footprint.chart_from_standard, {0, 1});
            if (!x || !y) return failure(PointDetectorFailure::InvalidInput);
            inverses.push_back({{{(*x)[0], (*y)[0]}, {(*x)[1], (*y)[1]}}});
        }
        const Coordinate centre{lower[0] + (upper[0] - lower[0]) * .5,
                                lower[1] + (upper[1] - lower[1]) * .5};
        double scale = 0;
        for (const auto& footprint : footprints)
            scale = std::max(scale, .25 * std::hypot(footprint.centre[0] - centre[0],
                                                     footprint.centre[1] - centre[1]) +
                                        norm(footprint.chart_from_standard));
        scale = std::nextafter(
            scale * (1 + policy.root_error + 128 * std::numeric_limits<double>::epsilon()),
            std::numeric_limits<double>::infinity());
        if (!std::isfinite(scale) || !(scale > 0))
            return failure(PointDetectorFailure::InvalidInput);
        double inverse_scale = 1;
        for (const auto& inverse : inverses)
            inverse_scale = std::max(inverse_scale, scale * norm(inverse));
        if (!std::isfinite(inverse_scale)) return failure(PointDetectorFailure::InvalidInput);
        auto discovery_policy = policy;
        discovery_policy.root_error /= inverse_scale;
        // Entirely hidden regions cannot disappear merely because this batch
        // spans more than one original sample. Keep at least the narrowest
        // original visibility resolution there, including disconnected islands.
        const auto extra_depth =
            static_cast<unsigned>(std::min(21.0, std::ceil(std::log2(inverse_scale))));
        const PointDetectorSampler normalized =
            [&](const Coordinate& z) -> std::expected<PointDetectorProbe, PointDetectorFailure> {
            auto point = sample({centre[0] + scale * z[0], centre[1] + scale * z[1]});
            if (point)
                for (auto& row : point->source_derivative)
                    for (auto& value : row) value *= scale;
            return point;
        };
        PointDetectorProbeBatchSampler normalized_batch;
        if (sample_batch)
            normalized_batch = [&](std::span<const Coordinate> coordinates) {
                std::vector<Coordinate> chart;
                chart.reserve(coordinates.size());
                for (const auto& z : coordinates)
                    chart.push_back({centre[0] + scale * z[0], centre[1] + scale * z[1]});
                auto values = sample_batch(chart);
                for (auto& point : values)
                    if (point)
                        for (auto& row : point->source_derivative)
                            for (auto& value : row) value *= scale;
                return values;
            };
        PointDetectorDarkCell normalized_dark;
        if (dark_cell)
            normalized_dark = [&](const Coordinate& lower, const Coordinate& upper,
                                  unsigned splits) {
                using finite_tail::Range;
                std::array<Range, 2> region;
                for (int i = 0; i < 2; ++i)
                    region[i] = Range(centre[i]) + Range(scale) * Range(lower[i], upper[i]);
                return region[0].Finite() && region[1].Finite() &&
                       dark_cell({region[0].lo, region[1].lo}, {region[0].hi, region[1].hi},
                                 splits);
            };
        std::vector<std::size_t> images;
        Detector engine(catalogue, brightness_scale, normalized, cancelled, discovery_policy,
                        normalized_batch, normalized_dark, policy.minimum_depth + extra_depth);
        const auto discovery = engine.Run(&images);
        if (!discovery) return std::unexpected(discovery.error());
        statistics = discovery->statistics;
        PointDetectorBatchResult result;
        result.samples.resize(footprints.size());
        result.statistics = statistics;
        for (std::size_t packet = 0; packet < footprints.size(); ++packet) {
            const auto& footprint = footprints[packet];
            const auto& inverse = inverses[packet];
            const double inverse_norm = norm(inverse);
            const double conditioning = norm(footprint.chart_from_standard) * inverse_norm;
            if (!std::isfinite(conditioning)) return failure(PointDetectorFailure::Unresolved);
            auto map = footprint.chart_from_standard;
            for (auto& row : map)
                for (auto& value : row) value /= scale;
            auto& output = result.samples[packet];
            for (const auto index : images) {
                const auto image = engine.Image(index);
                if (cancelled && cancelled()) return failure(PointDetectorFailure::Cancelled);
                const Coordinate delta{(centre[0] - footprint.centre[0]) + scale * image.z[0],
                                       (centre[1] - footprint.centre[1]) + scale * image.z[1]};
                const Coordinate original{inverse[0][0] * delta[0] + inverse[0][1] * delta[1],
                                          inverse[1][0] * delta[0] + inverse[1][1] * delta[1]};
                const double radius = std::hypot(original[0], original[1]);
                const double uncertainty =
                    scale * inverse_norm * image.uncertainty +
                    64 * std::numeric_limits<double>::epsilon() * conditioning * (1 + radius);
                // The original hard support cannot be decided from a root
                // interval that straddles it. Keep the entire batch private so
                // its caller can resolve that original packet independently.
                if (std::abs(radius - 4) <= uncertainty)
                    return failure(PointDetectorFailure::Unresolved);
                // A resolved image outside this original support contributes
                // exactly zero; do not compose or transfer an unused density.
                if (radius > 4 && std::isfinite(radius)) continue;
                const auto response = core::MakePointImageResponse(image.point.source_derivative,
                                                                   map, policy.geometry_error);
                if (!response) return failure(PointDetectorFailure::Unresolved);
                const auto density = response->DensityAtOriginalRoot(original);
                if (!density) return failure(PointDetectorFailure::Arithmetic);
                if (*density == 0) continue;
                const auto& star = catalogue.Stars()[image.star];
                const auto rgb = core::spectral::TransferPointSourceBand(
                    star.temperature_K, image.point.camera_over_source_frequency,
                    static_cast<double>(star.Intensity()) * brightness_scale, *density);
                if (!rgb) return failure(PointDetectorFailure::Arithmetic);
                const double correction =
                    std::hypot(image.z[0] - image.previous_z[0], image.z[1] - image.previous_z[1]);
                Rgb prior_rgb{};
                if (correction > 0) {
                    const auto prior = core::MakePointImageResponse(
                        image.previous.source_derivative, map, policy.geometry_error);
                    if (!prior) return failure(PointDetectorFailure::Unresolved);
                    const auto prior_density = prior->DensityAtOriginalRoot(original);
                    if (!prior_density) return failure(PointDetectorFailure::Arithmetic);
                    const auto transferred = core::spectral::TransferPointSourceBand(
                        star.temperature_K, image.previous.camera_over_source_frequency,
                        static_cast<double>(star.Intensity()) * brightness_scale, *prior_density);
                    if (!transferred) return failure(PointDetectorFailure::Arithmetic);
                    for (int channel = 0; channel < 3; ++channel)
                        prior_rgb[channel] = (*transferred)[channel] * image.previous.transmission;
                }
                const double weight_error =
                    std::expm1(4 * uncertainty + .5 * uncertainty * uncertainty);
                for (int channel = 0; channel < 3; ++channel) {
                    const double contribution = (*rgb)[channel] * image.point.transmission;
                    const double smooth_error =
                        correction > 0 ? 2 * std::abs(contribution - prior_rgb[channel]) *
                                             image.uncertainty / correction
                                       : 0;
                    output.rgb[channel] += contribution;
                    output.estimated_error[channel] +=
                        smooth_error +
                        contribution * (weight_error + response->arithmetic_area_bound +
                                        128 * std::numeric_limits<double>::epsilon());
                    if (!std::isfinite(output.rgb[channel]) ||
                        !std::isfinite(output.estimated_error[channel]))
                        return failure(PointDetectorFailure::Arithmetic);
                }
            }
            for (int channel = 0; channel < 3; ++channel)
                if (output.estimated_error[channel] >
                    policy.absolute_rgb_error + policy.relative_rgb_error * output.rgb[channel])
                    return failure(PointDetectorFailure::Unresolved);
        }
        return result;
    } catch (const std::bad_alloc&) {
        return failure(PointDetectorFailure::WorkLimit);
    }
}

std::expected<PointDetectorBatchResult, PointDetectorError> EvaluatePointDetectorGroup(
    const core::StarfieldSpatialIndex& catalogue, double brightness_scale,
    std::span<const PointDetectorFootprint> footprints, const PointDetectorSampler& sample,
    const std::function<bool()>& cancelled, const PointDetectorPolicy& policy,
    const PointDetectorProbeBatchSampler& sample_batch, const PointDetectorDarkCell& dark_cell,
    const PointDetectorFootprintBound& footprint_bound) {
    PointDetectorStatistics statistics;
    const auto failure = [&](PointDetectorFailure reason) {
        return std::unexpected(PointDetectorError{reason, statistics});
    };
    if (footprints.empty() || footprints.size() > kPointDetectorBatchCapacity || !sample ||
        !ValidPolicy(policy) || !std::isfinite(brightness_scale) || brightness_scale < 0)
        return failure(PointDetectorFailure::InvalidInput);
    // Failed discovery still performed real work. Add operation counts, but
    // caches are sequential and their peak reservation is the maximum, not sum.
    const auto account = [&](const PointDetectorStatistics& work) {
        statistics.probes += work.probes;
        statistics.probe_requests += work.probe_requests;
        statistics.probe_cache_comparisons += work.probe_cache_comparisons;
        statistics.probe_batches += work.probe_batches;
        statistics.maximum_probe_batch =
            std::max(statistics.maximum_probe_batch, work.maximum_probe_batch);
        statistics.cells += work.cells;
        statistics.candidate_visits += work.candidate_visits;
        statistics.newton_steps += work.newton_steps;
        statistics.roots += work.roots;
        statistics.inner_attempts += work.inner_attempts;
        statistics.tail_attempts += work.tail_attempts;
        statistics.reserved_cache_bytes =
            std::max(statistics.reserved_cache_bytes, work.reserved_cache_bytes);
        statistics.maximum_root_coordinate_error =
            std::max(statistics.maximum_root_coordinate_error, work.maximum_root_coordinate_error);
    };
    try {
        // Validate geometry before any spatial ordering. In particular, NaN
        // centres must never enter a comparator and singular kernels must not
        // be retried as if they were merely difficult discovery envelopes.
        for (const auto& footprint : footprints) {
            for (const double value : footprint.centre)
                if (!std::isfinite(value)) return failure(PointDetectorFailure::InvalidInput);
            for (const auto& row : footprint.chart_from_standard)
                for (const double value : row)
                    if (!std::isfinite(value)) return failure(PointDetectorFailure::InvalidInput);
            if (!Solve(footprint.chart_from_standard, {1, 0}) ||
                !Solve(footprint.chart_from_standard, {0, 1}))
                return failure(PointDetectorFailure::InvalidInput);
        }
        PointDetectorBatchResult result;
        result.samples.resize(footprints.size());
        std::vector<std::size_t> indices(footprints.size());
        std::iota(indices.begin(), indices.end(), 0);
        std::size_t remaining_shared_probes = std::max<std::size_t>(1024, 128 * footprints.size());
        const auto evaluate =
            [&](auto&& self, std::span<std::size_t> subset) -> std::optional<PointDetectorFailure> {
            if (cancelled && cancelled()) return PointDetectorFailure::Cancelled;
            if (subset.size() > 1 && remaining_shared_probes >= 512) {
                std::vector<PointDetectorFootprint> packets;
                packets.reserve(subset.size());
                for (const auto index : subset) packets.push_back(footprints[index]);
                auto shared_policy = policy;
                shared_policy.maximum_probes =
                    std::min(policy.maximum_probes, remaining_shared_probes);
                const auto batch =
                    EvaluatePointDetectorBatch(catalogue, brightness_scale, packets, sample,
                                               cancelled, shared_policy, sample_batch, dark_cell);
                const auto& work = batch ? batch->statistics : batch.error().statistics;
                account(work);
                remaining_shared_probes -= std::min(remaining_shared_probes, work.probes);
                if (batch) {
                    for (std::size_t i = 0; i < subset.size(); ++i)
                        result.samples[subset[i]] = batch->samples[i];
                    return std::nullopt;
                }
                // Inputs were validated above. An invalid derived envelope
                // (overflow or an unrepresentable scaled root tolerance) can
                // still leave smaller original footprints represented.
                if (batch.error().reason == PointDetectorFailure::Cancelled)
                    return batch.error().reason;
            }
            if (subset.size() == 1 || remaining_shared_probes < 512) {
                for (const auto index : subset) {
                    const auto& footprint = footprints[index];
                    const auto& m = footprint.chart_from_standard;
                    const PointDetectorSampler original = [&](const Coordinate& z)
                        -> std::expected<PointDetectorProbe, PointDetectorFailure> {
                        auto point =
                            sample({footprint.centre[0] + (m[0][0] * z[0] + m[0][1] * z[1]),
                                    footprint.centre[1] + (m[1][0] * z[0] + m[1][1] * z[1])});
                        if (!point) return point;
                        const auto derivative = point->source_derivative;
                        for (int row = 0; row < 2; ++row)
                            for (int col = 0; col < 2; ++col)
                                point->source_derivative[row][col] =
                                    derivative[row][0] * m[0][col] + derivative[row][1] * m[1][col];
                        return point;
                    };
                    PointDetectorProbeBatchSampler original_batch;
                    if (sample_batch)
                        original_batch = [&](std::span<const Coordinate> coordinates) {
                            std::vector<Coordinate> chart;
                            chart.reserve(coordinates.size());
                            for (const auto& z : coordinates)
                                chart.push_back(
                                    {footprint.centre[0] + (m[0][0] * z[0] + m[0][1] * z[1]),
                                     footprint.centre[1] + (m[1][0] * z[0] + m[1][1] * z[1])});
                            auto values = sample_batch(chart);
                            for (auto& point : values)
                                if (point) {
                                    const auto derivative = point->source_derivative;
                                    for (int row = 0; row < 2; ++row)
                                        for (int col = 0; col < 2; ++col)
                                            point->source_derivative[row][col] =
                                                derivative[row][0] * m[0][col] +
                                                derivative[row][1] * m[1][col];
                                }
                            return values;
                        };
                    PointDetectorDarkCell original_dark;
                    if (dark_cell)
                        original_dark = [&](const Coordinate& lower, const Coordinate& upper,
                                            unsigned splits) {
                            using finite_tail::Range;
                            const Range x(lower[0], upper[0]), y(lower[1], upper[1]);
                            std::array<Range, 2> region;
                            for (int i = 0; i < 2; ++i)
                                region[i] = Range(footprint.centre[i]) +
                                            (Range(m[i][0]) * x + Range(m[i][1]) * y);
                            return region[0].Finite() && region[1].Finite() &&
                                   dark_cell({region[0].lo, region[1].lo},
                                             {region[0].hi, region[1].hi}, splits);
                        };
                    ScalarFootprintBound original_bound;
                    if (footprint_bound)
                        original_bound = [&](std::span<const PointDetectorCell> cells,
                                             std::size_t& remaining) {
                            return footprint_bound(footprint, cells, remaining);
                        };
                    const auto leaf = Detector(catalogue, brightness_scale, original, cancelled,
                                               policy, original_batch, original_dark, 0,
                                               original_bound ? &original_bound : nullptr)
                                          .Run();
                    account(leaf ? leaf->statistics : leaf.error().statistics);
                    if (!leaf) {
                        const auto& used=leaf.error().statistics;
                        std::fprintf(stderr, "leaf_decline index=%zu centre=%a,%a probes=%zu cells=%zu visits=%zu reason=%d\n",
                            index, footprint.centre[0], footprint.centre[1], used.probes, used.cells,
                            used.candidate_visits, int(leaf.error().reason));
                        return leaf.error().reason;
                    }
                    result.samples[index] = {leaf->rgb, leaf->estimated_error};
                }
                return std::nullopt;
            }
            Coordinate lower = footprints[subset.front()].centre, upper = lower;
            for (const auto index : subset)
                for (int axis = 0; axis < 2; ++axis) {
                    lower[axis] = std::min(lower[axis], footprints[index].centre[axis]);
                    upper[axis] = std::max(upper[axis], footprints[index].centre[axis]);
                }
            const int axis = upper[1] - lower[1] > upper[0] - lower[0] ? 1 : 0;
            std::sort(subset.begin(), subset.end(), [&](std::size_t a, std::size_t b) {
                const double first = footprints[a].centre[axis],
                             second = footprints[b].centre[axis];
                return first == second ? a < b : first < second;
            });
            const auto middle = subset.size() / 2;
            if (const auto error = self(self, subset.first(middle))) return error;
            return self(self, subset.subspan(middle));
        };
        if (const auto error = evaluate(evaluate, std::span(indices))) return failure(*error);
        result.statistics = statistics;
        return result;
    } catch (const std::bad_alloc&) {
        return failure(PointDetectorFailure::WorkLimit);
    }
}

}  // namespace sirius::render

#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"
#include "sirius/render/session/kerr_point_detector.h"

#include <iomanip>
#include <iostream>

using namespace sirius;
using namespace sirius::render;

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil = camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u,
                                                     sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const core::PointStarfieldConfig stars;
    const core::StarfieldSpatialIndex catalogue(core::StarfieldGenerator(
        core::ExpandPointStarfieldConfig(stars)).GenerateCatalogue());
    const auto indexed = PrepareKerrDetectorCatalogue(catalogue);
    const PointDetectorFootprint footprint{
        {0, 22}, {{{0x1.d323e59e01b7bp-1, -0x1.9662de6ca9f26p-9}, {0, 0x1.d520d6948dde7p-1}}}};
    constexpr std::array cells{
        PointDetectorCell{{-0x1.9e98p+1,0x1.2c78p+1}, {-0x1.9e9p+1,0x1.2c8p+1}},
        PointDetectorCell{{-0x1.9e9p+1,0x1.2c78p+1}, {-0x1.9e88p+1,0x1.2c8p+1}},
        PointDetectorCell{{-0x1.9e9p+1,0x1.2c8p+1}, {-0x1.9e88p+1,0x1.2c88p+1}},
        PointDetectorCell{{-0x1.9e88p+1,0x1.2c8p+1}, {-0x1.9e8p+1,0x1.2c88p+1}},
        PointDetectorCell{{-0x1.9e88p+1,0x1.2c88p+1}, {-0x1.9e8p+1,0x1.2c9p+1}},
        PointDetectorCell{{-0x1.9e8p+1,0x1.2c88p+1}, {-0x1.9e78p+1,0x1.2c9p+1}},
        PointDetectorCell{{-0x1.9e8p+1,0x1.2c9p+1}, {-0x1.9e78p+1,0x1.2c98p+1}}
    };
    const PointDetectorPolicy policy;
    auto remaining = policy.maximum_candidate_visits;
    const auto bound = BoundKerrDetectorCells(*indexed, stars.brightness_scale, config, *launch,
                                            origin, footprint, cells, {}, remaining);
    std::cout << "device=" << info.name << " provider=" << info.driver_name
              << " visit_debit=" << policy.maximum_candidate_visits - remaining;
    if (!bound) {
        std::cout << " result=declined\n";
        return 27;
    }
    std::cout << std::setprecision(17) << " rgb_bound=" << (*bound)[0]
              << " absolute_policy=" << policy.absolute_rgb_error << '\n';
    return (*bound)[0] > 0 && (*bound)[0] < policy.absolute_rgb_error ? 0 : 28;
}

#pragma once

#include "sirius/core/kerr_detector/finite_screen.h"

namespace sirius::core::relativity::finite_tail_detail {

using SignedPolarCoordinates =
    std::array<Range, 3>;  // u, log(s), signed angle from the polar turn.
using SignedPolarJacobian =
    std::array<SignedPolarCoordinates, 3>;  // |mu|, radial time minus polar time, azimuth.

struct SignedPolarGeometry {
    double mass, spin;
    Range inverse_start, launch_mu, fixed_azimuth;
    unsigned winding;
};

inline bool ValidSignedPolarBox(const SignedPolarCoordinates& domain) {
    if (!std::ranges::all_of(domain, &Range::Finite)) return false;
    // Restrict to a single half-libration between consecutive equator
    // crossings. Its midpoint is the polar turn, with no inverse sine.
    const Range angle = kPiBounds * Range(.5) + domain[2];
    return angle.lo >= 0.0 && angle.hi <= kPiBounds.hi;
}

inline std::optional<SignedPolarCoordinates> EvaluateSignedPolar(
    const SignedPolarGeometry& geometry, const SignedPolarCoordinates& domain) {
    if (!ValidSignedPolarBox(domain)) return {};
    const auto& [u, log_s, angle_from_turn] = domain;
    const Range s = ExpBounds(log_s);
    const auto shape = MakeFinitePolarShape(geometry.mass, geometry.spin, u, s);
    const auto radial =
        EvaluateFiniteRadialPhase(geometry.mass, geometry.spin, u, s, geometry.inverse_start);
    if (!shape || !radial) return {};
    const Range half_pi = kPiBounds * Range(.5);
    const Range angle = half_pi + angle_from_turn;
    const Range amplitude = sqrt(shape->amplitude2);
    const auto half = IntegratePolarPartial(*shape, half_pi);
    const auto launch = IntegratePolarPartial(*shape, AsinBounds(geometry.launch_mu / amplitude));
    const auto exit = IntegratePolarPartial(*shape, angle);
    PhasePair target;
    for (unsigned coordinate = 0; coordinate < 2; ++coordinate) {
        target[coordinate] = Range(2.0 * geometry.winding) * half[coordinate] + launch[coordinate] +
                             exit[coordinate];
    }
    const Range radial_time = Range(-2.0) * radial->leading * log_s + radial->time_residual;
    const SignedPolarCoordinates result{
        amplitude * SineLobe(angle),
        radial_time - target[0],
        geometry.fixed_azimuth -
            (target[1] + radial->drag_at_turn * target[0] + radial->spin_residual),
    };
    if (!std::ranges::all_of(result, &Range::Finite)) return {};
    return result;
}

inline std::optional<SignedPolarJacobian> DifferentiateSignedPolar(
    const SignedPolarGeometry& geometry, const SignedPolarCoordinates& domain) {
    if (!ValidSignedPolarBox(domain)) return {};
    const auto& [u, log_s, angle_from_turn] = domain;
    const Range s = ExpBounds(log_s);
    const auto radial = EncloseRegularizedRadialPhase(geometry.mass, geometry.spin, u, s,
                                                      geometry.inverse_start, 128);
    if (!radial) return {};
    const FilmJet radius(u, {Range(1.0), Range(0.0)});
    const FilmJet separation(s, {Range(0.0), s});  // derivatives in u and log(s)
    const auto constants = InvertStationaryScalars(
        geometry.mass, geometry.spin, std::array{radius, FilmJet(0.0) - Square(separation)});
    if (!constants) return {};
    const FilmJet spin2 = Square(FilmJet(geometry.spin));
    const FilmJet b = spin2 - constants->eta - Square(constants->lambda);
    const FilmJet omega2 =
        (sqrt(Square(b) + FilmJet(4.0) * spin2 * constants->eta) - b) * FilmJet(.5);
    const FilmJet amplitude2 = constants->eta / omega2;
    const FilmJet amplitude = sqrt(amplitude2);
    const FilmJet drag(radial->limiting_drag,
                       {radial->drag_gradient[0], s * radial->drag_gradient[1]});
    const auto density = [&](Range polar_angle) {
        const FilmJet sine2(Square(SineLobe(polar_angle)));
        const FilmJet time = FilmJet(1.0) / sqrt(omega2 + spin2 * amplitude2 * sine2);
        const FilmJet longitude =
            time * (constants->lambda / (FilmJet(1.0) - amplitude2 * sine2) + drag);
        return std::array{time, longitude};
    };
    const auto integrate = [&](const FilmJet& endpoint) {
        std::array<FilmJet, 2> result{};
        constexpr unsigned panels = 128;
        for (unsigned i = 0; i < panels; ++i) {
            // Parameter derivatives at a fixed angle, followed by the
            // endpoint term from Leibniz's rule. Only the launch endpoint
            // depends on u or s in this chart.
            const auto values = density(endpoint.value * (Range(i, i + 1) / Range(panels)));
            for (unsigned axis = 0; axis < 2; ++axis)
                result[axis] =
                    result[axis] + values[axis] * FilmJet(endpoint.value / Range(panels));
        }
        const auto at_end = density(endpoint.value);
        for (unsigned axis = 0; axis < 2; ++axis)
            for (unsigned direction = 0; direction < 2; ++direction)
                result[axis].derivative[direction] =
                    result[axis].derivative[direction] +
                    at_end[axis].value * endpoint.derivative[direction];
        return result;
    };
    const auto launch_ratio = FilmJet(geometry.launch_mu) / amplitude;
    const Range launch_cosine = sqrt(Range(1.0) - Square(launch_ratio.value));
    const FilmJet launch_angle(
        AsinBounds(launch_ratio.value),
        {launch_ratio.derivative[0] / launch_cosine, launch_ratio.derivative[1] / launch_cosine});
    const Range half_pi = kPiBounds * Range(.5);
    const Range angle = half_pi + angle_from_turn;
    const auto half = integrate(FilmJet(half_pi));
    const auto launch = integrate(launch_angle);
    const auto exit = integrate(FilmJet(angle));
    std::array<FilmJet, 2> target;
    for (unsigned axis = 0; axis < 2; ++axis)
        target[axis] = FilmJet(2.0 * geometry.winding) * half[axis] + launch[axis] + exit[axis];

    const Range tau_u =
        Range(-2.0) * radial->leading_gradient[0] * log_s + radial->time_remainder.radial;
    const auto rates = density(angle);
    const Range sine = SineLobe(angle);
    const Range cosine(CosPoint(angle.hi).lo, CosPoint(angle.lo).hi);
    const SignedPolarJacobian result{{
        {amplitude.derivative[0] * sine, amplitude.derivative[1] * sine, amplitude.value * cosine},
        {tau_u - target[0].derivative[0], radial->time_log_derivative - target[0].derivative[1],
         Range(0.0) - rates[0].value},
        {Range(0.0) - (target[1].derivative[0] + radial->spin_remainder.radial),
         Range(0.0) - (target[1].derivative[1] + radial->spin_remainder.log_scale),
         Range(0.0) - rates[1].value},
    }};
    for (const auto& row : result)
        if (!std::ranges::all_of(row, &Range::Finite)) return {};
    return result;
}

struct SignedPolarResponse {
    Range latitude_time_determinant;
    Range longitude_slope;
    Range sky_determinant;
};

inline std::optional<SignedPolarResponse> EncloseSignedPolarResponse(const SignedPolarJacobian& j) {
    const auto& [mu, time, phi] = j;
    const Range det = mu[0] * time[1] - mu[1] * time[0];
    if (!(Abs(det).lo > 0.0 && time[2].hi < 0.0)) return {};
    const Range reciprocal = Range(det.lo > 0.0 ? 1.0 : -1.0) / Abs(det);
    // Hold the star's latitude and the radial/polar time equality fixed
    // while varying the signed polar phase.
    const Range u_p = (mu[1] * time[2] - time[1] * mu[2]) * reciprocal;
    const Range log_s_p = (time[0] * mu[2] - mu[0] * time[2]) * reciprocal;
    const Range phi_p = phi[2] + phi[0] * u_p + phi[1] * log_s_p;
    const Range sky_det = det * phi_p / (Range(0.0) - time[2]);
    if (!phi_p.Finite() || !sky_det.Finite()) return {};
    return SignedPolarResponse{det, phi_p, sky_det};
}

}  // namespace sirius::core::relativity::finite_tail_detail

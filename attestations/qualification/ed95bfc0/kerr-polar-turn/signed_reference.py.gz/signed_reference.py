"""Check the signed phase values using the archived independent Decimal quartic."""
from decimal import Decimal as D, localcontext
import gzip
import re
from pathlib import Path

archive = "attestations/qualification/fa11353e/kerr-finite-windings/reference.py.gz"
source = gzip.decompress(Path(archive).read_bytes()).decode().split("\nlines=Path(", 1)[0]
reference = {}
exec(compile(source, archive, "exec"), reference)
A = D.from_float(.9)
PI = D("3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865133")

def real(value):
    return D.from_float(float.fromhex(value))

def bounds(row, label):
    low, high = re.search(rf" {label}=\[([^,]+),([^\]]+)\]", row).groups()
    return real(low), real(high)

def point(row, label):
    return real(re.search(rf" {label}=([^ ]+)", row)[1])

def midpoint(pair):
    return (pair[0]+pair[1])/2

def sine(x):
    term = result = x
    for n in range(1, 56):
        term *= -x*x/D(2*n*(2*n+1))
        result += term
    return result

def small_asin(x):
    assert 0 < x < D(".2")
    term = result = x
    for n in range(1, 64):
        term *= x*x * D((2*n-1)**2) / D(2*n*(2*n+1))
        result += term
    return result

def polar(u, s, launch_mu, phase, panels):
    co = reference["inverse_by_newton"](u, -s*s)
    carter = co[3]/2
    z = (co[2]+carter)/2
    angular = (A*A-z)/A
    eta = carter-(angular-A)**2
    b = A*A - eta - angular*angular
    omega2 = ((b*b+4*A*A*eta).sqrt()-b)/2
    amplitude2 = eta/omega2
    amplitude = amplitude2.sqrt()

    def integrate(angle):
        h = angle/panels
        time = phi = D(0)
        for i in range(panels+1):
            node = sine(h*i)**2
            density = 1/(omega2 + A*A*amplitude2*node).sqrt()
            weight = 1 if i in (0, panels) else 4 if i%2 else 2
            time += weight*density
            phi += weight*density*angular/(1-amplitude2*node)
        return h*time/3, h*phi/3

    theta = PI/2 + phase
    start = small_asin(launch_mu/amplitude)
    return (amplitude*sine(theta), integrate(PI), integrate(start), integrate(theta))

def assert_contains(row, label, value):
    low, high = bounds(row, label)
    assert low <= value <= high, (label, low, value, high)

rows=Path(__file__).with_name("signed.log").read_text().splitlines()
pupil=next(row for row in rows if row.startswith("pupil "))
with localcontext() as ctx:
    ctx.prec=110
    inverse_start=midpoint(bounds(pupil, "start"))
    launch_mu=midpoint(bounds(pupil, "mu"))
    source_origin=midpoint(bounds(pupil, "phi"))
    for row in rows:
        if not row.startswith("reference_point "):
            continue
        winding = int(re.search(r" winding=(\d+)", row)[1])
        if winding not in (9,69):
            continue
        u = point(row, "u0")
        v = point(row, "log_s0")
        phase = point(row, "phase0")
        s = v.exp()
        _, residual, radial_time, _, drag = reference["full_integrals"](u, s, inverse_start, 1536)
        latitude, cycle, launch, final = polar(u, s, launch_mu, phase, 2048)
        target_time = D(winding)*cycle[0]+launch[0]+final[0]
        target_phi = D(winding)*cycle[1]+launch[1]+final[1]
        # On the time surface target_time equals radial_time. Use the same
        # continuous extension away from the surface when checking values.
        azimuth = source_origin-(target_phi+drag*target_time+residual)
        assert_contains(row, "latitude", latitude)
        assert_contains(row, "time_residual", radial_time-target_time)
        assert_contains(row, "azimuth", azimuth)
        print(f"winding={winding} phase={float(phase).hex()} latitude={latitude:.20g} "
              f"time_residual={radial_time-target_time:.20g} longitude={azimuth:.20g} enclosed=1")

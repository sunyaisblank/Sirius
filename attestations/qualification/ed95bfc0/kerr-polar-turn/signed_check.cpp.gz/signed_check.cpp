#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "../../src/sirius/render/session/kerr_point_detector.cpp"
#include "turn_certificate.h"

#include <iomanip>
#include <iostream>

using namespace sirius;
using namespace sirius::render;

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const PointDetectorFootprint footprint{
        {0, 22}, {{{0x1.d323e59e01b7bp-1, -0x1.9662de6ca9f26p-9}, {0, 0x1.d520d6948dde7p-1}}}};

    using namespace core::relativity::finite_tail_detail;

    const FilmVector cell{Range(-0x1.9de8p+1, -0x1.9dep+1), Range(0x1.2dp+1, 0x1.2d08p+1)};
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    const auto whole = evaluate(cell), anchor = evaluate(FilmMidpoint(cell));
    if (!whole || !anchor) return 40;
    const auto critical = CoverEscapingChart(cell, *whole, evaluate);
    if (!critical[0].Finite() || !critical[1].Finite() || !(critical[1].lo < 0.0)) return 41;
    const Range star_mu(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
    const Range star_azimuth(-0x1.1dcd0ee4d9734p+1, -0x1.1dcd0ee4d972dp+1);
    const double radius = std::midpoint(0x1.c01a569776898p-2, 0x1.c01a569776acep-2);
    const auto shape = MakeFinitePolarShape(1, .9, Range(radius), Range(0.0));
    const auto critical_radial =
        EvaluateFiniteRadialPhase(1, .9, Range(radius), Range(0.0), whole->inverse_start);
    if (!shape || !critical_radial) return 42;
    const Range launch_phase = AsinBounds(whole->initial_mu / sqrt(shape->amplitude2));
    const Range half_pi = kPiBounds * Range(.5);
    const auto half = IntegratePolarPartial(*shape, half_pi);
    const auto initial = IntegratePolarPartial(*shape, launch_phase);
    const Range fixed_azimuth = FixedPupilAzimuth(1, .9, *whole);
    if (!fixed_azimuth.Finite()) return 43;
    const auto print = [](std::string_view label, Range value) {
        std::cout << ' ' << label << "=[" << value.lo << ',' << value.hi << ']';
    };
    std::cout << std::hexfloat << "pupil";
    print("start", whole->inverse_start);
    print("mu", whole->initial_mu);
    print("phi", fixed_azimuth);
    std::cout << '\n';
    const Range signed_phase(-0x1p-12, 0x1p-12);
    for (const unsigned winding : {9u, 21u, 69u, 129u}) {
        const SignedPolarGeometry geometry{
            1.0, .9, whole->inverse_start, whole->initial_mu, fixed_azimuth, winding};
        const Range log =
            (critical_radial->time_residual - Range(2.0 * winding + 1.0) * half[0] - initial[0]) /
            (Range(2.0) * critical_radial->leading);
        if (!log.Finite()) return 44;
        const SignedPolarCoordinates domain{Range(radius - 0x1p-20, radius + 0x1p-20),
                                            log + Range(-0.025, 0.025), signed_phase};
        const auto branch = ProveSignedLatitudeTimeBranch(geometry, domain, star_mu);
        if (!branch) {
            std::cerr << "branch declined winding=" << winding << '\n';
            return 45;
        }
        const SignedPolarCoordinates enclosure{(*branch)[0], (*branch)[1], signed_phase};
        const auto slopes = DifferentiateSignedPolar(geometry, enclosure);
        const auto response = slopes ? EncloseSignedPolarResponse(*slopes) : std::nullopt;
        if (!response || !(Abs(response->sky_determinant).lo > 0.0)) return 46;
        const Range h = Range(0.0) - Square(ExpBounds((*branch)[1]));
        const auto film = ProveInverseImage(
            cell, {anchor->coordinate[0] - (*branch)[0], anchor->coordinate[1] - h},
            whole->jacobian);
        if (!film) return 47;
        const Range film_r2 = Square((*film)[0]) + Square((*film)[1]);
        if (!(film_r2.hi < 16.0)) return 48;
        const auto forward = EvaluateSignedPolar(geometry, enclosure);
        if (!forward) return 49;
        const bool may_match = AzimuthMayMatch((*forward)[2], star_azimuth);
        std::cout << "signed_branch winding=" << winding;
        print("u", (*branch)[0]);
        print("log_s", (*branch)[1]);
        print("phase", signed_phase);
        print("time_latitude_det", response->latitude_time_determinant);
        print("longitude_slope", response->longitude_slope);
        print("sky_det", response->sky_determinant);
        print("azimuth", (*forward)[2]);
        print("film_r2", film_r2);
        std::cout << " possible_star_longitude=" << may_match << '\n';
        for (double signed_sample : {signed_phase.lo, signed_phase.hi}) {
            const double u = std::midpoint((*branch)[0].lo, (*branch)[0].hi);
            const double v = std::midpoint((*branch)[1].lo, (*branch)[1].hi);
            const auto value =
                EvaluateSignedPolar(geometry, {Range(u), Range(v), Range(signed_sample)});
            if (!value) return 50;
            std::cout << "reference_point winding=" << winding << " u0=" << u << " log_s0=" << v
                      << " phase0=" << signed_sample;
            print("latitude", (*value)[0]);
            print("time_residual", (*value)[1]);
            print("azimuth", (*value)[2]);
            std::cout << '\n';
        }
    }
}

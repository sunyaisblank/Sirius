#pragma once

#include "signed_polar.h"

namespace sirius::core::relativity::finite_tail_detail {

inline FilmVector FilmMidpoint(const FilmVector& box) {
    return {Range(std::midpoint(box[0].lo, box[0].hi)), Range(std::midpoint(box[1].lo, box[1].hi))};
}

inline std::optional<FilmVector> ProveInverseImage(const FilmVector& box,
                                                   const FilmVector& midpoint_residual,
                                                   FilmMatrix jacobian) {
    const auto centre = FilmMidpoint(box);
    const FilmVector width{Range(box[0].hi - box[0].lo), Range(box[1].hi - box[1].lo)};
    if (!(width[0].lo > 0.0 && width[1].lo > 0.0)) return {};
    for (auto& row : jacobian)
        for (unsigned axis = 0; axis < 2; ++axis) row[axis] = row[axis] * width[axis];
    const auto inverse = ProveInjectiveChart(jacobian);
    if (!inverse) return {};
    FilmVector image;
    for (unsigned row = 0; row < 2; ++row) {
        Range displacement;
        for (unsigned col = 0; col < 2; ++col)
            displacement = displacement -
                           inverse->preconditioner[row][col] * midpoint_residual[col] +
                           inverse->residual[row][col] * (box[col] - centre[col]) / width[col];
        image[row] = centre[row] + width[row] * displacement;
        if (!image[row].Finite() || !(box[row].lo < image[row].lo && image[row].hi < box[row].hi))
            return {};
    }
    return image;
}

// The interval includes all signed phases, including zero, simultaneously.
// At each phase a continuous map sends the u/log(s) rectangle into its
// interior. The checked contraction gives exactly one latitude/time root.
inline std::optional<FilmVector> ProveSignedLatitudeTimeBranch(const SignedPolarGeometry& geometry,
                                                               const SignedPolarCoordinates& domain,
                                                               Range star_latitude) {
    const FilmVector box{domain[0], domain[1]};
    const auto middle = FilmMidpoint(box);
    const auto value = EvaluateSignedPolar(geometry, {middle[0], middle[1], domain[2]});
    const auto jacobian = DifferentiateSignedPolar(geometry, domain);
    if (!value || !jacobian) return {};
    return ProveInverseImage(
        box, {(*value)[0] - star_latitude, (*value)[1]},
        {{{(*jacobian)[0][0], (*jacobian)[0][1]}, {(*jacobian)[1][0], (*jacobian)[1][1]}}});
}

}  // namespace sirius::core::relativity::finite_tail_detail

#include "turn_certificate.h"

#include <iomanip>
#include <iostream>

using namespace sirius::core::relativity::finite_tail_detail;

static bool TightenForLatitudeAndTime(const SignedPolarGeometry& geometry,
                                      SignedPolarCoordinates& domain, Range source_mu) {
    const FilmVector box{domain[0], domain[1]};
    const auto centre = FilmMidpoint(box);
    const auto value = EvaluateSignedPolar(geometry, {centre[0], centre[1], domain[2]});
    const auto jacobian = DifferentiateSignedPolar(geometry, domain);
    if (!value || !jacobian) return true;
    const FilmVector residual{(*value)[0] - source_mu, (*value)[1]};
    const FilmVector width{Range(box[0].hi - box[0].lo), Range(box[1].hi - box[1].lo)};
    FilmMatrix scaled;
    for (unsigned row = 0; row < 2; ++row)
        for (unsigned col = 0; col < 2; ++col)
            scaled[row][col] = (*jacobian)[row][col] * width[col];
    const auto preconditioned = ProveInjectiveChart(scaled);
    if (!preconditioned) return true;
    for (unsigned row = 0; row < 2; ++row) {
        Range displacement;
        for (unsigned col = 0; col < 2; ++col)
            displacement = displacement -
                           preconditioned->preconditioner[row][col] * residual[col] +
                           preconditioned->residual[row][col] * (box[col] - centre[col]) / width[col];
        const Range image = centre[row] + width[row] * displacement;
        if (!image.Finite()) continue;
        if (image.hi < box[row].lo || image.lo > box[row].hi) return false;
        domain[row] = Range(std::max(box[row].lo, image.lo), std::min(box[row].hi, image.hi));
    }
    return true;
}

int main() {
    const Range u(0x1.c01a4a1e8d60bp-2, 0x1.c01a9e6094306p-2);
    const Range s(0.0, sqrt(Range(0x1.89d9044540001p-15)).hi);
    const Range source_mu(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
    const Range source_phi(-0x1.1dcd0ee4d9734p+1, -0x1.1dcd0ee4d972dp+1);
    constexpr Range start(0x1.111112f155084p-5, 0x1.111112f1550a2p-5);
    constexpr Range launch_mu(0x1.67f25c4fe005p-3, 0x1.67f25c4fe0117p-3);
    constexpr Range initial_phi(0x1.0409070a74c8p-5, 0x1.0409070a74e26p-5);
    const auto shape = MakeFinitePolarShape(1, .9, u, s);
    const auto radial = EncloseRegularizedRadialPhase(1, .9, u, s, start, 128);
    if (!shape || !radial) return 1;
    const Range amplitude = sqrt(shape->amplitude2);
    const Range cosine = source_mu / amplitude;
    const double max_sine2 = (Range(1.0) - Square(Range(cosine.lo))).hi;
    if (!(cosine.lo > 0.0 && max_sine2 > 0.0)) return 2;
    const double limit = AsinBounds(sqrt(Range(max_sine2))).hi;
    if (!std::isfinite(limit)) return 3;
    const Range p(-limit, limit);
    const Range half_pi = kPiBounds * Range(.5);
    const auto half = IntegratePolarPartial(*shape, half_pi);
    const auto first = IntegratePolarPartial(*shape, AsinBounds(launch_mu / amplitude));
    const auto last = IntegratePolarPartial(*shape, half_pi + p);
    const Range scale_edge = LogPoint(s.hi);
    std::cout << std::hexfloat << "signed_phase=[" << p.lo << ',' << p.hi << "]\n";
    unsigned outside_depth = 0, excluded = 0, possibilities = 0;
    for (unsigned winding = 1; winding <= 129; winding += 2) {  // North-source half-librations.
        const Range polar_time = Range(2.0 * winding) * half[0] + first[0] + last[0];
        const Range log_s =
            (radial->time_remainder.value - polar_time) / (Range(2.0) * radial->leading_factor);
        if (!log_s.Finite()) return 4;
        if (log_s.lo > scale_edge.hi) {
            ++outside_depth;
            continue;
        }
        const Range admissible_log(log_s.lo, std::min(log_s.hi, scale_edge.hi));
        const SignedPolarGeometry geometry{1, .9, start, launch_mu, initial_phi, winding};
        const SignedPolarCoordinates domain{u, admissible_log, p};
        const auto value = EvaluateSignedPolar(geometry, domain);
        if (!value) return 5;
        const auto& [latitude, time, azimuth] = *value;
        if (latitude.hi < source_mu.lo || latitude.lo > source_mu.hi || time.lo > 0.0 ||
            time.hi < 0.0 || !AzimuthMayMatch(azimuth, source_phi)) {
            ++excluded;
            continue;
        }
        constexpr unsigned pieces = 8;
        unsigned unresolved = 0;
        double first = p.lo;
        for (unsigned i = 1; i <= pieces; ++i) {
            const double last = i == pieces ? p.hi : std::lerp(p.lo, p.hi, double(i) / pieces);
            SignedPolarCoordinates refined{u, admissible_log, Range(first, last)};
            first = last;
            if (!TightenForLatitudeAndTime(geometry, refined, source_mu) ||
                !TightenForLatitudeAndTime(geometry, refined, source_mu))
                continue;
            const auto image = EvaluateSignedPolar(geometry, refined);
            if (image && !AzimuthMayMatch((*image)[2], source_phi)) {
                std::cout << "refined_exclusion winding=" << winding << " piece=" << i
                          << " phi=[" << (*image)[2].lo << ',' << (*image)[2].hi << "]\n";
                continue;
            }
            ++unresolved;
        }
        if (unresolved == 0) {
            ++excluded;
            continue;
        }
        ++possibilities;
        const auto jac = DifferentiateSignedPolar(geometry, domain);
        const auto response = jac ? EncloseSignedPolarResponse(*jac) : std::nullopt;
        std::cout << "possible winding=" << winding << " log_s=[" << admissible_log.lo << ','
                  << admissible_log.hi << "] azimuth=[" << azimuth.lo << ',' << azimuth.hi
                  << "] unresolved_pieces=" << unresolved;
        if (response)
            std::cout << " longitude_slope=[" << response->longitude_slope.lo << ','
                      << response->longitude_slope.hi << ']';
        std::cout << '\n';
    }
    std::cout << "outside_depth=" << outside_depth << " excluded=" << excluded
              << " possible=" << possibilities << '\n';
    return (outside_depth + excluded + possibilities) == 65 ? 0 : 6;
}

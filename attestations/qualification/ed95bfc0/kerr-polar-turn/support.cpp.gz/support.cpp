#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "../../src/sirius/render/session/kerr_point_detector.cpp"

#include <iomanip>
#include <iostream>

using namespace sirius;
using namespace sirius::render;

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const PointDetectorFootprint footprint{
        {0, 22}, {{{0x1.d323e59e01b7bp-1, -0x1.9662de6ca9f26p-9}, {0, 0x1.d520d6948dde7p-1}}}};

    using namespace core::relativity::finite_tail_detail;
    constexpr PointDetectorCell cells[]{
#include "cells.inc"
    };
    constexpr std::array<Range, 3> sources{
        Range(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1),
        Range(0x1.f4f533eb99ecfp-1, 0x1.f4f533eb99edap-1),
        Range(0x1.f4f53e06900eep-1, 0x1.f4f53e06900f8p-1),
    };
    std::array<unsigned, 3> overlaps{}, touches{}, finite{};
    std::array<Range, 3> radii{}, heights{};
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    std::cout << std::hexfloat;
    bool printed_geometry = false;
    for (std::size_t index = 0; index < std::size(cells); ++index) {
        const auto& cell = cells[index];
        FilmVector box{Range(cell.lower[0], cell.upper[0]), Range(cell.lower[1], cell.upper[1])};
        const std::array nearest{std::clamp(0.0, box[0].lo, box[0].hi),
                                 std::clamp(0.0, box[1].lo, box[1].hi)};
        for (unsigned axis = 0; axis < 2; ++axis) {
            const auto extent2 = Range(16.0) - Square(Range(nearest[1 - axis]));
            if (extent2.hi < 0) {
                box[axis] = InvalidRange();
                break;
            }
            const double extent = sqrt(Range(extent2.hi)).hi;
            box[axis] = Range(std::max(box[axis].lo, -extent), std::min(box[axis].hi, extent));
        }
        if (!box[0].Finite() || !box[1].Finite()) continue;
        const auto chart = evaluate(box);
        if (!chart) return 40;
        if (!printed_geometry) {
            const Range phi = FixedPupilAzimuth(1, .9, *chart);
            std::cout << "pupil start=[" << chart->inverse_start.lo << ','
                      << chart->inverse_start.hi << "] mu=[" << chart->initial_mu.lo << ','
                      << chart->initial_mu.hi << "] phi=[" << phi.lo << ',' << phi.hi << "]\n";
            printed_geometry = true;
        }
        const auto target = CoverEscapingChart(box, *chart, evaluate);
        if (!target[0].Finite() || !target[1].Finite()) return 41;
        if (target[1].lo >= 0) continue;
        if (index == 396) {
            const auto amplitude_sign = [&](double u) {
                const auto shape = MakeFinitePolarShape(1, .9, Range(u), Range(0.0));
                return shape ? sqrt(shape->amplitude2) - sources[0] : InvalidRange();
            };
            // Strict signs bracket a real critical radial root for every
            // represented catalogue latitude in the source interval.
            double lower = target[0].lo, upper = target[0].hi;
            if (!(amplitude_sign(lower).lo > 0.0 && amplitude_sign(upper).hi < 0.0)) return 44;
            for (unsigned i = 0; i < 52; ++i) {
                const double middle = std::midpoint(lower, upper);
                const Range sign = amplitude_sign(middle);
                if (sign.lo > 0.0)
                    lower = middle;
                else if (sign.hi < 0.0)
                    upper = middle;
                else
                    break;
            }
            const FilmVector point{Range(std::midpoint(box[0].lo, box[0].hi)),
                                   Range(std::midpoint(box[1].lo, box[1].hi))};
            const auto anchor = evaluate(point);
            const auto inverse = ProveInjectiveChart(chart->jacobian);
            if (!anchor || !inverse) return 45;
            const FilmVector value{anchor->coordinate[0] - Range(lower, upper),
                                   anchor->coordinate[1]};
            FilmVector image;
            bool inside = true;
            for (unsigned row = 0; row < 2; ++row) {
                image[row] = point[row];
                for (unsigned col = 0; col < 2; ++col) {
                    image[row] = image[row] - inverse->preconditioner[row][col] * value[col] +
                                 inverse->residual[row][col] * (box[col] - point[col]);
                }
                inside &= image[row].Finite() && image[row].lo > box[row].lo &&
                          image[row].hi < box[row].hi;
            }
            const Range support = Square(image[0]) + Square(image[1]);
            std::cout << "physical_crossing index=396 u=[" << lower << ',' << upper << "] z0=["
                      << image[0].lo << ',' << image[0].hi << "] z1=[" << image[1].lo << ','
                      << image[1].hi << "] r2=[" << support.lo << ',' << support.hi
                      << "] contraction=" << inverse->contraction << " strict_inclusion=" << inside
                      << '\n';
            if (!inside || !(support.hi < 16.0)) return 46;
        }
        const double lower_scale = target[1].hi < 0.0 ? sqrt(Range(-target[1].hi)).lo : 0.0;
        const Range scale(lower_scale, sqrt(Range(-target[1].lo)).hi);
        const auto shape = MakeFinitePolarShape(1, .9, target[0], scale);
        if (!shape) {
            std::cout << "shape failed index=" << index << " u=[" << target[0].lo << ','
                      << target[0].hi << "] h=[" << target[1].lo << ',' << target[1].hi << "]\n";
            return 42;
        }
        const auto amplitude = sqrt(shape->amplitude2);
        for (unsigned star = 0; star < sources.size(); ++star) {
            if (amplitude.lo > sources[star].hi || sources[star].lo > amplitude.hi) continue;
            const bool near_critical = target[1].hi >= 0;
            const auto merge = [](Range a, Range b) {
                return Range(std::min(a.lo, b.lo), std::max(a.hi, b.hi));
            };
            radii[star] = overlaps[star] ? merge(radii[star], target[0]) : target[0];
            heights[star] = overlaps[star] ? merge(heights[star], target[1]) : target[1];
            ++overlaps[star];
            touches[star] += near_critical;
            finite[star] += !near_critical;
            if (overlaps[star] <= 2 || near_critical)
                std::cout << "overlap star=" << star << " index=" << index << " z0=[" << box[0].lo
                          << ',' << box[0].hi << "] z1=[" << box[1].lo << ',' << box[1].hi
                          << "] u=[" << target[0].lo << ',' << target[0].hi << "] h=["
                          << target[1].lo << ',' << target[1].hi << "]\n";
        }
    }
    for (unsigned star = 0; star < sources.size(); ++star) {
        std::cout << "star=" << star << " overlaps=" << overlaps[star]
                  << " critical=" << touches[star] << " finite=" << finite[star] << " u=["
                  << radii[star].lo << ',' << radii[star].hi << "] h=[" << heights[star].lo << ','
                  << heights[star].hi << "]\n";
    }
}

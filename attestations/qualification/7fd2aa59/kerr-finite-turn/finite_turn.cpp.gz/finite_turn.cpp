#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "../../src/sirius/render/session/kerr_point_detector.cpp"

#include <iomanip>
#include <iostream>

using namespace sirius;
using namespace sirius::render;

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const PointDetectorFootprint footprint{
        {0, 22}, {{{0x1.d323e59e01b7bp-1, -0x1.9662de6ca9f26p-9}, {0, 0x1.d520d6948dde7p-1}}}};

    using namespace core::relativity::finite_tail_detail;
    constexpr PointDetectorCell cells[]{
#include "cells.inc"
    };
    const Range source_mu(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
    const Range source_phi(-0x1.1dcd0ee4d9734p+1, -0x1.1dcd0ee4d972dp+1);
    const AngularCatalogue::Entry turn_star{source_mu, source_phi, {}, {}};
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    const PointDetectorPolicy policy;
    std::vector<PointDetectorCell> finite_cells;
    unsigned critical = 0, excluded = 0, ambiguous = 0, visits = 0;
    for (unsigned index = 0; index < std::size(cells); ++index) {
        const auto& cell = cells[index];
        FilmVector box{Range(cell.lower[0], cell.upper[0]), Range(cell.lower[1], cell.upper[1])};
        const std::array nearest{std::clamp(0.0, box[0].lo, box[0].hi),
                                 std::clamp(0.0, box[1].lo, box[1].hi)};
        for (unsigned axis = 0; axis < 2; ++axis) {
            const auto extent2 = Range(16.0) - Square(Range(nearest[1 - axis]));
            if (extent2.hi < 0) {
                box[axis] = InvalidRange();
                break;
            }
            const auto extent = sqrt(Range(extent2.hi)).hi;
            box[axis] = Range(std::max(box[axis].lo, -extent), std::min(box[axis].hi, extent));
        }
        if (!box[0].Finite() || !box[1].Finite()) continue;
        const auto chart = evaluate(box);
        if (!chart) return 40;
        const auto [radius, potential] = CoverEscapingChart(box, *chart, evaluate);
        if (!radius.Finite() || !potential.Finite()) return 41;
        if (!(potential.lo < 0)) continue;
        const Range scale(potential.hi < 0 ? sqrt(Range(-potential.hi)).lo : 0.0,
                          sqrt(Range(-potential.lo)).hi);
        const auto shape = MakeFinitePolarShape(1, .9, radius, scale);
        if (!shape) return 42;
        const Range amplitude = sqrt(shape->amplitude2);
        if (amplitude.lo > source_mu.hi || source_mu.lo > amplitude.hi) continue;
        if (scale.lo == 0.0) {
            ++critical;
            continue;
        }
        const auto screen = PrepareFiniteTurnScreen(1, .9, radius, scale, *chart, *shape,
                                                     amplitude);
        if (!screen) return 43;
        const double maximum_winding =
            (screen->radial_time / (Range(2.0) * screen->half[0])).hi;
        if (!(maximum_winding >= 0.0 && maximum_winding < 8.0)) return 44;
        auto remaining = policy.maximum_candidate_visits;
        const bool misses = ExcludeFinitePolarTurn(*screen, *shape, amplitude, turn_star, true,
                                                   unsigned(maximum_winding) + 1, remaining, {});
        visits += policy.maximum_candidate_visits - remaining;
        if (misses) {
            finite_cells.push_back(cell);
            ++excluded;
        } else {
            std::cout << "candidate_or_unknown index=" << index << '\n';
            ++ambiguous;
        }
        if (index == 401) {
            // Synthetic overlap at the same fixed pupil and latitude. Use
            // the interval longitude at the turn and a broad time envelope.
            auto overlap = *screen;
            const Range time = Range(3.0) * screen->half[0] + screen->initial[0];
            overlap.radial_time = time;
            const Range azimuth = screen->fixed_azimuth -
                (Range(3.0) * screen->half[1] + screen->initial[1] +
                 screen->radial.drag_at_turn * time + screen->radial.spin_residual);
            auto possible = turn_star;
            possible.azimuth = Range(std::remainder(std::midpoint(azimuth.lo, azimuth.hi),
                                                     2 * std::numbers::pi));
            auto negative_budget = policy.maximum_candidate_visits;
            const bool retained = !ExcludeFinitePolarTurn(overlap, *shape, amplitude, possible,
                                                          true, 2, negative_budget, {});
            std::cout << "synthetic_time_and_longitude_overlap_refused=" << retained << '\n';
            if (!retained) return 45;
        }
    }
    std::cout << "supported_turn_finite_excluded=" << excluded << " critical=" << critical
              << " ambiguous=" << ambiguous << " winding_visits=" << visits << '\n';
    if (excluded != 28 || critical != 1 || ambiguous != 0) return 46;

    const core::PointStarfieldConfig stars;
    const core::StarfieldSpatialIndex catalogue(core::StarfieldGenerator(
        core::ExpandPointStarfieldConfig(stars)).GenerateCatalogue());
    const auto indexed = PrepareKerrDetectorCatalogue(catalogue);
    auto remaining = policy.maximum_candidate_visits;
    const auto rgb = BoundKerrDetectorCells(*indexed, stars.brightness_scale, config, *launch,
                                           origin, footprint, finite_cells, {}, remaining);
    std::cout << std::setprecision(17) << "shared_finite_turn_cells=" << finite_cells.size()
              << " admitted=" << bool(rgb)
              << " visits=" << policy.maximum_candidate_visits - remaining;
    if (rgb) std::cout << " bound_per_channel=" << (*rgb)[0];
    std::cout << '\n';
    return rgb && (*rgb)[0] >= 0.0 && (*rgb)[0] <= policy.absolute_rgb_error ? 0 : 47;
}

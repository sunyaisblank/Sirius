set -euo pipefail
export TMPDIR="$PWD/out/kerr-finite-turn"
g++-14 -std=c++2c -O3 -DNDEBUG -Wall -Wextra -Werror -DSIRIUS_CONTRACT_MODE=2 -DSIRIUS_HAS_RETAINED_COMPUTE=1 -DSIRIUS_RELEASE_RESOURCE_LOCKED=1 -Isrc -Ibin/linux-ci/src/sirius/backend/retained out/kerr-finite-turn/finite_turn.cpp bin/linux-ci/src/sirius/render/libsirius_render.a bin/linux-ci/src/sirius/backend/libsirius_backend_cpu.a bin/linux-ci/src/sirius/backend/libsirius_backend.a bin/linux-ci/src/sirius/core/libsirius_core.a bin/linux-ci/src/sirius/libsirius_base.a -lvulkan -ldl -lrt -pthread -o out/kerr-finite-turn/finite-turn
cd "$TMPDIR"
env -u SIRIUS_PACKAGED_SOFTWARE_VULKAN VK_DRIVER_FILES=/home/astra/.local/opt/mesa-dzn/dzn_icd.x86_64.json SIRIUS_VULKAN_DEVICE=0 SIRIUS_MEMORY_BUDGET_MB=2048 MESA_SHADER_CACHE_DISABLE=true XDG_CACHE_HOME="$TMPDIR/xdg-cache" /usr/bin/time -v timeout 45 ./finite-turn >finite-turn.log 2>&1

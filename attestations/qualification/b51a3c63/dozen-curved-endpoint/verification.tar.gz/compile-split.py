import hashlib
import importlib.util
from pathlib import Path
import re
import subprocess


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


scratch = Path(__file__).resolve().parent
root = scratch.parents[1]
kernels = root / 'src/sirius/kernels'
builder = module('retained_builder', root / 'scripts/build-retained-kernels.py')
tables = module('retained_tables', kernels / 'retained_program.py')
ordinary = tables.build_endpoint_program(parallel=True)
spherical = tables.build_schwarzschild_endpoint_program(parallel=True)

def word_count(table):
    return 3 + sum(len(table[field]) for field in ('outputs', 'operations', 'layer_offsets'))

frames = (word_count(ordinary), word_count(spherical), len(spherical['layer_offsets']) - 1,
          spherical['prefix_instructions'])
source = (scratch / 'retained_endpoint.slang').read_text()
native = source.rindex('[shader("compute")]')
reset = source.index('    for (uint i = lane; i < rowWords;', native)
flat_guard = source.index('    if (RTExact(ReadStored(rowBase + 504), RPZero())', reset)
flat_body = source.index('        if (lane != 0) return;', flat_guard)
curved_body = source.index('    if (!SelectEndpointProgram', flat_body)
assert source[curved_body - 6:curved_body] == '    }\n'
flat_route = '''    // Select row ownership from the immutable input before clearing any output.
    uint base = 1 + 225 * row;
    RetainedTriple mass = RTPack(RPFromBits(inputs[base]), RPFromBits(inputs[base + 1]),
                                 RPFromBits(inputs[base + 2]), RPFromBits(inputs[base + 3]));
    RetainedTriple charge = RTPack(RPFromBits(inputs[base + 10]), RPFromBits(inputs[base + 11]),
                                   RPFromBits(inputs[base + 12]), RPFromBits(inputs[base + 13]));
    RetainedTriple ambient = RTPack(RPFromBits(inputs[base + 15]), RPFromBits(inputs[base + 16]),
                                    RPFromBits(inputs[base + 17]), RPFromBits(inputs[base + 18]));
    bool flat = RTExact(mass, RPZero()) && RTExact(charge, RPZero()) && RTExact(ambient, RPZero());
'''
flat_finish = source.rindex('        return;\n    }\n', flat_body, curved_body)
flat_program = '\n'.join(line[4:] for line in source[flat_body:flat_finish].rstrip('\n').splitlines())
for tag, guard, body in (
    ('flat', '    if (!flat) return;\n', flat_program + '\n}\n#endif\n'),
    ('curved', '    if (flat) return;\n', source[curved_body:]),
):
    directory = scratch / tag
    directory.mkdir(exist_ok=True)
    leaf = directory / 'retained_endpoint.slang'
    for dependency in kernels.iterdir():
        if dependency.name != leaf.name and dependency.is_file():
            (directory / dependency.name).symlink_to(dependency)
    leaf.write_text(source[:reset] + flat_route + guard + source[reset:flat_guard] + body)
    target = scratch / f'{tag}.spv'
    builder.compile_shader(leaf, target, '/opt/slang/bin/slangc', '/usr/bin/spirv-as',
                           '/usr/bin/spirv-dis', '/usr/bin/spirv-val', ordinary['registers'], 5,
                           len(ordinary['layer_offsets']) - 1, ordinary['prefix_instructions'],
                           endpoint_specialized=frames)
    data = target.read_bytes()
    assembly = subprocess.check_output(['/usr/bin/spirv-dis', str(target)], text=True)
    calls = re.findall(r'OpFunctionCall\s+%\S+\s+%(EvaluateProgram|Project)\b', assembly)
    print(tag, len(data), hashlib.sha256(data).hexdigest(), 'calls', calls)
    assert calls.count('Project') == 1
    assert calls.count('EvaluateProgram') == (1 if tag == 'curved' else 0)

#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "support/retained_transport/endpoint_reference.h"
#include <algorithm>
#include <bit>
#include <fstream>
#include <string_view>
#include <vector>

#include <array>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <sys/resource.h>

namespace {
using namespace sirius;
using namespace sirius::backend;
using namespace sirius::core;

template<class T>
T Require(base::Expected<T> value) {
    if (value) return std::move(*value);
    std::fprintf(stderr, "%s\n", value.error().Description().c_str());
    std::exit(1);
}

long Peak() {
    struct rusage usage {};
    if (getrusage(RUSAGE_SELF, &usage) != 0) std::exit(2);
    return usage.ru_maxrss;
}

class DispatchMemory final : public ComputeDevice {
  public:
    DispatchMemory(ComputeDevice& device, std::span<const std::uint32_t> stock,
                   std::span<const std::uint32_t> alternate, std::ostream& readbacks)
        : device_(device), stock_(stock), alternate_(alternate), readbacks_(readbacks) {}
    const DeviceInfo& Info() const noexcept override { return device_.Info(); }
    base::Expected<KernelHandle> LoadKernel(std::span<const std::uint32_t> spirv) override {
        const auto stage = static_cast<RetainedCompute::KernelStage>(loaded_++);
        if (stage == RetainedCompute::KernelStage::kEndpoint) {
            if (!std::ranges::equal(spirv, stock_)) std::exit(9);
            if (!alternate_.empty()) spirv = alternate_;
        }
        auto handle = device_.LoadKernel(spirv);
        if (handle) {
            names_[handle->value] = RetainedCompute::StageName(stage);
            std::printf("load stage=%s bytes=%zu kernel=%u peak_rss_kib=%ld\n",
                        names_[handle->value], spirv.size_bytes(), handle->value, Peak());
        }
        return handle;
    }
    base::Expected<BufferHandle> CreateBuffer(std::uint64_t bytes, BufferUsage usage) override {
        return device_.CreateBuffer(bytes, usage);
    }
    base::Expected<std::uint64_t> RequiredBufferAllocationBytes(std::uint64_t bytes,
                                                                BufferUsage usage) override {
        return device_.RequiredBufferAllocationBytes(bytes, usage);
    }
    base::Expected<void> WriteBuffer(BufferHandle h, std::span<const std::byte> data) override {
        return device_.WriteBuffer(h, data);
    }
    base::Expected<void> ReadBuffer(BufferHandle h, std::span<std::byte> data) override {
        auto value = device_.ReadBuffer(h, data);
        if (value && endpoint_output_ == h.value) {
            const auto size = static_cast<std::uint64_t>(data.size());
            readbacks_.write(reinterpret_cast<const char*>(&size), sizeof(size));
            readbacks_.write(reinterpret_cast<const char*>(data.data()),
                             static_cast<std::streamsize>(data.size()));
            if (!readbacks_) std::exit(10);
        }
        return value;
    }
    base::Expected<void> Dispatch(KernelHandle kernel, std::span<const BufferHandle> buffers,
                                  std::uint32_t x, std::uint32_t y, std::uint32_t z,
                                  DispatchTiming* timing) override {
        const auto before = Peak();
        const auto started = std::chrono::steady_clock::now();
        DispatchTiming measured;
        if (!timing) timing = &measured;
        const bool first = !dispatched_[kernel.value];
        dispatched_[kernel.value] = true;
        RememberOutput(kernel, buffers);
        auto value = device_.Dispatch(kernel, buffers, x, y, z, timing);
        if (first || !value) {
            const auto ms = std::chrono::duration<double,std::milli>(
                std::chrono::steady_clock::now() - started).count();
            std::printf("dispatch stage=%s succeeded=%d before_rss_kib=%ld after_rss_kib=%ld "
                        "created=%d pipeline_ms=%.3f call_ms=%.3f\n",
                        names_[kernel.value], value.has_value(), before, Peak(),
                        timing->pipeline_created, timing->pipeline_setup_ms, ms);
            std::fflush(stdout);
        }
        return value;
    }
    bool SupportsIndependentPair() const noexcept override { return device_.SupportsIndependentPair(); }
    base::Expected<void> DispatchIndependentPair(const std::array<ComputeDispatch,2>& pair,
                                                  IndependentPairTiming* timing) override {
        const auto before = Peak();
        for (const auto& command : pair) RememberOutput(command.kernel, command.buffers);
        auto value = device_.DispatchIndependentPair(pair, timing);
        std::printf("pair first=%s second=%s succeeded=%d before_rss_kib=%ld after_rss_kib=%ld\n",
                    names_[pair[0].kernel.value], names_[pair[1].kernel.value],
                    value.has_value(), before, Peak());
        return value;
    }
    base::Expected<void> SetBufferAllocationLimit(std::uint64_t bytes) override {
        return device_.SetBufferAllocationLimit(bytes);
    }
    std::uint64_t BufferAllocationBytes() const noexcept override { return device_.BufferAllocationBytes(); }
    std::optional<std::uint64_t> BufferMutationEpoch(BufferHandle h) const noexcept override {
        return device_.BufferMutationEpoch(h);
    }
  private:
    void RememberOutput(KernelHandle kernel, std::span<const BufferHandle> buffers) {
        if (std::string_view(names_[kernel.value]) == "endpoint") {
            if (buffers.size() != 2) std::exit(11);
            endpoint_output_ = buffers[1].value;
        }
    }

    ComputeDevice& device_;
    std::span<const std::uint32_t> stock_;
    std::span<const std::uint32_t> alternate_;
    std::ostream& readbacks_;
    std::optional<std::uint32_t> endpoint_output_;
    std::array<const char*, RetainedCompute::kStageCount> names_{};
    std::array<bool, RetainedCompute::kStageCount> dispatched_{};
    std::size_t loaded_ = 0;
};
std::vector<std::uint32_t> LoadWords(const char* path) {
    std::ifstream stream(path, std::ios::binary | std::ios::ate);
    const auto size = static_cast<std::streamoff>(stream.tellg());
    if (size <= 0 || size % 4) std::exit(7);
    std::vector<std::uint32_t> words(static_cast<std::size_t>(size / 4));
    stream.seekg(0);
    stream.read(reinterpret_cast<char*>(words.data()), size);
    if (!stream) std::exit(7);
    return words;
}
}  // namespace

int main(int argc, char** argv) {
    if (argc != 4) return 7;
    const auto stock = LoadWords(argv[1]);
    const auto alternate = std::string_view(argv[2]) == "-" ? std::vector<std::uint32_t>{}
                                                             : LoadWords(argv[2]);
    std::ofstream readbacks(argv[3], std::ios::binary);
    if (!readbacks) return 8;
    const auto inventory = Require(EnumerateVulkanDevices());
    const auto index = Require(ResolveVulkanDeviceIndex(inventory));
    const auto physical = Require(CreateVulkanDevice(index));
    if (physical->Info().vendor_id != 0x1002 || physical->Info().name.find("780M") == std::string::npos ||
        physical->Info().driver_name.find("Dozen") == std::string::npos) return 3;
    std::printf("physical name=%s driver=%s vendor=%04x\n", physical->Info().name.c_str(),
                physical->Info().driver_name.c_str(), physical->Info().vendor_id);
    DispatchMemory device(*physical, stock, alternate, readbacks);
    if (!device.SetBufferAllocationLimit(1024ULL * 1024 * 1024)) return 4;
    auto compute = Require(RetainedCompute::Create(device,128));
    std::printf("buffers explicit_bytes=%llu peak_rss_kib=%ld\n",
                static_cast<unsigned long long>(device.BufferAllocationBytes()), Peak());
    CameraConfig camera_config;
    camera_config.width = 256;
    camera_config.height = 192;
    PinholeCamera camera(camera_config);
    const auto film = camera.ProjectFilmForObserver(115.5, 120.5, .5, .5);
    if (!film) return 5;
    KerrSchildFamily metric(KerrSchildParams::Kerr(1., 0.));
    TracerConfig config;
    config.max_steps = 2;  // Charge only the first physical intervals of an ordinary ray.
    config.integrator.initial_step = .1f;
    config.integrator.min_step = 1e-5f;
    config.integrator.max_step = 2.0f;
    config.integrator.abs_tolerance = config.integrator.rel_tolerance = 5e-6f;
    RetainedTraceExecutor executor(*compute, {}, 1000.0, 64);
    GeodesicTracer tracer(&metric, config);
    tracer.SetStepExecutor(&executor);
    const auto result = tracer.Trace(film->ray);
    const auto statistics = executor.Statistics();
    std::printf("trace steps=%d accepted=%llu rejected=%llu peak_rss_kib=%ld\n",
                result.steps_taken, static_cast<unsigned long long>(statistics.accepted_intervals),
                static_cast<unsigned long long>(statistics.rejected_intervals), Peak());
    if (executor.Error() || statistics.accepted_intervals != 2) return 6;
    std::vector<RetainedEndpointInput> fixtures;
    for (const auto& fixture : sirius::test::retained_endpoint::cases) {
        fixtures.push_back(std::bit_cast<RetainedEndpointInput>(fixture.input));
    }
    auto invalid_pack = fixtures[0];
    invalid_pack.values[4].valid = 0;
    fixtures.push_back(invalid_pack);
    auto invalid_curved = fixtures[1];
    invalid_curved.values[8] = RetainedValue::FromDouble(100);
    fixtures.push_back(invalid_curved);
    auto invalid_flat = fixtures[14];
    invalid_flat.values[8] = RetainedValue::FromDouble(0x1p70);
    fixtures.push_back(invalid_flat);
    const auto outputs = Require(compute->Endpoint(fixtures));
    for (std::size_t row = 0; row < outputs.size(); ++row) {
        if (row < std::size(sirius::test::retained_endpoint::cases)) {
            if (!outputs[row].valid ||
                outputs[row].component != sirius::test::retained_endpoint::cases[row].component)
                return 12;
            std::printf("fixture %s component=%u\n",
                        sirius::test::retained_endpoint::cases[row].name, outputs[row].component);
        } else if (outputs[row].valid) {
            return 13;
        }
    }
    std::printf("finite_endpoints=%zu intentional_refusals=3 peak_rss_kib=%ld\n",
                outputs.size() - 3, Peak());
    return 0;
}

import hashlib
import importlib.util
from pathlib import Path
import re
import subprocess


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


scratch = Path(__file__).resolve().parent
root = scratch.parents[1]
kernels = root / 'src/sirius/kernels'
builder = module('retained_builder', root / 'scripts/build-retained-kernels.py')
tables = module('retained_tables', kernels / 'retained_program.py')
ordinary = tables.build_endpoint_program(parallel=True)
spherical = tables.build_schwarzschild_endpoint_program(parallel=True)

def word_count(table):
    return 3 + sum(len(table[field]) for field in ('outputs', 'operations', 'layer_offsets'))

frames = (word_count(ordinary), word_count(spherical), len(spherical['layer_offsets']) - 1,
          spherical['prefix_instructions'])
leaf = scratch / 'retained_endpoint.slang'
for dependency in kernels.iterdir():
    if dependency.name != leaf.name and dependency.is_file():
        (scratch / dependency.name).symlink_to(dependency)
source = (kernels / leaf.name).read_text()
start = source.index('    if (!EvaluateProgram(row, rowBase, programBase, count, registers, 20,')
end = source.index('    if (lane == 0) outputs[rowBase] = 1;', start)
projection_begin = source.index('    if (!Project(rowBase, component, root))', start)
projection_end = source.index('    if (!EvaluateProgram(row, rowBase, programBase, count, registers, 100,', projection_begin)
projection = '\n'.join('        ' + line if line and not line.startswith('#') else line
                       for line in source[projection_begin:projection_end].rstrip('\n').splitlines())
replacement = '''    uint component = 4;
    RetainedTriple root;
    // Keep both curved evaluations at one call site for drivers that inline it.
    [loop] for (uint phase = 0; phase < 2; ++phase) {
        if (phase == 1) {
PROJECTION
        }
        if (!EvaluateProgram(row, rowBase, programBase, count, registers,
                             phase == 0 ? 20 : 100, lane, layers, prefix)) return;
    }
'''.replace('PROJECTION', projection)
leaf.write_text(source[:start] + replacement + source[end:])
for tag, shader in [('stock', kernels / leaf.name), ('compact', leaf)]:
    target = scratch / f'{tag}.spv'
    builder.compile_shader(shader, target, '/opt/slang/bin/slangc', '/usr/bin/spirv-as',
                           '/usr/bin/spirv-dis', '/usr/bin/spirv-val', ordinary['registers'], 5,
                           len(ordinary['layer_offsets']) - 1, ordinary['prefix_instructions'],
                           endpoint_specialized=frames)
    data = target.read_bytes()
    print(tag, len(data), hashlib.sha256(data).hexdigest())
    if tag == 'stock':
        assert hashlib.sha256(data).hexdigest() == 'd7c01a3d67f7c4617643aa36c2369ffc190f2e36e2ec9fd1d1aeb0a346a45e7c'
    assembly = subprocess.check_output(['/usr/bin/spirv-dis', str(target)], text=True)
    (scratch / f'{tag}.spvasm').write_text(assembly)
    calls = re.findall(r'OpFunctionCall\s+%\S+\s+%(EvaluateProgram|Project)\b', assembly)
    print(tag, 'calls', calls, 'DontUnroll', assembly.count('DontUnroll'))
    assert calls.count('EvaluateProgram') == (2 if tag == 'stock' else 1)
    assert calls.count('Project') == 2

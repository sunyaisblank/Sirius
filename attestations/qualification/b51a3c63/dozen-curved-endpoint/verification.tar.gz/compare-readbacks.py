from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import re
import struct
import sys


scratch = Path(__file__).resolve().parent
root = scratch.parents[1]
stride = (769 + 5 * 612) * 4

def blocks(name):
    data = (scratch / (name + '.readback')).read_bytes()
    print(f'{name}: {len(data)} bytes sha256={hashlib.sha256(data).hexdigest()}')
    offset = 0
    frames = []
    while offset < len(data):
        size, = struct.unpack_from('<Q', data, offset)
        offset += 8
        assert size > 0 and size % stride == 0 and offset + size <= len(data)
        frames.append(data[offset:offset + size])
        offset += size
    return frames

stock = blocks('stock')
assert stock == blocks('compact') == blocks('split')
print(f'{len(stock)} complete dispatch readbacks, {sum(map(len, stock)) // stride} rows byte-exact')
cases = json.loads((root / 'tests/support/retained_transport/endpoint_reference.json').read_text())['cases']
expected_fields = 0
with localcontext() as context:
    context.prec = 200
    for index, case in enumerate(cases):
        row_start = index * stride
        assert struct.unpack_from('<II', stock[-1], row_start) == (1, case['component'])
        for field, oracle_text in enumerate(case['reference']):
            start = row_start + (104 + 5 * field) * 4
            hi, lo, tail, radius, valid = struct.unpack_from('<ffffI', stock[-1], start)
            assert valid == 1
            ref = Decimal(oracle_text)
            difference = abs(sum(map(Decimal.from_float, (hi, lo, tail))) - ref)
            scale = 1 + abs(ref)
            assert difference <= Decimal.from_float(radius) + Decimal('1e-29') * scale, (index, field)
            assert difference <= Decimal('1e-11') * scale, (index, field)
            expected_fields += 1
    for index in range(len(cases), len(cases) + 3):
        assert struct.unpack_from('<I', stock[-1], index * stride)[0] == 0
print(f'{expected_fields} independent 105-digit endpoint projections meet original tolerances; three refusals')

if '--integrated' in sys.argv:
    integrated = blocks('integrated')
    assert integrated[:-1] == stock
    log = (scratch / 'integrated.log').read_text()
    selected = [int(row) for row in re.findall(r'^homogeneous_source_row=(\d+)$', log, re.M)]
    assert selected and len(selected) < len(cases) + 3
    assert integrated[-1] == b''.join(stock[-1][i * stride:(i + 1) * stride] for i in selected)
    routes = re.findall(r'^endpoint_route=(\w+)$', log, re.M)
    assert routes == ['endpoint_curved'] * 9 + ['endpoint', 'endpoint_curved']
    accepted = re.search(r'^trace steps=2 accepted=2 rejected=0 peak_rss_kib=(\d+)$', log, re.M)
    assert accepted and int(accepted[1]) < 2048 * 1024
    print(f'{len(selected)} sorted active rows in the smaller curved batch exact after mixed fallback')
    print('Nine curved physical dispatches, one original mixed fallback, one additional curved dispatch')

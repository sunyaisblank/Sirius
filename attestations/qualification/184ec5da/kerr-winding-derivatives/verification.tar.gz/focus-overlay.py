from pathlib import Path

root=Path.cwd()
scratch=Path(__file__).resolve().parent
source=root/'src/sirius/render/session'
overlay=scratch/'next/sirius/render/session'
overlay.mkdir(parents=True,exist_ok=True)

def insert(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)

pixels=insert((source/'pixel_shading.cpp').read_text(),'#include <algorithm>','#include <algorithm>\n#include <iostream>')
old='    const auto group =\n        EvaluatePointDetectorGroup(catalogue, brightness, footprints, probe, cancelled, {},'
pixels=insert(pixels,old,'''    const bool witness = x == 928 && y == 608 && width == 32 && height == 32;
    if (witness) {
        const auto at = std::ranges::find(indices, std::size_t{704});
        if (at == indices.end())
            return std::unexpected(PointDetectorError{PointDetectorFailure::InvalidInput, {}});
        const auto single = footprints[static_cast<std::size_t>(at - indices.begin())];
        footprints.assign(1, single);
        indices.assign(1, 704);
    }
'''+old)
old='''    if (!group) return std::unexpected(group.error());
    result.statistics = group->statistics;'''
pixels=insert(pixels,old,'''    if (!group) return std::unexpected(group.error());
    if (witness) {
        const auto& work = group->statistics;
        const auto& ray = group->samples.front();
        std::clog << "witness pupil " << sample.pupil_u << ',' << sample.pupil_v
                  << " probes=" << work.probes << " cells=" << work.cells
                  << " visits=" << work.candidate_visits
                  << " error=" << ray.estimated_error[0] << ',' << ray.estimated_error[1] << ','
                  << ray.estimated_error[2] << std::endl;
    }
    result.statistics = group->statistics;''')
(overlay/'pixel_shading.cpp').write_text(pixels)

point=insert((source/'point_source_detector.cpp').read_text(),'#include <algorithm>','#include <algorithm>\n#include <iostream>')
point=insert(point,'        if (terminal) Fail(PointDetectorFailure::Unresolved);',
    '''        if (terminal) {
            std::clog << std::hexfloat << "first unresolved terminal [" << cell.lower[0] << ','
                      << cell.lower[1] << "]-[" << cell.upper[0] << ',' << cell.upper[1]
                      << "]" << std::defaultfloat << " visits=" << statistics_.candidate_visits
                      << std::endl;
            Fail(PointDetectorFailure::Unresolved);
        }''')
(overlay/'point_source_detector.cpp').write_text(point)

k=insert((source/'kerr_point_detector.cpp').read_text(),'#include <mutex>','#include <mutex>\n#include <iostream>')
k=insert(k,'''    if (!bands) return {};''','''    if (!bands) {
        if(cells.size()==1)
            std::clog << "no reachable-latitude proof at " << std::hexfloat << cells.front().lower[0]
                      << ',' << cells.front().lower[1] << std::defaultfloat << std::endl;
        return {};
    }''')
k=insert(k,'''        if (!density) return {};''','''        if (!density) {
            std::clog << "unresolved azimuth winding=" << candidate.winding
                      << " approach=" << candidate.approaching_equator << std::hexfloat
                      << " source_mu=" << candidate.source->latitude.lo << ':'
                      << candidate.source->latitude.hi << " source_longitude=" << candidate.source->azimuth.lo
                      << ':' << candidate.source->azimuth.hi << " cover=" << radius.lo << ':' << radius.hi
                      << " H=" << minimum_potential << ':' << maximum_potential
                      << " log=" << candidate.log_scale.lo << ':' << candidate.log_scale.hi
                      << " cell=" << cells.front().lower[0] << ',' << cells.front().lower[1] << ':'
                      << cells.front().upper[0] << ',' << cells.front().upper[1]
                      << std::defaultfloat << " count=" << cells.size() << " remaining=" << remaining
                      << std::endl;
            return {};
        }''')
(overlay/'kerr_point_detector.cpp').write_text(k)

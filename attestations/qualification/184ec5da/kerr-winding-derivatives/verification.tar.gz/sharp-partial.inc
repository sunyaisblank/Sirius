// Integrate the fixed-angle parameter derivatives with the same enclosed
// Gauss rule used for the phase values. Leibniz's boundary term carries the
// changing polar endpoint.
inline std::array<FilmJet, 2> IntegratePolarDerivatives(
    const FilmJet& phase, const FilmJet& omega2, const FilmJet& modulation,
    const FilmJet& amplitude2, const FilmJet& angular, const FilmJet& drag) {
    std::array<FilmJet, 2> result{};
    if (!phase.value.Finite() || phase.value.lo < 0.0 ||
        phase.value.hi > kPiBounds.hi * .5) {
        for (auto& term : result) term.derivative.fill(InvalidRange());
        return result;
    }
    const auto density = [&](auto sin2, auto frequency, auto variation, auto amplitude,
                             auto momentum, auto radial_drag) {
        using N = decltype(sin2);
        const N time = N(1.0) / sqrt(frequency + variation * sin2);
        return std::array{time, time * (momentum / (N(1.0) - amplitude * sin2) + radial_drag)};
    };
    const auto boundary =
        density(PolarSineSquared(phase.value), omega2.value, modulation.value, amplitude2.value,
                angular.value, drag.value);
    constexpr unsigned panels = 32;
    const Range step = Range(phase.value.lo) / Range(panels);
    const double tail = (Range(phase.value.hi) - Range(phase.value.lo)).hi;
    for (unsigned axis = 0; axis < phase.derivative.size(); ++axis) {
        const auto differential = [&](auto angle) {
            using N = decltype(angle);
            using Jet = RadialJet<N>;
            const auto jet = [&](const FilmJet& p) {
                return Jet(N(p.value), N(p.derivative[axis]));
            };
            const auto q =
                density(Jet(PolarSineSquared(angle)), jet(omega2), jet(modulation), jet(amplitude2),
                        jet(angular), jet(drag));
            return std::array{q[0].dual, q[1].dual};
        };
        PhasePair integral{};
        if (phase.value.lo > 0.0) {
            for (unsigned i = 0; i < panels; ++i) {
                const auto part =
                    PhaseGaussPanel(Range(i) * step, Range(i + 1) * step, differential);
                for (unsigned j = 0; j < part.size(); ++j) integral[j] = integral[j] + part[j];
            }
        }
        const auto end = differential(phase.value);
        for (unsigned j = 0; j < result.size(); ++j)
            result[j].derivative[axis] = integral[j] + Range(0.0, tail) * end[j] +
                                         boundary[j] * phase.derivative[axis];
    }
    return result;
}


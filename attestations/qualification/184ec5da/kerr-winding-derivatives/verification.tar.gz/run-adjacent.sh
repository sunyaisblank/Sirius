#!/usr/bin/env bash
set -euo pipefail
root="$PWD"
s="$root/out/kerr-winding-derivative"
lib="$root/bin/linux-ci/src/sirius"
export TMPDIR="$s"
g++-14 -I"$s/next" -I"$root/src" -std=c++2c -O3 -DNDEBUG -Wall -Wextra -Werror \
    -DSIRIUS_CONTRACT_MODE=2 -DSIRIUS_HAS_RETAINED_COMPUTE=1 -DSIRIUS_RELEASE_RESOURCE_LOCKED=1 \
    -fno-fast-math -ffp-contract=off -frounding-math "$s/adjacent-support.cpp" \
    "$lib/backend/libsirius_backend_cpu.a" "$lib/backend/libsirius_backend.a" \
    "$lib/core/libsirius_core.a" "$lib/libsirius_base.a" -lvulkan -ldl -lrt -pthread -o "$s/adjacent-support"
cd "$s"
env -u SIRIUS_PACKAGED_SOFTWARE_VULKAN VK_DRIVER_FILES="$HOME/.local/opt/mesa-dzn/dzn_icd.x86_64.json" SIRIUS_VULKAN_DEVICE=0 SIRIUS_MEMORY_BUDGET_MB=2048 MESA_SHADER_CACHE_DISABLE=true XDG_CACHE_HOME="$PWD/adjacent-direct-cache" /usr/bin/time -v timeout 130 ./adjacent-support "$@"

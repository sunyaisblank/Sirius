import sys
from pathlib import Path

root=Path.cwd()
s=Path(__file__).resolve().parent
overlay=s/'shared'
diagnostics='--production' not in sys.argv

def replace(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)

def save(file,text):
    path=overlay/'sirius'/file
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text)

screen='core/kerr_detector/finite_screen.h'
h=(root/'src/sirius'/screen).read_text()
h=replace(h, 'struct CatalogueScreen {', '''struct ReachableCatalogueRow {
    const AngularCatalogue::Row* row;
    Range latitude;
    unsigned band;
    std::vector<const AngularCatalogue::Entry*> subset;
};

using ReachableCatalogueRows = std::array<std::vector<ReachableCatalogueRow>, 2>;

struct CatalogueScreen {''')
h=replace(h,'''    const AngularCatalogue& catalogue, const std::array<unsigned, 3>& cutoffs, Range turn_amplitude,
    double clearance, std::size_t& remaining, const std::function<bool()>& cancelled,
    const NearCriticalPhases* shared_phases,
    std::span<const AngularCatalogue::Entry* const> excluded_turns,
    std::optional<Range> finite_scale, Range density_to_rgb, double grouped_allowance) {''',
'''    const ReachableCatalogueRows& reachable, const std::array<unsigned, 3>& cutoffs,
    std::size_t& remaining, const std::function<bool()>& cancelled,
    const NearCriticalPhases* shared_phases, std::optional<Range> finite_scale,
    Range density_to_rgb, double grouped_allowance) {''')
a=h.index('        const AngularCatalogue::Row* row;',h.index('    struct ScreenRow {'))
b=h.index('    CatalogueScreen result',a)
h=h[:a]+'''        const ReachableCatalogueRow* sources;
        std::optional<PolarDerivativeStrip::PolarJet> endpoint;
        PhasePair equator, critical_equator;
    };
    std::array<std::vector<ScreenRow>, 2> screen_rows;
    for (unsigned hemisphere = 0; hemisphere < reachable.size(); ++hemisphere) {
        auto& output = screen_rows[hemisphere];
        output.reserve(reachable[hemisphere].size());
        for (const auto& row : reachable[hemisphere]) {
            if (cancelled && cancelled()) return {};
            const auto equator = polar.Partial(AsinBounds(row.latitude / amplitude));
            if (!equator[0].Finite() || !equator[1].Finite()) return {};
            PhasePair critical_equator = equator;
            if (shared_phases) {
                const auto partial = shared_phases->polar.Partial(
                    AsinBounds(row.latitude / shared_phases->absolute_amplitude));
                if (partial[0].Finite() && partial[1].Finite()) critical_equator = partial;
            }
            const auto endpoint =
                strip && row.subset.empty() ? strip->ToLatitude(row.latitude) : std::nullopt;
            output.push_back({&row, endpoint, equator, critical_equator});
        }
    }
'''+h[b:]
h=replace(h,'            if (m >= prepared.cutoff) continue;',
'''            const auto& sources = *prepared.sources;
            if (m >= cutoffs[sources.band]) continue;''')
h=replace(h,'strip->Density(prepared.latitude,','strip->Density(sources.latitude,')
h=replace(h,'density_to_rgb * prepared.row->weighted_temperature * *density;',
            'density_to_rgb * sources.row->weighted_temperature * *density;')
h=h.replace('prepared.subset','sources.subset').replace('prepared.row','sources.row')
save(screen,h)

render='render/session/kerr_point_detector.cpp'
r=((s/'next'/'sirius'/render) if diagnostics else (root/'src/sirius'/render)).read_text()
r=replace(r,'template <typename ExcludeTurn>\nstd::optional<std::array<SourceBand, 3>> CollectReachableSources(',
'''struct ReachableCatalogue {
    std::array<SourceBand, 3> bands;
    ReachableCatalogueRows rows;
};

template <typename ExcludeTurn>
std::optional<ReachableCatalogue> CollectReachableSources(''')
r=replace(r, '    std::array<SourceBand, 3> result{};', '    ReachableCatalogue result{};')
r=replace(r, '        auto& band = result[group];', '        auto& band = result.bands[group];')
r=replace(r,'''    for (bool north : {false, true}) {
        for (const auto& row : catalogue.Rows(north)) {''',
'''    for (bool north : {false, true}) {
        auto& output = result.rows[north ? 1 : 0];
        for (const auto& row : catalogue.Rows(north)) {''')
r=replace(r,'''                add(LatitudeBand(gap.lo), row.weighted_temperature, gap.lo);
                continue;''','''                const unsigned band = LatitudeBand(gap.lo);
                add(band, row.weighted_temperature, gap.lo);
                output.push_back({&row, row.latitude, band, {}});
                continue;''')
r=replace(r,'''            // Only rows touching a band edge or a polar turn require individual visits.
            for (const auto& entry : row.entries) {
                if (remaining == 0) return {};''',
'''            // Resolve the boundary rows once and keep their longitude order
            // for every later winding query.
            std::array<std::vector<const AngularCatalogue::Entry*>, 3> by_band;
            std::array<Range, 3> latitude;
            for (const auto& entry : row.entries) {
                if (remaining == 0 || (cancelled && cancelled())) return {};''')
r=replace(r,'''                add(LatitudeBand(star_gap.lo), entry.weighted_temperature, star_gap.lo);
            }''',
'''                const unsigned band = LatitudeBand(star_gap.lo);
                add(band, entry.weighted_temperature, star_gap.lo);
                auto& limits = latitude[band];
                auto& entries = by_band[band];
                limits = entries.empty() ? entry.latitude
                                         : Range(std::min(limits.lo, entry.latitude.lo),
                                                 std::max(limits.hi, entry.latitude.hi));
                entries.push_back(&entry);
            }
            for (unsigned band = 0; band < by_band.size(); ++band)
                if (!by_band[band].empty())
                    output.push_back({&row, latitude[band], band, std::move(by_band[band])});''')
r=replace(r,'    std::vector<const AngularCatalogue::Entry*> excluded_turns;\n','')
r=replace(r,'        excluded_turns.push_back(&source);\n','')
r=replace(r,'''    const auto bands =
        CollectReachableSources''','''    const auto reachable =
        CollectReachableSources''')
r=replace(r,'    if (!bands)', '    if (!reachable)')
r=replace(r,'    for (const auto& band : *bands)', '    for (const auto& band : reachable->bands)')
r=replace(r,'i < bands->size()','i < reachable->bands.size()')
r=replace(r,'const auto& band = (*bands)[i];','const auto& band = reachable->bands[i];')
r=replace(r,'''        mass, spin, radius, scale, *whole, *polar, *phase, *angular, cutoffs, amplitude, clearance,
        remaining, cancelled, phases ? &*phases : nullptr, excluded_turns,''',
'''        mass, spin, radius, scale, *whole, *polar, *phase, reachable->rows, cutoffs, remaining,
        cancelled, phases ? &*phases : nullptr,''')
save(render,r)
if diagnostics:
    for file in ('render/session/point_source_detector.cpp','render/session/pixel_shading.cpp'):
        save(file,(s/'next/sirius'/file).read_text())

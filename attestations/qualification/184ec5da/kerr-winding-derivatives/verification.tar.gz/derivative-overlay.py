from pathlib import Path
import sys

root=Path.cwd()
scratch=Path(__file__).resolve().parent
inc='sirius/core/kerr_detector/finite_screen.h'
src=(root/'src'/inc).read_text()
old='inline std::optional<AzimuthDerivative> DifferentiateFiniteAzimuth('
assert src.count(old)==1
src=src.replace(old,(scratch/'sharp-partial.inc').read_text()+old)
old='''    const auto half = integrate(FilmJet(Range(kPiBounds.lo * .5, kPiBounds.hi * .5)));'''
i=src.index(old,src.index('inline std::optional<AzimuthDerivative> DifferentiateFiniteAzimuth('))
j=src.index('\n}',i)
src=src[:i]+'''    const auto derivative = [&](const auto& quadrature) -> std::optional<AzimuthDerivative> {
        const auto half = quadrature(FilmJet(Range(kPiBounds.lo * .5, kPiBounds.hi * .5)));
        const auto initial = quadrature(asin_mu(chart.initial_mu));
        const auto final = quadrature(asin_mu(source_mu));
        std::array<FilmJet, 2> target;
        for (unsigned i = 0; i < 2; ++i) {
            const FilmJet period = half[i] * FilmJet(2.0);
            target[i] =
                period * FilmJet(winding) + initial[i] + (approach ? period - final[i] : final[i]);
        }
        const Range radial_u =
            Range(-2.0) * radial->leading_gradient[0] * log_s + radial->time_remainder.radial;
        const Range transverse = s * target[0].derivative[1] - radial->time_log_derivative;
        if (!(transverse.lo > 0.0)) return {};
        const Range log_s_u = (radial_u - target[0].derivative[0]) / transverse;
        const Range conditioned =
            Range(0.0) - (target[1].derivative[0] + radial->spin_remainder.radial +
                          (s * target[1].derivative[1] + radial->spin_remainder.log_scale) * log_s_u);
        if (!conditioned.Finite() || !transverse.Finite()) return {};
        const Range z2 = Square(Abs(source_mu));
        const Range speed = sqrt((amplitude2.value - z2) * (omega2.value + a2.value * z2));
        if (!speed.Finite() || !(speed.lo > 0.0)) return {};
        return AzimuthDerivative{conditioned, transverse, speed};
    };
    const auto coarse = derivative(integrate);
    if (s.hi >= 0x1p-20 || (coarse && Abs(coarse->conditioned_radial_slope).lo > 0.0))
        return coarse;
    const auto enclosed = [&](const FilmJet& endpoint) {
        return IntegratePolarDerivatives(endpoint, omega2, a2 * amplitude2, amplitude2,
                                         constants->lambda, drag);
    };
    const auto sharp = derivative(enclosed);
    return sharp ? sharp : coarse;'''+src[j:]
dst=scratch/'next'/inc
dst.parent.mkdir(parents=True,exist_ok=True)
dst.write_text(src)
render='sirius/render/session/kerr_point_detector.cpp'
p=scratch/'next'/render
p.parent.mkdir(parents=True,exist_ok=True)
p.write_bytes((root/'src'/render).read_bytes())

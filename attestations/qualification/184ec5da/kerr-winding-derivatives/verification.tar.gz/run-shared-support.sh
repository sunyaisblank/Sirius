#!/usr/bin/env bash
set -euo pipefail
root="$PWD"
s="$root/out/kerr-winding-derivative"
lib="$root/bin/linux-ci/src/sirius"
export TMPDIR="$s"
g++-14 -I"$root/src" -std=c++2c -O3 -DNDEBUG -Wall -Wextra -Werror \
    -DSIRIUS_CONTRACT_MODE=2 -DSIRIUS_HAS_RETAINED_COMPUTE=1 -DSIRIUS_RELEASE_RESOURCE_LOCKED=1 \
    -fno-fast-math -ffp-contract=off -frounding-math -c "$s/shared-support.cpp" -o "$s/shared-support.o"
objects=()
for version in exact shared; do
    if [[ "$version" == shared ]]; then objects+=("$s/focused-shared/kerr_point_detector.o"); fi
    g++-14 -o "$s/cell-$version" "$s/shared-support.o" "${objects[@]}" \
        "$lib/render/libsirius_render.a" "$lib/backend/libsirius_backend_cpu.a" \
        "$lib/backend/libsirius_backend.a" "$lib/core/libsirius_core.a" "$lib/libsirius_base.a" \
        -lvulkan -ldl -lrt -pthread
    (
        cd "$s"
        env -u SIRIUS_PACKAGED_SOFTWARE_VULKAN VK_DRIVER_FILES="$HOME/.local/opt/mesa-dzn/dzn_icd.x86_64.json" \
            SIRIUS_VULKAN_DEVICE=0 SIRIUS_MEMORY_BUDGET_MB=2048 MESA_SHADER_CACHE_DISABLE=true \
            XDG_CACHE_HOME="$PWD/$version-controls-cache" /usr/bin/time -v timeout 80 "./cell-$version" 61 1 64 1
    ) > "$s/cell-$version.log" 2>&1
done

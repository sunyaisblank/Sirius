#!/usr/bin/env bash
set -euo pipefail
root="$PWD"
s="$root/out/kerr-winding-derivative"
lib="$root/bin/linux-ci/src/sirius"
g++-14 -o "$s/cell-committed" "$s/shared-support.o" \
    "$lib/render/libsirius_render.a" "$lib/backend/libsirius_backend_cpu.a" \
    "$lib/backend/libsirius_backend.a" "$lib/core/libsirius_core.a" "$lib/libsirius_base.a" \
    -lvulkan -ldl -lrt -pthread
cd "$s"
env -u SIRIUS_PACKAGED_SOFTWARE_VULKAN VK_DRIVER_FILES="$HOME/.local/opt/mesa-dzn/dzn_icd.x86_64.json" \
    SIRIUS_VULKAN_DEVICE=0 SIRIUS_MEMORY_BUDGET_MB=2048 MESA_SHADER_CACHE_DISABLE=true \
    XDG_CACHE_HOME="$PWD/committed-controls-cache" /usr/bin/time -v timeout 80 ./cell-committed 61 1 64 1

#include "sirius/core/kerr_detector/finite_screen.h"
#include <iomanip>
#include <iostream>
int main() {
    using namespace sirius::core::relativity::finite_tail_detail;
    StationaryChart chart{};
    chart.initial_mu = {0x1.67f25c4fe005p-3,0x1.67f25c4fe0117p-3};
    chart.inverse_start = {0x1.111112f155084p-5,0x1.111112f1550a2p-5};
    const Range log(-88,-85), centre(0x1.c01bf13a8b6fbp-2,0x1.c01c02e6d537ap-2);
    const auto answer=DifferentiateFiniteAzimuth(1, .9, centre, ExpBounds(log), log, chart,
                                                 69,true,{0x1.f4ed100889174p-1,0x1.f4ed10088917ep-1});
    if (!answer) return 11;
    const Range slope=answer->conditioned_radial_slope;
    std::cout<<std::setprecision(17)<<"slope=["<<slope.lo<<','<<slope.hi<<"]\n";
}

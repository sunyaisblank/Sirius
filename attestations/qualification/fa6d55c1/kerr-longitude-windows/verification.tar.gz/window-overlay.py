from pathlib import Path
import sys

s=Path('out/kerr-scalar-traversal')
root=Path.cwd()
target=s/'windows/sirius'
diagnostics='--production' not in sys.argv

def read(name):
    if diagnostics and name=='render/session/kerr_point_detector.cpp':
        return (s/'next/sirius'/name).read_text()
    return (root/'src/sirius'/name).read_text()

def save(name,text):
    p=target/name
    p.parent.mkdir(exist_ok=True,parents=True)
    p.write_text(text)

def replace(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)

name='core/kerr_detector/angular_catalogue.h'
t=read(name)
t=replace(t,'        std::vector<Entry> entries;',
'''        std::vector<Entry> entries;
        std::vector<Range> temperature_prefix;''')
start=t.index('        template <class Entries, class GetEntry, class Visit>')
t=t[:start]+'''        std::optional<Range> QueryWeight(Range unwrapped) const {
            Range total;
            const bool valid = QuerySlices(
                entries, longitude_error, unwrapped, std::identity{}, [&](auto first, auto last) {
                    const auto i = first - entries.begin(), j = last - entries.begin();
                    total = total + (temperature_prefix[j] - temperature_prefix[i]);
                    return total.Finite();
                });
            return valid ? std::optional(total) : std::nullopt;
        }

        template <class Entries, class GetEntry, class Visit>
        static bool QueryEntries(const Entries& entries, double longitude_error, Range unwrapped,
                                 GetEntry get_entry, Visit&& visit) {
            return QuerySlices(entries, longitude_error, unwrapped, get_entry,
                               [&](auto first, auto last) {
                                   return std::all_of(first, last, [&](const auto& item) {
                                       return visit(get_entry(item));
                                   });
                               });
        }

      private:
'''+t[start:]
at=t.index('      private:',start)
a,b=t[:at],t[at:]
b=replace(b,'''        template <class Entries, class GetEntry, class Visit>
        static bool QueryEntries(const Entries& entries, double longitude_error, Range unwrapped,
                                 GetEntry get_entry, Visit&& visit) {''',
'''        template <class Entries, class GetEntry, class Visit>
        static bool QuerySlices(const Entries& entries, double longitude_error, Range unwrapped,
                                GetEntry get_entry, Visit&& visit) {''')
b=replace(b,'            const auto apply = [&](const auto& item) { return visit(get_entry(item)); };\n','')
b=replace(b,'                return std::all_of(entries.begin(), entries.end(), apply);',
            '                return visit(entries.begin(), entries.end());')
b=replace(b,'''                for (auto at = std::max(lo, previous_end); at < hi; ++at)
                    if (!apply(*at)) return false;''',
'''                const auto first = std::max(lo, previous_end);
                if (first < hi && !visit(first, hi)) return false;''')
t=a+b
t=replace(t,'''        for (auto& hemisphere : index.rows_)
            for (auto& row : hemisphere) std::ranges::sort(row.entries, {}, &Entry::longitude_key);''',
'''        for (auto& hemisphere : index.rows_)
            for (auto& row : hemisphere) {
                if (row.entries.empty()) continue;
                std::ranges::sort(row.entries, {}, &Entry::longitude_key);
                row.temperature_prefix.reserve(row.entries.size() + 1);
                row.temperature_prefix.emplace_back();
                for (const auto& entry : row.entries)
                    row.temperature_prefix.push_back(
                        row.temperature_prefix.back() + entry.weighted_temperature);
            }''')
save(name,t)

name='core/kerr_detector/finite_screen.h'
t=read(name)
old='''    unsigned band;
    std::vector<const AngularCatalogue::Entry*> subset;'''
assert t.count(old)==1
t=t.replace(old,'''    unsigned band;
    std::vector<const AngularCatalogue::Entry*> subset;
    Range weighted_temperature;''')
t=replace(t,'''    constexpr unsigned first_grouped_winding = 12;''',
'''    constexpr unsigned first_grouped_winding = 8;
    constexpr unsigned first_whole_row_winding = 12;''')
t=replace(t,'''                strip && row.subset.empty() ? strip->ToLatitude(row.latitude) : std::nullopt;''',
            '''                strip ? strip->ToLatitude(row.latitude) : std::nullopt;''')
t=replace(t,'''                            const Range contribution =
                                density_to_rgb * sources.row->weighted_temperature * *density;
                            const Range total = result.grouped_rgb + Range(0.0, contribution.hi);
                            if (contribution.Finite() && contribution.hi >= 0.0 &&
                                total.hi <= grouped_allowance) {''',
'''                            const bool whole_row = m >= first_whole_row_winding ||
                                                   !sources.subset.empty();
                            const auto weight = whole_row
                                                    ? std::optional(sources.weighted_temperature)
                                                    : sources.row->QueryWeight(sky);
                            const Range contribution =
                                weight ? density_to_rgb * *weight * *density : InvalidRange();
                            const Range total = result.grouped_rgb + Range(0.0, contribution.hi);
                            // Keep most of the grouped allowance available to
                            // deeper windings even when early windows match.
                            const double allowance = m >= first_whole_row_winding
                                                         ? grouped_allowance
                                                         : grouped_allowance * .25;
                            if (contribution.Finite() && contribution.hi >= 0.0 &&
                                total.hi <= allowance) {''')
t=replace(t,'''                        // The immutable row total already includes every longitude.
                        // No individual source is examined while applying this bound.''',
'''                        // Reduce the matching longitude slices via prefix
                        // sums, or use the row's outward aggregate for a
                        // sufficiently faint winding.''')
save(name,t)

name='render/session/kerr_point_detector.cpp'
t=read(name)
t=replace(t,'output.push_back({&row, row.latitude, band, {}});',
            'output.push_back({&row, row.latitude, band, {}, row.weighted_temperature});')
t=replace(t,'            std::array<Range, 3> latitude;', '            std::array<Range, 3> latitude, weight;')
t=replace(t,'                entries.push_back(&entry);',
           '''                weight[band] = weight[band] + entry.weighted_temperature;
                entries.push_back(&entry);''')
t=replace(t,'output.push_back({&row, latitude[band], band, std::move(by_band[band])});',
            'output.push_back({&row, latitude[band], band, std::move(by_band[band]), weight[band]});')
save(name,t)

import json, os, shlex, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

root=Path.cwd()
scratch=root/'out/kerr-scalar-traversal'
build=root/'bin/linux-ci'
inc=scratch/'next'
env={**os.environ,'TMPDIR':str(scratch)}
output=scratch/'focused'
output.mkdir(exist_ok=True)
settings=json.loads((build/'compile_commands.json').read_text())
old=json.loads((scratch/'link-commands.json').read_text())['link'][0]
libs=old[old.index('src/sirius/app/libsirius_app_lib.a'):]
obj={}
compile=[]
for unit in ('point_source_detector','pixel_shading','kerr_point_detector','render_session'):
    suffix='sirius/render/session/'+unit+'.cpp'
    entry,=[entry for entry in settings if entry['file']==str(root/'src'/suffix)]
    flags=shlex.split(entry['command'])
    assert flags[-2]=='-c' and flags[-4]=='-o'
    target=output/(unit+'.o')
    obj[unit]=str(target)
    compile.append([flags[0],'-I'+str(inc),*flags[1:-4],'-o',str(target),'-c',str(inc/suffix)])
runner=output/'block.o'
compile.append(['/usr/bin/g++-14','-std=c++2c','-O3','-DNDEBUG','-fno-access-control',
                '-DSIRIUS_HAS_RETAINED_COMPUTE=1','-I'+str(root/'src'),'-o',str(runner),'-c',
                str(scratch/'block.cpp')])
link=['/usr/bin/g++-14',str(runner),*obj.values(),'-o',str(scratch/'block-bins'),*libs]
def run(args):
    subprocess.run(args,cwd=build,env=env,check=True)

if '--link-only' not in sys.argv:
    with ThreadPoolExecutor(max_workers=3) as executor:
        list(executor.map(run,compile))
run(link)
(output/'commands.json').write_text(json.dumps({'compile':compile,'link':link},indent=2)+'\n')

from pathlib import Path
s=Path('out/kerr-scalar-traversal')
p=s/'next/sirius/render/session/point_source_detector.cpp'
t=p.read_text()
old='''                if (statistics_.candidate_visits == policy_.maximum_candidate_visits) {
                    flush();
                    Fail(PointDetectorFailure::WorkLimit);
                }
                ++statistics_.candidate_visits;'''
new='''                if (statistics_.candidate_visits == policy_.maximum_candidate_visits) {
                    std::clog << "catalogue exhaustion at depth=" << cell.depth
                              << " mixed=" << mixed << " regular=" << result.regular
                              << " cone=" << query_radius << " bound_visits=" << omission_visits_
                              << " standard_box=" << std::hexfloat << cell.lower[0] << ','
                              << cell.lower[1] << ':' << cell.upper[0] << ',' << cell.upper[1]
                              << std::defaultfloat;
                    for (unsigned d=0; d<measure_visits_.size(); ++d)
                        if (measure_visits_[d]) std::clog << " depth" << d << '=' << measure_visits_[d];
                    std::clog << std::endl;
                    flush();
                    Fail(PointDetectorFailure::WorkLimit);
                }
                ++measure_visits_[cell.depth];
                ++statistics_.candidate_visits;'''
assert t.count(old)==1
t=t.replace(old,new)
old='''        statistics_.candidate_visits += available - remaining;'''
assert t.count(old)==1
t=t.replace(old,'''        omission_visits_ += available - remaining;
'''+old)
old='''    PointDetectorStatistics statistics_;'''
assert t.count(old)==1
t=t.replace(old,'''    std::size_t omission_visits_{};
    std::array<std::size_t,21> measure_visits_{};
'''+old)
p.write_text(t)
path=s/'next/sirius/render/session/render_session.cpp'
path.write_bytes(Path('src/sirius/render/session/render_session.cpp').read_bytes())

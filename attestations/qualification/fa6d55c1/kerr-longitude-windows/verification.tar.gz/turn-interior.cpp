#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "sirius/render/session/kerr_point_detector.cpp"

#include <chrono>
#include <iomanip>
#include <iostream>
#include <map>

using namespace sirius;
using namespace sirius::render;

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const auto film=camera.ProjectFilmForObserver(origin[0],origin[1]+22.0,
                                                  sample.pupil_u,sample.pupil_v);
    if (!film||!film->differential) return 40;
    const auto& matrix=film->differential->angular_jacobian;
    const double d=std::fma(matrix[0][0],matrix[1][1],-matrix[0][1]*matrix[1][0]);
    const double sigma=(60*core::constants::math::kPi/180.0)/1080.0;
    const PointDetectorFootprint footprint{
        {0,22}, {{{sigma*matrix[1][1]/d,-sigma*matrix[0][1]/d},
                  {-sigma*matrix[1][0]/d,sigma*matrix[0][0]/d}}}};
    std::cout<<std::hexfloat<<"footprint_matrix "<<footprint.chart_from_standard[0][0]<<' '
              <<footprint.chart_from_standard[0][1]<<' '<<footprint.chart_from_standard[1][0]<<' '
              <<footprint.chart_from_standard[1][1]<<'\n';
    const core::PointStarfieldConfig stars;
    const core::StarfieldSpatialIndex catalogue(core::StarfieldGenerator(
        core::ExpandPointStarfieldConfig(stars)).GenerateCatalogue());
    const auto indexed=PrepareKerrDetectorCatalogue(catalogue);
    #include "turn-cells.inc"
    using namespace core::relativity::finite_tail_detail;
    const Range source_mu(0x1.f4f48bf6938b9p-1,0x1.f4f48bf6938c5p-1);
    const auto latitude_residual = [&](double u) {
        const auto shape = MakeFinitePolarShape(1.0,.9,Range(u),Range(0.0));
        return shape ? sqrt(shape->amplitude2)-source_mu : InvalidRange();
    };
    double a=0x1.c01a4a99ae36dp-2, b=0x1.c01a5c45b2e11p-2;
    std::cout << std::hexfloat << "critical latitude faces=" << latitude_residual(a).lo
              << ':' << latitude_residual(b).hi << std::endl;
    if (!(latitude_residual(a).lo > 0 && latitude_residual(b).hi < 0)) return 41;
    for (int i=0; i<40; ++i) {
        const double m=std::midpoint(a,b);
        const auto residual=latitude_residual(m);
        if (residual.lo>0) a=m;
        else if (residual.hi<0) b=m;
        else break;
    }
    const Range u(a,b);
    std::cout<<"critical radius=["<<u.lo<<','<<u.hi<<"]"<<std::endl;
    const auto cell=archived[66];
    const FilmVector box{Range(cell.lower[0],cell.upper[0]),Range(cell.lower[1],cell.upper[1])};
    const auto evaluate = [&](const FilmVector& x) {
        return EvaluateFilmChart(config,metric.GetParams(),*launch,origin,footprint,x);
    };
    const FilmVector middle{Range(std::midpoint(box[0].lo,box[0].hi)),
                            Range(std::midpoint(box[1].lo,box[1].hi))};
    const auto full=evaluate(box), centre=evaluate(middle);
    if (!full||!centre) return 42;
    const auto &jac=full->jacobian;
    const auto mid=[](Range x){ return std::midpoint(x.lo,x.hi); };
    const double j00=mid(jac[0][0]),j01=mid(jac[0][1]),j10=mid(jac[1][0]),j11=mid(jac[1][1]);
    const double det=j00*j11-j01*j10;
    if (!std::isfinite(det) || det==0) return 43;
    const std::array inverse{std::array{Range(j11/det),Range(-j01/det)},
                             std::array{Range(-j10/det),Range(j00/det)}};
    const FilmVector residual{centre->coordinate[0]-u,centre->coordinate[1]};
    FilmVector map;
    for (unsigned i=0; i<2; ++i) {
        map[i]=middle[i]-inverse[i][0]*residual[0]-inverse[i][1]*residual[1];
        Range norm;
        for (unsigned j=0; j<2; ++j) {
            const Range derivative=Range(i==j ? 1.:0.)-inverse[i][0]*jac[0][j]-inverse[i][1]*jac[1][j];
            map[i]=map[i]+derivative*(box[j]-middle[j]);
            norm=norm+Abs(derivative);
        }
        if (!norm.Finite() || norm.hi>=1) return 44;
        std::cout<<"contraction_axis="<<i<<" norm_upper="<<norm.hi<<" film_coordinate=["
                 <<map[i].lo<<','<<map[i].hi<<"] domain=["<<box[i].lo<<','<<box[i].hi<<"]"<<std::endl;
        if (!map[i].Finite() || !(box[i].lo<map[i].lo && map[i].hi<box[i].hi)) return 45;
    }
    const Range gaussian_r2=Square(map[0])+Square(map[1]);
    std::cout<<"film_gaussian_radius_squared=["<<gaussian_r2.lo<<','<<gaussian_r2.hi<<"]"<<std::endl;
    if (!gaussian_r2.Finite() || !(gaussian_r2.hi<16)) return 46;
    std::cout << "interior_critical_contact=1" << std::endl;
}

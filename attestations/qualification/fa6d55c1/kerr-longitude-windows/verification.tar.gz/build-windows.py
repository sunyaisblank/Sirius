from pathlib import Path
import json,os,subprocess
root=Path.cwd()
s=root/'out/kerr-scalar-traversal'
data=json.loads((s/'focused/commands.json').read_text())
cmd=next(a for a in data['compile'] if a[-1].endswith('/kerr_point_detector.cpp'))
target=str(s/'windows/sirius/render/session/kerr_point_detector.cpp')
obj=str(s/'focused/kerr_windows.o')
cmd=cmd[:1]+['-I'+str(s/'windows')]+cmd[1:-4]+['-o',obj,'-c',target]
link=[obj if a.endswith('/kerr_point_detector.o') else a for a in data['link']]
link[link.index('-o')+1]=str(s/'block-windows')
env={**os.environ,'TMPDIR':str(s)}
for command in (cmd,link):
    subprocess.run(command,cwd=root/'bin/linux-ci',env=env,check=True)
(s/'windows-commands.json').write_text(json.dumps({'compile':cmd,'link':link},indent=2)+'\n')

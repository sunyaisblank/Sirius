import json
import os
from pathlib import Path
import subprocess

root=Path.cwd()
scratch=root/'out/kerr-contact-scheduler'
overlay=scratch/'overlay/sirius/render/session'
target=scratch/'focused'
target.mkdir(exist_ok=True)

pixels=(overlay/'pixel_shading.cpp').read_text()
marker='    const auto group =\n        EvaluatePointDetectorGroup(catalogue, brightness, footprints, probe, cancelled, {},'
assert pixels.count(marker)==1
pixels=pixels.replace(marker,'''    // Keep the original block's launch ray and film origin, then exercise
    // the archived pixel footprint without the other block members.
    if (x == 928 && y == 608 && width == 32 && height == 32) {
        const auto at = std::ranges::find(indices, std::size_t{704});
        if (at == indices.end())
            return std::unexpected(PointDetectorError{PointDetectorFailure::InvalidInput, {}});
        const auto selected = footprints[static_cast<std::size_t>(at - indices.begin())];
        footprints.assign(1, selected);
        indices.assign(1, 704);
    }
''' + marker)
(target/'pixel_shading.cpp').write_text(pixels)

detector=(overlay/'point_source_detector.cpp').read_text()
marker='''        if (finite_bounds_ && coarse.has_hidden_probe && cell.depth + 1 == policy_.maximum_depth) {'''
assert detector.count(marker)==1
detector=detector.replace(marker, '        if (finite_bounds_ && cell.depth + 1 == policy_.maximum_depth) {')
marker='''        if (terminal) {
            FlushFiniteCells();
            Fail(PointDetectorFailure::Unresolved);
        }'''
assert detector.count(marker)==1
detector=detector.replace(marker,'''        if (terminal) {
            std::clog << "unresolved terminal footprint box=" << std::hexfloat
                      << cell.lower[0] << ',' << cell.lower[1] << ':' << cell.upper[0] << ','
                      << cell.upper[1] << std::defaultfloat << " hidden=" << coarse.has_hidden_probe
                      << " probes=" << statistics_.probes
                      << " visits=" << statistics_.candidate_visits << std::endl;
            FlushFiniteCells();
            Fail(PointDetectorFailure::Unresolved);
        }''')
(target/'point_source_detector.cpp').write_text(detector)

data=json.loads((scratch/'link-commands.json').read_text())
environment={**os.environ,'TMPDIR':str(scratch)}
def run(command):
    subprocess.run(command,cwd=root/'bin/linux-ci',env=environment,check=True)

objects={}
for source in ('pixel_shading','point_source_detector'):
    path=target/(source+'.o')
    commands=[row for row in data['compile'] if row[-1].endswith('/'+source+'.cpp')]
    assert len(commands)==1
    run([*commands[0][:-4],'-o',str(path),'-c',str(target/(source+'.cpp'))])
    objects[str(scratch/(source+'.o'))]=str(path)
objects[str(scratch/'block')]=str(scratch/'block-focused')
run([objects.get(flag,flag) for flag in data['link'][0]])

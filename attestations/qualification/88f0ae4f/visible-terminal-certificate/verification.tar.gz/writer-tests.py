import json
import os
from pathlib import Path
import shlex
import subprocess
from xml.etree import ElementTree

root=Path.cwd()
scratch=root/'out/kerr-contact-scheduler'
build=root/'bin/linux-ci'
selected=[
    'PNGWriterTest.DecodeRoundTripMatchesSRGBEncoding',
    'PNGWriterTest.NonFiniteRadianceIsRejected',
    'EXRRoundTripTests.PpmRgbaBoundaryAppliesExactlyOneSrgbEncode',
    'EXRRoundTripTests.HDRGradientSurvivesWriteAndRead',
    'EXRRoundTripTests.NonFiniteRadianceIsRejected',
]
env={**os.environ,'TMPDIR':str(scratch)}
def run(args,cwd=build):
    return subprocess.run(args,cwd=cwd,env=env,check=True)

run(['cmake','--build','--preset','linux-ci','--target','gtest_main','-j','2'],root)
compile_commands=json.loads((build/'compile_commands.json').read_text())
objects=[]
commands=[]
for name in ('png_writer_test.cpp','exr_writer_test.cpp'):
    configured,=[row for row in compile_commands if row['file'].endswith('/'+name)]
    flags=shlex.split(configured['command'])
    assert flags[-2]=='-c' and flags[-4]=='-o'
    target=str(scratch/(name+'.o'))
    objects.append(target)
    command=[*flags[:-4],'-o',target,'-c',configured['file']]
    commands.append(command)
    run(command)
binary=scratch/'writer-tests'
libs=build/'src/sirius'
link=['/usr/bin/g++-14',*objects,str(libs/'render/libsirius_render.a'),
      str(libs/'core/libsirius_core.a'),str(libs/'libsirius_base.a'),'lib/libgtest_main.a',
      'lib/libgtest.a','-pthread','-o',str(binary)]
run(link)
(scratch/'writer-commands.json').write_text(json.dumps({'compile':commands,'link':link},indent=2)+'\n')
xml=scratch/'writer.xml'
run([str(binary),'--gtest_filter='+':'.join(selected),'--gtest_output=xml:'+str(xml)],scratch)
nodes=ElementTree.parse(xml).getroot().findall('.//testcase')
actual=[node.attrib['classname']+'.'+node.attrib['name'] for node in nodes]
assert sorted(actual)==sorted(selected)
assert all(node.attrib['status']=='run' and
           all(node.find(tag) is None for tag in ('skipped','failure','error')) for node in nodes)
print('Five original output-writer witnesses passed with zero failures, errors or skips.')

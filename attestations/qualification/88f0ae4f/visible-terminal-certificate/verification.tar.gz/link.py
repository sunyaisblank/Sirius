from concurrent.futures import ThreadPoolExecutor
import gzip
import json
from pathlib import Path
import os
import shlex
import subprocess
import sys

root = Path.cwd()
scratch = root / 'out/kerr-contact-scheduler'
build = root / 'bin/linux-ci'
overlay = scratch / 'overlay'
workdir = overlay / 'sirius/render/session'
history = root / 'attestations/qualification/7fd2aa59/kerr-finite-turn/early-build.json.gz'
historical = json.loads(gzip.decompress(history.read_bytes()))
compile_commands = json.loads((build / 'compile_commands.json').read_text())
objects = {}
compile_jobs = []
for name in ('point_source_detector', 'kerr_point_detector', 'pixel_shading'):
    configured, = [row for row in compile_commands if row['file'].endswith('/session/'+name+'.cpp')]
    flags = shlex.split(configured['command'])
    assert flags[-2] == '-c' and flags[-4] == '-o'
    objects[name] = str(scratch/(name+'.o'))
    compile_jobs.append([flags[0], '-I'+str(overlay), *flags[1:-4], '-o', objects[name],
                         '-c', str(workdir/(name+'.cpp'))])
block_flags, = [row for row in historical['compile'] if row[-1].endswith('/block.cpp')]
objects['block'] = str(scratch/'block.o')
compile_jobs.append([*block_flags[:-4], '-o', objects['block'], '-c', str(scratch/'block.cpp')])
common = ['/usr/bin/g++-14', '-I'+str(overlay), '-I'+str(root/'src'),
          '-std=c++2c','-DNDEBUG','-O3','-Wall','-Wextra','-Werror',
          '-DSIRIUS_CONTRACT_MODE=2','-DSIRIUS_HAS_RETAINED_COMPUTE=1','-DSIRIUS_RELEASE_RESOURCE_LOCKED=1',
          '-fno-fast-math','-ffp-contract=off','-frounding-math']
for name in ('compare-finite','probe-groups'):
    objects[name] = str(scratch/(name+'.o'))
    compile_jobs.append([*common, '-o', objects[name], '-c', str(scratch/(name+'.cpp'))])

libs = historical['link'][historical['link'].index('src/sirius/app/libsirius_app_lib.a'):]
link_jobs = [
    ['/usr/bin/g++-14', *[objects[name] for name in ('block','point_source_detector','pixel_shading','kerr_point_detector')],
     '-o',str(scratch/'block'), *libs],
    ['/usr/bin/g++-14', objects['compare-finite'], objects['point_source_detector'],
     '-o',str(scratch/'compare-finite'), *libs],
    ['/usr/bin/g++-14', objects['probe-groups'], objects['point_source_detector'],
     '-o',str(scratch/'probe-groups'), *libs],
]
env = {**os.environ,'TMPDIR':str(scratch)}
with ThreadPoolExecutor(max_workers=4) as workers:
    list(workers.map(lambda flags: subprocess.run(flags,cwd=build,env=env,check=True),
                     compile_jobs[:1] if '--detector' in sys.argv else
                     compile_jobs if '--compile' in sys.argv else link_jobs))
if '--compile' not in sys.argv:
    (scratch/'link-commands.json').write_text(json.dumps({'compile':compile_jobs,'link':link_jobs},indent=2)+'\n')

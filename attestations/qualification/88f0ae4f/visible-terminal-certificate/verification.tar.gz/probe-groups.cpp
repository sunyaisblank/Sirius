#include "sirius/render/session/point_source_detector.h"

#include <array>
#include <cmath>
#include <iostream>
#include <vector>

using namespace sirius;
using namespace sirius::render;

int main() {
    const core::StarfieldSpatialIndex catalogue(std::vector<core::StarEntry>{});
    const std::array footprints{PointDetectorFootprint{{0.0, 0.0}, {{{1.,0.},{0.,1.}}}}};
    for (const unsigned mode : {0u,1u,2u,3u,4u,5u,6u}) {
        std::size_t callbacks = 0, admitted = 0, spent = 0, legacy = 0;
        bool cancelled = false;
        const PointDetectorSampler sample = [](DetectorCoordinate z)
            -> std::expected<PointDetectorProbe,PointDetectorFailure> {
            if (z[0] == std::floor(z[0]) && z[1] == std::floor(z[1])) return PointDetectorProbe{};
            PointDetectorProbe point;
            point.visible = true;
            point.direction = {1.0, .001*z[0], .001*z[1]};
            point.source_derivative = {{{.001,0.},{0.,.001}}};
            return point;
        };
        const PointDetectorFiniteBounds groups{
            [&](const PointDetectorFootprint&, const PointDetectorCell&, std::size_t& remaining)
                -> std::optional<PointDetectorPolarContact> {
                if (remaining == 0) return {};
                --remaining;
                ++spent;
                const bool escaping = !((mode == 5 || mode == 6) && spent == 1);
                return PointDetectorPolarContact{1, escaping};
            },
            [&](const PointDetectorFootprint&, std::span<const PointDetectorCell> cells,
                std::size_t& remaining) -> std::optional<std::array<double,3>> {
                ++callbacks;
                if (mode == 4) {
                    ++remaining;
                    return {};
                }
                if (mode == 3) cancelled = true;
                if (remaining == 0) return {};
                --remaining;
                ++spent;
                if (mode == 2 || (mode == 1 && cells.size() > 4)) return {};
                admitted += cells.size();
                return std::array<double,3>{1e-10*cells.size(),2e-10*cells.size(),3e-10*cells.size()};
            }};
        PointDetectorPolicy policy;
        policy.maximum_depth = 2;
        policy.minimum_depth = 2;
        const PointDetectorCellBound single =
            [&](const PointDetectorFootprint&, const DetectorCoordinate&, const DetectorCoordinate&,
                std::size_t& remaining) -> std::optional<std::array<double,3>> {
                ++legacy;
                if (remaining == 0) return {};
                --remaining;
                ++spent;
                if (mode != 5) return {};
                return std::array<double,3>{1e-10,2e-10,3e-10};
            };
        const auto result = EvaluatePointDetectorGroup(catalogue, 1.0, footprints, sample,
            [&]{return cancelled;},policy,{},{},single,groups);
        const auto& stats = result ? result->statistics : result.error().statistics;
        std::cout << "mode=" << mode << " completed=" << bool(result)
                  << " reason=" << (result ? -1 : int(result.error().reason))
                  << " probes=" << stats.probes << " cells=" << stats.cells
                  << " callbacks=" << callbacks << " charged=" << stats.candidate_visits
                  << " actual=" << spent << " admitted=" << admitted << " legacy=" << legacy;
        if (result)
            for (const auto error : result->samples[0].estimated_error) std::cout << ' ' << error;
        std::cout << '\n';
        if (spent != stats.candidate_visits) return 1;
        if (mode < 2) {
            const auto wanted = mode == 0 ? 1u : 7u;
            if (!result || admitted != 16 || callbacks != wanted ||
                result->samples[0].rgb != std::array<double,3>{} ||
                result->samples[0].estimated_error[0] < 1.6e-9 ||
                result->samples[0].estimated_error[0] > 1.601e-9)
                return 2;
        } else if (mode < 5) {
            const std::array reasons{PointDetectorFailure::Unresolved, PointDetectorFailure::Cancelled,
                                     PointDetectorFailure::Arithmetic};
            if (result || result.error().reason != reasons[mode-2] ||
                (mode >= 3 && callbacks != 1)) return 3;
        } else if (admitted != 15 || legacy != 1 || callbacks != 1) {
            return 4;
        } else if (mode == 5) {
            if (!result || result->samples[0].estimated_error[0] < 1.6e-9 ||
                result->samples[0].estimated_error[0] > 1.601e-9)
                return 5;
        } else if (result || result.error().reason != PointDetectorFailure::Unresolved) {
            return 6;
        }
    }
}

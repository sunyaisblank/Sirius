from pathlib import Path

work = Path(__file__).resolve().parent
base = work / 'overlay/sirius/render/session'

def change(name, edits):
    path = base / name
    source = path.read_text()
    for before, after in edits:
        assert source.count(before) == 1, (name, before, source.count(before))
        source = source.replace(before, after)
    path.write_text(source)

change('point_source_detector.h', [
    ('''struct PointDetectorFiniteBounds {
    std::function<bool(const PointDetectorFootprint&, const PointDetectorCell&)> contains;''',
     '''struct PointDetectorPolarContact {
    std::uint32_t source;
    bool strictly_escaping;
};

struct PointDetectorFiniteBounds {
    std::function<std::optional<PointDetectorPolarContact>(
        const PointDetectorFootprint&, const PointDetectorCell&, std::size_t&)> select;'''),
])
change('kerr_point_detector.h', [
    ('''[[nodiscard]] bool StrictlyEscapingKerrDetectorCell(
    const core::CameraConfig& camera, const backend::DetectorLaunchFrame& launch,
    const DetectorCoordinate& film_origin, const PointDetectorFootprint& footprint,
    const PointDetectorCell& cell);''',
     '''[[nodiscard]] std::optional<PointDetectorPolarContact> FindKerrDetectorPolarContact(
    const KerrDetectorCatalogue& catalogue, const core::CameraConfig& camera,
    const backend::DetectorLaunchFrame& launch, const DetectorCoordinate& film_origin,
    const PointDetectorFootprint& footprint, const PointDetectorCell& cell,
    const std::function<bool()>& cancelled, std::size_t& remaining);'''),
])
change('pixel_shading.cpp', [
    ('''        finite_bounds.contains = [&, origin](const PointDetectorFootprint& footprint,
                                             const PointDetectorCell& cell) {
            return StrictlyEscapingKerrDetectorCell(camera.GetConfig(), *prepared, origin,
                                                   footprint, cell);
        };''',
     '''        finite_bounds.select = [&, origin](const PointDetectorFootprint& footprint,
                                           const PointDetectorCell& cell, std::size_t& remaining) {
            return FindKerrDetectorPolarContact(*kerr_catalogue, camera.GetConfig(), *prepared,
                                              origin, footprint, cell, cancelled, remaining);
        };'''),
])

kerr = base/'kerr_point_detector.cpp'
source = kerr.read_text()
source = source.replace('''  private:
    std::span<const core::StarEntry> stars_;''', '''    std::optional<std::uint32_t> SinglePolarContact(Range amplitude,
                                                    const std::function<bool()>& cancelled,
                                                    std::size_t& remaining) const {
        const auto* angular = Get(cancelled);
        if (!angular || !amplitude.Finite()) return {};
        std::call_once(prepare_latitude_, [&] {
            try {
                std::vector<const AngularCatalogue::Entry*> sorted;
                sorted.reserve(stars_.size());
                for (bool north : {false, true})
                    for (const auto& row : angular->Rows(north))
                        for (const auto& entry : row.entries) {
                            sorted.push_back(&entry);
                            latitude_width_ = std::max(latitude_width_,
                                (Range(entry.latitude.hi) - Range(entry.latitude.lo)).hi);
                        }
                std::ranges::sort(sorted, {}, [](const auto* entry) { return entry->latitude.lo; });
                latitude_order_ = std::move(sorted);
            } catch (const std::bad_alloc&) {
                // Ordinary bounded traversal remains available.
            }
        });
        const double cutoff = (Range(amplitude.lo) - Range(latitude_width_)).lo;
        auto current = std::ranges::lower_bound(latitude_order_, cutoff, {},
                                               [](const auto* entry) { return entry->latitude.lo; });
        std::optional<std::uint32_t> result;
        for (; current != latitude_order_.end() && (*current)->latitude.lo <= amplitude.hi;
             ++current) {
            if (remaining == 0 || (cancelled && cancelled())) return {};
            --remaining;
            if ((*current)->latitude.hi < amplitude.lo) continue;
            if (result) return {};
            result = static_cast<std::uint32_t>(current - latitude_order_.begin());
        }
        return result;
    }

  private:
    std::span<const core::StarEntry> stars_;
    mutable std::once_flag prepare_latitude_;
    mutable std::vector<const AngularCatalogue::Entry*> latitude_order_;
    mutable double latitude_width_ = 0.0;''')
start = source.index('bool StrictlyEscapingKerrDetectorCell(')
end = source.index('std::optional<std::array<double, 3>> BoundKerrDetectorCells(',start)
replacement = '''std::optional<PointDetectorPolarContact> FindKerrDetectorPolarContact(
    const KerrDetectorCatalogue& catalogue, const core::CameraConfig& camera,
    const backend::DetectorLaunchFrame& launch, const DetectorCoordinate& film_origin,
    const PointDetectorFootprint& footprint, const PointDetectorCell& cell,
    const std::function<bool()>& cancelled, std::size_t& remaining) {
    const auto& [mass, spin, charge, lambda] = launch.metric;
    if (!(mass > spin && spin > 0.0) || charge != 0.0 || lambda != 0.0 || !RoundingEnvironment())
        return {};
    const core::KerrSchildParams metric{mass, spin, charge, lambda};
    FilmVector box{Range(cell.lower[0], cell.upper[0]), Range(cell.lower[1], cell.upper[1])};
    if (!box[0].Finite() || !box[1].Finite()) return {};
    box = ClipGaussian(box);
    if (!box[0].Finite() || !box[1].Finite()) return {};
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(camera, metric, launch, film_origin, footprint, region);
    };
    const auto chart = evaluate(box);
    if (!chart) return {};
    const auto [radius, potential] = CoverEscapingChart(box, *chart, evaluate);
    if (!radius.Finite() || !potential.Finite() || !(potential.lo < 0.0)) return {};
    const bool escaping = potential.hi < 0.0;
    const Range scale(escaping ? sqrt(Range(-potential.hi)).lo : 0.0,
                      sqrt(Range(-potential.lo)).hi);
    const auto shape = MakeFinitePolarShape(mass, spin, radius, scale);
    if (!shape) return {};
    const auto contact = catalogue.SinglePolarContact(sqrt(shape->amplitude2), cancelled, remaining);
    if (!contact) return {};
    return PointDetectorPolarContact{*contact, escaping};
}

'''
source = source[:start] + replacement + source[end:]
kerr.write_text(source)

change('point_source_detector.cpp', [
    ('''    std::function<bool(const PointDetectorCell&)> contains;''',
     '''    std::function<std::optional<PointDetectorPolarContact>(
        const PointDetectorCell&, std::size_t&)> select;'''),
    ('''            FlushFiniteCells();
            if (queued_cells_ != 0) {''',
     '''            FlushFiniteCells();
            if (pending_critical_) {
                const Cell critical{pending_critical_->lower, pending_critical_->upper,
                                    policy_.maximum_depth};
                const auto original = Refine(critical, Measure(critical));
                for (unsigned channel = 0; channel < 3; ++channel)
                    queued_error_[channel] =
                        queued_error_[channel] + finite_tail::Range(original.error[channel]);
            }
            if (queued_cells_ != 0 || pending_critical_) {'''),
    # The critical leaf had already consumed a cell ticket at scheduling time.
    ('''                const auto original = Refine(critical, Measure(critical));''',
     '''                --statistics_.cells;
                const auto original = Refine(critical, Measure(critical));'''),
    ('''            if (result.bounded_omission) {
                using finite_tail::Range;''',
     '''            if (result.bounded_omission) {
                using finite_tail::Range;'''), 
    ('''            const bool eligible = finite_bounds_->contains(bounds);
            CheckCancellation();
            if (eligible) {
                pending_cells_.push_back(bounds);
                ++queued_cells_;
                if (pending_cells_.size() == 32) FlushFiniteCells();
                result.bounded_omission = true;
                return result;
            }''',
     '''            const auto available = policy_.maximum_candidate_visits - statistics_.candidate_visits;
            auto remaining = available;
            const auto contact = finite_bounds_->select(bounds, remaining);
            if (remaining > available) Fail(PointDetectorFailure::Arithmetic);
            statistics_.candidate_visits += available - remaining;
            selector_visits_ += available - remaining;
            CheckCancellation();
            if (contact && contact->strictly_escaping) {
                if (pending_source_ && *pending_source_ != contact->source) FlushFiniteCells();
                pending_source_ = contact->source;
                pending_cells_.push_back(bounds);
                ++queued_cells_;
                std::clog << "queued finite polar cell " << std::hexfloat << bounds.lower[0]
                          << ',' << bounds.lower[1] << std::defaultfloat << " source="
                          << contact->source << " pending=" << pending_cells_.size() << std::endl;
                if (pending_cells_.size() == 32) FlushFiniteCells();
                result.bounded_omission = true;
                return result;
            }
            if (contact && !pending_critical_) {
                pending_critical_ = bounds;
                std::clog << "deferred critical polar cell " << std::hexfloat << bounds.lower[0]
                          << ',' << bounds.lower[1] << std::defaultfloat << " source="
                          << contact->source << std::endl;
                result.bounded_omission = true;
                return result;
            }'''),
    ('''        ++group_attempts_;
        const auto available''',
     '''        ++group_attempts_;
        std::clog << "finite polar certificate begin cells=" << cells.size()
                  << " probes=" << statistics_.probes
                  << " visits=" << statistics_.candidate_visits << std::endl;
        const auto available'''),
    ('''        CheckCancellation();
        if (bound && std::ranges::all_of(*bound, [&](double error)''',
     '''        CheckCancellation();
        if (bound && std::ranges::all_of(*bound, [&](double error)'''),
    ('''            ++group_accepted_;
            for (unsigned i = 0; i < 3; ++i)''',
     '''            ++group_accepted_;
            std::clog << "finite polar certificate accepted cells=" << cells.size()
                      << " visits=" << available - remaining
                      << " rgb_bound=" << (*bound)[0] << std::endl;
            for (unsigned i = 0; i < 3; ++i)'''),
    ('''        if (cells.size() == 1) Fail(PointDetectorFailure::Unresolved);''',
     '''        std::clog << "finite polar certificate declined cells=" << cells.size()
                  << " visits=" << available - remaining << std::endl;
        if (cells.size() == 1) Fail(PointDetectorFailure::Unresolved);'''),
    ('''        pending_cells_.clear();
    }''',
     '''        pending_cells_.clear();
        pending_source_.reset();
    }'''),
    ('''        if (queued_cells_ != 0)
            std::clog''',
     '''        if (queued_cells_ != 0 || selector_visits_ != 0 || pending_critical_)
            std::clog'''),
    ('''                      << " total_visits=" << statistics_.candidate_visits''',
     '''                      << " selector_visits=" << selector_visits_
                      << " total_visits=" << statistics_.candidate_visits'''),
    ('''        if (terminal) FlushFiniteCells();
        // At the last split''',
     '''        // At the last split'''),
    ('''        if (terminal) Fail(PointDetectorFailure::Unresolved);
        const auto children''',
     '''        if (terminal) {
            FlushFiniteCells();
            Fail(PointDetectorFailure::Unresolved);
        }
        const auto children'''),
    ('''    std::vector<PointDetectorCell> pending_cells_;''',
     '''    std::vector<PointDetectorCell> pending_cells_;
    std::optional<std::uint32_t> pending_source_;
    std::optional<PointDetectorCell> pending_critical_;
    std::size_t selector_visits_ = 0;'''),
    ('''                    if (finite_bounds.contains && finite_bounds.bound) {
                        local_finite.contains = [&](const PointDetectorCell& cell) {
                            return finite_bounds.contains(footprint, cell);
                        };''',
     '''                    if (finite_bounds.select && finite_bounds.bound) {
                        local_finite.select = [&](const PointDetectorCell& cell,
                                                  std::size_t& remaining) {
                            return finite_bounds.select(footprint, cell, remaining);
                        };'''),
    ('''                                               local_finite.contains ? &local_finite : nullptr)''',
     '''                                               local_finite.select ? &local_finite : nullptr)'''),
])

# A finite-contact parent uses its individual terminal charts before any
# whole-parent query can consume the shared visit ledger.
change('point_source_detector.cpp', [
    ("""            coarse.whole_sky_query && cell.depth + 1 == policy_.maximum_depth;""",
     """            !finite_bounds_ && coarse.whole_sky_query &&
            cell.depth + 1 == policy_.maximum_depth;"""),
])

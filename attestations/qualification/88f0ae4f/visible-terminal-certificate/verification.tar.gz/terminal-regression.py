import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
from xml.etree import ElementTree

root=Path.cwd()
scratch=root/'out/kerr-contact-scheduler'
build=root/'bin/linux-ci'
libs=build/'src/sirius'
env={**os.environ,'TMPDIR':str(scratch)}
configured,=[row for row in json.loads((build/'compile_commands.json').read_text())
             if row['file'].endswith('/point_source_detector_test.cpp')]
flags=shlex.split(configured['command'])
assert flags[-2]=='-c' and flags[-4]=='-o'
obj=scratch/'point-source-tests.o'
binary=scratch/'terminal-regression'
before='--before' in sys.argv
compile=[*flags[:-4],'-o',str(obj),'-c',configured['file']]
def run(args,**kwargs):
    return subprocess.run(args,cwd=build,env=env,**kwargs)
if before:
    run(compile,check=True)
link=['/usr/bin/g++-14',str(obj),str(libs/'render/libsirius_render.a'),
      str(libs/'core/libsirius_core.a'),str(libs/'libsirius_base.a'),
      'lib/libgtest_main.a','lib/libgtest.a','-pthread','-o',str(binary)]
run(link,check=True)
label='before' if before else 'after'
xml=scratch/f'terminal-regression-{label}.xml'
name='PointSourceDetector.VisibleTerminalCellsUseTheOriginalFootprintAllowance'
test=run([str(binary),'--gtest_filter='+(name if before else 'PointSourceDetector.*'),
          '--gtest_output=xml:'+str(xml)])
nodes=ElementTree.parse(xml).getroot().findall('.//testcase')
if before:
    assert test.returncode==1 and len(nodes)==1 and nodes[0].find('failure') is not None
else:
    assert test.returncode==0 and len(nodes)==20 and any(
        node.attrib['classname']+'.'+node.attrib['name']==name for node in nodes)
    assert all(node.attrib['status']=='run' and
               all(node.find(tag) is None for tag in ('skipped','failure','error')) for node in nodes)
(scratch/'terminal-regression-commands.json').write_text(
    json.dumps({'compile':compile,'link':link},indent=2)+'\n')

#!/usr/bin/env bash
set -euo pipefail
base="$PWD"
s="$base/out/kerr-catalogue-aggregate"
lib="$base/bin/linux-ci/src/sirius"
export TMPDIR="$s"
g++-14 -I"$s/extension-overlay" -I"$base/src" -std=c++2c -O3 -DNDEBUG -Wall -Wextra -Werror \
    -DSIRIUS_CONTRACT_MODE=2 -DSIRIUS_HAS_RETAINED_COMPUTE=1 -DSIRIUS_RELEASE_RESOURCE_LOCKED=1 \
    -fno-fast-math -ffp-contract=off -frounding-math "$s/branch-reference.cpp" \
    "$lib/backend/libsirius_backend_cpu.a" "$lib/backend/libsirius_backend.a" \
    "$lib/core/libsirius_core.a" "$lib/libsirius_base.a" -lvulkan -ldl -lrt -pthread -o "$s/branch-reference"
cd "$s"
env -u SIRIUS_PACKAGED_SOFTWARE_VULKAN VK_DRIVER_FILES="$HOME/.local/opt/mesa-dzn/dzn_icd.x86_64.json" SIRIUS_VULKAN_DEVICE=0 SIRIUS_MEMORY_BUDGET_MB=2048 MESA_SHADER_CACHE_DISABLE=true XDG_CACHE_HOME="$PWD/branch-cache" /usr/bin/time -v timeout 50 ./branch-reference

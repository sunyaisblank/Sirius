// The finite film cell ends before some latitude branches become complete
// over radius. Continue the separated radial chart slightly past that edge
// to certify a single branch. Only physical roots contribute to the flux.
std::optional<AzimuthDerivative> ExtendLatitudeBranch(
    double mass, double spin, Range centre, Range scale, const StationaryChart& chart,
    const FiniteCandidate& candidate) {
    const Range extended(0.0, (Range(scale.hi) * Range(65.0 / 64.0)).hi);
    const auto prior =
        EncloseRegularizedRadialPhase(mass, spin, centre, extended, chart.inverse_start, 128);
    const auto shape = MakeFinitePolarShape(mass, spin, centre, extended);
    if (!prior || !shape) return {};
    const auto latitude = candidate.source->latitude;
    const double clearance = (sqrt(shape->amplitude2) - latitude).lo;
    if (!(clearance > 0.0) ||
        !EncloseLatitudeRootMonotonicity(mass, spin, centre, extended, chart.initial_mu,
                                       clearance, *prior))
        return {};
    const Range edge_scale(extended.hi);
    const auto edge =
        EvaluateFiniteRadialPhase(mass, spin, centre, edge_scale, chart.inverse_start);
    if (!edge) return {};
    const Range edge_log = LogPoint(extended.hi);
    const Range edge_time = Range(-2.0) * edge->leading * edge_log + edge->time_residual;
    const Range target_at_edge =
        PolarTargetAt(mass, spin, centre, edge_scale, chart.initial_mu, latitude,
                      candidate.winding, candidate.approaching_equator)[0];
    if (!edge_time.Finite() || !target_at_edge.Finite() || !(target_at_edge.lo > edge_time.hi))
        return {};
    const Range target =
        PolarTargetAt(mass, spin, centre, extended, chart.initial_mu, latitude,
                      candidate.winding, candidate.approaching_equator)[0];
    const Range log_scale = (prior->time_remainder.value - target) /
                            (Range(2.0) * prior->leading_factor);
    if (!log_scale.Finite()) return {};
    const Range log_branch(log_scale.lo, std::min(edge_log.hi, log_scale.hi));
    const Range separation = ExpBounds(log_branch);
    if (!separation.Finite() || separation.lo > extended.hi) return {};
    return DifferentiateFiniteAzimuth(mass, spin, centre,
                                     {separation.lo, std::min(separation.hi, extended.hi)},
                                     log_branch, chart, candidate.winding,
                                     candidate.approaching_equator, latitude);
}


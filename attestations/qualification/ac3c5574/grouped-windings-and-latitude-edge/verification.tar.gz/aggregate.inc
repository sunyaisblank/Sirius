// Share the differentiated fixed-angle integrals across a strip of small
// radial turning separations. Each partial then needs only one local panel
// and the Leibniz boundary term for its moving polar endpoint.
class PolarDerivativeStrip {
  public:
    static std::optional<PolarDerivativeStrip> Prepare(double mass, double spin, Range centre,
                                                        Range scale, const StationaryChart& chart) {
        PolarDerivativeStrip result;
        const Range domain(0.0, std::min(scale.hi, 0x1p-10));
        const auto radial =
            EncloseRegularizedRadialPhase(mass, spin, centre, domain, chart.inverse_start, 128);
        const FilmJet u(centre, {Range(1.0), Range(0.0)}), s(domain, {Range(0.0), Range(1.0)});
        const auto constants =
            InvertStationaryScalars(mass, spin, std::array{u, FilmJet(0.0) - Square(s)});
        if (!radial || !constants) return {};
        result.radial_ = *radial;
        result.a2_ = Square(FilmJet(spin));
        result.angular_ = constants->lambda;
        const auto p = result.a2_ - constants->eta - Square(result.angular_);
        result.omega2_ =
            (sqrt(Square(p) + FilmJet(4.0) * result.a2_ * constants->eta) - p) * FilmJet(.5);
        result.amplitude2_ = constants->eta / result.omega2_;
        result.amplitude_ = sqrt(result.amplitude2_);
        result.maximum_log_scale_ = LogPoint(domain.hi).lo;
        if (!result.amplitude_.value.Finite() || !std::isfinite(result.maximum_log_scale_))
            return {};
        for (unsigned i = 0; i < kPanels; ++i) {
            const auto sample = result.At({Node(i), Node(i + 1)});
            const FilmJet width(Range(Node(i + 1)) - Range(Node(i)));
            for (unsigned j = 0; j < sample.size(); ++j)
                result.prefix_[i + 1][j] = result.prefix_[i][j] + sample[j] * width;
        }
        const auto half = result.Integrate(
            FilmJet(Range(kPiBounds.lo * .5, kPiBounds.hi * .5)));
        const auto initial = result.ToLatitude(chart.initial_mu);
        if (!half || !initial) return {};
        result.initial_ = *initial;
        for (unsigned j = 0; j < half->size(); ++j)
            result.period_[j] = (*half)[j] * FilmJet(2.0);
        return result;
    }

    using PolarJet = std::array<FilmJet, 2>;

    std::optional<PolarJet> ToLatitude(Range latitude) const {
        const FilmJet ratio = FilmJet(latitude) / amplitude_;
        const Range value = AsinBounds(ratio.value), divisor = sqrt(Range(1.0) - Square(ratio.value));
        return Integrate({value, {ratio.derivative[0] / divisor, ratio.derivative[1] / divisor}});
    }

    bool Covers(Range log_separation) const { return log_separation.hi <= maximum_log_scale_; }

    std::optional<Range> Density(Range latitude, const PolarJet& final, unsigned winding,
                                 bool approach, Range log_separation, Range separation,
                                 Range sky) const {
        if (!sky.Finite()) return {};
        PolarJet target;
        for (unsigned j = 0; j < target.size(); ++j)
            target[j] = period_[j] * FilmJet(winding) + initial_[j] +
                        (approach ? period_[j] - final[j] : final[j]);
        const Range radial_u =
            Range(-2.0) * radial_.leading_gradient[0] * log_separation + radial_.time_remainder.radial;
        const Range transverse = separation * target[0].derivative[1] - radial_.time_log_derivative;
        if (!(transverse.lo > 0.0)) return {};
        const Range log_s_u = (radial_u - target[0].derivative[0]) / transverse;
        const Range slope = Abs(target[1].derivative[0] + radial_.spin_remainder.radial +
                                (separation * target[1].derivative[1] + radial_.spin_remainder.log_scale) *
                                    log_s_u);
        if (!(slope.lo > 0.0)) return {};
        const Range z2 = Square(latitude);
        const Range speed = sqrt((amplitude2_.value - z2) * (omega2_.value + a2_.value * z2));
        const Range span = (Range(sky.hi) - Range(sky.lo)) / (Range(2.0) * kPiBounds);
        const Range roots = Range(1.0) + Range(std::floor(span.hi));
        const Range density = roots * Range(2.0) * Square(separation) / (slope * transverse * speed);
        return density.Finite() ? std::optional(density) : std::nullopt;
    }

  private:
    static constexpr unsigned kPanels = 128;
    static constexpr double kEnd = kPiBounds.hi * .5;
    static double Node(unsigned i) { return std::scalbn(double(i) * kEnd, -7); }

    PolarJet At(Range angle) const {
        const auto sin2 = FilmJet(Square(SineLobe(angle)));
        const FilmJet time = FilmJet(1.0) / sqrt(omega2_ + a2_ * amplitude2_ * sin2);
        return {time, time * (angular_ / (FilmJet(1.0) - amplitude2_ * sin2) +
                              FilmJet(radial_.limiting_drag, radial_.drag_gradient))};
    }

    std::optional<PolarJet> Integrate(const FilmJet& phase) const {
        const Range angle = phase.value;
        if (!angle.Finite() || angle.lo < 0.0 || angle.hi > kEnd) return {};
        unsigned i = std::min(kPanels, unsigned(angle.lo / kEnd * kPanels));
        if (Node(i) > angle.lo) --i;
        const auto sample = At({Node(i), angle.hi});
        const auto boundary = At(angle);
        const FilmJet length(angle - Range(Node(i)));
        PolarJet result;
        for (unsigned j = 0; j < sample.size(); ++j) {
            result[j] = prefix_[i][j] + sample[j] * length;
            for (unsigned axis = 0; axis < 2; ++axis)
                result[j].derivative[axis] =
                    result[j].derivative[axis] + boundary[j].value * phase.derivative[axis];
            if (!result[j].value.Finite() || !result[j].derivative[0].Finite() ||
                !result[j].derivative[1].Finite())
                return {};
        }
        return result;
    }

    FilmJet a2_, angular_, omega2_, amplitude2_, amplitude_;
    RegularizedRadialPhase radial_;
    double maximum_log_scale_;
    PolarJet period_, initial_;
    std::array<PolarJet, kPanels + 1> prefix_{};
};


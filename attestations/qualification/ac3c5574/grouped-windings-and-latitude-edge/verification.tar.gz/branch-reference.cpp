#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "sirius/render/session/kerr_point_detector.cpp"

#include <iomanip>
#include <iostream>
#include <map>

using namespace sirius;
using namespace sirius::render;

using Real = long double;
using Pair = std::array<Real, 2>;

struct PolarReference {
    Real angular, amplitude2, omega2, drag;
};

PolarReference IndependentShape(Real mass, Real spin, Real centre, Real separation) {
    const Real u = centre, a = spin;
    const auto delta = [&](Real x) { return 1 - 2 * mass * x + a * a * x * x; };
    const Real b = delta(u) * u * u;
    const Real db = (2 * a * a * u - 2 * mass) * u * u + 2 * delta(u) * u;
    Real angular = 3, carter = 25;
    for (int i = 0; i < 16; ++i) {
        const Real k = a * a - a * angular;
        const Real p = 1 + k * u * u, dp = 2 * k * u;
        const Real residual = p * p - b * carter + separation * separation;
        const Real tangent = 2 * p * dp - db * carter;
        const Real d_l = -2 * a * u * u * p, d_c = -b;
        const Real d_dl = -2 * a * (u * u * dp + 2 * u * p), d_dc = -db;
        const Real det = d_l * d_dc - d_c * d_dl;
        angular -= (d_dc * residual - d_c * tangent) / det;
        carter -= (d_l * tangent - d_dl * residual) / det;
    }
    const Real eta = carter - (angular - a) * (angular - a);
    const Real k = eta + angular * angular - a * a;
    const Real omega2 = (k + std::sqrt(k * k + 4 * a * a * eta)) / 2;
    Real low = 0, high = u;
    for (int i = 0; i < 85; ++i) {
        const Real q = std::midpoint(low, high);
        const Real p = 1 + (a * a - a * angular) * q * q;
        if (p * p - delta(q) * q * q * carter > 0)
            low = q;
        else
            high = q;
    }
    const Real turn = std::midpoint(low, high);
    return {angular, eta / omega2, omega2,
            turn * (2 * a * mass - a * a * angular * turn) / delta(turn)};
}

Pair IndependentPartial(Real mass, Real spin, Real centre, Real separation, Real latitude) {
    const auto shape = IndependentShape(mass, spin, centre, separation);
    constexpr int panels = 16384;
    const Real end = std::asin(std::min(1.L, latitude / std::sqrt(shape.amplitude2)));
    const Real step = end / panels;
    Pair integral{};
    for (int i = 0; i <= panels; ++i) {
        const Real sin = std::sin(i * step);
        const Real mu2 = shape.amplitude2 * sin * sin;
        const Real time = 1 / std::sqrt(shape.omega2 + spin * spin * mu2);
        const Real factor = (i == 0 || i == panels ? 1 : (i % 2 ? 4 : 2)) * step / 3;
        integral[0] += factor * time;
        integral[1] += factor * time * (shape.angular / (1 - mu2) + shape.drag);
    }
    return integral;
}
Pair IndependentRadial(Real mass, Real spin, Real u, Real s, Real launch) {
    const auto shape = IndependentShape(mass,spin,u,s);
    const Real a = spin, l = shape.angular;
    const Real eta = shape.amplitude2 * shape.omega2, carter = eta + (l-a)*(l-a);
    const auto delta = [&](Real q) { return 1 - 2 * mass * q + a * a * q * q; };
    const auto radial = [&](Real q) {
        const Real p = 1 + (a*a-a*l)*q*q;
        return p*p-delta(q)*q*q*carter;
    };
    Real lower = 0, upper = u;
    for (int i=0; i<85; ++i) {
        const Real mid = std::midpoint(lower,upper);
        (radial(mid)>0 ? lower : upper)=mid;
    }
    const Real outer = std::midpoint(lower,upper);
    lower=u;
    upper=u*1.01L;
    if (!(radial(upper)>0)) throw std::runtime_error("inner radial root bracket");
    for (int i=0; i<85; ++i) {
        const Real mid = std::midpoint(lower,upper);
        (radial(mid)>0 ? upper : lower)=mid;
    }
    const Real inner = std::midpoint(lower,upper), gap = inner-outer;
    const Real k4 = -a*a*eta, k3 = 2*mass*carter;
    const Real c0 = 1/(outer*inner), c1 = k3+(outer+inner)*k4;
    constexpr unsigned panels=8192;
    Pair integral{};
    for (const Real end : {launch,0.L}) {
        const Real step = std::asinh(std::sqrt((outer-end)/gap))/panels;
        for (unsigned i=0; i<=panels; ++i) {
            const Real t = std::sinh(i*step), v = outer-gap*t*t;
            const Real quad = c0+v*(c1+k4*v);
            const Real factor = 2*(i==0 || i==panels ? 1 : (i%2 ? 4 : 2))*step/3;
            const Real time = factor/std::sqrt(quad);
            integral[0] += time;
            integral[1] += time * v*(2*a*mass-a*a*l*v)/delta(v);
        }
    }
    return integral;
}

Pair IndependentTarget(Real mass, Real spin, Real u, Real s, Real initial_mu, Real final_mu) {
    const auto shape=IndependentShape(mass,spin,u,s);
    const auto half=IndependentPartial(mass,spin,u,s,std::sqrt(shape.amplitude2));
    const auto start=IndependentPartial(mass,spin,u,s,initial_mu);
    const auto stop=IndependentPartial(mass,spin,u,s,final_mu);
    const Real time=12*half[0]+start[0]-stop[0];
    const Real angle=12*half[1]+start[1]-stop[1];
    return {time,angle-shape.drag*time};
}

Pair IndependentLatitudeRoot(Real u, Real s_edge, Real launch, Real initial_mu, Real latitude) {
    constexpr Real mass=1;
    const Real spin=static_cast<Real>(.9);
    const auto residual=[&](Real s) {
        return IndependentRadial(mass,spin,u,s,launch)[0] -
               IndependentTarget(mass,spin,u,s,initial_mu,latitude)[0];
    };
    Real low=s_edge*.99L, high=s_edge*(65.L/64);
    if (!(residual(low)>0 && residual(high)<0)) throw std::runtime_error("latitude root bracket");
    for (int i=0; i<39; ++i) {
        const Real mid=std::midpoint(low,high);
        (residual(mid)>0 ? low : high)=mid;
    }
    const Real root=std::midpoint(low,high);
    const Real azimuth=-IndependentRadial(mass,spin,u,root,launch)[1] -
                       IndependentTarget(mass,spin,u,root,initial_mu,latitude)[1];
    return {root,azimuth};
}

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const auto film=camera.ProjectFilmForObserver(origin[0],origin[1]+22.0,
                                                  sample.pupil_u,sample.pupil_v);
    if (!film||!film->differential) return 40;
    const auto& matrix=film->differential->angular_jacobian;
    const double d=std::fma(matrix[0][0],matrix[1][1],-matrix[0][1]*matrix[1][0]);
    const double sigma=(60*core::constants::math::kPi/180.0)/1080.0;
    const PointDetectorFootprint footprint{
        {0,22}, {{{sigma*matrix[1][1]/d,-sigma*matrix[0][1]/d},
                  {-sigma*matrix[1][0]/d,sigma*matrix[0][0]/d}}}};
    using namespace core::relativity::finite_tail_detail;
    std::cout<<std::hexfloat<<"footprint_matrix "<<footprint.chart_from_standard[0][0]<<' '
              <<footprint.chart_from_standard[0][1]<<' '<<footprint.chart_from_standard[1][0]<<' '
              <<footprint.chart_from_standard[1][1]<<'\n';
    const PointDetectorCell cell{{-0x1.9e78p+1,0x1.2c98p+1},{-0x1.9e74p+1,0x1.2c9cp+1}};
    const FilmVector original{Range(cell.lower[0],cell.upper[0]),Range(cell.lower[1],cell.upper[1])};
    auto box=original;
    const std::array nearest{std::clamp(0.0,box[0].lo,box[0].hi),
                             std::clamp(0.0,box[1].lo,box[1].hi)};
    for (unsigned axis=0; axis<2; ++axis) {
        const Range extent2=Range(16.0)-Square(Range(nearest[1-axis]));
        if (extent2.hi<0.0) return 41;
        const double extent=sqrt(Range(extent2.hi)).hi;
        box[axis]=Range(std::max(box[axis].lo,-extent),std::min(box[axis].hi,extent));
    }
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    const auto chart=evaluate(box);
    if (!chart) return 41;
    const auto [range,potential]=CoverEscapingChart(box,*chart,evaluate);
    if (!range.Finite()||!potential.Finite()) return 42;
    std::cout<<"stationary_radius=["<<range.lo<<','<<range.hi<<"] H=["<<potential.lo<<','
              <<potential.hi<<"]\n";
    const double high = sqrt(Range(-potential.lo)).hi;
    AngularCatalogue::Entry star{Range(0x1.d67f90b9760bp-2,0x1.d67f90b9760bbp-2),
        Range(-0x1.015f94f22ec77p+0,-0x1.015f94f22ec67p+0),{},0};
    const FiniteCandidate candidate{5,&star,true,{}};
    const auto continued=ExtendLatitudeBranch(1.0,.9,range,Range(0.0,high),*chart,candidate);
    if (!continued) return 43;
    const Real inverse_launch=std::midpoint(chart->inverse_start.lo,chart->inverse_start.hi);
    const Real initial=std::midpoint(chart->initial_mu.lo,chart->initial_mu.hi);
    const Real latitude=std::midpoint(star.latitude.lo,star.latitude.hi);
    const auto slope=continued->conditioned_radial_slope;
    unsigned accepted=0;
    constexpr Real h=0x1p-24L;
    for (double point : {range.lo,std::midpoint(range.lo,range.hi),range.hi}) {
        const auto lo=IndependentLatitudeRoot(Real(point)-h,high,inverse_launch,initial,latitude);
        const auto hi=IndependentLatitudeRoot(Real(point)+h,high,inverse_launch,initial,latitude);
        const Real derivative=(hi[1]-lo[1])/(2*h);
        std::cout<<std::defaultfloat<<std::setprecision(17)<<"slope="<<derivative<<" enclosure="
                 <<slope.lo<<':'<<slope.hi<<" root_separations="<<lo[0]<<':'<<hi[0]
                 <<" physical_edge="<<high<<'\n';
        if (slope.lo <= derivative && derivative <= slope.hi) ++accepted;
    }
    std::cout<<"independent_extended_slopes="<<accepted<<"/3\n";
    return accepted==3 ? 0 : 44;
}

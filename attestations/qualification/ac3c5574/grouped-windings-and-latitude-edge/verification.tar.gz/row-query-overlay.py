from pathlib import Path
import sys

root = Path.cwd()
scratch = Path(__file__).resolve().parent
production = scratch/'production-overlay/sirius'
aggregate = (scratch/'aggregate.inc').read_text()
baseline = '--baseline' in sys.argv

def source(name):
    return (root/'src/sirius'/name).read_text()

def write(name, contents):
    dest = production/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(contents)

def patch(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

screen = source('core/kerr_detector/finite_screen.h')
if not baseline:
    screen = patch(screen, 'struct CatalogueScreen {', aggregate + 'struct CatalogueScreen {')
    screen = patch(screen, '    std::vector<FiniteCandidate> candidates;',
                   '    std::vector<FiniteCandidate> candidates;\n    Range grouped_rgb;')
    screen = patch(screen, '    std::optional<Range> finite_scale) {',
                   '    std::optional<Range> finite_scale, Range density_to_rgb, double allowance) {')
    screen = patch(screen, '''    struct ScreenRow {
        const AngularCatalogue::Row* row;''', '''    const auto strip = finite_scale ? std::nullopt
                                    : PolarDerivativeStrip::Prepare(mass, spin, centre, scale, chart);
    struct ScreenRow {
        const AngularCatalogue::Row* row;
        Range latitude;
        std::optional<PolarDerivativeStrip::PolarJet> endpoint;''')
    screen = patch(screen, '''                output.push_back(
                    {&row, std::move(entries), equator, critical_equator, cutoffs[group]});''',
                   '''                const auto endpoint = strip && entries.empty()
                                          ? strip->ToLatitude(latitude) : std::nullopt;
                output.push_back({&row, latitude, endpoint, std::move(entries), equator,
                                  critical_equator, cutoffs[group]});''')
    screen = patch(screen, '    CatalogueScreen result{{}, edge_time, period, initial};',
                   '''    CatalogueScreen result{{}, {}, edge_time, period, initial};
    unsigned grouped_rows = 0;
    unsigned grouped_first = last, grouped_last = 0;''')
    screen = patch(screen, '        const bool near_critical =',
                   '''        const auto grouped_separation = strip && strip->Covers(log_branch)
                                            ? ExpBounds(log_branch) : InvalidRange();
        const bool near_critical =''')
    screen = patch(screen, '''                if (sky.lo > sky.hi) continue;
                const auto visit''',
                   '''                if (sky.lo > sky.hi) continue;
                if (grouped_separation.Finite() && prepared.endpoint) {
                    const Range full_part =
                        approach ? period[0] - prepared.equator[0] : prepared.equator[0];
                    const Range full_target = m_value * period[0] + initial[0] + full_part;
                    if (full_target.Finite() && full_target.lo > edge_time.hi) {
                        // If a row has any matching source, charge one visit for
                        // the group and conservatively include the whole row's weight.
                        if (prepared.row->Query(sky, [](const auto&) { return false; })) continue;
                        const auto density = strip->Density(prepared.latitude, *prepared.endpoint,
                            m, approach, log_branch, grouped_separation, sky);
                        if (density) {
                            const Range contribution =
                                density_to_rgb * prepared.row->weighted_temperature * *density;
                            const Range total = result.grouped_rgb + Range(0.0, contribution.hi);
                            if (contribution.Finite() && contribution.hi >= 0.0 && total.hi <= allowance) {
                                if (remaining == 0 || (cancelled && cancelled())) return {};
                                --remaining;
                                result.grouped_rgb = total;
                                ++grouped_rows;
                                grouped_first = std::min(grouped_first, m);
                                grouped_last = m;
                                continue;
                            }
                        }
                    }
                }
                const auto visit''')
    # The empty-query shortcut must distinguish an invalid angular interval from a valid empty one.
    screen = patch(screen, '''                if (grouped_separation.Finite() && prepared.endpoint) {''',
                   '''                if (grouped_separation.Finite() && prepared.endpoint && sky.Finite()) {''')
    screen = patch(screen, '''    return result;
}

inline std::optional<RefinedCandidate> RefineFiniteAzimuth''',
                   '''    std::clog << " rows=" << grouped_rows << " group_windings=" << grouped_first
              << ':' << grouped_last << " aggregate_rgb=" << result.grouped_rgb.hi << std::endl;
    return result;
}

inline std::optional<RefinedCandidate> RefineFiniteAzimuth''')
    screen = patch(screen, '#include <functional>', '#include <functional>\n#include <iostream>')
write('core/kerr_detector/finite_screen.h', screen)

kerr = source('render/session/kerr_point_detector.cpp')
kerr = patch(kerr, '#include <mutex>', '#include <mutex>\n#include <iostream>')
kerr = patch(kerr, '''    const auto screen = ScreenFiniteWindings''',
             '''    std::clog << "cell [[";
    for (const auto& cell : cells)
        std::clog << std::hexfloat << cell.lower[0] << ',' << cell.lower[1] << ';'
                  << cell.upper[0] << ',' << cell.upper[1] << ';';
    const auto before_screen = remaining;
    std::clog << "]] H=" << minimum_potential << ':' << maximum_potential
              << " radius=" << radius.lo << ':' << radius.hi << std::defaultfloat
              << " finite=" << bool(finite_cutoff) << " stages=" << cutoffs[0] << ','
              << cutoffs[1] << ',' << cutoffs[2] << " avail=" << remaining << std::endl;
    const auto screen = ScreenFiniteWindings''')
if not baseline:
    kerr = patch(kerr, '''                                                           : std::nullopt);''',
                 '''                                                           : std::nullopt,
                                             *colour / determinant,
                                             PointDetectorPolicy{}.absolute_rgb_error * .01);''')
kerr = patch(kerr, '''    if (!screen) return {};
    for (const auto& candidate''',
             '''    std::clog << " screen=" << bool(screen) << " screen_visits=" << before_screen - remaining
              << " candidates=" << (screen ? screen->candidates.size() : 0) << std::endl;
    if (!screen) return {};
''' + ('' if baseline else '    upper_bound = upper_bound + screen->grouped_rgb;\n') +
             '''    for (const auto& candidate''')
kerr = patch(kerr, '''    return std::array{upper_bound.hi, upper_bound.hi, upper_bound.hi};''',
             '''    std::clog << " result=" << upper_bound.hi << " remaining=" << remaining << std::endl;
    return std::array{upper_bound.hi, upper_bound.hi, upper_bound.hi};''')
write('render/session/kerr_point_detector.cpp', kerr)

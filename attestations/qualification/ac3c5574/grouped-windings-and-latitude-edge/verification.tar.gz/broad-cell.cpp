#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "sirius/render/session/kerr_point_detector.cpp"

#include <iomanip>
#include <iostream>
#include <map>

using namespace sirius;
using namespace sirius::render;

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const auto film=camera.ProjectFilmForObserver(origin[0],origin[1]+22.0,
                                                  sample.pupil_u,sample.pupil_v);
    if (!film||!film->differential) return 40;
    const auto& matrix=film->differential->angular_jacobian;
    const double d=std::fma(matrix[0][0],matrix[1][1],-matrix[0][1]*matrix[1][0]);
    const double sigma=(60*core::constants::math::kPi/180.0)/1080.0;
    const PointDetectorFootprint footprint{
        {0,22}, {{{sigma*matrix[1][1]/d,-sigma*matrix[0][1]/d},
                  {-sigma*matrix[1][0]/d,sigma*matrix[0][0]/d}}}};
    using namespace core::relativity::finite_tail_detail;
    std::cout<<std::hexfloat<<"footprint_matrix "<<footprint.chart_from_standard[0][0]<<' '
              <<footprint.chart_from_standard[0][1]<<' '<<footprint.chart_from_standard[1][0]<<' '
              <<footprint.chart_from_standard[1][1]<<'\n';
    const PointDetectorCell cell{{-0x1.9e9p+1,0x1.2c78p+1},{-0x1.9e88p+1,0x1.2c8p+1}};
    const FilmVector original{Range(cell.lower[0],cell.upper[0]),Range(cell.lower[1],cell.upper[1])};
    auto box=original;
    const std::array nearest{std::clamp(0.0,box[0].lo,box[0].hi),
                             std::clamp(0.0,box[1].lo,box[1].hi)};
    for (unsigned axis=0; axis<2; ++axis) {
        const Range extent2=Range(16.0)-Square(Range(nearest[1-axis]));
        if (extent2.hi<0.0) return 41;
        const double extent=sqrt(Range(extent2.hi)).hi;
        box[axis]=Range(std::max(box[axis].lo,-extent),std::min(box[axis].hi,extent));
    }
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    const auto chart=evaluate(box);
    if (!chart) return 41;
    const auto [range,potential]=CoverEscapingChart(box,*chart,evaluate);
    if (!range.Finite()||!potential.Finite()) return 42;
    std::cout<<"stationary_radius=["<<range.lo<<','<<range.hi<<"] H=["<<potential.lo<<','
              <<potential.hi<<"]\n";
    const core::PointStarfieldConfig stars;
    const core::StarfieldSpatialIndex catalogue(core::StarfieldGenerator(
        core::ExpandPointStarfieldConfig(stars)).GenerateCatalogue());
    const auto indexed=PrepareKerrDetectorCatalogue(catalogue);
    constexpr std::size_t budget=131072;
    auto remaining=budget;
    const auto bound=BoundKerrDetectorCells(*indexed,stars.brightness_scale,config,*launch,
                                            origin,footprint,std::span(&cell,1),{},remaining);
    std::cout<<std::defaultfloat<<std::setprecision(17)<<"certificate="<<bool(bound)
              <<" candidate_visits="<<budget-remaining;
    if (bound) std::cout<<" rgb="<<(*bound)[0]<<','<<(*bound)[1]<<','<<(*bound)[2];
    std::cout<<'\n';
}

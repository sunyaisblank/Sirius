#include "sirius/backend/cpu/geodesic_tracer.h"
#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/core/camera_sampling.h"

#include "sirius/render/session/kerr_point_detector.cpp"

#include <iomanip>
#include <iostream>
#include <map>

using namespace sirius;
using namespace sirius::render;

using Real = long double;
using Pair = std::array<Real, 2>;

struct PolarReference {
    Real angular, amplitude2, omega2, drag;
};

PolarReference IndependentShape(Real mass, Real spin, Real centre, Real separation) {
    const Real u = centre, a = spin;
    const auto delta = [&](Real x) { return 1 - 2 * mass * x + a * a * x * x; };
    const Real b = delta(u) * u * u;
    const Real db = (2 * a * a * u - 2 * mass) * u * u + 2 * delta(u) * u;
    Real angular = 3, carter = 25;
    for (int i = 0; i < 16; ++i) {
        const Real k = a * a - a * angular;
        const Real p = 1 + k * u * u, dp = 2 * k * u;
        const Real residual = p * p - b * carter + separation * separation;
        const Real tangent = 2 * p * dp - db * carter;
        const Real d_l = -2 * a * u * u * p, d_c = -b;
        const Real d_dl = -2 * a * (u * u * dp + 2 * u * p), d_dc = -db;
        const Real det = d_l * d_dc - d_c * d_dl;
        angular -= (d_dc * residual - d_c * tangent) / det;
        carter -= (d_l * tangent - d_dl * residual) / det;
    }
    const Real eta = carter - (angular - a) * (angular - a);
    const Real k = eta + angular * angular - a * a;
    const Real omega2 = (k + std::sqrt(k * k + 4 * a * a * eta)) / 2;
    Real low = 0, high = u;
    for (int i = 0; i < 85; ++i) {
        const Real q = std::midpoint(low, high);
        const Real p = 1 + (a * a - a * angular) * q * q;
        if (p * p - delta(q) * q * q * carter > 0)
            low = q;
        else
            high = q;
    }
    const Real turn = std::midpoint(low, high);
    return {angular, eta / omega2, omega2,
            turn * (2 * a * mass - a * a * angular * turn) / delta(turn)};
}

Pair IndependentPartial(Real mass, Real spin, Real centre, Real separation, Real latitude) {
    const auto shape = IndependentShape(mass, spin, centre, separation);
    constexpr int panels = 16384;
    const Real end = std::asin(latitude / std::sqrt(shape.amplitude2));
    const Real step = end / panels;
    Pair integral{};
    for (int i = 0; i <= panels; ++i) {
        const Real sin = std::sin(i * step);
        const Real mu2 = shape.amplitude2 * sin * sin;
        const Real time = 1 / std::sqrt(shape.omega2 + spin * spin * mu2);
        const Real factor = (i == 0 || i == panels ? 1 : (i % 2 ? 4 : 2)) * step / 3;
        integral[0] += factor * time;
        integral[1] += factor * time * (shape.angular / (1 - mu2) + shape.drag);
    }
    return integral;
}

int main() {
    core::CameraConfig config;
    config.r = 30;
    config.theta = 80 * core::constants::math::kPi / 180.0;
    config.fov = 60;
    config.width = 1920;
    config.height = 1080;
    config.beta_x = .1;
    config.beta_y = .02;
    config.beta_z = -.01;
    config.focal_length = 50;
    config.aperture = 2.8f;
    config.focus_distance = 30;
    core::ThinLensCamera camera(config);
    core::KerrSchildFamily metric(core::KerrSchildParams::Kerr(1, .9));
    core::CameraSample sample;
    bool first = true;
    core::ForEachCameraSample(4, [&](auto next) {
        if (first) sample = next;
        first = false;
    });
    const DetectorCoordinate origin{928 + double(sample.image_u), 608 + double(sample.image_v)};
    const auto pupil =
        camera.ProjectFilmForObserver(origin[0], origin[1], sample.pupil_u, sample.pupil_v);
    if (!pupil) return 20;
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 21;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 22;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 23;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 24;
    const auto compute = backend::RetainedCompute::Create(**device, 1);
    if (!compute) return 25;
    backend::RetainedTraceExecutor executor(**compute);
    backend::TracerConfig trace;
    trace.enable_disk = false;
    trace.enable_ray_bundles = true;
    trace.bundle_point_source = true;
    backend::GeodesicTracer tracer(&metric, trace);
    tracer.SetStepExecutor(&executor);
    const auto launch = tracer.PrepareDetectorPupil(pupil->ray);
    if (!launch || executor.Error()) return 26;
    const auto film=camera.ProjectFilmForObserver(origin[0],origin[1]+22.0,
                                                  sample.pupil_u,sample.pupil_v);
    if (!film||!film->differential) return 40;
    const auto& matrix=film->differential->angular_jacobian;
    const double d=std::fma(matrix[0][0],matrix[1][1],-matrix[0][1]*matrix[1][0]);
    const double sigma=(60*core::constants::math::kPi/180.0)/1080.0;
    const PointDetectorFootprint footprint{
        {0,22}, {{{sigma*matrix[1][1]/d,-sigma*matrix[0][1]/d},
                  {-sigma*matrix[1][0]/d,sigma*matrix[0][0]/d}}}};
    using namespace core::relativity::finite_tail_detail;
    std::cout<<std::hexfloat<<"footprint_matrix "<<footprint.chart_from_standard[0][0]<<' '
              <<footprint.chart_from_standard[0][1]<<' '<<footprint.chart_from_standard[1][0]<<' '
              <<footprint.chart_from_standard[1][1]<<'\n';
    const PointDetectorCell cell{{-0x1.9e9p+1,0x1.2c78p+1},{-0x1.9e88p+1,0x1.2c8p+1}};
    const FilmVector original{Range(cell.lower[0],cell.upper[0]),Range(cell.lower[1],cell.upper[1])};
    auto box=original;
    const std::array nearest{std::clamp(0.0,box[0].lo,box[0].hi),
                             std::clamp(0.0,box[1].lo,box[1].hi)};
    for (unsigned axis=0; axis<2; ++axis) {
        const Range extent2=Range(16.0)-Square(Range(nearest[1-axis]));
        if (extent2.hi<0.0) return 41;
        const double extent=sqrt(Range(extent2.hi)).hi;
        box[axis]=Range(std::max(box[axis].lo,-extent),std::min(box[axis].hi,extent));
    }
    const auto evaluate = [&](const FilmVector& region) {
        return EvaluateFilmChart(config, metric.GetParams(), *launch, origin, footprint, region);
    };
    const auto chart=evaluate(box);
    if (!chart) return 41;
    const auto [range,potential]=CoverEscapingChart(box,*chart,evaluate);
    if (!range.Finite()||!potential.Finite()) return 42;
    std::cout<<"stationary_radius=["<<range.lo<<','<<range.hi<<"] H=["<<potential.lo<<','
              <<potential.hi<<"]\n";
    const double high = sqrt(Range(-potential.lo)).hi;
    const auto strip = PolarDerivativeStrip::Prepare(1.0, .9, range, Range(0.0,high), *chart);
    if (!strip) return 43;
    const Real mass = 1.0, spin = static_cast<Real>(.9), u = std::midpoint(range.lo,range.hi);
    const Real amp = std::sqrt(IndependentShape(mass,spin,u,high/2).amplitude2);
    unsigned enclosed = 0, points = 0;
    const auto inside = [&](Range bounds, Real value) {
        ++points;
        if (bounds.lo <= value && value <= bounds.hi)
            ++enclosed;
        else
            std::cerr<<std::defaultfloat<<std::setprecision(18)<<"miss "<<bounds.lo<<' '<<value<<' '<<bounds.hi<<'\n';
    };
    for (double frac : {.05,.30,.65,.92,.98}) {
        const Range mu(double(frac * amp - .00005L), double(frac * amp + .00005L));
        const auto partial = strip->ToLatitude(mu);
        if (!partial) return 44;
        for (Real sep : {Real(high)*.2L,Real(high)*.6L,Real(high)*.9L}) {
            for (Real lat : {Real(mu.lo),Real(std::midpoint(mu.lo,mu.hi)),Real(mu.hi)}) {
                const auto val = IndependentPartial(mass, spin, u, sep, lat);
                constexpr Real h = 0x1p-22L;
                const auto low_u = IndependentPartial(mass, spin, u-h, sep, lat);
                const auto high_u = IndependentPartial(mass, spin, u+h, sep, lat);
                const auto low_s = IndependentPartial(mass, spin, u, sep-h, lat);
                const auto high_s = IndependentPartial(mass, spin, u, sep+h, lat);
                for (unsigned j = 0; j < val.size(); ++j) {
                    inside((*partial)[j].value, val[j]);
                    inside((*partial)[j].derivative[0], (high_u[j]-low_u[j])/(2*h));
                    inside((*partial)[j].derivative[1], (high_s[j]-low_s[j])/(2*h));
                }
            }
        }
    }
    std::cout << std::defaultfloat << "independent_polar_enclosures="<<enclosed<<'/'<<points<<'\n';
    if (points != 270 || enclosed != points) return 45;
}

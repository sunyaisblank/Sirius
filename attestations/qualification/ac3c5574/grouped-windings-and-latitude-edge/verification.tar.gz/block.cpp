#include "sirius/backend/device.h"
#include "sirius/backend/retained_trace_executor.h"
#include "sirius/render/session/render_session.h"

#include <iostream>

using namespace sirius;

int main() {
    const auto inventory = backend::EnumerateVulkanDevices();
    if (!inventory) return 1;
    const auto index = backend::ResolveVulkanDeviceIndex(*inventory);
    if (!index || *index >= inventory->size()) return 2;
    const auto& info = (*inventory)[*index];
    if (info.vendor_id != 0x1002 || info.name.find("780M") == std::string::npos) return 3;
    auto device = backend::CreateVulkanDevice(*index);
    if (!device) return 4;
    const auto compute = backend::RetainedCompute::Create(**device, 128);
    if (!compute) return 5;
    backend::RetainedTraceExecutor executor(
        **compute, {}, 1000.0, 64, backend::RetainedUsesPortableArithmetic(info)
             ? backend::RetainedTraceExecutor::SphericalEscape::Disabled
             : backend::RetainedTraceExecutor::SphericalEscape::Certified);
    render::RenderSession session(executor, 64, 32);
    render::SessionConfig config;
    config.width = 1920;
    config.height = 1080;
    config.samples_per_pixel = 4;
    config.backend = render::RenderBackend::Vulkan;
    config.write_output = false;
    config.metric_id = core::MetricId::Kerr;
    config.black_hole_spin = .9;
    config.observer_distance = 30.0;
    config.observer_inclination = 80 * core::constants::math::kPi / 180.0;
    config.camera_fov = 60;
    config.enable_disk = false;
    config.ray_bundles = true;
    config.point_starfield = true;
    config.camera_beta_forward = .1;
    config.camera_beta_up = .02;
    config.camera_beta_right = -.01;
    config.lens_type = core::LensType::ThinLens;
    config.camera_focal_length = 50;
    config.camera_aperture = 2.8f;
    config.camera_focus_distance = 30;
    const auto configured = session.Configure(config);
    if (!configured) {
        std::cerr << configured.error().Description() << '\n';
        return 6;
    }
    const auto initialised = session.Initialise();
    if (!initialised) {
        std::cerr << initialised.error().Description() << '\n';
        return 7;
    }
    auto result = session.ShadeBlock(928, 608, 32, 32, session.tracer_.get(), session.pixel_block_);
    if (!result) {
        std::cerr << result.error().Description() << '\n';
        return 8;
    }
    std::cout << "canonical block completed\n";
}

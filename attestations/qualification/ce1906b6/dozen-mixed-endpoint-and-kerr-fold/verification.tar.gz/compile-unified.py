import hashlib
import importlib.util
from pathlib import Path
import re
import subprocess


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


scratch = Path(__file__).resolve().parent
root = scratch.parents[1]
kernels = root / 'src/sirius/kernels'
builder = load_module('retained_builder', root / 'scripts/build-retained-kernels.py')
tables = load_module('retained_tables', kernels / 'retained_program.py')
ordinary = tables.build_endpoint_program(parallel=True)
spherical = tables.build_schwarzschild_endpoint_program(parallel=True)

def word_count(table):
    return 3 + sum(len(table[field]) for field in ('outputs', 'operations', 'layer_offsets'))

frames = (word_count(ordinary), word_count(spherical), len(spherical['layer_offsets']) - 1,
          spherical['prefix_instructions'])
leaf = scratch / 'retained_endpoint.slang'
for dependency in kernels.iterdir():
    if dependency.name != leaf.name and dependency.is_file() and not (scratch / dependency.name).exists():
        (scratch / dependency.name).symlink_to(dependency)
source = (kernels / leaf.name).read_text()
native = source.rindex('[shader("compute")]')
start = source.index('#ifndef SIRIUS_RETAINED_CURVED_ENDPOINT', native)
flat = source.index('    if (RTExact', start)
flat_setup = source.index('        for (uint i = 0; i < 4;', flat)
flat_project = source.index('        uint selected;', flat_setup)
flat_publish = source.index('        for (uint i = 0; i < 40;', flat_project)
flat_end = source.index('    }\n#endif', flat_publish)
curved = source.index('#ifdef SIRIUS_RETAINED_CURVED_ENDPOINT', flat_end)
curved_select = source.index('    if (!SelectEndpointProgram', curved)
curved_publish = source.index('            for (uint i = 0; i < 4;', curved_select)
curved_end = source.index('        }\n        if (!EvaluateProgram', curved_publish)

flat_test = source[flat:flat_setup]
flat_test = flat_test[:flat_test.index(' {\n')].replace('if (', 'const bool flat = ', 1).rstrip()[:-1] + ';'
flat_test = flat_test.replace('\n        RTExact', '\n                      RTExact')
flat_setup_code = source[flat_setup:flat_project].replace(
    '                if (lane == 0)\n', '').replace(
    '                    WriteStored', '                WriteStored').replace(
    '            if (lane == 0) WriteStored', '            WriteStored')
flat_publication_code = source[flat_publish:flat_end].replace('temporal', 'root').replace(
    'if (lane == 0) ', '').replace('RetainedTriple phase', 'RetainedTriple projected').replace(
    'RTNegate(phase) : phase', 'RTNegate(projected) : projected').replace(
    'phase = RTNegate(', 'projected = RTNegate(').replace('phase.valid', 'projected.valid').replace(
    'i * 5, phase)', 'i * 5, projected)')
new = f'''{flat_test}
    if (flat && lane != 0) return;
    if (!flat && !SelectEndpointProgram(rowBase, programBase, count, registers, layers, prefix))
        return;
    uint component = 4;
    RetainedTriple root;
    // Keep one native projection and interpreter call site. Curved
    // groups retain their original join, while flat rows stay with lane zero.
    [loop] for (uint phase = 0; phase < 3; ++phase) {{
        if (phase == 1) {{
            if (!Project(rowBase, component, root) || (flat && component != 0)) return;
            if (flat) {{
{''.join('        ' + line for line in flat_publication_code.splitlines(keepends=True)).rstrip()}
            }}
{source[curved_publish:curved_end].rstrip()}
        }} else if (flat) {{
{''.join('    ' + line for line in flat_setup_code.splitlines(keepends=True)).rstrip()}
        }} else if (!EvaluateProgram(row, rowBase, programBase, count, registers,
                                    phase == 0 ? 20 : 100, lane, layers, prefix)) return;
    }}
'''
finish = source.index('#endif\n    if (lane == 0) outputs[rowBase] = 1;', curved_end) + len('#endif\n')
leaf.write_text(source[:start] + new + source[finish:])
for tag, shader in [('stock', kernels / leaf.name), ('unified', leaf)]:
    target = scratch / f'{tag}.spv'
    builder.compile_shader(shader, target, '/opt/slang/bin/slangc', '/usr/bin/spirv-as',
                           '/usr/bin/spirv-dis', '/usr/bin/spirv-val', ordinary['registers'], 5,
                           len(ordinary['layer_offsets']) - 1, ordinary['prefix_instructions'],
                           endpoint_specialized=frames)
    data = target.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assembly = subprocess.check_output(['/usr/bin/spirv-dis', str(target)], text=True)
    calls = re.findall(r'OpFunctionCall\s+%\S+\s+%(EvaluateProgram|Project)\b', assembly)
    print(tag, len(data), digest, calls)
    if tag == 'stock':
        assert digest == 'd7c01a3d67f7c4617643aa36c2369ffc190f2e36e2ec9fd1d1aeb0a346a45e7c'
    else:
        assert calls.count('EvaluateProgram') == calls.count('Project') == 1

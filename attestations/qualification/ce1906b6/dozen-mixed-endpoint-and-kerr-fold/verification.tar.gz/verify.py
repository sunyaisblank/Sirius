from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import re
import struct


scratch = Path(__file__).resolve().parent
root = scratch.parents[1]
stride = (769 + 5 * 612) * 4

def blocks(name):
    data = (scratch / (name + '.readback')).read_bytes()
    print(f'{name}: {len(data)} bytes sha256={hashlib.sha256(data).hexdigest()}')
    offset = 0
    frames = []
    while offset < len(data):
        size, = struct.unpack_from('<Q', data, offset)
        offset += 8
        assert size > 0 and size % stride == 0 and offset + size <= len(data)
        frames.append(data[offset:offset + size])
        offset += size
    return frames

readback = (scratch / 'unified.readback').read_bytes()
assert hashlib.sha256(readback).hexdigest() == '5cc8d1f16072b3a4f572d0b78cf71f75429b31146798bcd5973e7ef468331b28'
stock = blocks('unified')
assert [len(block) // stride for block in stock] == [1, 2, 2, 2, 1, 2, 2, 2, 1, 20]
print(f'{len(stock)} complete dispatch readbacks, {sum(map(len, stock)) // stride} rows byte-exact')
log = (scratch / 'unified.log').read_text()
trace = re.search(r'^trace steps=2 accepted=2 rejected=0 peak_rss_kib=(\d+)$', log, re.M)
mixed = re.search(r'^finite_endpoints=17 intentional_refusals=3 peak_rss_kib=(\d+)$', log, re.M)
assert trace and mixed and max(int(trace[1]), int(mixed[1])) < 2 * 1024 * 1024
assert len(re.findall(r'^load stage=', log, re.M)) == 7
assert len(re.findall(r'^dispatch stage=endpoint ', log, re.M)) == 1
assert log.count('Exit status: 0') == 1
print(f'trace peak={trace[1]} KiB and mixed peak={mixed[1]} KiB; one Endpoint pipeline')
cases = json.loads((root / 'tests/support/retained_transport/endpoint_reference.json').read_text())['cases']
expected_fields = 0
with localcontext() as context:
    context.prec = 200
    for index, case in enumerate(cases):
        row_start = index * stride
        assert struct.unpack_from('<II', stock[-1], row_start) == (1, case['component'])
        for field, oracle_text in enumerate(case['reference']):
            start = row_start + (104 + 5 * field) * 4
            hi, lo, tail, radius, valid = struct.unpack_from('<ffffI', stock[-1], start)
            assert valid == 1
            ref = Decimal(oracle_text)
            difference = abs(sum(map(Decimal.from_float, (hi, lo, tail))) - ref)
            scale = 1 + abs(ref)
            assert difference <= Decimal.from_float(radius) + Decimal('1e-29') * scale, (index, field)
            assert difference <= Decimal('1e-11') * scale, (index, field)
            expected_fields += 1
    for index in range(len(cases), len(cases) + 3):
        assert struct.unpack_from('<I', stock[-1], index * stride)[0] == 0
print(f'{expected_fields} independent 105-digit endpoint projections meet original tolerances; three refusals')


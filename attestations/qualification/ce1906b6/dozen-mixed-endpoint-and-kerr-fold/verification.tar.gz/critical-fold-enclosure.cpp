#include "sirius/core/kerr_detector/finite_screen.h"

#include <iostream>

namespace {
using namespace sirius::core::relativity::finite_tail_detail;
using Jet = TaylorSeries<2>;

Jet Sine(const Jet& angle) {
    const auto& [a, d1, d2] = angle.coefficient;
    const Range s = SineLobe(a);
    const Range c(CosPoint(std::min(a.hi, kPiBounds.hi)).lo,
                  CosPoint(std::max(a.lo, 0.0)).hi);
    Jet result;
    result.coefficient = {s, c * d1, c * d2 - Range(.5) * s * Square(d1)};
    return result;
}

Jet Asin(const Jet& value) {
    const auto& [x, d1, d2] = value.coefficient;
    const Range c = sqrt(Range(1.0) - Square(x));
    Jet result;
    result.coefficient = {AsinBounds(x), d1 / c,
                          d2 / c + Range(.5) * x * Square(d1) / (c * Square(c))};
    return result;
}

struct SphericalShape {
    Jet angular, omega2, amplitude, carter;
};

SphericalShape Shape(const Jet& inverse) {
    const Jet a(.9), a2 = a * a, one(1.0), r = one / inverse, r2 = r * r;
    const Jet angular = (r2 * (Jet(3.0) - r) - a2 * (r + one)) / (a * (r - one));
    const Jet eta = r2 * r *
                    (Jet(4.0) * a2 - r * (r - Jet(3.0)) * (r - Jet(3.0))) /
                    (a2 * (r - one) * (r - one));
    const Jet b = a2 - eta - angular * angular;
    const Jet omega2 = Jet(.5) * (sqrt(b * b + Jet(4.0) * a2 * eta) - b);
    const Jet d = angular - a;
    return {angular, omega2, sqrt(eta / omega2), eta + d * d};
}

template <class Function>
Jet UnitIntegral(const Function& f) {
    // Integrate each Taylor coefficient through its interval range over the
    // panel, using a normalized fixed interval before taking derivatives.
    constexpr unsigned panels = 2048;
    Jet sum;
    for (unsigned i = 0; i < panels; ++i)
        sum = sum + f(Jet(Range(double(i) / panels, double(i + 1) / panels)));
    return sum / Jet(panels);
}

void Print(const char* name, Range value) {
    std::cout << name << " [" << value.lo << ", " << value.hi << "]\n";
}

}  // namespace

int main() {
    if (!RoundingEnvironment()) return 1;
    std::cout << std::hexfloat;
    const Range phase(0.0, 0x1p-10);
    const Range inverse(.43759975, .4376005);
    const Range source_mu(0x1.f4f48bf6938b9p-1, 0x1.f4f48bf6938c5p-1);
    const Range launch_mu(0x1.67f25c4fe005p-3, 0x1.67f25c4fe0117p-3);
    const Range inverse_start(0x1.111112f155084p-5, 0x1.111112f1550a2p-5);
    const Range sine = SineLobe(phase);
    const Range cosine(CosPoint(phase.hi).lo, 1.0);
    const auto amp_u = Shape(Jet::Variable(inverse.lo, inverse.hi)).amplitude.coefficient;
    const Range target = source_mu / cosine;
    const Range left = Shape(Jet(inverse.lo)).amplitude.coefficient[0];
    const Range right = Shape(Jet(inverse.hi)).amplitude.coefficient[0];
    if (!(amp_u[1].hi < 0.0 && right.hi < target.lo && target.hi < left.lo)) return 2;
    const Range minus_derivative = Range(0.0) - amp_u[1];
    const Range u1 = (Range(0.0) - amp_u[0] * sine) / (cosine * minus_derivative);
    const Range u2 = (Range(0.0) - amp_u[0]) / (Range(2.0) * minus_derivative) + sine * u1 / cosine +
                     amp_u[2] * Square(u1) / minus_derivative;
    Jet u;
    u.coefficient = {inverse, u1, u2};
    const auto shape = Shape(u);
    const Jet a(.9), a2 = a * a, d1 = Jet(2.0) * a, d2 = Jet(0.0) - a2 * shape.angular;
    const auto delta = [&](const Jet& x) { return Jet(1.0) + x * (a2 * x - Jet(2.0)); };
    const Jet drag = u * (d1 + u * d2) / delta(u);
    const Jet amplitude2 = shape.amplitude * shape.amplitude;
    const auto polar_density = [&](const Jet& angle) {
        const Jet s = Sine(angle), s2 = s * s;
        const Jet time = Jet(1.0) / sqrt(shape.omega2 + a2 * amplitude2 * s2);
        return time * (shape.angular / (Jet(1.0) - amplitude2 * s2) + drag);
    };
    const auto partial = [&](const Jet& end) {
        return end * UnitIntegral([&](const Jet& t) { return polar_density(t * end); });
    };
    const Jet half_pi(kPiBounds * Range(.5));
    Jet final;
    final.coefficient = {half_pi.coefficient[0] + phase, Range(1.0), Range(0.0)};
    const Jet fixed_winding = partial(Jet(kPiBounds));
    const Jet source_endpoints = partial(Asin(Jet(launch_mu) / shape.amplitude)) + partial(final);
    const Jet z = a2 - a * shape.angular;
    const Jet c2 = z * z - a2 * shape.carter;
    const Jet c1 = Jet(2.0) * (shape.carter + u * c2);
    const Jet c0 = Jet(1.0) / (u * u);
    const auto radial = [&](const Jet& start) {
        return (u - start) * UnitIntegral([&](const Jet& t) {
            const Jet x = start + t * (u - start), sum = u + x;
            const Jet g = sqrt(c0 + x * (c1 + x * c2));
            return (drag * (a2 * sum - Jet(2.0)) - d1 - d2 * sum) / (g * delta(x));
        });
    };
    const Range periodic_curvature = Range(-2.0) * fixed_winding.coefficient[2];
    const Range remainder_curvature = Range(-2.0) *
        (source_endpoints + radial(Jet(inverse_start)) + radial(Jet(0.0))).coefficient[2];
    const Range start_slope = Range(0.0) - polar_density(half_pi).coefficient[0];
    Print("periodic curvature", periodic_curvature);
    Print("remaining curvature", remainder_curvature);
    Print("zero-phase slope", start_slope);
    constexpr int lower_winding = 1025;
    const Range curvature = Range(lower_winding) * periodic_curvature + remainder_curvature;
    const Range right_slope = start_slope + Range(phase.hi) * curvature;
    Print("curvature at first winding", curvature);
    Print("right-edge slope at first winding", right_slope);
    if (!(periodic_curvature.lo > 0 && curvature.lo > 0 &&
          start_slope.hi < 0 && right_slope.lo > 0))
        return 3;
    const Range fold = (Range(0.0) - start_slope) /
                       (Range(2049.0) * periodic_curvature + remainder_curvature);
    Print("fold phase at winding 2049", fold);
    return !fold.Finite() || !(fold.lo > 0.0 && fold.hi < 0x1p-11) ? 4 : 0;
}

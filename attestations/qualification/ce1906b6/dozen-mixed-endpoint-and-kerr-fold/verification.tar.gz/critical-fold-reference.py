"""Independent spherical-limit reduction for the archived Kerr polar fold."""
import gzip
from pathlib import Path
import re

import mpmath as mp


source = Path('attestations/qualification/b4f9c01a/kerr-tail-stationary-longitude/fold.log.gz')
observed = gzip.decompress(source.read_bytes()).decode()
pupil = next(line for line in observed.splitlines() if line.startswith('pupil '))
branch = next(line for line in observed.splitlines() if line.startswith('signed_branch '))
slopes = [line for line in observed.splitlines() if line.startswith('slope_endpoint ')]

def binary64(text):
    return mp.mpf(float.fromhex(text))

def interval(line, label):
    low, high = re.search(rf'\b{label}=\[([^,]+),([^\]]+)\]', line).groups()
    return binary64(low), binary64(high)

def center(pair):
    return (pair[0] + pair[1]) / 2

def evaluate(winding, precision):
    with mp.workdps(precision):
        spin = mp.mpf(.9)
        spin2 = spin**2
        inverse_start = center(interval(pupil, 'start'))
        launch_mu = center(interval(pupil, 'mu'))
        fixed_azimuth = center(interval(pupil, 'phi'))
        source_mu = center((binary64('0x1.f4f48bf6938b9p-1'), binary64('0x1.f4f48bf6938c5p-1')))
        source_phi = center((binary64('-0x1.1dcd0ee4d9734p+1'), binary64('-0x1.1dcd0ee4d972dp+1')))

        def spherical_constants(r):
            # Solve R=R'=0 in the ordinary Boyer-Lindquist radius.
            angular = (r**2 * (r - 3) + spin2 * (r + 1)) / (spin * (1 - r))
            eta = r**3 * (4 * spin2 - r * (r - 3)**2) / (spin2 * (r - 1)**2)
            b = spin2 - eta - angular**2
            omega2 = (mp.sqrt(b*b + 4*spin2*eta) - b) / 2
            return angular, eta, omega2

        def longitude_at(phase, with_time=False):
            def latitude(r):
                _, eta, omega2 = spherical_constants(r)
                return mp.sqrt(eta / omega2) * mp.cos(phase) - source_mu

            r = mp.findroot(latitude, (mp.mpf('2.284'), mp.mpf('2.287')))
            u = 1 / r
            angular, eta, omega2 = spherical_constants(r)
            amp2 = eta / omega2
            parameter = -spin2 * amp2 / omega2
            initial = mp.asin(launch_mu / mp.sqrt(amp2))
            final = mp.pi / 2 + phase
            factor = 1 / mp.sqrt(omega2)
            target_time = factor * (2*winding*mp.ellipk(parameter) +
                                    mp.ellipf(initial, parameter) + mp.ellipf(final, parameter))
            polar_phi = factor * angular * (2*winding*mp.ellippi(amp2, parameter) +
                                            mp.ellippi(amp2, initial, parameter) +
                                            mp.ellippi(amp2, final, parameter))

            carter = eta + (angular - spin)**2
            a2 = (spin2 - spin * angular)**2 - spin2 * carter
            a1, a0 = 2 * carter + 2 * u * a2, r**2
            drag1, drag2 = 2 * spin, -spin2 * angular
            def delta(x):
                return 1 + x * (spin2 * x - 2)
            drag_turn = u * (drag1 + drag2*u) / delta(u)
            def speed(x):
                return mp.sqrt(a0 + x*(a1 + a2*x))
            leading = 1 / speed(u)

            def drag_residual(x):
                return (drag_turn * (spin2 * (x+u) - 2) - drag1 - drag2*(x+u)) / (speed(x)*delta(x))
            radial_phi = sum(mp.quad(drag_residual, [start, u]) for start in (0, inverse_start))
            longitude = fixed_azimuth - (polar_phi + drag_turn*target_time + radial_phi)
            if not with_time:
                return longitude

            def time_residual(x):
                g, gt = speed(x), speed(u)
                return (a1 + a2*(x+u)) / (g*gt*(g+gt))
            gap_over_s = 2 * leading
            residual = sum(2*leading*(mp.log(2*mp.sqrt(u-start)) - mp.log(gap_over_s)/2) +
                           mp.quad(time_residual, [start, u]) for start in (0, inverse_start))
            return longitude, (residual-target_time)/(2*leading)

        def slope(phase):
            return mp.diff(longitude_at, phase)
        phase = mp.findroot(slope, (mp.mpf(0), mp.mpf(1)/1024))
        longitude, log_s = longitude_at(phase, True)
        gap = abs(mp.atan2(mp.sin(longitude-source_phi), mp.cos(longitude-source_phi)))
        result = phase, slope(0), slope(mp.mpf(1)/2048), mp.diff(longitude_at, phase, 2), gap, log_s
        if winding == 2049:
            assert 0 < phase < mp.mpf(1)/2048
            for sample, archived in zip(result[1:3], slopes, strict=True):
                lo, hi = interval(archived, 'longitude_slope')
                assert lo < sample < hi, (lo,sample,hi)
            lo, hi = interval(branch, 'log_s')
            assert lo < log_s < hi
        assert result[3] > 0
        print(f'winding={winding} digits={precision} ' +
              ' '.join(f'{key}={mp.nstr(val, 20)}' for key, val in
                       zip(('phase','slope_zero','slope_2^-11','curvature','longitude_gap','log_s'), result)))
        return result

with mp.workdps(90):
    for winding in (1025, 2049, 4097, 8193):
        coarse = evaluate(winding, 42)
        fine = evaluate(winding, 58)
        assert max(abs((a-b)/(1+abs(b))) for a,b in zip(coarse, fine, strict=True)) < mp.mpf('1e-36')
